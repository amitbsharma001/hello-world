# Redaction evidence

Measured by `scripts/eval_redaction.py` against the real
`aegis/services/redaction.sanitize()` over a labeled set. Reproduce with
`make eval-redaction`. This replaces the unmeasured "privacy boundary" claim
(KNOWN_ISSUES #17) with numbers.

## Headline (measured, reproducible)

| Metric | Value |
|---|---|
| Recall on the categories the regex is **designed for** | **100%** (15 cases) |
| Overall recall incl. out-of-scope PII | 80% (20/25) |
| False-positive rate on benign technical text | **0%** (0/12) |

## What it catches well (structured secrets/identifiers)
AWS/GitHub/Slack/Stripe keys, JWTs, API tokens, credit cards, emails, IPv4/IPv6,
URLs, UUIDs, unix/windows home paths, and phone numbers (formatted, intl, and
bounded bare-digit). All at 100% recall in the set, 0% false positives.

## The honest boundary — what it CANNOT catch
Regex structurally cannot recognize:
- **Person names** (e.g. "Amit Sharma") — needs NER.
- **Freeform postal addresses**.
- **Passport / license-plate style arbitrary alphanumerics** (no stable shape).

So the layer is **structured-secret scrubbing**, not a complete PII boundary.
If PII *of people* (names, addresses) is in scope, add an NER pass; the regex
layer alone should not be described as a privacy guarantee.

## Bugs found and fixed via this harness (verify-don't-assert)
1. **Hex error codes matched as phones** (e.g. `0x80004005`) — a real false
   positive. Fixed by requiring phone *structure* (separators / `(area)` form).
2. **Regression from that fix**: bare-digit numbers like a toll-free
   `18005551234` stopped matching. Re-measured, then added a **bounded**
   bare-digit fallback (11–15 digits) that catches toll-free numbers without
   matching 10-digit epoch timestamps or ≤8-digit codes. FP stayed at 0%.

Both were caught only because the harness *runs* and re-measures — not from
inspection.

## Caveat on this evidence
The labeled set is small (25 positives, 12
negatives) and hand-built — it demonstrates the boundary and guards against the
specific regressions above; it is **not** a statistically powered benchmark. For
production assurance, expand the set (hundreds of cases per category, real
redacted samples) and track recall/precision over time.
