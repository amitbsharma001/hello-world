# django-aegis

**AI-powered ticket operations sub-app for Django.** Drop it into an existing project, run two commands, and get a Notion-style queue with Gemini-powered description rewriting, action plans, and missing-info detection — even without a Gemini API key (deterministic mock fallback).

```
┌────────────────────────────────────────────────────────────┐
│  pip install -e .                                          │
│  python manage.py migrate aegis                            │
│  python manage.py aegis_demo --analyze                     │
│  python manage.py runserver                                │
│  → open http://127.0.0.1:8000/                             │
└────────────────────────────────────────────────────────────┘
```

51 tests pass. Works without any external API key thanks to the mock Gemini client. Real Gemini kicks in the moment you set `GEMINI_API_KEY`.

---

## What you get

- **Ticket queue** — Notion-style minimal UI, sorted by AI-computed operational priority
- **AI description enhancement** — rewrites bad tickets into structured, actionable ones
- **Action plans** — 3-8 next steps with priorities, effort estimates, success criteria
- **Missing-information detection** — automatic follow-up questions
- **SLA / aging / risk scoring** — composite priority score per ticket
- **Connectors** — Jira (real), CSV upload, REST API ingestion, easy to add more
- **REST API** — full DRF endpoints with action routes (`/api/tickets/<id>/analyze/`)
- **HTMX-driven UI** — single deployable, no SPA, no API drift
- **Admin integration** — full Django admin for everything
- **Celery optional** — synchronous by default, switch to async with one setting

---

## Installation in an existing Django project

### 1. Install

```bash
# from the package directory
pip install -e .

# or from a git ref
pip install git+ssh://git@github.com/you/django-aegis.git
```

### 2. Add to `INSTALLED_APPS`

```python
# your_project/settings.py
INSTALLED_APPS = [
    # ... your apps ...
    "rest_framework",   # required
    "aegis",
]
```

### 3. Add the AEGIS config dict (all keys optional)

```python
import os

AEGIS = {
    # Leave GEMINI_API_KEY empty to use the deterministic mock client.
    "GEMINI_API_KEY": os.environ.get("GEMINI_API_KEY", ""),
    "MOCK_GEMINI":    not bool(os.environ.get("GEMINI_API_KEY")),

    "GEMINI_MODEL_PRO":   "gemini-2.5-pro",
    "GEMINI_MODEL_FLASH": "gemini-2.5-flash",

    "USE_CELERY":            False,    # True in production
    "DEFAULT_SLA_HOURS":     24,
    "TICKET_LIST_PAGE_SIZE": 50,
    "ENABLE_UI":             True,
    "ENABLE_REST_API":       True,

    "CONNECTORS": {
        "jira": {
            "base_url":  os.environ.get("JIRA_BASE_URL", ""),
            "email":     os.environ.get("JIRA_EMAIL", ""),
            "api_token": os.environ.get("JIRA_API_TOKEN", ""),
            "jql":       "updated >= -7d",
        },
    },
}
```

### 4. Mount the URLs wherever you want

```python
# your_project/urls.py
urlpatterns = [
    path("admin/", admin.site.urls),
    # ... your urls ...
    path("ops/", include("aegis.urls")),   # UI at /ops/, API at /ops/api/
]
```

### 5. Migrate

```bash
python manage.py migrate aegis
```

That's it. Open `/ops/` and you're done.

---

## Running the included demo project

If you want to see it working before integrating:

```bash
cd demo_project
python manage.py migrate
python manage.py aegis_demo --count 12 --analyze
python manage.py runserver
```

Open `http://127.0.0.1:8000/` and you'll see 12 realistic tickets, fully analyzed, sorted by AI priority. Click any one for the detail view with enhanced description, action plan, and missing-info checklist.

---

## How the AI layer works

### Mock vs. real

The demo "just works" because of a deterministic mock client that returns schema-valid, content-aware responses. It inspects the ticket title/description for keywords (`outage` → sev1, `api` → `api-gateway`, etc.) and produces plausible analysis without any API call.

```python
# aegis/services/gemini.py
def get_client():
    if conf.MOCK_GEMINI or not conf.GEMINI_API_KEY:
        return MockGeminiClient()        # deterministic, free, offline
    return GeminiClient(conf.GEMINI_API_KEY)
```

To use real Gemini:

```bash
pip install -e ".[gemini]"     # installs google-genai
export GEMINI_API_KEY=your-key
```

The rest is transparent — same call sites, same schemas, same persistence.

### Structured outputs

Every LLM call goes through a pydantic schema and is rejected if it doesn't validate:

```python
# aegis/services/schemas.py
class EnhancedDescription(BaseModel):
    problem_summary: str = Field(..., max_length=600)
    business_impact: str
    technical_analysis: str
    affected_systems: list[str]
    severity_suggestion: Literal["sev1", "sev2", "sev3", "sev4"]
    confidence: float = Field(..., ge=0, le=1)
    # ...
```

Every artifact is persisted with model name, tokens in/out, latency, cost — so you get a per-ticket AI spend dashboard for free via the admin.

---

## Connectors

### Built-in

| Name | What | Status |
|---|---|---|
| `manual` | Create tickets via UI / REST API | ✓ |
| `csv` | Bulk upload via UI or management command | ✓ |
| `jira` | Atlassian Jira Cloud (polling) | ✓ |

### Run a sync

```bash
python manage.py aegis_sync --source jira --analyze
```

The sync respects an incremental cursor (`SyncCursor` model) so subsequent runs only pull updated tickets.

### Adding your own connector

```python
# myproject/connectors/zendesk.py
from aegis.connectors.base import Connector, RawTicket, registry

class ZendeskConnector(Connector):
    name = "zendesk"

    def fetch(self, cursor=None):
        for issue in self._http_get_paginated(...):
            yield RawTicket(
                source="zendesk",
                source_id=issue["id"],
                title=issue["subject"],
                description=issue["description"],
                status=issue["status"],
                # ...
            )

# Register at startup (e.g. in your AppConfig.ready())
registry.register(ZendeskConnector)
```

Then add to `AEGIS["CONNECTORS"]["zendesk"]` and you can `aegis_sync --source zendesk`.

---

## REST API

Mounted under `<your_prefix>/api/`. Defaults to anonymous reads; in your project, restrict via `REST_FRAMEWORK["DEFAULT_PERMISSION_CLASSES"]`.

```
GET    /api/tickets/                 List tickets (paginated)
POST   /api/tickets/                 Create
GET    /api/tickets/<id>/            Retrieve (includes computed score)
PATCH  /api/tickets/<id>/            Update
DELETE /api/tickets/<id>/            Delete
POST   /api/tickets/<id>/enhance/    Run enhancement
POST   /api/tickets/<id>/plan/       Run action plan
POST   /api/tickets/<id>/missing_info/   Run missing-info detection
POST   /api/tickets/<id>/analyze/    Run all three
GET    /api/tickets/<id>/artifacts/  List AI runs for this ticket
```

Example:

```bash
curl -X POST http://localhost:8000/ops/api/tickets/ \
  -H "Content-Type: application/json" \
  -d '{"title":"DB slow","description_raw":"queries timing out","severity":"sev2"}'

curl -X POST http://localhost:8000/ops/api/tickets/<id>/analyze/
```

---

## Production setup

### Celery

Set `AEGIS["USE_CELERY"] = True`. Make sure `aegis.tasks` is autodiscovered (Celery does this by default for all `INSTALLED_APPS`). All HTMX action endpoints and the create flow then enqueue instead of running synchronously.

### Postgres

The models work on SQLite (for demo) and PostgreSQL (for production) with no changes. For scale, add these to your Postgres setup:
- BRIN indexes on `Ticket.opened_at`, `TicketHistory.occurred_at`
- Monthly partitioning on `TicketHistory` (via `pg_partman`)

### Permissions

The default API is open. In production:

```python
REST_FRAMEWORK = {
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.SessionAuthentication",
        # add JWT etc as needed
    ],
}
```

### Cost control

The mock client costs zero. With real Gemini, you can control spend by:
- Setting `MOCK_GEMINI=True` in non-production
- Routing planning/missing-info to flash via `GEMINI_MODEL_PRO = "gemini-2.5-flash"` if cost is more important than depth
- All AI artifacts persist `cost_usd` — query `AIArtifact.objects.aggregate(Sum('cost_usd'))` for spend.

---

## Configuration reference

All keys in `settings.AEGIS` are optional. Defaults shown:

| Key | Default | Purpose |
|---|---|---|
| `GEMINI_API_KEY` | `""` | Real Gemini key. Empty = mock. |
| `MOCK_GEMINI` | `True` | Force mock even with key set (useful for tests). |
| `GEMINI_MODEL_PRO` | `"gemini-2.5-pro"` | Model for enhancement / planning. |
| `GEMINI_MODEL_FLASH` | `"gemini-2.5-flash"` | Model for missing-info. |
| `USE_CELERY` | `False` | Async via Celery. |
| `DEFAULT_SLA_HOURS` | `24` | Used when ticket has no `sla_due_at`. |
| `TICKET_LIST_PAGE_SIZE` | `50` | Queue page rows. |
| `ENABLE_UI` | `True` | Mount the HTML views. |
| `ENABLE_REST_API` | `True` | Mount the REST API. |
| `CONNECTORS` | `{}` | Per-connector config dicts. |
| `REQUEST_TIMEOUT_SECONDS` | `30` | Used by connector HTTP clients. |
| `MAX_RETRIES` | `4` | Gemini retry attempts. |

---

## Testing

```bash
# from package root
PYTHONPATH=.:demo_project pytest aegis/tests/
```

Or use the included `pyproject.toml` config:

```bash
pytest
```

51 tests cover models, services, connectors, views, REST API. All run against the mock Gemini client so they're fast and offline.

---

## Management commands

```bash
python manage.py aegis_demo --count 12 --analyze
python manage.py aegis_demo --clear --count 5

python manage.py aegis_sync --source jira --analyze
```

---

## Repository layout

```
aegis/
├── __init__.py
├── apps.py                       AppConfig
├── conf.py                       Settings facade (single AEGIS dict)
├── models.py                     Ticket, History, AIArtifact, AgentRun, SyncCursor
├── views.py                      UI views + HTMX action endpoints
├── api.py                        DRF serializers + viewsets
├── urls.py
├── admin.py
├── forms.py
├── signals.py
├── tasks.py                      Celery tasks (optional)
├── services/
│   ├── gemini.py                 Real + Mock client, factory
│   ├── schemas.py                Pydantic structured outputs
│   ├── prompts.py                Jinja prompt templates
│   ├── enhance.py                Enhancement / planning / missing-info
│   └── sla.py                    Aging / risk / priority scoring
├── connectors/
│   ├── base.py                   Connector ABC, RawTicket DTO, upsert_raw
│   ├── manual.py
│   ├── jira.py
│   └── csv_connector.py
├── management/commands/
│   ├── aegis_demo.py
│   └── aegis_sync.py
├── templates/aegis/
│   ├── base.html                 Notion-style shell
│   ├── queue.html
│   ├── ticket_detail.html
│   ├── ticket_form.html
│   ├── csv_upload.html
│   └── partials/
│       ├── enhanced_panel.html
│       ├── plan_panel.html
│       ├── missing_panel.html
│       └── status_pill.html
└── tests/
    ├── conftest.py
    ├── test_models.py
    ├── test_services.py
    ├── test_connectors.py
    └── test_views.py
```

---

## License

MIT
