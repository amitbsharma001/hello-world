# Forecast evidence

Measured by `scripts/eval_forecast.py` (reproduce: `make eval-forecast`).
200 trials/process, walk-forward one-step-ahead. Compares the dashboard's
run-rate (trailing 4-week mean) against a naive "last value" baseline.
This replaces the unmeasured "forecast" claim (KNOWN_ISSUES #18) with numbers.

## Measured accuracy

| Process | MAE (% of level) | Bias | naive-1 MAE | Run-rate helps? |
|---|---|---|---|---|
| stationary | 2.7 (13.7%) | -0.0 | 3.4 | yes |
| trend_up | 3.4 (11.6%) | -2.5 | 3.44 | yes |
| trend_down | 3.13 (12.8%) | +2.0 | 3.38 | yes |
| seasonal | 9.06 (45.4%) | +1.01 | 5.23 | **no** |
| step_change | 2.71 (13.5%) | -1.12 | 2.62 | **no** |

Backlog **weeks-to-clear** point estimate: MAE **1.01 weeks**
over 200 genuinely-declining cases (no confidence interval).

## Honest interpretation

- **Stationary / noisy** (its happy path): ~14% error, ~zero bias, and it beats
  the naive baseline — the 4-week smoothing genuinely helps here.
- **Trends**: systematic **bias** (under-predicts a rising series by ~2.5/wk,
  over-predicts a falling one by ~2/wk) because there is no trend term. It lags.
- **Seasonal**: ~45% error and **worse than naive-1** — it misses turning points.
- **Step changes**: also loses to naive-1 around the break.
- **Backlog clearance**: a point estimate off by ~1 week on average, with no interval.

## Verdict
The label "forecast" overstated this. It is a **run-rate indicator**: a useful
smoother when intake/resolution are roughly stationary, and misleading on trends
or seasonality. The dashboard card has been relabelled "Run-rate outlook —
indicative, not a forecast." For real prediction, use a model with trend/seasonal
terms (Holt / Holt-Winters) and report a confidence interval.

## Caveat on this evidence
Synthetic processes with known structure — this characterizes the estimator's
behavior, not performance on your specific ticket history. Re-run against real
weekly series before relying on any number.
