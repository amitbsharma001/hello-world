import sys
import os
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "demo_project"))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "demo.settings")
