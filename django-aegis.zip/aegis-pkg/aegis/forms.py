from django import forms
from .models import Ticket


class TicketForm(forms.ModelForm):
    class Meta:
        model = Ticket
        fields = ["title", "description_raw", "severity", "assignee", "team", "status"]
        widgets = {
            "title": forms.TextInput(attrs={
                "class": "w-full text-2xl font-semibold border-0 focus:ring-0 px-0 py-2 placeholder-gray-300",
                "placeholder": "Untitled ticket",
                "autocomplete": "off",
                "autofocus": True,
            }),
            "description_raw": forms.Textarea(attrs={
                "class": "w-full border-0 focus:ring-0 px-0 py-2 resize-none placeholder-gray-300 text-base leading-relaxed",
                "placeholder": "Describe what's happening. The AI will rewrite this.",
                "rows": 8,
            }),
            "severity": forms.Select(attrs={"class": "aegis-input"}),
            "assignee": forms.TextInput(attrs={
                "class": "aegis-input", "placeholder": "you@example.com"
            }),
            "team": forms.TextInput(attrs={
                "class": "aegis-input", "placeholder": "e.g. Payments"
            }),
            "status": forms.Select(attrs={"class": "aegis-input"}),
        }


class CSVUploadForm(forms.Form):
    file = forms.FileField(
        widget=forms.FileInput(attrs={"class": "block w-full text-sm"})
    )
    run_ai = forms.BooleanField(required=False, initial=True, label="Run AI analysis after upload")
