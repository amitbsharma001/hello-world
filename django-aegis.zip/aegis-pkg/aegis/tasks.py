"""
Celery tasks. Only imported if AEGIS["USE_CELERY"] = True.

In your project's celery.py, just make sure `aegis.tasks` is in autodiscover_tasks().
"""
import logging
from celery import shared_task

from .models import Ticket
from .services import enhance_description, generate_plan, detect_missing_info

log = logging.getLogger("assist.tasks")


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def enhance_ticket(self, ticket_id):
    try:
        ticket = Ticket.objects.get(id=ticket_id)
        enhance_description(ticket, force=True)
    except Exception as exc:
        log.exception("assist.enhance_ticket.failed")
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def plan_ticket(self, ticket_id):
    try:
        ticket = Ticket.objects.get(id=ticket_id)
        generate_plan(ticket, force=True)
    except Exception as exc:
        log.exception("assist.plan_ticket.failed")
        raise self.retry(exc=exc)


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def missing_info_ticket(self, ticket_id):
    try:
        ticket = Ticket.objects.get(id=ticket_id)
        detect_missing_info(ticket, force=True)
    except Exception as exc:
        log.exception("assist.missing_info_ticket.failed")
        raise self.retry(exc=exc)


@shared_task
def run_full_analysis(ticket_id):
    enhance_ticket(ticket_id)
    plan_ticket(ticket_id)
    missing_info_ticket(ticket_id)


@shared_task(bind=True, max_retries=2, default_retry_delay=60)
def pull_all_connectors(self, user_id=None, mode="all", window=None):
    """Run the multi-connector pull in the background (production scaling path
    for the Sync console). Enqueued from the view when AEGIS['USE_CELERY']=True."""
    from .services.sync_runner import run_all_pulls
    user = None
    if user_id is not None:
        try:
            from django.contrib.auth import get_user_model
            user = get_user_model().objects.filter(id=user_id).first()
        except Exception:
            user = None
    try:
        return run_all_pulls(user=user, mode=mode, window=window)
    except Exception as exc:
        log.exception("assist.pull_all_connectors.failed")
        raise self.retry(exc=exc)
