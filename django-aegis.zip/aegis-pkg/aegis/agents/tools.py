"""
Tools available to agents.

Each tool is a callable with a docstring and a JSON-serializable signature
the LLM sees. The MockGeminiClient generates tool calls that look plausible
given the ticket content; real Gemini would do the same via function calling.

These implementations are mock-realistic — they produce believable outputs
derived from the ticket / DB / time of day so a demo feels alive. Swap them
for real Datadog / Grafana / Slack / Stripe / etc. clients in production.
"""
from __future__ import annotations
import hashlib
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable

from django.utils import timezone


@dataclass
class Tool:
    name: str
    description: str
    fn: Callable
    args_schema: dict  # JSON-schema-ish for the LLM


_REGISTRY: dict[str, Tool] = {}


def tool(name: str, description: str, args_schema: dict):
    def deco(fn):
        _REGISTRY[name] = Tool(name=name, description=description, fn=fn,
                               args_schema=args_schema)
        return fn
    return deco


def get_tool(name: str) -> Tool | None:
    return _REGISTRY.get(name)


def list_tools() -> list[Tool]:
    return list(_REGISTRY.values())


# ---- Deterministic mock seed from ticket content ----
def _seed(ticket) -> random.Random:
    h = hashlib.sha256(
        f"{ticket.id}-{ticket.title}-{ticket.description_raw}".encode()
    ).digest()
    return random.Random(int.from_bytes(h[:8], "big"))


# ---- Tools ----

@tool(
    name="search_similar_tickets",
    description="Find past tickets similar to a query. Returns up to k results with title, resolution_hours, and outcome.",
    args_schema={"query": "string", "k": "integer (default 5)"},
)
def search_similar_tickets(ticket, *, query: str, k: int = 5) -> dict:
    """Mock semantic search over historical tickets."""
    from aegis.models import Ticket
    qs = Ticket.objects.exclude(id=ticket.id).order_by("-opened_at")[:50]
    candidates = list(qs)
    if not candidates:
        return {"results": []}
    rng = _seed(ticket)
    # Pick k candidates "by relevance" (deterministic shuffle)
    rng.shuffle(candidates)
    picked = candidates[:k]
    return {
        "results": [
            {
                "source_id": t.source_id or str(t.id)[:8],
                "title": t.title,
                "severity": t.severity,
                "team": t.team or "unknown",
                "resolution_hours": (
                    round((t.resolved_at - t.opened_at).total_seconds() / 3600, 1)
                    if t.resolved_at else None
                ),
                "outcome": "resolved" if t.resolved_at else t.status,
                "similarity": round(0.6 + rng.random() * 0.35, 2),
            }
            for t in picked
        ]
    }


@tool(
    name="check_recent_deployments",
    description="Check deployments for a service in the last N hours. Returns deploy timestamps and authors.",
    args_schema={"service": "string", "hours": "integer (default 24)"},
)
def check_recent_deployments(ticket, *, service: str, hours: int = 24) -> dict:
    """Mock deploy history. Returns 0–3 deploys with realistic patterns."""
    rng = _seed(ticket)
    rng.random()  # advance
    rng.random()
    now = timezone.now()
    desc = (ticket.description_raw or "").lower()
    # If the ticket mentions "deploy", "after deploy", "PR", "rollout" — return a recent deploy
    deploy_hinted = any(w in desc for w in ["deploy", "rollout", "after", "pr #", "release"])
    n_deploys = (1 if deploy_hinted else 0) + rng.randint(0, 2)
    deploys = []
    for i in range(n_deploys):
        age_h = rng.uniform(0.1, hours)
        deploys.append({
            "service": service,
            "deployed_at": (now - timedelta(hours=age_h)).isoformat(),
            "age_hours": round(age_h, 1),
            "git_sha": hashlib.sha1(f"{service}{i}{ticket.id}".encode()).hexdigest()[:7],
            "author": rng.choice(["jane@x.com", "kumar@x.com", "alex@x.com", "sam@x.com"]),
            "title": rng.choice([
                "fix(payments): handle expired card retry",
                "feat(checkout): new validation rules",
                "chore(deps): bump library versions",
                "refactor(api): order endpoint split",
                "fix(auth): session timeout edge case",
            ]),
        })
    deploys.sort(key=lambda d: d["age_hours"])
    return {"service": service, "deploys": deploys, "lookback_hours": hours}


@tool(
    name="query_metrics",
    description="Query monitoring metrics (error_rate, latency_p95, throughput) for a service over a time window.",
    args_schema={"service": "string", "metric": "string", "window_minutes": "integer (default 60)"},
)
def query_metrics(ticket, *, service: str, metric: str, window_minutes: int = 60) -> dict:
    """Mock metrics. Severity influences the numbers so the agent's conclusions make sense."""
    rng = _seed(ticket)
    for _ in range(3): rng.random()  # advance
    sev = ticket.severity
    baseline = {
        "error_rate":   {"sev1": 8.5, "sev2": 3.2, "sev3": 1.1, "sev4": 0.3},
        "latency_p95":  {"sev1": 4200, "sev2": 1800, "sev3": 850, "sev4": 320},
        "throughput":   {"sev1": 320, "sev2": 1200, "sev3": 5400, "sev4": 8200},
    }.get(metric, {})
    value = baseline.get(sev, 1.0) * rng.uniform(0.85, 1.15)
    trend = "rising" if sev in ("sev1", "sev2") and metric in ("error_rate", "latency_p95") else "stable"
    unit = {"error_rate": "%", "latency_p95": "ms", "throughput": "req/min"}.get(metric, "")
    return {
        "service": service,
        "metric": metric,
        "window_minutes": window_minutes,
        "current_value": round(value, 2),
        "unit": unit,
        "trend": trend,
        "baseline_value": round(value * rng.uniform(0.2, 0.5), 2) if trend == "rising" else round(value, 2),
        "anomalous": trend == "rising",
    }


@tool(
    name="post_to_slack",
    description="Post a notification to a Slack channel (e.g. #incidents, #payments-oncall). Returns delivery status.",
    args_schema={"channel": "string", "message": "string"},
)
def post_to_slack(ticket, *, channel: str, message: str) -> dict:
    """Mock Slack post. In production: real Slack webhook."""
    return {
        "delivered": True, "channel": channel,
        "ts": timezone.now().isoformat(),
        "preview": message[:200],
    }


@tool(
    name="update_ticket_field",
    description="Update a ticket field (severity, team, status). Returns the old and new value.",
    args_schema={"field": "string (severity|team|status)", "value": "string", "reason": "string"},
)
def update_ticket_field(ticket, *, field: str, value: str, reason: str) -> dict:
    """Actually update the ticket. This is the only tool with side effects on the ticket."""
    allowed = {"severity", "team", "status"}
    if field not in allowed:
        return {"ok": False, "error": f"field must be one of {allowed}"}
    old = getattr(ticket, field)
    setattr(ticket, field, value)
    ticket.save(update_fields=[field, "updated_at"])
    return {"ok": True, "field": field, "old": old, "new": value, "reason": reason}


@tool(
    name="check_partner_status",
    description="Check the public status page of a third-party partner (e.g. stripe, sendgrid, aws). Returns health.",
    args_schema={"partner": "string"},
)
def check_partner_status(ticket, *, partner: str) -> dict:
    rng = _seed(ticket)
    for _ in range(5): rng.random()
    desc = (ticket.description_raw or "").lower()
    # If ticket mentions partner, weight toward "degraded"
    mentions = partner.lower() in desc
    status = "degraded" if mentions and rng.random() < 0.6 else "operational"
    return {
        "partner": partner,
        "status": status,
        "incidents_open": 1 if status == "degraded" else 0,
        "last_checked": timezone.now().isoformat(),
    }


@tool(
    name="request_info_from_user",
    description="Send a follow-up question back to the ticket reporter, asking for specific missing info.",
    args_schema={"questions": "list of strings"},
)
def request_info_from_user(ticket, *, questions: list) -> dict:
    """Mock: in production this would email / Slack-DM the reporter and write to the ticket comment thread."""
    return {
        "sent": True,
        "to": ticket.assignee or "reporter",
        "n_questions": len(questions),
        "preview": questions[:3],
    }


@tool(
    name="finish",
    description="Conclude the investigation. Provide a summary, recommended severity, and a list of follow-up actions.",
    args_schema={
        "summary": "string",
        "root_cause_hypothesis": "string",
        "recommended_severity": "sev1|sev2|sev3|sev4",
        "recommended_actions": "list of strings",
        "confidence": "float 0..1",
    },
)
def finish(ticket, *, summary: str, root_cause_hypothesis: str = "",
           recommended_severity: str = "", recommended_actions: list = None,
           confidence: float = 0.5) -> dict:
    """Special terminal tool. Agent loop stops when this is called."""
    return {
        "summary": summary,
        "root_cause_hypothesis": root_cause_hypothesis,
        "recommended_severity": recommended_severity,
        "recommended_actions": recommended_actions or [],
        "confidence": confidence,
    }
