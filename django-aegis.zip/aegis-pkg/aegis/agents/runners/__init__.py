"""Specialized agents. Each is a spec — same ReAct loop, different role + tools."""
from ..base import AgentSpec, run as run_agent
from ...models import Ticket, AgentRun


TRIAGE_AGENT = AgentSpec(
    name="Triage",
    role="Initial assessment and severity recommendation",
    system_prompt=(
        "You triage incoming tickets. Goal: in 3-5 steps, decide severity, "
        "identify the likely affected system, and either confirm the team "
        "or hand off to the Investigator. You do NOT mutate the ticket — "
        "you produce a recommendation that a human approves."
    ),
    allowed_tools=[
        "search_similar_tickets",
        "check_recent_deployments",
        "query_metrics",
        "check_partner_status",
        "finish",
    ],
    max_steps=5,
)


INVESTIGATOR_AGENT = AgentSpec(
    name="Investigator",
    role="Deep technical investigation",
    system_prompt=(
        "You investigate deeply once Triage has flagged a ticket. Goal: "
        "produce a defensible root-cause hypothesis using metrics, deploy "
        "history, and patterns across similar past tickets. Prefer "
        "diagnostic tools first; do not call communication tools."
    ),
    allowed_tools=[
        "query_metrics",
        "check_recent_deployments",
        "search_similar_tickets",
        "check_partner_status",
        "finish",
    ],
    max_steps=6,
)


RESOLVER_AGENT = AgentSpec(
    name="Resolver",
    role="Stakeholder communication + remediation prep",
    system_prompt=(
        "You drive resolution: notify the right channel, request missing "
        "information from the reporter, and propose concrete remediation "
        "steps. Always communicate first before suggesting risky actions."
    ),
    allowed_tools=[
        "post_to_slack",
        "request_info_from_user",
        "update_ticket_field",
        "finish",
    ],
    max_steps=5,
)


AGENTS = {
    "triage": TRIAGE_AGENT,
    "investigator": INVESTIGATOR_AGENT,
    "resolver": RESOLVER_AGENT,
}


def run_named(agent_name: str, ticket: Ticket, *, user=None, **kwargs) -> AgentRun:
    spec = AGENTS.get(agent_name.lower())
    if not spec:
        raise ValueError(f"unknown agent {agent_name!r}; choose from {list(AGENTS)}")
    return run_agent(spec, ticket, user=user, **kwargs)


def run_pipeline(ticket: Ticket, *, trigger: str = "auto", user=None) -> list:
    """
    Multi-agent pipeline. Triage -> (Investigator if Triage thinks serious) -> Resolver.

    This is what makes Assist agentic: the first agent's decision determines
    whether further agents run.
    """
    runs = []
    triage_run = run_named("triage", ticket, trigger=trigger, user=user)
    runs.append(triage_run)

    rec = (triage_run.output or {}).get("final") or {}
    rec_sev = rec.get("recommended_severity", "sev3")

    if rec_sev in ("sev1", "sev2"):
        inv_run = run_named("investigator", ticket, trigger="handoff_from_triage", user=user)
        runs.append(inv_run)

    res_run = run_named("resolver", ticket, trigger="handoff_from_triage", user=user)
    runs.append(res_run)
    return runs
