"""Prompts for the agent loop."""
import json
import jinja2

_env = jinja2.Environment(undefined=jinja2.StrictUndefined, autoescape=False)


REACT_TEMPLATE = """
You are the {{ spec.name }}. Your role: {{ spec.role }}.

{{ spec.system_prompt }}

You operate as a ReAct agent: at each step, produce a Thought and choose an
Action (one of the available tools). After each Action you'll see the
Observation. Continue until you have enough information, then call the
`finish` tool with your conclusion.

Available tools:
{% for t in available_tools %}
  - {{ t.name }}: {{ t.description }}
    args: {{ t.args_schema | tojson }}
{% endfor %}

# Current ticket
ID: {{ ticket.source_id or ticket.id }}
Title: {{ ticket.title }}
Severity (current): {{ ticket.severity }}
Status: {{ ticket.status }}
Team: {{ ticket.team or "—" }}
Reporter said:
---
{{ ticket.description_raw }}
---

# What you've done so far
{% if not history %}
(no steps yet — this is your first action)
{% else %}
{% for h in history %}
Step {{ loop.index }}:
  Thought: {{ h.thought }}
  Action: {{ h.action }}({{ h.action_input | tojson }})
  Observation: {{ h.observation | tojson }}

{% endfor %}
{% endif %}

# Your task
Decide what to do next. Return JSON only:
{
  "thought": "your reasoning, 1-2 sentences",
  "action": "<tool name from the list above>",
  "action_input": { ... arguments matching the tool's args schema ... },
  "is_final": false
}

Set is_final=true and action="finish" when you have enough information to
conclude. Do not call the same tool with the same arguments twice — pick a
different angle.
"""


def render_react_prompt(*, spec, ticket, history, available_tools):
    return _env.from_string(REACT_TEMPLATE).render(
        spec=spec, ticket=ticket, history=history,
        available_tools=available_tools,
    ).strip()
