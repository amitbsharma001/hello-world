"""
Agent runtime — ReAct-style loop.

Each step:
    1. LLM observes the ticket + history + available tools
    2. LLM produces a Thought + Action (tool name + args) OR finishes
    3. We execute the tool, capture the Observation
    4. Persist as an AgentStep so the UI can show what's happening
    5. Repeat until `finish` is called or max_steps is hit
"""
from __future__ import annotations
import logging
import time
import uuid
from dataclasses import dataclass
from typing import Optional
from django.utils import timezone

from ..models import AgentRun, AgentStep, Ticket
from ..services.gemini import get_client
from ..services.schemas import AgentDecisionStep
from ..conf import conf
from . import tools as toolmod
from . import prompts as agent_prompts

log = logging.getLogger("aegis.agents")


@dataclass
class AgentSpec:
    name: str
    role: str               # Short one-liner shown in UI
    system_prompt: str
    allowed_tools: list[str]
    max_steps: int = 8


def run(spec: AgentSpec, ticket: Ticket, *,
        trigger: str = "manual",
        idempotency_key: Optional[str] = None) -> AgentRun:
    """Execute one full agent run for a ticket."""
    key = idempotency_key or f"{spec.name}:{ticket.id}:{uuid.uuid4()}"
    existing = AgentRun.objects.filter(idempotency_key=key).first()
    if existing:
        return existing

    run_row = AgentRun.objects.create(
        idempotency_key=key,
        agent=spec.name,
        ticket=ticket,
        trigger=trigger,
        status=AgentRun.Status.RUNNING,
        input={"ticket_id": str(ticket.id), "role": spec.role},
        started_at=timezone.now(),
    )

    history: list[dict] = []
    client = get_client()
    final_output = None

    try:
        for seq in range(spec.max_steps):
            # 1. Build a prompt and ask the LLM what to do next
            prompt = agent_prompts.render_react_prompt(
                spec=spec, ticket=ticket, history=history,
                available_tools=[toolmod.get_tool(t) for t in spec.allowed_tools],
            )
            t0 = time.perf_counter()
            decision, meta = client.generate(
                model=conf.GEMINI_MODEL_FLASH,
                prompt=prompt,
                schema=AgentDecisionStep,
            )
            llm_ms = int((time.perf_counter() - t0) * 1000)

            # 2. Execute the chosen tool
            tool = toolmod.get_tool(decision.action)
            if not tool:
                obs = {"error": f"unknown tool {decision.action!r}"}
            else:
                # Filter args to only those the tool accepts
                try:
                    obs = tool.fn(ticket, **(decision.action_input or {}))
                except TypeError as e:
                    obs = {"error": f"tool call failed: {e}"}
                except Exception as e:
                    log.exception(f"agent.tool_failed: {decision.action}")
                    obs = {"error": str(e)}

            # 3. Persist the step
            AgentStep.objects.create(
                run=run_row, seq=seq + 1,
                name=decision.action,
                input={
                    "thought": decision.thought,
                    "action": decision.action,
                    "action_input": decision.action_input or {},
                },
                output={"observation": obs, "llm_ms": llm_ms},
                started_at=timezone.now(),
                finished_at=timezone.now(),
            )

            history.append({
                "thought": decision.thought,
                "action": decision.action,
                "action_input": decision.action_input or {},
                "observation": obs,
            })

            # 4. If the agent called `finish`, we're done
            if decision.action == "finish":
                final_output = obs
                break

        run_row.status = AgentRun.Status.SUCCEEDED
        run_row.output = {
            "steps": len(history),
            "final": final_output,
            "history_summary": [
                {"action": h["action"], "thought": h["thought"][:120]}
                for h in history
            ],
        }
    except Exception as e:
        log.exception("agent.run_failed")
        run_row.status = AgentRun.Status.FAILED
        run_row.error = repr(e)
    finally:
        run_row.finished_at = timezone.now()
        run_row.save()

    # 5. If the agent recommended a severity / actions, surface them on the ticket
    if final_output and isinstance(final_output, dict):
        _apply_recommendations(ticket, final_output)

    return run_row


def _apply_recommendations(ticket: Ticket, output: dict):
    """If the agent's final answer included a severity bump, surface it."""
    # We don't auto-mutate ticket.severity — humans approve via the UI.
    # But we DO surface the agent's recommendation in the ticket's plan_payload
    # so it shows up next to the other AI artifacts.
    recommended_sev = output.get("recommended_severity")
    if recommended_sev and ticket.priority_ai is None:
        # Boost priority_ai based on agent's confidence
        ticket.priority_ai = float(output.get("confidence", 0.5)) * 100
        ticket.save(update_fields=["priority_ai", "updated_at"])
