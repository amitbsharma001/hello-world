import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("aegis", "0008_dual_accounts_writeback"),
    ]

    operations = [
        migrations.AddField(
            model_name="ticket",
            name="pulled_by",
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="claimed_tickets", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="ticket",
            name="pulled_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
