import uuid
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("aegis", "0006_teammember_project_member_scope"),
    ]

    operations = [
        migrations.AddField(
            model_name="teammember",
            name="label",
            field=models.CharField(blank=True, db_index=True, max_length=64),
        ),
        migrations.CreateModel(
            name="Escalation",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False,
                                        primary_key=True, serialize=False)),
                ("title", models.CharField(max_length=200)),
                ("message", models.TextField(
                    help_text="Sent to every assignee, with their ticket appended.")),
                ("level", models.CharField(
                    choices=[("l1", "Level 1 — heads-up"),
                             ("l2", "Level 2 — action needed"),
                             ("l3", "Level 3 — management attention")],
                    default="l2", max_length=4)),
                ("status", models.CharField(
                    choices=[("open", "Open"), ("in_progress", "In progress"),
                             ("resolved", "Resolved"), ("cancelled", "Cancelled")],
                    db_index=True, default="open", max_length=16)),
                ("notify", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("closed_at", models.DateTimeField(blank=True, null=True)),
                ("created_by", models.ForeignKey(
                    null=True, on_delete=django.db.models.deletion.SET_NULL,
                    related_name="escalations", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="EscalationItem",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False,
                                        primary_key=True, serialize=False)),
                ("assignee", models.CharField(blank=True, max_length=128)),
                ("email_to", models.CharField(blank=True, max_length=254)),
                ("email_status", models.CharField(
                    choices=[("pending", "Pending"), ("sent", "Sent"),
                             ("failed", "Failed"), ("skipped", "Skipped (no email)")],
                    db_index=True, default="pending", max_length=8)),
                ("email_note", models.CharField(blank=True, max_length=300)),
                ("email_sent_at", models.DateTimeField(blank=True, null=True)),
                ("status", models.CharField(
                    choices=[("pending", "Pending"), ("notified", "Notified"),
                             ("acknowledged", "Acknowledged"),
                             ("resolved", "Resolved"), ("cancelled", "Cancelled")],
                    db_index=True, default="pending", max_length=16)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("escalation", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="items", to="aegis.escalation")),
                ("ticket", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="escalation_items", to="aegis.ticket")),
            ],
            options={"ordering": ["assignee"]},
        ),
        migrations.AddConstraint(
            model_name="escalationitem",
            constraint=models.UniqueConstraint(fields=("escalation", "ticket"),
                                               name="uniq_escalation_ticket"),
        ),
        migrations.AddIndex(
            model_name="escalationitem",
            index=models.Index(fields=["escalation", "status"],
                               name="aegis_escit_esc_status_idx"),
        ),
    ]
