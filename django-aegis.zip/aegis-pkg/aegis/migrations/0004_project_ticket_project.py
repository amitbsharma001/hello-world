import uuid
import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("aegis", "0003_agentstep"),
    ]

    operations = [
        migrations.CreateModel(
            name="Project",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("key", models.CharField(help_text="Short code, e.g. PAY. Matched against incoming ticket project/team.", max_length=32, unique=True)),
                ("name", models.CharField(max_length=120)),
                ("source", models.CharField(choices=[("jira", "Jira"), ("zendesk", "Zendesk"), ("csv", "CSV import"), ("manual", "Manual"), ("api", "REST API")], default="manual", max_length=16)),
                ("external_key", models.CharField(blank=True, help_text="Project key in the source system (e.g. the Jira project key).", max_length=64)),
                ("default_team", models.CharField(blank=True, max_length=64)),
                ("description", models.TextField(blank=True)),
                ("sync_enabled", models.BooleanField(db_index=True, default=True)),
                ("discovered", models.BooleanField(default=False, help_text="Auto-registered from an inbound sync; not yet enabled by an admin.")),
                ("last_synced_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={
                "ordering": ["-sync_enabled", "name"],
            },
        ),
        migrations.AddField(
            model_name="ticket",
            name="project",
            field=models.ForeignKey(blank=True, db_index=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="tickets", to="aegis.project"),
        ),
    ]
