import uuid
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("aegis", "0004_project_ticket_project"),
    ]

    operations = [
        migrations.CreateModel(
            name="UserAIConfig",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("provider", models.CharField(choices=[("gemini", "Google Gemini"), ("openai", "OpenAI"), ("anthropic", "Anthropic")], default="gemini", max_length=16)),
                ("model_name", models.CharField(default="gemini-2.5-flash", max_length=64)),
                ("api_key_enc", models.TextField(blank=True)),
                ("jira_base_url", models.URLField(blank=True)),
                ("jira_email", models.CharField(blank=True, max_length=160)),
                ("jira_token_enc", models.TextField(blank=True)),
                ("last_verified_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("user", models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name="ai_config", to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name="TicketAction",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("kind", models.CharField(choices=[("push_description", "Pushed description to Jira"), ("post_comment", "Posted resolution steps to Jira"), ("customer_email", "Generated customer email")], max_length=24)),
                ("status", models.CharField(choices=[("success", "Success"), ("mock", "Mock (no live credentials)"), ("failed", "Failed")], default="success", max_length=12)),
                ("detail", models.TextField(blank=True)),
                ("payload", models.JSONField(default=dict)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("ticket", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="actions", to="aegis.ticket")),
                ("user", models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="ticket_actions", to=settings.AUTH_USER_MODEL)),
            ],
            options={
                "ordering": ["-created_at"],
            },
        ),
        migrations.AddIndex(
            model_name="ticketaction",
            index=models.Index(fields=["ticket", "-created_at"], name="aegis_ticke_ticket__idx"),
        ),
    ]
