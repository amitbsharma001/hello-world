import uuid
import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("aegis", "0005_useraiconfig_ticketaction"),
    ]

    operations = [
        migrations.AddField(
            model_name="project",
            name="member_scope",
            field=models.CharField(
                choices=[("all", "All assignees in the project"), ("team", "Only my configured team members")],
                default="all", max_length=8,
                help_text="Restrict the pull to specific team members within this project."),
        ),
        migrations.AlterField(
            model_name="project",
            name="source",
            field=models.CharField(
                choices=[("jira", "Jira"), ("servicenow", "ServiceNow"), ("zendesk", "Zendesk"),
                         ("csv", "CSV import"), ("manual", "Manual"), ("api", "REST API")],
                default="manual", max_length=16),
        ),
        migrations.CreateModel(
            name="TeamMember",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=120)),
                ("source", models.CharField(choices=[("jira", "Jira"), ("servicenow", "ServiceNow")], default="jira", max_length=16)),
                ("account", models.CharField(help_text="The person's identity in the source (email or account id).", max_length=200)),
                ("source_url", models.URLField(blank=True, help_text="Base URL of this member's source instance, e.g. https://org.atlassian.net")),
                ("pull_all_projects", models.BooleanField(default=True)),
                ("default_team", models.CharField(blank=True, max_length=64)),
                ("sync_enabled", models.BooleanField(db_index=True, default=True)),
                ("last_synced_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("projects", models.ManyToManyField(blank=True, related_name="members", to="aegis.project")),
            ],
            options={
                "ordering": ["-sync_enabled", "name"],
            },
        ),
    ]
