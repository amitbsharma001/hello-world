from django.db import migrations, models


def seed_dual_accounts(apps, schema_editor):
    """Copy the legacy single account into the matching per-source column so
    existing members keep pulling/matching exactly as before."""
    TeamMember = apps.get_model("aegis", "TeamMember")
    for m in TeamMember.objects.all():
        changed = []
        acct = (m.account or "").strip()
        if acct and m.source == "jira" and not m.jira_account:
            m.jira_account = acct
            changed.append("jira_account")
        if acct and m.source == "servicenow" and not m.servicenow_account:
            m.servicenow_account = acct
            changed.append("servicenow_account")
        if changed:
            m.save(update_fields=changed)


def noop(apps, schema_editor):
    pass


class Migration(migrations.Migration):

    dependencies = [
        ("aegis", "0007_label_escalations"),
    ]

    operations = [
        migrations.AddField(
            model_name="teammember",
            name="jira_account",
            field=models.CharField(blank=True, help_text="Jira email or accountId",
                                   max_length=200),
        ),
        migrations.AddField(
            model_name="teammember",
            name="servicenow_account",
            field=models.CharField(blank=True, help_text="ServiceNow assigned_to email",
                                   max_length=200),
        ),
        migrations.RunPython(seed_dual_accounts, noop),
        migrations.AddField(
            model_name="escalation",
            name="post_to_source",
            field=models.BooleanField(
                default=True,
                help_text="Also post the message on each ticket in Jira / ServiceNow."),
        ),
        migrations.AddField(
            model_name="escalationitem",
            name="comment_status",
            field=models.CharField(
                choices=[("pending", "Pending"), ("posted", "Posted"),
                         ("mock", "Mock (no live credentials)"),
                         ("failed", "Failed"), ("skipped", "Skipped")],
                db_index=True, default="skipped", max_length=8),
        ),
        migrations.AddField(
            model_name="escalationitem",
            name="comment_note",
            field=models.CharField(blank=True, max_length=300),
        ),
        migrations.AddField(
            model_name="escalationitem",
            name="comment_posted_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
