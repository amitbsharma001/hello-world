from django.contrib import admin
from .models import Ticket, TicketHistory, AIArtifact, AgentRun, SyncCursor


@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("title", "owner", "source", "source_id", "status", "severity", "team", "opened_at", "priority_ai")
    list_filter = ("source", "status", "severity", "team", "owner")
    search_fields = ("title", "description_raw", "source_id", "assignee", "owner__username")
    date_hierarchy = "opened_at"
    raw_id_fields = ("owner",)
    readonly_fields = ("id", "created_at", "updated_at", "content_hash",
                       "enhanced_payload", "plan_payload", "missing_info_payload",
                       "description_enhanced")


@admin.register(TicketHistory)
class TicketHistoryAdmin(admin.ModelAdmin):
    list_display = ("ticket", "event_type", "actor", "occurred_at")
    list_filter = ("event_type",)
    date_hierarchy = "occurred_at"


@admin.register(AIArtifact)
class AIArtifactAdmin(admin.ModelAdmin):
    list_display = ("ticket", "kind", "model", "confidence", "tokens_in", "tokens_out", "cost_usd", "latency_ms", "created_at")
    list_filter = ("kind", "model")
    readonly_fields = ("payload", "raw_response")


@admin.register(AgentRun)
class AgentRunAdmin(admin.ModelAdmin):
    list_display = ("agent", "ticket", "status", "trigger", "started_at", "finished_at")
    list_filter = ("agent", "status", "trigger")


@admin.register(SyncCursor)
class SyncCursorAdmin(admin.ModelAdmin):
    list_display = ("source", "cursor", "last_run_at")
