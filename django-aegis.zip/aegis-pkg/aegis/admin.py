from django.contrib import admin
from .models import Ticket, TicketHistory, AIArtifact, AgentRun, SyncCursor, Project, UserAIConfig, TicketAction


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("key", "name", "source", "sync_enabled", "discovered", "default_team", "last_synced_at")
    list_filter = ("sync_enabled", "discovered", "source")
    search_fields = ("key", "name", "external_key", "default_team")
    list_editable = ("sync_enabled",)
    readonly_fields = ("id", "created_at", "updated_at", "last_synced_at")


@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ("title", "owner", "source", "source_id", "status", "severity", "team", "opened_at", "priority_ai")
    list_filter = ("source", "status", "severity", "team", "owner")
    search_fields = ("title", "description_raw", "source_id", "assignee", "owner__username")
    date_hierarchy = "opened_at"
    raw_id_fields = ("owner",)
    readonly_fields = ("id", "created_at", "updated_at", "content_hash",
                       "enhanced_payload", "plan_payload", "missing_info_payload",
                       "description_enhanced")


@admin.register(TicketHistory)
class TicketHistoryAdmin(admin.ModelAdmin):
    list_display = ("ticket", "event_type", "actor", "occurred_at")
    list_filter = ("event_type",)
    date_hierarchy = "occurred_at"


@admin.register(AIArtifact)
class AIArtifactAdmin(admin.ModelAdmin):
    list_display = ("ticket", "kind", "model", "confidence", "tokens_in", "tokens_out", "cost_usd", "latency_ms", "created_at")
    list_filter = ("kind", "model")
    readonly_fields = ("payload", "raw_response")


@admin.register(AgentRun)
class AgentRunAdmin(admin.ModelAdmin):
    list_display = ("agent", "ticket", "status", "trigger", "started_at", "finished_at")
    list_filter = ("agent", "status", "trigger")


@admin.register(SyncCursor)
class SyncCursorAdmin(admin.ModelAdmin):
    list_display = ("source", "cursor", "last_run_at")


@admin.register(UserAIConfig)
class UserAIConfigAdmin(admin.ModelAdmin):
    list_display = ("user", "provider", "model_name", "is_configured", "jira_configured", "updated_at")
    list_filter = ("provider",)
    search_fields = ("user__username", "jira_email")
    readonly_fields = ("api_key_enc", "jira_token_enc", "created_at", "updated_at")


@admin.register(TicketAction)
class TicketActionAdmin(admin.ModelAdmin):
    list_display = ("ticket", "kind", "status", "user", "created_at")
    list_filter = ("kind", "status")
    readonly_fields = ("id", "created_at")
