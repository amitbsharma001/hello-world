from django.apps import AppConfig


class AssistConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "aegis"
    verbose_name = "Assist — Ticket Operations"

    def ready(self):
        from . import signals  # noqa: F401
