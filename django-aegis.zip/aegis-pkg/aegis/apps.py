from django.apps import AppConfig


class AegisConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "aegis"
    verbose_name = "Aegis — Ticket Operations"

    def ready(self):
        from . import signals  # noqa: F401
