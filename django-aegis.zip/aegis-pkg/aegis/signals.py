from django.db.models.signals import post_save
from django.dispatch import receiver
import logging

from .models import Ticket, TicketHistory
from .conf import conf

log = logging.getLogger("assist.signals")


@receiver(post_save, sender=Ticket)
def record_history(sender, instance: Ticket, created, **kwargs):
    TicketHistory.objects.create(
        ticket=instance,
        event_type="created" if created else "updated",
        payload={"status": instance.status, "severity": instance.severity},
    )


@receiver(post_save, sender=Ticket)
def auto_triage(sender, instance: Ticket, created, **kwargs):
    """
    On new ticket creation, kick off the multi-agent pipeline.

    Controlled by AEGIS['AUTO_TRIAGE'] (default True). Synchronous in the
    demo (the mock agent loop is ~150ms total). In production, this dispatches
    to Celery.
    """
    if not created:
        return
    if not getattr(conf, "AUTO_TRIAGE", True):
        return
    if instance.source == "demo":
        # demo seed runs its own analysis flow, skip
        return
    try:
        from .agents import run_pipeline
        run_pipeline(instance, trigger="auto_on_create")
    except Exception:
        log.exception("assist.auto_triage_failed")
