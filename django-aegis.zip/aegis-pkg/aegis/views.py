from __future__ import annotations
import json
import logging
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.views.decorators.http import require_http_methods, require_POST, require_GET
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpResponse, JsonResponse, Http404
from django.db.models import Q
from django.utils import timezone

from .models import Ticket, AIArtifact
from .forms import TicketForm, CSVUploadForm
from .conf import conf
from .services import enhance_description, generate_plan, detect_missing_info
from .services.gemini import AIConfigRequired
from .services.sla import score as sla_score, status_label
from .connectors.base import upsert_raw, ingest
from .connectors.csv_connector import CSVConnector
from .perms import filter_for_user, can_view, is_admin

log = logging.getLogger("aegis.views")


def _maybe_run_ai(ticket: Ticket, user=None):
    """Run AI analysis. In production with USE_CELERY, this would enqueue."""
    if conf.USE_CELERY:
        from . import tasks
        tasks.run_full_analysis.delay(str(ticket.id))
    else:
        try:
            enhance_description(ticket, user=user)
            ticket.refresh_from_db()
            generate_plan(ticket, user=user)
            detect_missing_info(ticket, user=user)
        except Exception as e:
            log.exception("aegis.ai.failed")
            messages.error(
                None,  # noop in non-request context; will surface in view
                f"AI analysis failed: {e}",
            )


# ---- Queue ----

@login_required
def queue(request):
    qs = filter_for_user(Ticket.objects.all(), request.user)

    q = request.GET.get("q", "").strip()
    status = request.GET.get("status", "")
    sev = request.GET.get("sev", "")
    team = request.GET.get("team", "")

    if q:
        qs = qs.filter(Q(title__icontains=q) | Q(description_raw__icontains=q))
    if status:
        qs = qs.filter(status=status)
    if sev:
        qs = qs.filter(severity=sev)
    if team:
        qs = qs.filter(team__icontains=team)

    tickets = list(qs[:conf.TICKET_LIST_PAGE_SIZE * 2])
    annotated = []
    for t in tickets:
        s = sla_score(t)
        annotated.append({"t": t, "s": s, "label": status_label(s)})
    annotated.sort(key=lambda x: x["s"]["operational_priority"], reverse=True)
    annotated = annotated[: conf.TICKET_LIST_PAGE_SIZE]

    context = {
        "tickets": annotated,
        "q": q,
        "status": status,
        "sev": sev,
        "team": team,
        "status_choices": Ticket.Status.choices,
        "severity_choices": Ticket.Severity.choices,
        "total": qs.count(),
        "open_count": qs.exclude(status__in=["resolved", "closed"]).count(),
        "critical_count": sum(1 for x in annotated if x["label"] == "critical"),
        "is_admin_user": is_admin(request.user),
    }
    return render(request, "aegis/queue.html", context)


# ---- Detail ----

@login_required
def detail(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)
    if not can_view(request.user, ticket):
        raise Http404("Ticket not found")
    s = sla_score(ticket)
    context = {
        "ticket": ticket,
        "score": s,
        "label": status_label(s),
        "enhanced": ticket.enhanced_payload,
        "plan": ticket.plan_payload,
        "missing": ticket.missing_info_payload,
        "history": ticket.history.all()[:20],
        "artifacts": ticket.artifacts.all()[:10],
        "is_admin_user": is_admin(request.user),
        "runs": _agent_runs_for(ticket),
    }
    return render(request, "aegis/ticket_detail.html", context)


# ---- Create ----

@login_required
def create(request):
    if request.method == "POST":
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.source = "manual"
            ticket.owner = request.user
            ticket.opened_at = timezone.now()
            ticket.save()
            run_ai = request.POST.get("run_ai") == "on"
            if run_ai:
                _maybe_run_ai(ticket, user=request.user)
                ticket.refresh_from_db()
            messages.success(request, "Ticket created.")
            return redirect("aegis:detail", ticket_id=ticket.id)
    else:
        form = TicketForm()
    return render(request, "aegis/ticket_form.html", {"form": form})


# ---- AI actions (HTMX endpoints) ----

def _check_ticket_access(request, ticket_id):
    """Get ticket if user can access it, else 404."""
    ticket = get_object_or_404(Ticket, id=ticket_id)
    if not can_view(request.user, ticket):
        raise Http404("Ticket not found")
    return ticket


def _htmx_config_required(request):
    """Return an HTMX-friendly prompt to configure the AI key."""
    return render(request, "aegis/partials/config_required.html", status=200)


@login_required
@require_POST
def action_enhance(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        enhance_description(ticket, force=True, user=request.user)
        ticket.refresh_from_db()
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("enhance.failed")
        return _htmx_error(f"Enhancement failed: {e}")
    return render(request, "aegis/partials/enhanced_panel.html", {"ticket": ticket})


@login_required
@require_POST
def action_plan(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        generate_plan(ticket, force=True, user=request.user)
        ticket.refresh_from_db()
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("plan.failed")
        return _htmx_error(f"Plan generation failed: {e}")
    return render(request, "aegis/partials/plan_panel.html", {"ticket": ticket, "plan": ticket.plan_payload})


@login_required
@require_POST
def action_missing(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        detect_missing_info(ticket, force=True, user=request.user)
        ticket.refresh_from_db()
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("missing.failed")
        return _htmx_error(f"Missing-info detection failed: {e}")
    return render(request, "aegis/partials/missing_panel.html", {"ticket": ticket, "missing": ticket.missing_info_payload})


@login_required
@require_POST
def action_run_all(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        enhance_description(ticket, force=True, user=request.user)
        ticket.refresh_from_db()
        generate_plan(ticket, force=True, user=request.user)
        detect_missing_info(ticket, force=True, user=request.user)
        ticket.refresh_from_db()
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("run_all.failed")
        return _htmx_error(f"AI run failed: {e}")
    response = HttpResponse(status=204)
    response["HX-Redirect"] = reverse("aegis:detail", args=[str(ticket.id)])
    return response


@login_required
@require_POST
def action_status(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    new_status = request.POST.get("status")
    if new_status in dict(Ticket.Status.choices):
        ticket.status = new_status
        if new_status == Ticket.Status.RESOLVED and not ticket.resolved_at:
            ticket.resolved_at = timezone.now()
        ticket.save()
    return render(request, "aegis/partials/status_pill.html", {"ticket": ticket})


# ---- Agent actions (autonomous reasoning) ----

@login_required
@require_POST
def action_run_agent(request, ticket_id, agent_name):
    """Manually trigger a specific named agent on a ticket."""
    from .agents import run_named
    ticket = _check_ticket_access(request, ticket_id)
    try:
        run_named(agent_name, ticket, trigger="manual", user=request.user)
        ticket.refresh_from_db()
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("agent.run_failed")
        return _htmx_error(f"Agent run failed: {e}")
    return render(request, "aegis/partials/agent_timeline.html",
                  {"ticket": ticket, "runs": _agent_runs_for(ticket)})


@login_required
@require_POST
def action_run_pipeline(request, ticket_id):
    """Run the full multi-agent pipeline (Triage -> maybe Investigator -> Resolver)."""
    from .agents import run_pipeline
    ticket = _check_ticket_access(request, ticket_id)
    try:
        run_pipeline(ticket, trigger="manual_pipeline", user=request.user)
        ticket.refresh_from_db()
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("pipeline.failed")
        return _htmx_error(f"Pipeline failed: {e}")
    return render(request, "aegis/partials/agent_timeline.html",
                  {"ticket": ticket, "runs": _agent_runs_for(ticket)})


@login_required
def agents_inbox(request):
    """Org-wide feed of recent agent runs. Admins see all; users see only theirs."""
    from .models import AgentRun
    qs = AgentRun.objects.select_related("ticket").order_by("-started_at")
    if not is_admin(request.user):
        qs = qs.filter(ticket__owner=request.user)
    runs = list(qs[:50])
    # Pull recommended actions out of each run
    for r in runs:
        final = (r.output or {}).get("final") or {}
        r.recommended_actions = final.get("recommended_actions") or []
        r.recommended_severity = final.get("recommended_severity")
        r.summary = final.get("summary") or ""
        r.steps_count = r.steps.count()
    return render(request, "aegis/agents_inbox.html", {
        "runs": runs,
        "is_admin_user": is_admin(request.user),
    })


@login_required
def dashboard(request):
    """Portfolio command center: diagnostic + predictive analytics, time-range aware. Admin only."""
    from .models import AgentRun, Project
    from datetime import timedelta
    from collections import Counter, defaultdict

    if not is_admin(request.user):
        raise Http404()

    now = timezone.now()
    risk_window = now + timedelta(hours=8)
    RESOLVED_STATES = ("resolved", "closed")
    SLA_TARGET = {"sev1": 4, "sev2": 12, "sev3": 48, "sev4": 120}

    # ---- Time-range selector (period-over-period comparison) ----
    ALLOWED = {"7": 7, "30": 30, "90": 90}
    range_key = request.GET.get("range", "30")
    period_days = ALLOWED.get(range_key, 30)
    period_label = f"{period_days}d"
    p_start = now - timedelta(days=period_days)
    pp_start = now - timedelta(days=period_days * 2)

    # ---- Project filter (scope all analytics to one project, or all) ----
    project_options = list(Project.objects.filter(sync_enabled=True).order_by("name"))
    project_filter = request.GET.get("project", "")
    active_project = None
    base_qs = Ticket.objects.select_related("owner", "project")
    if project_filter:
        active_project = next((p for p in project_options if str(p.id) == project_filter), None)
        if active_project is None:
            active_project = Project.objects.filter(id=project_filter).first()
        if active_project:
            base_qs = base_qs.filter(project=active_project)

    tickets = list(base_qs.all())

    def is_open(t):     return t.status not in RESOLVED_STATES
    def is_resolved(t): return t.resolved_at is not None
    def age_h(t):       return (now - t.opened_at).total_seconds() / 3600
    def res_h(t):       return (t.resolved_at - t.opened_at).total_seconds() / 3600
    def in_window(dt, a, b): return dt is not None and a <= dt < b

    open_tickets = [t for t in tickets if is_open(t)]
    resolved_tickets = [t for t in tickets if is_resolved(t)]

    def sla_state(t):
        if not t.sla_due_at: return "none"
        if t.resolved_at:    return "met" if t.resolved_at <= t.sla_due_at else "missed"
        if t.sla_due_at < now:           return "breached"
        if t.sla_due_at <= risk_window:  return "at_risk"
        return "on_track"

    def hours_to_breach(t):
        return round((t.sla_due_at - now).total_seconds() / 3600, 1) if t.sla_due_at else None

    def compliance(lst):
        ws = [t for t in lst if t.sla_due_at]
        if not ws: return None
        return round(sum(1 for t in ws if t.resolved_at <= t.sla_due_at) / len(ws) * 100)

    def mttr(lst):
        ds = [res_h(t) for t in lst]
        return round(sum(ds) / len(ds), 1) if ds else 0

    def percentile(vals, p):
        if not vals: return 0
        s = sorted(vals); k = (len(s) - 1) * p / 100
        f = int(k); c = min(f + 1, len(s) - 1)
        return round(s[f] + (s[c] - s[f]) * (k - f), 1)

    # ---- Period-scoped flow ----
    created_p  = [t for t in tickets if in_window(t.opened_at, p_start, now)]
    created_pp = [t for t in tickets if in_window(t.opened_at, pp_start, p_start)]
    resolved_p  = [t for t in tickets if in_window(t.resolved_at, p_start, now)]
    resolved_pp = [t for t in tickets if in_window(t.resolved_at, pp_start, p_start)]

    def delta(cur, prev):
        d = cur - prev
        return {"cur": cur, "prev": prev, "diff": d,
                "pct": round((d / prev * 100)) if prev else (100 if cur else 0)}

    sla_all = compliance(resolved_tickets); sla_all = sla_all if sla_all is not None else 100
    sla_p, sla_pp = compliance(resolved_p), compliance(resolved_pp)
    mttr_all = mttr(resolved_tickets)
    mttr_p, mttr_pp = mttr(resolved_p), mttr(resolved_pp)
    net_flow_p = len(created_p) - len(resolved_p)
    net_flow_pp = len(created_pp) - len(resolved_pp)

    # ---- Cycle-time percentiles (tail latency) ----
    res_hours = [res_h(t) for t in resolved_tickets]
    cycle = {"p50": percentile(res_hours, 50),
             "p90": percentile(res_hours, 90),
             "p95": percentile(res_hours, 95),
             "n": len(res_hours)}

    # ---- MTTR by severity ----
    mttr_by_sev = []
    for k, label in [("sev1", "Sev 1"), ("sev2", "Sev 2"), ("sev3", "Sev 3"), ("sev4", "Sev 4")]:
        grp = [t for t in resolved_tickets if t.severity == k]
        actual = mttr(grp); target = SLA_TARGET[k]
        mttr_by_sev.append({"key": k, "label": label, "actual": actual, "target": target,
                            "n": len(grp), "over": actual > target and len(grp) > 0,
                            "pct": min(100, round(actual / (target * 1.5) * 100)) if target else 0})

    # ---- Core counts ----
    breached = [t for t in open_tickets if sla_state(t) == "breached"]
    at_risk  = [t for t in open_tickets if sla_state(t) == "at_risk"]
    escalations = [t for t in open_tickets if t.severity in ("sev1", "sev2")]
    unassigned = [t for t in open_tickets if not t.assignee]

    # ---- Aging distribution ----
    buckets = [("< 1 day", 0, 24), ("1-3 days", 24, 72), ("3-7 days", 72, 168), ("> 1 week", 168, 1e9)]
    aging_dist = []
    for label, lo, hi in buckets:
        n = sum(1 for t in open_tickets if lo <= age_h(t) < hi)
        aging_dist.append({"label": label, "n": n})
    max_bucket = max((b["n"] for b in aging_dist), default=1) or 1
    for b in aging_dist:
        b["pct"] = round(b["n"] / max_bucket * 100)
    stale_count = sum(1 for t in open_tickets if age_h(t) >= 168)

    # ---- Status bottleneck ----
    status_stuck = []
    by_status = defaultdict(list)
    for t in open_tickets:
        by_status[t.status].append(t)
    for value, label in Ticket.Status.choices:
        if value in RESOLVED_STATES: continue
        grp = by_status.get(value, [])
        if not grp: continue
        status_stuck.append({"key": value, "label": label, "n": len(grp),
                             "avg_age": round(sum(age_h(t) for t in grp) / len(grp), 1),
                             "bottleneck": value in ("blocked", "waiting_customer", "waiting_engineering")})
    status_stuck.sort(key=lambda s: s["avg_age"], reverse=True)

    # ---- 6-week trends ----
    weeks = []
    for w in range(5, -1, -1):
        w_start = now - timedelta(days=7 * (w + 1)); w_end = now - timedelta(days=7 * w)
        weeks.append({
            "label": w_end.strftime("%b %d"),
            "created": sum(1 for t in tickets if in_window(t.opened_at, w_start, w_end)),
            "resolved": sum(1 for t in tickets if in_window(t.resolved_at, w_start, w_end)),
            "backlog": sum(1 for t in tickets if t.opened_at <= w_end and (t.resolved_at is None or t.resolved_at > w_end)),
        })
    max_wk_flow = max([max(w["created"], w["resolved"]) for w in weeks] + [1])
    max_backlog = max([w["backlog"] for w in weeks] + [1])
    for w in weeks:
        w["created_pct"] = round(w["created"] / max_wk_flow * 100)
        w["resolved_pct"] = round(w["resolved"] / max_wk_flow * 100)
        w["backlog_pct"] = round(w["backlog"] / max_backlog * 100)

    # ---- PREDICTIVE: outlook / forecast ----
    recent = weeks[-4:] if len(weeks) >= 4 else weeks
    avg_wk_created = sum(w["created"] for w in recent) / len(recent) if recent else 0
    avg_wk_resolved = sum(w["resolved"] for w in recent) / len(recent) if recent else 0
    net_wk = avg_wk_created - avg_wk_resolved
    backlog_now = len(open_tickets)
    if net_wk < -0.01 and avg_wk_resolved > 0:
        weeks_to_clear = round(backlog_now / abs(net_wk), 1)
        backlog_outlook = {"state": "clearing", "weeks": weeks_to_clear,
                           "text": f"Clears in ~{weeks_to_clear} wk at current burn rate."}
    elif net_wk > 0.01:
        backlog_outlook = {"state": "growing", "rate": round(net_wk, 1),
                           "text": f"Growing ~+{round(net_wk, 1)}/wk — no clearance at current rate."}
    else:
        backlog_outlook = {"state": "steady", "text": "Steady — intake matches resolution."}
    breaches_48h = sum(1 for t in open_tickets
                       if t.sla_due_at and now < t.sla_due_at <= now + timedelta(hours=48))
    forecast = {
        "backlog": backlog_outlook,
        "breaches_48h": breaches_48h,
        "expected_resolutions_7d": round(avg_wk_resolved),
        "expected_intake_7d": round(avg_wk_created),
    }

    # ---- Team scorecard ----
    team_names = sorted({t.team for t in tickets if t.team})
    team_rows = []
    for name in team_names:
        tt = [t for t in tickets if t.team == name]
        tt_open = [t for t in tt if is_open(t)]
        tt_c = [t for t in tt if in_window(t.opened_at, p_start, now)]
        tt_r = [t for t in tt if in_window(t.resolved_at, p_start, now)]
        tt_rs = [t for t in tt if t.resolved_at and t.sla_due_at]
        tt_met = [t for t in tt_rs if t.resolved_at <= t.sla_due_at]
        ages = [age_h(t) for t in tt_open]
        team_rows.append({
            "name": name, "open": len(tt_open),
            "critical": sum(1 for t in tt_open if t.severity in ("sev1", "sev2")),
            "at_risk": sum(1 for t in tt_open if sla_state(t) in ("breached", "at_risk")),
            "avg_age": round(sum(ages) / len(ages), 1) if ages else 0,
            "resolved_p": len(tt_r), "net_flow": len(tt_c) - len(tt_r),
            "sla_pct": round(len(tt_met) / len(tt_rs) * 100) if tt_rs else 100})
    team_rows.sort(key=lambda r: (r["critical"], r["at_risk"], r["open"]), reverse=True)
    max_team_open = max((r["open"] for r in team_rows), default=1) or 1
    for r in team_rows:
        r["load_pct"] = round(r["open"] / max_team_open * 100)

    # ---- Hotspots ----
    crit_open = [t for t in open_tickets if t.severity in ("sev1", "sev2")]
    hot = Counter(t.team or "—" for t in crit_open)
    total_crit = len(crit_open) or 1
    hotspots = [{"team": tm, "n": n, "pct": round(n / total_crit * 100)} for tm, n in hot.most_common(4)]

    # ---- Workload ----
    oc = Counter(t.owner.username for t in open_tickets if t.owner)
    total_owned = sum(oc.values()) or 1
    max_owner = max(oc.values(), default=1) or 1
    owners = [{"username": u, "n": n, "pct": round(n / max_owner * 100),
               "share": round(n / total_owned * 100), "overloaded": n >= max(4, max_owner)}
              for u, n in oc.most_common(6)]

    # ---- SLA watchlist ----
    watchlist = sorted([t for t in open_tickets if t.sla_due_at], key=lambda t: t.sla_due_at)[:6]
    watchlist_rows = [{"t": t, "state": sla_state(t), "htb": hours_to_breach(t)} for t in watchlist]

    # ---- Agent leverage ----
    runs_qs = AgentRun.objects.filter(started_at__gte=p_start)
    runs_count = runs_qs.count()
    touched = runs_qs.values("ticket").distinct().count()
    auto = {"runs": runs_count, "tickets_touched": touched,
            "coverage_pct": round(touched / (len(tickets) or 1) * 100),
            "minutes_saved": runs_count * 12}

    # ---- Health score + trend ----
    pct_stale = (stale_count / len(open_tickets) * 100) if open_tickets else 0
    s_sla = sla_all
    s_backlog = max(0, 100 - max(0, net_flow_p) * 8)
    s_escal = max(0, 100 - len(escalations) * 6)
    s_aging = max(0, 100 - pct_stale)
    health = round(0.40 * s_sla + 0.25 * s_backlog + 0.20 * s_escal + 0.15 * s_aging)
    prior_sla = sla_pp if sla_pp is not None else s_sla
    prior_backlog = max(0, 100 - max(0, net_flow_pp) * 8)
    prior_health = round(0.40 * prior_sla + 0.25 * prior_backlog + 0.20 * s_escal + 0.15 * s_aging)
    health_trend = health - prior_health
    if health >= 90:   grade, hstatus = "A", "Healthy"
    elif health >= 80: grade, hstatus = "B", "Healthy"
    elif health >= 70: grade, hstatus = "C", "Watch"
    elif health >= 60: grade, hstatus = "D", "Watch"
    else:              grade, hstatus = "F", "At risk"
    gauge_dash = round(health / 100 * 326.7, 1)
    gauge_gap = round(326.7 - gauge_dash, 1)
    health_factors = [
        {"label": "SLA compliance", "score": round(s_sla), "weight": "40%"},
        {"label": "Backlog flow",   "score": round(s_backlog), "weight": "25%"},
        {"label": "Escalations",    "score": round(s_escal), "weight": "20%"},
        {"label": "Aging",          "score": round(s_aging), "weight": "15%"},
    ]

    # ---- Auto insights ----
    insights = []
    if net_flow_p > 0:
        insights.append({"level": "warning", "title": "Backlog is growing",
            "body": f"{len(created_p)} created vs {len(resolved_p)} resolved in the last {period_label} (net +{net_flow_p}). Resolution isn't keeping pace with intake."})
    elif net_flow_p < 0:
        insights.append({"level": "positive", "title": "Backlog is burning down",
            "body": f"{len(resolved_p)} resolved vs {len(created_p)} created in the last {period_label} (net {net_flow_p})."})
    if forecast["breaches_48h"]:
        insights.append({"level": "warning", "title": f"{forecast['breaches_48h']} breach{'es' if forecast['breaches_48h']!=1 else ''} forecast in 48h",
            "body": f"{forecast['breaches_48h']} open ticket{'s are' if forecast['breaches_48h']!=1 else ' is'} due to breach SLA within the next two days."})
    if breached:
        insights.append({"level": "critical", "title": f"{len(breached)} ticket{'s' if len(breached)!=1 else ''} past SLA",
            "body": f"{len(breached)} open ticket{'s have' if len(breached)!=1 else ' has'} already breached, with {len(at_risk)} at risk within 8 hours."})
    wt = next((r for r in team_rows if r["sla_pct"] < 60 and (r["critical"] or r["at_risk"])), None)
    if wt:
        insights.append({"level": "critical", "title": f"{wt['name']} needs attention",
            "body": f"{wt['name']} has {wt['critical']} critical and {wt['at_risk']} at-risk tickets, SLA at {wt['sla_pct']}%."})
    s1 = next((m for m in mttr_by_sev if m["key"] == "sev1" and m["over"]), None)
    if s1:
        insights.append({"level": "warning", "title": "Sev 1 resolution is slow",
            "body": f"Sev 1 MTTR is {s1['actual']}h against a {s1['target']}h target (p90 across all sev: {cycle['p90']}h)."})
    ov = next((o for o in owners if o["overloaded"]), None)
    if ov:
        insights.append({"level": "warning", "title": f"{ov['username']} is overloaded",
            "body": f"{ov['username']} holds {ov['n']} open tickets — {ov['share']}% of all active work. Consider rebalancing."})
    if backlog_outlook["state"] == "clearing":
        insights.append({"level": "positive", "title": "Backlog on track to clear",
            "body": f"At the current burn rate the open backlog clears in about {backlog_outlook['weeks']} weeks."})
    if auto["runs"]:
        insights.append({"level": "positive", "title": "Agents are carrying load",
            "body": f"Autonomous agents ran {auto['runs']} times across {auto['tickets_touched']} tickets — ~{auto['minutes_saved']} analyst-minutes saved."})
    order = {"critical": 0, "warning": 1, "info": 2, "positive": 3}
    insights.sort(key=lambda x: order.get(x["level"], 9))
    insights = insights[:5]

    exec_kpis = {
        "open": len(open_tickets), "sla_all": sla_all, "sla_p": sla_p, "sla_pp": sla_pp,
        "breached": len(breached), "at_risk": len(at_risk),
        "mttr_all": mttr_all, "mttr_p": mttr_p, "mttr_pp": mttr_pp,
        "created": delta(len(created_p), len(created_pp)),
        "resolved": delta(len(resolved_p), len(resolved_pp)),
        "net_flow_p": net_flow_p, "net_flow_pp": net_flow_pp,
        "escalations": len(escalations), "unassigned": len(unassigned),
    }

    # ---- Per-project portfolio rollup (only when viewing all projects) ----
    project_rows = []
    if not active_project:
        proj_ids = {t.project_id for t in tickets if t.project_id}
        id_to_proj = {p.id: p for p in Project.objects.filter(id__in=proj_ids)}
        for pid in proj_ids:
            proj = id_to_proj.get(pid)
            if not proj:
                continue
            pt = [t for t in tickets if t.project_id == pid]
            pt_open = [t for t in pt if is_open(t)]
            pt_rs = [t for t in pt if t.resolved_at and t.sla_due_at]
            pt_met = [t for t in pt_rs if t.resolved_at <= t.sla_due_at]
            crit = sum(1 for t in pt_open if t.severity in ("sev1", "sev2"))
            risk = sum(1 for t in pt_open if sla_state(t) in ("breached", "at_risk"))
            sla_pct = round(len(pt_met) / len(pt_rs) * 100) if pt_rs else 100
            ph = round(0.6 * sla_pct + 0.4 * max(0, 100 - crit * 12))
            phs = "Healthy" if ph >= 80 else ("Watch" if ph >= 60 else "At risk")
            project_rows.append({
                "id": pid, "key": proj.key, "name": proj.name,
                "open": len(pt_open), "critical": crit, "at_risk": risk,
                "resolved_p": sum(1 for t in pt if in_window(t.resolved_at, p_start, now)),
                "sla_pct": sla_pct, "health": ph, "hstatus": phs,
                "last_synced_at": proj.last_synced_at,
            })
        project_rows.sort(key=lambda r: (r["health"], -r["critical"]))

    return render(request, "aegis/dashboard.html", {
        "range_key": range_key, "period_label": period_label,
        "ranges": [("7", "7 days"), ("30", "30 days"), ("90", "90 days")],
        "project_options": project_options, "project_filter": project_filter,
        "active_project": active_project, "project_rows": project_rows,
        "health": health, "grade": grade, "hstatus": hstatus,
        "health_trend": health_trend, "prior_health": prior_health,
        "gauge_dash": gauge_dash, "gauge_gap": gauge_gap,
        "health_factors": health_factors, "insights": insights,
        "exec_kpis": exec_kpis, "cycle": cycle, "forecast": forecast,
        "team_rows": team_rows, "weeks": weeks, "mttr_by_sev": mttr_by_sev,
        "aging_dist": aging_dist, "stale_count": stale_count,
        "status_stuck": status_stuck, "hotspots": hotspots,
        "watchlist_rows": watchlist_rows, "owners": owners, "auto": auto,
        "is_admin_user": True,
    })



@login_required
def projects(request):
    """Project configuration — admin only."""
    from .models import Project
    from django.db.models import Count
    if not is_admin(request.user):
        raise Http404()
    qs = (Project.objects.annotate(ticket_count=Count("tickets"))
          .order_by("-sync_enabled", "discovered", "name"))
    projects = list(qs)
    enabled = [p for p in projects if p.sync_enabled]
    discovered = [p for p in projects if p.discovered and not p.sync_enabled]
    disabled = [p for p in projects if not p.sync_enabled and not p.discovered]
    return render(request, "aegis/projects.html", {
        "projects": projects, "enabled": enabled, "discovered": discovered,
        "disabled": disabled, "source_choices": Project.Source.choices,
        "require_configured": getattr(conf, "SYNC_REQUIRE_CONFIGURED_PROJECT", True),
        "is_admin_user": True,
    })


@login_required
@require_POST
def project_toggle(request, project_id):
    from .models import Project
    if not is_admin(request.user):
        raise Http404()
    project = get_object_or_404(Project, id=project_id)
    project.sync_enabled = not project.sync_enabled
    if project.sync_enabled:
        project.discovered = False
    project.save(update_fields=["sync_enabled", "discovered", "updated_at"])
    return render(request, "aegis/partials/project_row.html",
                  {"p": project, "ticket_count": project.tickets.count()})


@login_required
def project_form(request, project_id=None):
    from .models import Project
    if not is_admin(request.user):
        raise Http404()
    project = get_object_or_404(Project, id=project_id) if project_id else None
    if request.method == "POST":
        key = (request.POST.get("key") or "").strip().upper()
        name = (request.POST.get("name") or "").strip()
        source = request.POST.get("source") or Project.Source.MANUAL
        external_key = (request.POST.get("external_key") or "").strip()
        default_team = (request.POST.get("default_team") or "").strip()
        description = (request.POST.get("description") or "").strip()
        sync_enabled = request.POST.get("sync_enabled") == "on"
        if not key or not name:
            messages.error(request, "Key and name are required.")
        else:
            dup = Project.objects.filter(key__iexact=key)
            if project:
                dup = dup.exclude(id=project.id)
            if dup.exists():
                messages.error(request, f"A project with key '{key}' already exists.")
            else:
                if project is None:
                    project = Project(key=key)
                project.key = key; project.name = name; project.source = source
                project.external_key = external_key; project.default_team = default_team
                project.description = description; project.sync_enabled = sync_enabled
                if sync_enabled:
                    project.discovered = False
                project.save()
                messages.success(request, f"Saved project {key}.")
                return redirect("aegis:projects")
    return render(request, "aegis/project_form.html", {
        "project": project, "source_choices": Project.Source.choices,
        "is_admin_user": True,
    })




# ---- Per-user AI configuration ----

@login_required
def ai_settings(request):
    """Each user manages their own AI + Jira credentials here."""
    from .models import UserAIConfig
    cfg, _ = UserAIConfig.objects.get_or_create(user=request.user)

    if request.method == "POST":
        cfg.provider = request.POST.get("provider") or cfg.provider
        cfg.model_name = (request.POST.get("model_name") or "").strip() or cfg.model_name
        api_key = (request.POST.get("api_key") or "").strip()
        if api_key and api_key != "__unchanged__":
            cfg.set_api_key(api_key)
        # Optional Jira write-back creds
        cfg.jira_base_url = (request.POST.get("jira_base_url") or "").strip()
        cfg.jira_email = (request.POST.get("jira_email") or "").strip()
        jira_token = (request.POST.get("jira_token") or "").strip()
        if jira_token and jira_token != "__unchanged__":
            cfg.set_jira_token(jira_token)
        # Clearing the key
        if request.POST.get("clear_api_key") == "on":
            cfg.api_key_enc = ""
        cfg.save()
        messages.success(request, "AI settings saved." +
                         ("" if cfg.is_configured else " Add an API key to enable the agents."))
        return redirect("aegis:ai_settings")

    return render(request, "aegis/ai_settings.html", {
        "cfg": cfg,
        "provider_choices": UserAIConfig.Provider.choices,
        "require_cfg": getattr(conf, "REQUIRE_USER_AI_CONFIG", True),
        "mock_mode": conf.MOCK_GEMINI,
    })


# ---- Outbound ticket actions (Jira write-back + customer email) ----

@login_required
@require_POST
def action_push_description(request, ticket_id):
    """Push the AI-enhanced description back to the source (Jira) issue."""
    from .models import TicketAction
    from .services.jira_client import JiraClient
    ticket = _check_ticket_access(request, ticket_id)

    description = ticket.description_enhanced or ""
    if not description:
        return _htmx_error("No AI-enhanced description yet. Run 'Enhance' first.")

    issue_key = ticket.source_id or ticket.id.hex[:8].upper()
    client = JiraClient.for_user(request.user)
    result = client.update_description(issue_key, description)

    action = TicketAction.objects.create(
        ticket=ticket, user=request.user,
        kind=TicketAction.Kind.PUSH_DESCRIPTION,
        status=(TicketAction.Status.MOCK if result.mock else
                TicketAction.Status.SUCCESS if result.ok else TicketAction.Status.FAILED),
        detail=result.detail,
        payload={"issue_key": issue_key, "chars": len(description)},
    )
    return render(request, "aegis/partials/action_result.html",
                  {"action": action, "result": result, "label": "Description pushed to Jira"})


@login_required
@require_POST
def action_post_steps(request, ticket_id):
    """Post the resolution steps (resolver plan) as a Jira comment."""
    from .models import TicketAction
    from .services.jira_client import JiraClient
    ticket = _check_ticket_access(request, ticket_id)

    # Build the steps text from the action plan
    plan = ticket.plan_payload or {}
    actions = plan.get("actions") or []
    if not actions:
        return _htmx_error("No resolution plan yet. Run 'Plan' or the agent pipeline first.")

    lines = ["*Resolution steps (AI-generated, reviewed by " + request.user.get_username() + "):*", ""]
    for i, a in enumerate(actions, 1):
        title = a.get("title", "Step")
        desc = a.get("description", "")
        pr = a.get("priority", "")
        lines.append(f"{i}. [{pr}] {title} — {desc}")
    steps_text = "\n".join(lines)

    issue_key = ticket.source_id or ticket.id.hex[:8].upper()
    client = JiraClient.for_user(request.user)
    result = client.add_comment(issue_key, steps_text)

    action = TicketAction.objects.create(
        ticket=ticket, user=request.user,
        kind=TicketAction.Kind.POST_COMMENT,
        status=(TicketAction.Status.MOCK if result.mock else
                TicketAction.Status.SUCCESS if result.ok else TicketAction.Status.FAILED),
        detail=result.detail,
        payload={"issue_key": issue_key, "steps": steps_text},
    )
    return render(request, "aegis/partials/action_result.html",
                  {"action": action, "result": result, "label": "Resolution steps posted as comment",
                   "preview": steps_text})


@login_required
@require_POST
def action_customer_email(request, ticket_id):
    """Generate a customer-facing communication email (draft for review)."""
    from .models import TicketAction
    from .services.comms import generate_customer_email
    ticket = _check_ticket_access(request, ticket_id)

    try:
        email, meta = generate_customer_email(ticket, user=request.user)
    except AIConfigRequired:
        return _htmx_config_required(request)
    except Exception as e:
        log.exception("customer_email.failed")
        return _htmx_error(f"Email generation failed: {e}")

    action = TicketAction.objects.create(
        ticket=ticket, user=request.user,
        kind=TicketAction.Kind.CUSTOMER_EMAIL,
        status=TicketAction.Status.SUCCESS,
        detail="Draft generated",
        payload={"subject": email.subject, "body": email.body, "tone": email.tone},
    )
    return render(request, "aegis/partials/customer_email.html",
                  {"email": email, "action": action, "ticket": ticket})


def _agent_runs_for(ticket):
    """Return the most recent agent runs for a ticket, with per-step detail prefetched."""
    runs = list(ticket.agent_runs.order_by("-started_at").prefetch_related("steps")[:5])
    for r in runs:
        final = (r.output or {}).get("final") or {}
        r.recommended_actions = final.get("recommended_actions") or []
        r.recommended_severity = final.get("recommended_severity")
        r.recommended_confidence = final.get("confidence")
        r.summary = final.get("summary") or ""
        r.ordered_steps = list(r.steps.order_by("seq"))
    return runs


# ---- CSV upload ----

@login_required
def csv_upload(request):
    if request.method == "POST":
        form = CSVUploadForm(request.POST, request.FILES)
        if form.is_valid():
            content = form.cleaned_data["file"].read()
            conn = CSVConnector(content=content)
            ai = form.cleaned_data["run_ai"]

            tickets, report = ingest(conn.fetch())
            for ticket in tickets:
                if not request.user.is_staff and ticket.owner_id is None:
                    ticket.owner = request.user
                    ticket.save(update_fields=["owner"])
                if ai:
                    try:
                        _maybe_run_ai(ticket, user=request.user)
                    except Exception:
                        log.exception("csv.ai_failed")

            msg = f"Imported {report.imported} new, updated {report.updated}."
            skipped = report.skipped_disabled + report.skipped_discovered
            if skipped:
                msg += f" Skipped {skipped} from unconfigured/disabled projects"
                if report.discovered_projects:
                    msg += f" ({', '.join(report.discovered_projects)} — enable in Projects to sync)"
                msg += "."
            messages.success(request, msg)
            return redirect("aegis:queue")
    else:
        form = CSVUploadForm()
    return render(request, "aegis/csv_upload.html", {"form": form})


# ---- Helpers ----

def _htmx_error(msg: str) -> HttpResponse:
    return HttpResponse(
        f'<div class="rounded-md bg-red-50 border border-red-200 p-3 text-sm text-red-700">{msg}</div>',
        status=200,  # 200 so HTMX swaps the message in
    )
