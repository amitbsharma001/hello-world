from __future__ import annotations
import json
import logging
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.views.decorators.http import require_http_methods, require_POST, require_GET
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpResponse, JsonResponse, Http404
from django.db.models import Q
from django.utils import timezone

from .models import Ticket, AIArtifact
from .forms import TicketForm, CSVUploadForm
from .conf import conf
from .services import enhance_description, generate_plan, detect_missing_info
from .services.sla import score as sla_score, status_label
from .connectors.base import upsert_raw
from .connectors.csv_connector import CSVConnector
from .perms import filter_for_user, can_view, is_admin

log = logging.getLogger("aegis.views")


def _maybe_run_ai(ticket: Ticket):
    """Run AI analysis. In production with USE_CELERY, this would enqueue."""
    if conf.USE_CELERY:
        from . import tasks
        tasks.run_full_analysis.delay(str(ticket.id))
    else:
        try:
            enhance_description(ticket)
            ticket.refresh_from_db()
            generate_plan(ticket)
            detect_missing_info(ticket)
        except Exception as e:
            log.exception("aegis.ai.failed")
            messages.error(
                None,  # noop in non-request context; will surface in view
                f"AI analysis failed: {e}",
            )


# ---- Queue ----

@login_required
def queue(request):
    qs = filter_for_user(Ticket.objects.all(), request.user)

    q = request.GET.get("q", "").strip()
    status = request.GET.get("status", "")
    sev = request.GET.get("sev", "")
    team = request.GET.get("team", "")

    if q:
        qs = qs.filter(Q(title__icontains=q) | Q(description_raw__icontains=q))
    if status:
        qs = qs.filter(status=status)
    if sev:
        qs = qs.filter(severity=sev)
    if team:
        qs = qs.filter(team__icontains=team)

    tickets = list(qs[:conf.TICKET_LIST_PAGE_SIZE * 2])
    annotated = []
    for t in tickets:
        s = sla_score(t)
        annotated.append({"t": t, "s": s, "label": status_label(s)})
    annotated.sort(key=lambda x: x["s"]["operational_priority"], reverse=True)
    annotated = annotated[: conf.TICKET_LIST_PAGE_SIZE]

    context = {
        "tickets": annotated,
        "q": q,
        "status": status,
        "sev": sev,
        "team": team,
        "status_choices": Ticket.Status.choices,
        "severity_choices": Ticket.Severity.choices,
        "total": qs.count(),
        "open_count": qs.exclude(status__in=["resolved", "closed"]).count(),
        "critical_count": sum(1 for x in annotated if x["label"] == "critical"),
        "is_admin_user": is_admin(request.user),
    }
    return render(request, "aegis/queue.html", context)


# ---- Detail ----

@login_required
def detail(request, ticket_id):
    ticket = get_object_or_404(Ticket, id=ticket_id)
    if not can_view(request.user, ticket):
        raise Http404("Ticket not found")
    s = sla_score(ticket)
    context = {
        "ticket": ticket,
        "score": s,
        "label": status_label(s),
        "enhanced": ticket.enhanced_payload,
        "plan": ticket.plan_payload,
        "missing": ticket.missing_info_payload,
        "history": ticket.history.all()[:20],
        "artifacts": ticket.artifacts.all()[:10],
        "is_admin_user": is_admin(request.user),
        "runs": _agent_runs_for(ticket),
    }
    return render(request, "aegis/ticket_detail.html", context)


# ---- Create ----

@login_required
def create(request):
    if request.method == "POST":
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.source = "manual"
            ticket.owner = request.user
            ticket.opened_at = timezone.now()
            ticket.save()
            run_ai = request.POST.get("run_ai") == "on"
            if run_ai:
                _maybe_run_ai(ticket)
                ticket.refresh_from_db()
            messages.success(request, "Ticket created.")
            return redirect("aegis:detail", ticket_id=ticket.id)
    else:
        form = TicketForm()
    return render(request, "aegis/ticket_form.html", {"form": form})


# ---- AI actions (HTMX endpoints) ----

def _check_ticket_access(request, ticket_id):
    """Get ticket if user can access it, else 404."""
    ticket = get_object_or_404(Ticket, id=ticket_id)
    if not can_view(request.user, ticket):
        raise Http404("Ticket not found")
    return ticket


@login_required
@require_POST
def action_enhance(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        enhance_description(ticket, force=True)
        ticket.refresh_from_db()
    except Exception as e:
        log.exception("enhance.failed")
        return _htmx_error(f"Enhancement failed: {e}")
    return render(request, "aegis/partials/enhanced_panel.html", {"ticket": ticket})


@login_required
@require_POST
def action_plan(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        generate_plan(ticket, force=True)
        ticket.refresh_from_db()
    except Exception as e:
        log.exception("plan.failed")
        return _htmx_error(f"Plan generation failed: {e}")
    return render(request, "aegis/partials/plan_panel.html", {"ticket": ticket, "plan": ticket.plan_payload})


@login_required
@require_POST
def action_missing(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        detect_missing_info(ticket, force=True)
        ticket.refresh_from_db()
    except Exception as e:
        log.exception("missing.failed")
        return _htmx_error(f"Missing-info detection failed: {e}")
    return render(request, "aegis/partials/missing_panel.html", {"ticket": ticket, "missing": ticket.missing_info_payload})


@login_required
@require_POST
def action_run_all(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    try:
        enhance_description(ticket, force=True)
        ticket.refresh_from_db()
        generate_plan(ticket, force=True)
        detect_missing_info(ticket, force=True)
        ticket.refresh_from_db()
    except Exception as e:
        log.exception("run_all.failed")
        return _htmx_error(f"AI run failed: {e}")
    response = HttpResponse(status=204)
    response["HX-Redirect"] = reverse("aegis:detail", args=[str(ticket.id)])
    return response


@login_required
@require_POST
def action_status(request, ticket_id):
    ticket = _check_ticket_access(request, ticket_id)
    new_status = request.POST.get("status")
    if new_status in dict(Ticket.Status.choices):
        ticket.status = new_status
        if new_status == Ticket.Status.RESOLVED and not ticket.resolved_at:
            ticket.resolved_at = timezone.now()
        ticket.save()
    return render(request, "aegis/partials/status_pill.html", {"ticket": ticket})


# ---- Agent actions (autonomous reasoning) ----

@login_required
@require_POST
def action_run_agent(request, ticket_id, agent_name):
    """Manually trigger a specific named agent on a ticket."""
    from .agents import run_named
    ticket = _check_ticket_access(request, ticket_id)
    try:
        run_named(agent_name, ticket, trigger="manual")
        ticket.refresh_from_db()
    except Exception as e:
        log.exception("agent.run_failed")
        return _htmx_error(f"Agent run failed: {e}")
    return render(request, "aegis/partials/agent_timeline.html",
                  {"ticket": ticket, "runs": _agent_runs_for(ticket)})


@login_required
@require_POST
def action_run_pipeline(request, ticket_id):
    """Run the full multi-agent pipeline (Triage -> maybe Investigator -> Resolver)."""
    from .agents import run_pipeline
    ticket = _check_ticket_access(request, ticket_id)
    try:
        run_pipeline(ticket, trigger="manual_pipeline")
        ticket.refresh_from_db()
    except Exception as e:
        log.exception("pipeline.failed")
        return _htmx_error(f"Pipeline failed: {e}")
    return render(request, "aegis/partials/agent_timeline.html",
                  {"ticket": ticket, "runs": _agent_runs_for(ticket)})


@login_required
def agents_inbox(request):
    """Org-wide feed of recent agent runs. Admins see all; users see only theirs."""
    from .models import AgentRun
    qs = AgentRun.objects.select_related("ticket").order_by("-started_at")
    if not is_admin(request.user):
        qs = qs.filter(ticket__owner=request.user)
    runs = list(qs[:50])
    # Pull recommended actions out of each run
    for r in runs:
        final = (r.output or {}).get("final") or {}
        r.recommended_actions = final.get("recommended_actions") or []
        r.recommended_severity = final.get("recommended_severity")
        r.summary = final.get("summary") or ""
        r.steps_count = r.steps.count()
    return render(request, "aegis/agents_inbox.html", {
        "runs": runs,
        "is_admin_user": is_admin(request.user),
    })


def _agent_runs_for(ticket):
    """Return the most recent agent runs for a ticket, with per-step detail prefetched."""
    runs = list(ticket.agent_runs.order_by("-started_at").prefetch_related("steps")[:5])
    for r in runs:
        final = (r.output or {}).get("final") or {}
        r.recommended_actions = final.get("recommended_actions") or []
        r.recommended_severity = final.get("recommended_severity")
        r.recommended_confidence = final.get("confidence")
        r.summary = final.get("summary") or ""
        r.ordered_steps = list(r.steps.order_by("seq"))
    return runs


# ---- CSV upload ----

@login_required
def csv_upload(request):
    if request.method == "POST":
        form = CSVUploadForm(request.POST, request.FILES)
        if form.is_valid():
            content = form.cleaned_data["file"].read()
            conn = CSVConnector(content=content)
            created = 0
            updated = 0
            ai = form.cleaned_data["run_ai"]
            for raw in conn.fetch():
                ticket, was_created, _ = upsert_raw(raw)
                if was_created:
                    # CSV imports are owned by the importing user unless they're staff
                    # (staff imports are unowned — visible to all staff)
                    if not request.user.is_staff:
                        ticket.owner = request.user
                        ticket.save(update_fields=["owner"])
                    created += 1
                    if ai:
                        try:
                            _maybe_run_ai(ticket)
                        except Exception:
                            log.exception("csv.ai_failed")
                else:
                    updated += 1
            messages.success(request, f"Imported {created} new, updated {updated}.")
            return redirect("aegis:queue")
    else:
        form = CSVUploadForm()
    return render(request, "aegis/csv_upload.html", {"form": form})


# ---- Helpers ----

def _htmx_error(msg: str) -> HttpResponse:
    return HttpResponse(
        f'<div class="rounded-md bg-red-50 border border-red-200 p-3 text-sm text-red-700">{msg}</div>',
        status=200,  # 200 so HTMX swaps the message in
    )
