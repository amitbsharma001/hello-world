"""django-aegis — AI-powered ticket operations sub-app."""
__version__ = "0.1.0"
default_app_config = "aegis.apps.AegisConfig"
