from django.urls import path, include
from rest_framework.routers import DefaultRouter

from . import views
from .api import TicketViewSet
from .conf import conf

app_name = "aegis"

router = DefaultRouter()
router.register(r"tickets", TicketViewSet, basename="ticket")

urlpatterns = []

if conf.ENABLE_UI:
    urlpatterns += [
        path("", views.home, name="home"),
        path("workspace/", views.queue, name="queue"),
        path("my/", views.my_work, name="my_work"),
        path("new/", views.create, name="create"),
        path("upload/", views.csv_upload, name="csv_upload"),
        path("agents/", views.agents_inbox, name="agents_inbox"),
        path("dashboard/", views.dashboard, name="dashboard"),
        path("projects/", views.projects, name="projects"),
        path("projects/new/", views.project_form, name="project_create"),
        path("projects/<uuid:project_id>/edit/", views.project_form, name="project_edit"),
        path("projects/<uuid:project_id>/toggle/", views.project_toggle, name="project_toggle"),
        path("teams/", views.teams, name="teams"),
        path("teams/import/", views.team_import, name="team_import"),
        path("teams/new/", views.team_form, name="team_create"),
        path("teams/<uuid:member_id>/edit/", views.team_form, name="team_edit"),
        path("teams/<uuid:member_id>/toggle/", views.team_toggle, name="team_toggle"),
        path("sync/", views.sync_now, name="sync"),
        path("sync/run/", views.sync_run, name="sync_run"),
        path("t/<uuid:ticket_id>/", views.detail, name="detail"),
        path("t/<uuid:ticket_id>/enhance/", views.action_enhance, name="action_enhance"),
        path("t/<uuid:ticket_id>/plan/", views.action_plan, name="action_plan"),
        path("t/<uuid:ticket_id>/missing/", views.action_missing, name="action_missing"),
        path("t/<uuid:ticket_id>/run-all/", views.action_run_all, name="action_run_all"),
        path("t/<uuid:ticket_id>/status/", views.action_status, name="action_status"),
        path("t/<uuid:ticket_id>/agent/<str:agent_name>/", views.action_run_agent, name="action_run_agent"),
        path("t/<uuid:ticket_id>/pipeline/", views.action_run_pipeline, name="action_run_pipeline"),
        path("t/<uuid:ticket_id>/push-description/", views.action_push_description, name="action_push_description"),
        path("t/<uuid:ticket_id>/post-steps/", views.action_post_steps, name="action_post_steps"),
        path("t/<uuid:ticket_id>/customer-email/", views.action_customer_email, name="action_customer_email"),
        path("settings/ai/", views.ai_settings, name="ai_settings"),
        path("escalations/", views.escalations, name="escalations"),
        path("escalations/new/", views.escalation_new, name="escalation_new"),
        path("escalations/<uuid:esc_id>/", views.escalation_detail, name="escalation_detail"),
        path("escalations/<uuid:esc_id>/items/", views.escalation_items_update, name="escalation_items_update"),
        path("escalations/<uuid:esc_id>/close/", views.escalation_close, name="escalation_close"),
    ]

if conf.ENABLE_REST_API:
    urlpatterns += [
        path("api/", include(router.urls)),
    ]
