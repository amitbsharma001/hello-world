from django.urls import path, include
from rest_framework.routers import DefaultRouter

from . import views
from .api import TicketViewSet
from .conf import conf

app_name = "aegis"

router = DefaultRouter()
router.register(r"tickets", TicketViewSet, basename="ticket")

urlpatterns = []

if conf.ENABLE_UI:
    urlpatterns += [
        path("", views.queue, name="queue"),
        path("new/", views.create, name="create"),
        path("upload/", views.csv_upload, name="csv_upload"),
        path("agents/", views.agents_inbox, name="agents_inbox"),
        path("t/<uuid:ticket_id>/", views.detail, name="detail"),
        path("t/<uuid:ticket_id>/enhance/", views.action_enhance, name="action_enhance"),
        path("t/<uuid:ticket_id>/plan/", views.action_plan, name="action_plan"),
        path("t/<uuid:ticket_id>/missing/", views.action_missing, name="action_missing"),
        path("t/<uuid:ticket_id>/run-all/", views.action_run_all, name="action_run_all"),
        path("t/<uuid:ticket_id>/status/", views.action_status, name="action_status"),
        path("t/<uuid:ticket_id>/agent/<str:agent_name>/", views.action_run_agent, name="action_run_agent"),
        path("t/<uuid:ticket_id>/pipeline/", views.action_run_pipeline, name="action_run_pipeline"),
    ]

if conf.ENABLE_REST_API:
    urlpatterns += [
        path("api/", include(router.urls)),
    ]
