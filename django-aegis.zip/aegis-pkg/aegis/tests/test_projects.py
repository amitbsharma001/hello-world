"""Tests for project configuration + sync gating."""
import pytest
from aegis.models import Project, Ticket
from aegis.services.sync_gate import resolve_project, SyncReport
from aegis.connectors.base import RawTicket, ingest
from aegis.conf import conf


@pytest.fixture
def enabled_project(db):
    return Project.objects.create(key="PAY", name="Payments", external_key="PAY",
                                  source=Project.Source.JIRA, sync_enabled=True)


@pytest.fixture
def disabled_project(db):
    return Project.objects.create(key="OLD", name="Legacy", external_key="OLD",
                                  source=Project.Source.JIRA, sync_enabled=False)


# ---- resolve_project ----

@pytest.mark.django_db
def test_enabled_project_is_allowed(enabled_project):
    d = resolve_project("jira", "PAY")
    assert d.allowed is True
    assert d.project == enabled_project
    assert d.reason == "enabled"


@pytest.mark.django_db
def test_disabled_project_is_blocked(disabled_project):
    d = resolve_project("jira", "OLD")
    assert d.allowed is False
    assert d.reason == "disabled"


@pytest.mark.django_db
def test_unknown_project_auto_registers_as_discovered():
    assert Project.objects.filter(key="NEW").count() == 0
    d = resolve_project("jira", "NEW", auto_register=True)
    assert d.allowed is False
    assert d.reason == "discovered"
    p = Project.objects.get(key="NEW")
    assert p.sync_enabled is False
    assert p.discovered is True


@pytest.mark.django_db
def test_unknown_project_without_autoregister_is_unconfigured():
    d = resolve_project("jira", "GHOST", auto_register=False)
    assert d.allowed is False
    assert d.reason == "unconfigured"
    assert Project.objects.filter(key="GHOST").count() == 0


@pytest.mark.django_db
def test_no_key_is_unconfigured():
    d = resolve_project("jira", "")
    assert d.allowed is False
    assert d.reason == "unconfigured"


@pytest.mark.django_db
def test_matches_by_external_key(enabled_project):
    d = resolve_project("jira", "pay")
    assert d.allowed is True
    assert d.project == enabled_project


@pytest.mark.django_db
def test_open_mode_allows_everything(monkeypatch):
    monkeypatch.setattr(conf, "SYNC_REQUIRE_CONFIGURED_PROJECT", False, raising=False)
    d = resolve_project("jira", "WHATEVER")
    assert d.allowed is True
    assert d.reason == "open"


# ---- gated ingest ----

@pytest.mark.django_db
def test_ingest_only_enabled_projects(enabled_project, disabled_project):
    raws = [
        RawTicket(source="jira", source_id="P-1", title="pay issue", project="PAY"),
        RawTicket(source="jira", source_id="O-1", title="old issue", project="OLD"),
        RawTicket(source="jira", source_id="N-1", title="new issue", project="BRAND_NEW"),
    ]
    tickets, report = ingest(raws)
    assert report.imported == 1
    assert Ticket.objects.filter(source_id="P-1").count() == 1
    assert Ticket.objects.filter(source_id="O-1").count() == 0
    assert Ticket.objects.filter(source_id="N-1").count() == 0
    assert report.skipped_disabled == 1
    assert report.skipped_discovered == 1
    assert "BRAND_NEW" in report.discovered_projects


@pytest.mark.django_db
def test_ingest_sets_project(enabled_project):
    raws = [RawTicket(source="jira", source_id="P-9", title="x", project="PAY")]
    tickets, report = ingest(raws)
    assert tickets[0].project == enabled_project


@pytest.mark.django_db
def test_ingest_stamps_last_synced(enabled_project):
    assert enabled_project.last_synced_at is None
    ingest([RawTicket(source="jira", source_id="P-2", title="y", project="PAY")])
    enabled_project.refresh_from_db()
    assert enabled_project.last_synced_at is not None


# ---- projects config views ----

@pytest.mark.django_db
def test_projects_page_admin_ok(admin_client, enabled_project):
    r = admin_client.get("/projects/")
    assert r.status_code == 200
    assert b"Project configuration" in r.content
    assert b"PAY" in r.content


@pytest.mark.django_db
def test_projects_page_user_blocked(alice_client, enabled_project):
    r = alice_client.get("/projects/")
    assert r.status_code == 404


@pytest.mark.django_db
def test_project_toggle(admin_client, enabled_project):
    assert enabled_project.sync_enabled is True
    r = admin_client.post(f"/projects/{enabled_project.id}/toggle/")
    assert r.status_code == 200
    enabled_project.refresh_from_db()
    assert enabled_project.sync_enabled is False


@pytest.mark.django_db
def test_project_toggle_enabling_clears_discovered(admin_client):
    p = Project.objects.create(key="DISC", name="Discovered", sync_enabled=False, discovered=True)
    admin_client.post(f"/projects/{p.id}/toggle/")
    p.refresh_from_db()
    assert p.sync_enabled is True
    assert p.discovered is False


@pytest.mark.django_db
def test_project_create(admin_client):
    r = admin_client.post("/projects/new/", {
        "key": "newproj", "name": "New Project", "source": "jira",
        "external_key": "NP", "default_team": "Platform", "sync_enabled": "on",
    })
    assert r.status_code == 302
    p = Project.objects.get(key="NEWPROJ")
    assert p.name == "New Project"
    assert p.sync_enabled is True


@pytest.mark.django_db
def test_project_create_rejects_duplicate_key(admin_client, enabled_project):
    r = admin_client.post("/projects/new/", {
        "key": "PAY", "name": "Dup", "source": "jira", "sync_enabled": "on",
    })
    assert r.status_code == 200
    assert Project.objects.filter(key="PAY").count() == 1


@pytest.mark.django_db
def test_dashboard_project_filter(admin_client, enabled_project):
    Ticket.objects.create(source="demo", title="pay one", project=enabled_project,
                          severity="sev2", status="open")
    Ticket.objects.create(source="demo", title="orphan", severity="sev3", status="open")
    r = admin_client.get(f"/dashboard/?project={enabled_project.id}")
    assert r.status_code == 200
    assert b"Scoped to PAY" in r.content
