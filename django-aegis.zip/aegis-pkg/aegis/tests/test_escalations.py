"""Tests for bulk escalations (services/escalations.py + views).

The recipient-resolution and lifecycle-transition logic is pure and tested
without the DB; creation/sending/views are Django tests (run locally with
`make verify` — they use the locmem email backend).
"""
import pytest

from aegis.services.escalations import (
    looks_like_email, resolve_recipient, can_transition, ITEM_TRANSITIONS,
)


# ---- pure: recipient resolution -------------------------------------------

def test_looks_like_email():
    assert looks_like_email("a@b.com")
    assert not looks_like_email("5f8a-accountid")
    assert not looks_like_email("a@b")          # no TLD dot
    assert not looks_like_email("a b@c.com")    # space
    assert not looks_like_email("")
    assert not looks_like_email(None)


def test_resolve_direct_email_assignee():
    email, why = resolve_recipient("Priya@Org.com", {})
    assert email == "Priya@Org.com" and "email" in why


def test_resolve_via_team_member_account():
    emails = {"5f8a-accountid": "priya@org.com"}
    email, why = resolve_recipient("5F8A-AccountId", emails)
    assert email == "priya@org.com" and "team member" in why


def test_resolve_unresolvable_is_skipped_with_reason():
    email, why = resolve_recipient("5f8a-unknown", {})
    assert email is None and "no known email" in why
    email, why = resolve_recipient("", {})
    assert email is None and "no assignee" in why


# ---- pure: lifecycle transitions -------------------------------------------

def test_transition_matrix_forward_only():
    assert can_transition("pending", "notified")
    assert can_transition("notified", "acknowledged")
    assert can_transition("acknowledged", "resolved")
    assert can_transition("pending", "resolved")       # fast-path allowed
    assert not can_transition("resolved", "pending")   # never backwards
    assert not can_transition("resolved", "acknowledged")
    assert not can_transition("cancelled", "resolved")
    assert not can_transition("nonsense", "resolved")


def test_terminal_states_have_no_exits():
    assert ITEM_TRANSITIONS["resolved"] == set()
    assert ITEM_TRANSITIONS["cancelled"] == set()


# ---- Django: creation, sending, cap ----------------------------------------

@pytest.fixture
def three_tickets(db):
    from aegis.models import Ticket, TeamMember
    TeamMember.objects.create(name="Priya", source="jira", account="priya@org.com",
                              label="Backend")
    t1 = Ticket.objects.create(title="A", description_raw="x",
                               assignee="priya@org.com", source="jira", source_id="J-1")
    t2 = Ticket.objects.create(title="B", description_raw="x",
                               assignee="no-email-id", source="jira", source_id="J-2")
    t3 = Ticket.objects.create(title="C", description_raw="x",
                               assignee="", source="jira", source_id="J-3")
    return [t1, t2, t3]


@pytest.mark.django_db
def test_create_escalation_bulk_and_skip_reasons(admin_user, three_tickets):
    from aegis.services.escalations import create_escalation
    esc = create_escalation(title="Push", message="Please update", level="l2",
                            tickets=three_tickets, user=admin_user, notify=True)
    items = {i.ticket.source_id: i for i in esc.items.all()}
    assert len(items) == 3
    assert items["J-1"].email_status == "pending" and items["J-1"].email_to == "priya@org.com"
    assert items["J-2"].email_status == "skipped" and "no known email" in items["J-2"].email_note
    assert items["J-3"].email_status == "skipped" and "no assignee" in items["J-3"].email_note


@pytest.mark.django_db
def test_send_marks_sent_and_advances_cycle(settings, admin_user, three_tickets):
    settings.EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"
    from django.core import mail
    from aegis.services.escalations import create_escalation, send_escalation_emails
    esc = create_escalation(title="Push", message="Please update", level="l2",
                            tickets=three_tickets, user=admin_user, notify=True)
    r = send_escalation_emails(esc)
    assert r["sent"] == 1 and r["failed"] == 0 and len(mail.outbox) == 1
    assert "Push" in mail.outbox[0].subject and "J-1" in mail.outbox[0].body
    item = esc.items.get(ticket__source_id="J-1")
    assert item.email_status == "sent" and item.status == "notified"
    esc.refresh_from_db()
    assert esc.status == "in_progress"


@pytest.mark.django_db
def test_escalation_cap_blocks_oversized_run(admin_user, client, settings, three_tickets):
    from aegis.models import Escalation
    settings.AEGIS = {"ESCALATION": {"MAX_TICKETS": 2}}
    client.force_login(admin_user)
    resp = client.post("/escalations/new/", {
        "action": "create", "title": "big", "message": "m", "level": "l2",
        "open_only": "on",
    })
    assert Escalation.objects.count() == 0
    assert resp.status_code == 200  # re-rendered with error message


# ---- pure: cross-system helpers (dual accounts) -----------------------------

def test_best_email_picks_first_email():
    from aegis.services.escalations import best_email
    assert best_email(["5f8a-accountid", "priya@org.com"]) == "priya@org.com"
    assert best_email(["5f8a-accountid"]) is None
    assert best_email([]) is None


def test_comment_target_decision():
    from types import SimpleNamespace as NS
    from aegis.services.escalations import comment_target
    assert comment_target(NS(source="jira", source_id="J-1"), True) == ("pending", "")
    assert comment_target(NS(source="servicenow", source_id="INC1"), True) == ("pending", "")
    st, note = comment_target(NS(source="jira", source_id="J-1"), False)
    assert st == "skipped" and "disabled" in note
    st, note = comment_target(NS(source="csv", source_id="x"), True)
    assert st == "skipped" and "csv" in note
    st, note = comment_target(NS(source="jira", source_id=""), True)
    assert st == "skipped" and "source id" in note


# ---- Django: dual accounts --------------------------------------------------

@pytest.mark.django_db
def test_email_resolves_accountid_via_other_system(admin_user):
    """A Jira accountId assignee reaches a real inbox through the member's
    ServiceNow (or any email) account — the point of dual configuration."""
    from aegis.models import Ticket, TeamMember
    from aegis.services.escalations import create_escalation
    TeamMember.objects.create(name="Priya", source="jira",
                              jira_account="5f8a-accountid",
                              servicenow_account="priya@org.com",
                              account="5f8a-accountid")
    t = Ticket.objects.create(title="A", description_raw="x", source="jira",
                              source_id="J-9", assignee="5f8a-accountid")
    esc = create_escalation(title="T", message="m", level="l2", tickets=[t],
                            user=admin_user, notify=True)
    item = esc.items.get()
    assert item.email_to == "priya@org.com"
    assert item.email_status == "pending"


@pytest.mark.django_db
def test_member_account_for_and_legacy_fallback(db):
    from aegis.models import TeamMember
    dual = TeamMember.objects.create(name="D", source="jira",
                                     jira_account="d@x.com", servicenow_account="d.sn@x.com",
                                     account="d@x.com")
    legacy = TeamMember.objects.create(name="L", source="servicenow",
                                       account="l@x.com")
    assert dual.account_for("jira") == "d@x.com"
    assert dual.account_for("servicenow") == "d.sn@x.com"
    assert legacy.account_for("servicenow") == "l@x.com"   # falls back to legacy pair
    assert legacy.account_for("jira") == ""                 # never leaks across sources


@pytest.mark.django_db
def test_comments_mock_when_no_credentials(admin_user, three_tickets):
    from aegis.models import TicketAction
    from aegis.services.escalations import create_escalation, post_escalation_comments
    esc = create_escalation(title="T", message="m", level="l2",
                            tickets=three_tickets, user=admin_user,
                            notify=False, post_to_source=True)
    r = post_escalation_comments(esc)
    # All three are jira tickets with source ids -> all attempted, all mock.
    assert r == {"posted": 0, "mock": 3, "failed": 0, "attempted": 3}
    assert esc.items.filter(comment_status="mock").count() == 3
    assert TicketAction.objects.filter(kind="post_comment", status="mock").count() == 3
    esc.refresh_from_db()
    assert esc.status == "in_progress"
