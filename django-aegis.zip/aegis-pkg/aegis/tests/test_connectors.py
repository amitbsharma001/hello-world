import pytest
from aegis.connectors.base import RawTicket, upsert_raw, registry
from aegis.connectors.csv_connector import CSVConnector
from aegis.connectors.jira import JiraConnector
from aegis.models import Ticket


def test_registry_has_builtin_connectors():
    names = registry.list()
    assert "manual" in names
    assert "jira" in names
    assert "csv" in names


def test_raw_ticket_content_hash_stable():
    a = RawTicket(source="x", title="t", description="d", status="open")
    b = RawTicket(source="x", title="t", description="d", status="open")
    assert a.content_hash() == b.content_hash()


def test_raw_ticket_content_hash_changes():
    a = RawTicket(source="x", title="t", description="d", status="open")
    b = RawTicket(source="x", title="t", description="d", status="in_progress")
    assert a.content_hash() != b.content_hash()


# ---- upsert_raw ----

@pytest.mark.django_db
def test_upsert_creates_new():
    raw = RawTicket(source="jira", source_id="PAY-1", title="bad",
                    description="things broken", status="open", severity="High")
    ticket, created, changed = upsert_raw(raw)
    assert created
    assert changed
    assert ticket.severity == "sev2"  # High -> sev2
    assert ticket.status == "open"


@pytest.mark.django_db
def test_upsert_updates_existing():
    raw = RawTicket(source="jira", source_id="PAY-2", title="bad",
                    description="thing broken", status="open")
    upsert_raw(raw)
    raw.status = "in_progress"
    raw.title = "less bad"
    t2, created2, changed2 = upsert_raw(raw)
    assert not created2
    assert changed2
    assert t2.status == "in_progress"
    assert t2.title == "less bad"
    assert Ticket.objects.filter(source="jira", source_id="PAY-2").count() == 1


@pytest.mark.django_db
def test_upsert_handles_unknown_severity():
    raw = RawTicket(source="jira", source_id="X", title="t",
                    description="d", severity="WTF")
    ticket, _, _ = upsert_raw(raw)
    assert ticket.severity == "sev3"  # default


# ---- CSV ----

CSV_INPUT = """source_id,title,description,status,severity,assignee,team,tags
T-1,API down,503 errors,open,High,jane@example.com,Payments,prod|urgent
T-2,Slow login,users report slow login,in_progress,Medium,john@example.com,Auth,latency
"""


def test_csv_connector_parses():
    conn = CSVConnector(content=CSV_INPUT)
    raws = list(conn.fetch())
    assert len(raws) == 2
    assert raws[0].source == "csv"
    assert raws[0].source_id == "T-1"
    assert raws[0].title == "API down"
    assert raws[0].tags == ["prod", "urgent"]


@pytest.mark.django_db
def test_csv_connector_upserts():
    conn = CSVConnector(content=CSV_INPUT)
    for raw in conn.fetch():
        upsert_raw(raw)
    assert Ticket.objects.filter(source="csv").count() == 2


def test_csv_empty_content():
    conn = CSVConnector(content="")
    assert list(conn.fetch()) == []


# ---- Jira (unit test only, no network) ----

def test_jira_health_check_unconfigured():
    conn = JiraConnector({})
    assert not conn.health_check()


def test_jira_adf_to_text():
    conn = JiraConnector({})
    adf = {
        "type": "doc",
        "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": "Hello "}, {"type": "text", "text": "world"}]},
            {"type": "paragraph", "content": [{"type": "text", "text": "Second line"}]},
        ],
    }
    out = conn._adf_to_text(adf)
    assert "Hello world" in out
    assert "Second line" in out


def test_jira_to_raw():
    conn = JiraConnector({"base_url": "https://x.atlassian.net"})
    issue = {
        "key": "PAY-42", "id": "10042",
        "fields": {
            "summary": "Payments down",
            "description": "broken",
            "status": {"name": "In Progress"},
            "priority": {"name": "Highest"},
            "assignee": {"emailAddress": "a@x.com"},
            "components": [{"name": "Payments"}],
            "labels": ["prod"],
            "created": "2026-01-01T10:00:00.000+0000",
            "updated": "2026-01-02T10:00:00.000+0000",
        },
    }
    raw = conn._to_raw(issue)
    assert raw.source_id == "PAY-42"
    assert raw.title == "Payments down"
    assert raw.assignee == "a@x.com"
    assert raw.team == "Payments"
    assert raw.tags == ["prod"]
    assert raw.source_url == "https://x.atlassian.net/browse/PAY-42"
