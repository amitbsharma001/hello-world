"""Tests for the rule-based team-performance signals (services/performance.py).

Pure-logic tests — pass explicit cfg so they don't depend on settings.
"""
from aegis.services.performance import (
    DEFAULTS, evaluate_member, team_rollup, build_performance,
)

CFG = dict(DEFAULTS)


def row(**kw):
    base = {"name": "X", "account": "x@x.com", "open": 0, "critical": 0,
            "at_risk": 0, "avg_age": 0, "resolved_p": 0, "created_p": 0,
            "net_flow": 0, "sla_met": 0, "sla_total": 0, "sla_pct": 100,
            "stale_open": 0}
    base.update(kw)
    return base


def codes(flags):
    return {f["code"] for f in flags}


def test_min_sample_guard_blocks_all_flags():
    r = row(open=1, resolved_p=0, created_p=0, sla_pct=0, sla_total=5, at_risk=5)
    assert evaluate_member(r, team_median_open=1, cfg=CFG) == []


def test_sla_low_fires_with_numbers_in_reason():
    r = row(open=4, resolved_p=4, sla_met=2, sla_total=4, sla_pct=50)
    flags = evaluate_member(r, 2, CFG)
    assert "sla_low" in codes(flags)
    reason = next(f for f in flags if f["code"] == "sla_low")["reason"]
    assert "50%" in reason and "70%" in reason and "2/4" in reason


def test_sla_low_needs_min_resolved_sample():
    r = row(open=4, resolved_p=2, sla_met=0, sla_total=2, sla_pct=0)
    assert "sla_low" not in codes(evaluate_member(r, 2, CFG))


def test_sla_exposure_fires_at_threshold():
    r = row(open=5, at_risk=3)
    assert "sla_exposure" in codes(evaluate_member(r, 2, CFG))
    assert "sla_exposure" not in codes(evaluate_member(row(open=5, at_risk=2), 2, CFG))


def test_backlog_growth_and_reason_math():
    r = row(open=6, created_p=7, resolved_p=4, net_flow=3)
    flags = evaluate_member(r, 3, CFG)
    assert "backlog_growth" in codes(flags)
    reason = next(f for f in flags if f["code"] == "backlog_growth")["reason"]
    assert "+3" in reason and "created 7" in reason and "resolved 4" in reason


def test_stale_tickets_flag():
    assert "stale_tickets" in codes(evaluate_member(row(open=5, stale_open=3), 3, CFG))
    assert "stale_tickets" not in codes(evaluate_member(row(open=5, stale_open=2), 3, CFG))


def test_zero_throughput():
    assert "zero_throughput" in codes(evaluate_member(row(open=3, resolved_p=0), 2, CFG))
    assert "zero_throughput" not in codes(evaluate_member(row(open=3, resolved_p=1), 2, CFG))


def test_overload_relative_to_median():
    r = row(open=8, resolved_p=1)
    assert "overload" in codes(evaluate_member(r, team_median_open=3, cfg=CFG))
    # below OVERLOAD_MIN_OPEN never flags even if relatively large
    assert "overload" not in codes(evaluate_member(row(open=4, resolved_p=1), 1, CFG))
    # zero median (empty team baseline) never divides / flags
    assert "overload" not in codes(evaluate_member(r, team_median_open=0, cfg=CFG))


def test_healthy_member_has_no_flags():
    r = row(open=3, resolved_p=5, created_p=4, net_flow=-1,
            sla_met=5, sla_total=5, sla_pct=100)
    assert evaluate_member(r, 3, CFG) == []


def test_rollup_math():
    rows = [row(name="A", open=4, critical=1, at_risk=2, resolved_p=3, created_p=5,
                net_flow=2, sla_met=2, sla_total=3, avg_age=10),
            row(name="B", open=2, resolved_p=4, created_p=2, net_flow=-2,
                sla_met=4, sla_total=4, avg_age=4)]
    ru = team_rollup(rows)
    assert ru["open"] == 6 and ru["critical"] == 1 and ru["at_risk"] == 2
    assert ru["resolved_p"] == 7 and ru["net_flow"] == 0
    assert ru["sla_pct"] == round(6 / 7 * 100)
    assert ru["active"] == 2 and ru["members"] == 2
    assert ru["median_open"] == 3 and ru["busiest"] == "A"
    # weighted avg age: (10*4 + 4*2)/6 = 8.0
    assert ru["avg_age"] == 8.0


def test_rollup_empty_and_no_sla_sample():
    assert team_rollup([])["sla_pct"] is None
    ru = team_rollup([row(open=1)])
    assert ru["sla_pct"] is None  # no resolved-with-SLA sample -> unknown, not 100


def test_build_performance_sorts_danger_first():
    danger = row(name="D", open=5, at_risk=4, resolved_p=2)
    warn = row(name="W", open=4, created_p=6, resolved_p=3, net_flow=3)
    ok = row(name="OK", open=1, resolved_p=3, sla_met=3, sla_total=3)
    perf = build_performance([ok, warn, danger], CFG)
    assert [r["name"] for r in perf["flagged"]] == ["D", "W"]
    assert perf["rollup"]["members"] == 3
    assert all("flags" in r for r in (ok, warn, danger))
