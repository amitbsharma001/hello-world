"""Tests for: pull-claim ownership, Graph import client, role-aware home,
and escalation ticket selection."""
import pytest


# ---- pure: Graph client mock + normalization -------------------------------

def test_graph_mock_when_no_credentials():
    from aegis.services.graph_client import GraphClient
    c = GraphClient()
    assert c.live is False
    r = c.fetch_group_members("payments-team@acme.com")
    assert r.ok and r.mock
    assert len(r.people) == 4
    assert all("@acme.com" in p.email for p in r.people)


def test_graph_empty_group_email():
    from aegis.services.graph_client import GraphClient
    r = GraphClient().fetch_group_members("")
    assert not r.ok and "No group email" in r.detail


def test_graph_person_normalization():
    from aegis.services.graph_client import GraphClient
    # mail preferred; falls back to userPrincipalName; needs an address.
    assert GraphClient._person_from_graph({"displayName": "A", "mail": "a@x.com"}).email == "a@x.com"
    upn = GraphClient._person_from_graph({"displayName": "B", "userPrincipalName": "b@x.com"})
    assert upn.email == "b@x.com"
    assert GraphClient._person_from_graph({"displayName": "No mail"}) is None


def test_graph_live_flag_requires_all_three():
    from aegis.services.graph_client import GraphClient
    assert GraphClient(tenant_id="t", client_id="c", client_secret="s").live
    assert not GraphClient(tenant_id="t", client_id="c").live


# ---- Django: pull claim ----------------------------------------------------

@pytest.fixture
def two_users(db, django_user_model):
    a = django_user_model.objects.create_user("puller_a", password="x")
    b = django_user_model.objects.create_user("puller_b", password="x")
    return a, b


def _raw(source_id="J-1", assignee="a@x.com"):
    from aegis.connectors.base import RawTicket
    return RawTicket(source="jira", source_id=source_id, title="T",
                     description="d", assignee=assignee)


@pytest.mark.django_db
def test_first_pull_claims_ticket(two_users):
    from aegis.connectors.base import ingest
    a, b = two_users
    tickets, _ = ingest([_raw()], pulled_by=a, claim_pulls=True, auto_register=True)
    assert len(tickets) == 1
    assert tickets[0].pulled_by_id == a.id and tickets[0].pulled_at is not None


@pytest.mark.django_db
def test_second_users_pull_does_not_steal_claim(two_users):
    from aegis.connectors.base import ingest
    from aegis.models import Ticket
    a, b = two_users
    ingest([_raw()], pulled_by=a, claim_pulls=True)
    # b pulls the SAME ticket (updated content) — claim must stay with a.
    ingest([_raw(assignee="a@x.com")], pulled_by=b, claim_pulls=True)
    t = Ticket.objects.get(source="jira", source_id="J-1")
    assert t.pulled_by_id == a.id
    assert Ticket.objects.count() == 1  # still deduped, no copy


@pytest.mark.django_db
def test_claim_off_by_default_leaves_pulled_by_null(two_users):
    from aegis.connectors.base import ingest
    a, _ = two_users
    tickets, _ = ingest([_raw()], pulled_by=a, claim_pulls=False)
    assert tickets[0].pulled_by_id is None


@pytest.mark.django_db
def test_unclaimed_existing_gets_claimed(two_users):
    from aegis.connectors.base import ingest
    from aegis.models import Ticket
    a, b = two_users
    # First ingest with claim OFF -> unclaimed row.
    ingest([_raw()], pulled_by=a, claim_pulls=False)
    # b pulls with claim ON -> should claim the previously-unclaimed ticket.
    ingest([_raw()], pulled_by=b, claim_pulls=True)
    assert Ticket.objects.get(source="jira", source_id="J-1").pulled_by_id == b.id


# ---- Django: role-aware home + my_work -------------------------------------

@pytest.mark.django_db
def test_home_redirects_by_role(client, django_user_model):
    staff = django_user_model.objects.create_user("staff", password="x", is_staff=True)
    user = django_user_model.objects.create_user("user", password="x")

    client.force_login(staff)
    assert client.get("/").url.endswith("/workspace/")

    client.force_login(user)
    assert client.get("/").url.endswith("/my/")


@pytest.mark.django_db
def test_my_work_forbidden_content_scope(client, django_user_model):
    """my_work shows only the requesting user's tickets."""
    from aegis.models import Ticket
    user = django_user_model.objects.create_user("u1", password="x")
    other = django_user_model.objects.create_user("u2", password="x")
    Ticket.objects.create(title="Mine", description_raw="d", source="jira",
                          source_id="M1", owner=user)
    Ticket.objects.create(title="Theirs", description_raw="d", source="jira",
                          source_id="T1", owner=other)
    client.force_login(user)
    resp = client.get("/my/")
    assert resp.status_code == 200
    body = resp.content.decode()
    assert "Mine" in body and "Theirs" not in body


@pytest.mark.django_db
def test_staff_redirected_out_of_my_work(client, django_user_model):
    staff = django_user_model.objects.create_user("s", password="x", is_staff=True)
    client.force_login(staff)
    assert client.get("/my/").status_code == 302


# ---- Django: escalation explicit selection ---------------------------------

@pytest.mark.django_db
def test_escalation_honors_selected_ids(client, django_user_model):
    from aegis.models import Ticket, Escalation, EscalationItem
    staff = django_user_model.objects.create_user("adm", password="x", is_staff=True)
    t1 = Ticket.objects.create(title="A", description_raw="d", source="jira",
                               source_id="A1", assignee="a@x.com")
    t2 = Ticket.objects.create(title="B", description_raw="d", source="jira",
                               source_id="B1", assignee="b@x.com")
    Ticket.objects.create(title="C", description_raw="d", source="jira",
                          source_id="C1", assignee="c@x.com")
    client.force_login(staff)
    resp = client.post("/escalations/new/", {
        "action": "create", "title": "Push", "message": "m", "level": "l2",
        "open_only": "on", "notify": "", "post_to_source": "",
        "ticket_ids": [str(t1.id), str(t2.id)],
    })
    assert resp.status_code == 302
    esc = Escalation.objects.get()
    assert esc.items.count() == 2
    assert set(esc.items.values_list("ticket_id", flat=True)) == {t1.id, t2.id}
