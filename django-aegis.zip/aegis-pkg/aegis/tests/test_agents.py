import pytest
from aegis.agents import run_named, run_pipeline, AGENTS
from aegis.agents.tools import list_tools, get_tool
from aegis.models import AgentRun, AgentStep


@pytest.mark.django_db
def test_tools_registered():
    names = {t.name for t in list_tools()}
    assert "search_similar_tickets" in names
    assert "check_recent_deployments" in names
    assert "query_metrics" in names
    assert "post_to_slack" in names
    assert "finish" in names


@pytest.mark.django_db
def test_triage_runs_and_produces_steps(ticket):
    run = run_named("triage", ticket)
    assert run.status == AgentRun.Status.SUCCEEDED
    assert run.agent == "Triage"
    assert run.steps.count() >= 1
    # Last step should be 'finish'
    assert run.steps.order_by("-seq").first().name == "finish"


@pytest.mark.django_db
def test_triage_produces_recommendation(ticket):
    run = run_named("triage", ticket)
    final = run.output["final"]
    assert "recommended_severity" in final
    assert final["recommended_severity"] in ("sev1", "sev2", "sev3", "sev4")
    assert "summary" in final
    assert len(final.get("recommended_actions", [])) >= 1


@pytest.mark.django_db
def test_investigator_uses_diagnostic_tools_only(ticket):
    run = run_named("investigator", ticket)
    tool_names = {s.name for s in run.steps.all()}
    # Investigator should NOT call communication tools
    assert "post_to_slack" not in tool_names
    assert "request_info_from_user" not in tool_names


@pytest.mark.django_db
def test_resolver_communicates(ticket):
    run = run_named("resolver", ticket)
    tool_names = {s.name for s in run.steps.all()}
    # Resolver should use at least one communication tool
    assert tool_names & {"post_to_slack", "request_info_from_user"}


@pytest.mark.django_db
def test_pipeline_runs_triage_then_resolver(ticket):
    # Make ticket low severity so investigator is skipped
    ticket.severity = "sev4"
    ticket.description_raw = "low priority cleanup task"
    ticket.save()
    runs = run_pipeline(ticket)
    agent_names = [r.agent for r in runs]
    assert "Triage" in agent_names
    assert "Resolver" in agent_names


@pytest.mark.django_db
def test_pipeline_escalates_to_investigator_on_high_sev(db, alice):
    """Triage flags sev1/sev2 -> investigator joins."""
    from aegis.models import Ticket
    t = Ticket.objects.create(
        source="manual", owner=alice,
        title="production outage api down",
        description_raw="all customers cannot complete payments. complete outage.",
        severity="sev2",
    )
    runs = run_pipeline(t)
    agent_names = [r.agent for r in runs]
    assert "Triage" in agent_names
    # If triage recommended sev1/sev2, investigator runs
    triage_final = (runs[0].output or {}).get("final") or {}
    if triage_final.get("recommended_severity") in ("sev1", "sev2"):
        assert "Investigator" in agent_names


@pytest.mark.django_db
def test_agent_steps_persisted_with_thought_and_observation(ticket):
    run = run_named("triage", ticket)
    step = run.steps.order_by("seq").first()
    assert step.input.get("thought")
    assert step.input.get("action")
    assert "observation" in step.output


@pytest.mark.django_db
def test_search_similar_tickets_tool_returns_results(ticket, alice):
    from aegis.models import Ticket
    # Create a few other tickets so search has something to find
    for i in range(3):
        Ticket.objects.create(
            owner=alice, title=f"similar {i}", description_raw="x", severity="sev3",
        )
    tool = get_tool("search_similar_tickets")
    out = tool.fn(ticket, query="api down", k=3)
    assert "results" in out
    assert len(out["results"]) <= 3


@pytest.mark.django_db
def test_query_metrics_tool(ticket):
    tool = get_tool("query_metrics")
    out = tool.fn(ticket, service="payments-api", metric="error_rate", window_minutes=60)
    assert "current_value" in out
    assert "trend" in out
    assert "anomalous" in out


@pytest.mark.django_db
def test_update_ticket_field_actually_mutates(ticket):
    tool = get_tool("update_ticket_field")
    out = tool.fn(ticket, field="severity", value="sev1", reason="agent escalation")
    assert out["ok"]
    ticket.refresh_from_db()
    assert ticket.severity == "sev1"


@pytest.mark.django_db
def test_update_ticket_field_rejects_unknown_field(ticket):
    tool = get_tool("update_ticket_field")
    out = tool.fn(ticket, field="nope", value="x", reason="r")
    assert not out["ok"]


@pytest.mark.django_db
def test_auto_triage_fires_on_new_ticket(db, alice, settings):
    """When a non-demo ticket is created, the pipeline fires automatically."""
    settings.AEGIS = {**getattr(settings, "AEGIS", {}),
                     "AUTO_TRIAGE": True, "MOCK_GEMINI": True}
    from aegis.models import Ticket
    t = Ticket.objects.create(
        source="manual", owner=alice,
        title="ticket that should trigger auto-triage",
        description_raw="something broke",
        severity="sev3",
    )
    # The signal should have fired the pipeline
    runs = AgentRun.objects.filter(ticket=t)
    assert runs.count() >= 1
    assert runs.filter(agent="Triage").exists()


@pytest.mark.django_db
def test_auto_triage_disabled(db, alice, settings):
    settings.AEGIS = {**getattr(settings, "AEGIS", {}),
                     "AUTO_TRIAGE": False, "MOCK_GEMINI": True}
    from aegis.models import Ticket
    t = Ticket.objects.create(
        source="manual", owner=alice,
        title="should NOT trigger",
        description_raw="x",
        severity="sev3",
    )
    assert AgentRun.objects.filter(ticket=t).count() == 0
