import pytest
from django.utils import timezone
from datetime import timedelta

from aegis.models import Ticket, TicketHistory, AIArtifact


@pytest.mark.django_db
def test_ticket_create_records_history(ticket):
    history = TicketHistory.objects.filter(ticket=ticket)
    assert history.count() == 1
    assert history.first().event_type == "created"


@pytest.mark.django_db
def test_ticket_update_records_history(ticket):
    ticket.status = Ticket.Status.IN_PROGRESS
    ticket.save()
    assert TicketHistory.objects.filter(ticket=ticket).count() == 2


@pytest.mark.django_db
def test_ticket_unique_per_source(db):
    Ticket.objects.create(source="jira", source_id="PAY-1", title="x", description_raw="y")
    with pytest.raises(Exception):
        Ticket.objects.create(source="jira", source_id="PAY-1", title="z", description_raw="w")


@pytest.mark.django_db
def test_ticket_age_hours(ticket):
    ticket.opened_at = timezone.now() - timedelta(hours=5)
    ticket.save()
    assert 4.9 < ticket.age_hours < 5.1


@pytest.mark.django_db
def test_ticket_is_open(ticket):
    assert ticket.is_open
    ticket.status = Ticket.Status.RESOLVED
    ticket.save()
    assert not ticket.is_open
