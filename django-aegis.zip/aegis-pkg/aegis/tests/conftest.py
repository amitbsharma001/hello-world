import pytest
from django.conf import settings
from aegis.services import gemini as gemini_mod


@pytest.fixture(autouse=True)
def _force_mock_gemini(settings):
    """All tests use mock Gemini and AUTO_TRIAGE off unless overridden."""
    settings.AEGIS = {
        **getattr(settings, "AEGIS", {}),
        "MOCK_GEMINI": True,
        "AUTO_TRIAGE": False,  # tests that need it enable explicitly
    }
    gemini_mod.reset_client()
    yield
    gemini_mod.reset_client()


@pytest.fixture
def admin_user(db, django_user_model):
    return django_user_model.objects.create_user(
        username="admin", password="x", is_staff=True, is_superuser=True,
    )


@pytest.fixture
def alice(db, django_user_model):
    return django_user_model.objects.create_user(username="alice", password="x")


@pytest.fixture
def bob(db, django_user_model):
    return django_user_model.objects.create_user(username="bob", password="x")


@pytest.fixture
def admin_client(client, admin_user):
    client.force_login(admin_user)
    return client


@pytest.fixture
def alice_client(client, alice):
    client.force_login(alice)
    return client


@pytest.fixture
def bob_client(client, bob):
    client.force_login(bob)
    return client


@pytest.fixture
def ticket(db, alice):
    """A ticket owned by alice (used by most existing tests)."""
    from aegis.models import Ticket
    return Ticket.objects.create(
        source="manual",
        owner=alice,
        title="API down",
        description_raw="payments api returning 503 since 14:00. tried restart, no luck.",
        severity=Ticket.Severity.SEV2,
        team="Payments",
        assignee="oncall@example.com",
    )


@pytest.fixture
def ticket_sparse(db, alice):
    from aegis.models import Ticket
    return Ticket.objects.create(
        source="manual",
        owner=alice,
        title="thing broken",
        description_raw="not working",
        severity=Ticket.Severity.SEV3,
    )
