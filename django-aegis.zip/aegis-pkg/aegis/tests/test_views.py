import pytest
from django.urls import reverse
from aegis.models import Ticket, AIArtifact


# ---- queue ----

@pytest.mark.django_db
def test_queue_anonymous_redirects_to_login(client):
    r = client.get(reverse("aegis:queue"))
    assert r.status_code == 302
    assert "/accounts/login/" in r["Location"]


@pytest.mark.django_db
def test_queue_empty_for_alice(alice_client):
    r = alice_client.get(reverse("aegis:queue"))
    assert r.status_code == 200
    assert b"don't own any tickets" in r.content


@pytest.mark.django_db
def test_queue_lists_own_tickets(alice_client, ticket):
    r = alice_client.get(reverse("aegis:queue"))
    assert r.status_code == 200
    assert ticket.title.encode() in r.content
    assert b"your tickets" in r.content


@pytest.mark.django_db
def test_queue_admin_sees_all(admin_client, ticket):
    r = admin_client.get(reverse("aegis:queue"))
    assert r.status_code == 200
    assert ticket.title.encode() in r.content
    assert b"admin view" in r.content
    assert b"Owner" in r.content   # admin-only column header


@pytest.mark.django_db
def test_queue_bob_cannot_see_alices_tickets(bob_client, ticket):
    r = bob_client.get(reverse("aegis:queue"))
    assert r.status_code == 200
    assert ticket.title.encode() not in r.content


@pytest.mark.django_db
def test_queue_filter_by_status(alice_client, ticket, alice):
    Ticket.objects.create(owner=alice, title="other", description_raw="x",
                          severity="sev3", status="resolved")
    r = alice_client.get(reverse("aegis:queue"), {"status": "open"})
    assert r.status_code == 200
    assert ticket.title.encode() in r.content
    assert b"other" not in r.content


@pytest.mark.django_db
def test_queue_search(alice_client, ticket, alice):
    Ticket.objects.create(owner=alice, title="completely different",
                          description_raw="x", severity="sev3")
    r = alice_client.get(reverse("aegis:queue"), {"q": "API"})
    assert r.status_code == 200
    assert ticket.title.encode() in r.content
    assert b"completely different" not in r.content


# ---- detail ----

@pytest.mark.django_db
def test_detail_owner_can_view(alice_client, ticket):
    r = alice_client.get(reverse("aegis:detail", args=[ticket.id]))
    assert r.status_code == 200
    assert ticket.title.encode() in r.content


@pytest.mark.django_db
def test_detail_admin_can_view(admin_client, ticket):
    r = admin_client.get(reverse("aegis:detail", args=[ticket.id]))
    assert r.status_code == 200
    # Admin sees the owner badge
    assert b"owner:" in r.content


@pytest.mark.django_db
def test_detail_other_user_cannot_view(bob_client, ticket):
    r = bob_client.get(reverse("aegis:detail", args=[ticket.id]))
    assert r.status_code == 404


@pytest.mark.django_db
def test_detail_anonymous_redirects(client, ticket):
    r = client.get(reverse("aegis:detail", args=[ticket.id]))
    assert r.status_code == 302


# ---- create ----

@pytest.mark.django_db
def test_create_get(alice_client):
    r = alice_client.get(reverse("aegis:create"))
    assert r.status_code == 200


@pytest.mark.django_db
def test_create_sets_owner_to_current_user(alice_client, alice):
    r = alice_client.post(reverse("aegis:create"), {
        "title": "Test ticket",
        "description_raw": "Something is broken",
        "severity": "sev3",
        "status": "open",
        "team": "Eng",
        "assignee": "me@example.com",
    })
    assert r.status_code == 302
    t = Ticket.objects.get(title="Test ticket")
    assert t.owner == alice
    assert t.source == "manual"


@pytest.mark.django_db
def test_create_with_ai_owner_is_creator(alice_client, alice):
    r = alice_client.post(reverse("aegis:create"), {
        "title": "Bigger broken thing",
        "description_raw": "API gateway returning 503 errors",
        "severity": "sev2",
        "status": "open",
        "team": "Platform",
        "assignee": "",
        "run_ai": "on",
    })
    assert r.status_code == 302
    t = Ticket.objects.get(title="Bigger broken thing")
    assert t.owner == alice
    assert t.enhanced_payload
    assert t.plan_payload


# ---- HTMX action endpoints — permission-aware ----

@pytest.mark.django_db
def test_action_enhance_owner(alice_client, ticket):
    r = alice_client.post(reverse("aegis:action_enhance", args=[ticket.id]))
    assert r.status_code == 200
    ticket.refresh_from_db()
    assert ticket.enhanced_payload


@pytest.mark.django_db
def test_action_enhance_other_user_blocked(bob_client, ticket):
    r = bob_client.post(reverse("aegis:action_enhance", args=[ticket.id]))
    assert r.status_code == 404
    ticket.refresh_from_db()
    assert not ticket.enhanced_payload


@pytest.mark.django_db
def test_action_enhance_admin_can(admin_client, ticket):
    r = admin_client.post(reverse("aegis:action_enhance", args=[ticket.id]))
    assert r.status_code == 200


@pytest.mark.django_db
def test_action_plan(alice_client, ticket):
    r = alice_client.post(reverse("aegis:action_plan", args=[ticket.id]))
    assert r.status_code == 200
    ticket.refresh_from_db()
    assert ticket.plan_payload


@pytest.mark.django_db
def test_action_missing(alice_client, ticket):
    r = alice_client.post(reverse("aegis:action_missing", args=[ticket.id]))
    assert r.status_code == 200
    ticket.refresh_from_db()
    assert ticket.missing_info_payload


@pytest.mark.django_db
def test_action_status(alice_client, ticket):
    r = alice_client.post(reverse("aegis:action_status", args=[ticket.id]),
                          {"status": "in_progress"})
    assert r.status_code == 200
    ticket.refresh_from_db()
    assert ticket.status == "in_progress"


@pytest.mark.django_db
def test_action_status_other_user_blocked(bob_client, ticket):
    r = bob_client.post(reverse("aegis:action_status", args=[ticket.id]),
                        {"status": "in_progress"})
    assert r.status_code == 404


@pytest.mark.django_db
def test_action_run_all(alice_client, ticket):
    r = alice_client.post(reverse("aegis:action_run_all", args=[ticket.id]))
    assert r.status_code == 204
    assert "HX-Redirect" in r.headers
    ticket.refresh_from_db()
    assert ticket.enhanced_payload
    assert ticket.plan_payload
    assert ticket.missing_info_payload


# ---- CSV upload ----

@pytest.mark.django_db
def test_csv_upload_creates_with_owner(alice_client, alice):
    from io import BytesIO
    csv = b"source_id,title,description,status,severity,assignee,team,tags\nT-99,broken,bad,open,High,a@b.c,Eng,\n"
    upload = BytesIO(csv); upload.name = "tickets.csv"
    r = alice_client.post(reverse("aegis:csv_upload"), {"file": upload, "run_ai": ""})
    assert r.status_code == 302
    t = Ticket.objects.get(source="csv", source_id="T-99")
    assert t.owner == alice


@pytest.mark.django_db
def test_csv_upload_admin_keeps_unowned(admin_client):
    """Admin imports stay unowned (visible to all staff)."""
    from io import BytesIO
    csv = b"source_id,title,description,status,severity,assignee,team,tags\nT-100,broken,bad,open,High,a@b.c,Eng,\n"
    upload = BytesIO(csv); upload.name = "tickets.csv"
    r = admin_client.post(reverse("aegis:csv_upload"), {"file": upload, "run_ai": ""})
    assert r.status_code == 302
    t = Ticket.objects.get(source="csv", source_id="T-100")
    assert t.owner is None


# ---- REST API ----

@pytest.mark.django_db
def test_api_requires_auth(client):
    r = client.get("/api/tickets/")
    assert r.status_code == 403


@pytest.mark.django_db
def test_api_list_only_own(alice_client, ticket, alice, bob):
    Ticket.objects.create(owner=bob, title="bob's ticket",
                          description_raw="x", severity="sev3")
    r = alice_client.get("/api/tickets/")
    assert r.status_code == 200
    items = r.json().get("results", r.json())
    titles = [t["title"] for t in items]
    assert ticket.title in titles
    assert "bob's ticket" not in titles


@pytest.mark.django_db
def test_api_list_admin_sees_all(admin_client, ticket, alice, bob):
    Ticket.objects.create(owner=bob, title="bob's ticket",
                          description_raw="x", severity="sev3")
    r = admin_client.get("/api/tickets/")
    assert r.status_code == 200
    items = r.json().get("results", r.json())
    titles = [t["title"] for t in items]
    assert ticket.title in titles
    assert "bob's ticket" in titles


@pytest.mark.django_db
def test_api_create_owns_to_creator(alice_client, alice):
    import json
    r = alice_client.post("/api/tickets/", data=json.dumps({
        "title": "API ticket",
        "description_raw": "via API",
        "severity": "sev3",
        "status": "open",
    }), content_type="application/json")
    assert r.status_code in (200, 201), r.content
    t = Ticket.objects.get(title="API ticket")
    assert t.owner == alice


@pytest.mark.django_db
def test_api_retrieve_other_user_404(bob_client, ticket):
    r = bob_client.get(f"/api/tickets/{ticket.id}/")
    assert r.status_code == 404


@pytest.mark.django_db
def test_api_analyze_owner(alice_client, ticket):
    r = alice_client.post(f"/api/tickets/{ticket.id}/analyze/")
    assert r.status_code == 200
    data = r.json()
    assert data["enhanced_payload"]
    assert data["plan_payload"]
    assert data["missing_info_payload"]


@pytest.mark.django_db
def test_api_analyze_other_user_404(bob_client, ticket):
    r = bob_client.post(f"/api/tickets/{ticket.id}/analyze/")
    assert r.status_code == 404


# ---- Agent endpoints ----

@pytest.mark.django_db
def test_agents_inbox_login_required(client):
    r = client.get(reverse("aegis:agents_inbox"))
    assert r.status_code == 302


@pytest.mark.django_db
def test_agents_inbox_alice_only_sees_own_runs(alice_client, alice, bob):
    from aegis.models import Ticket
    from aegis.agents import run_named
    alice_t = Ticket.objects.create(owner=alice, title="alice ticket",
                                    description_raw="x", severity="sev3")
    bob_t = Ticket.objects.create(owner=bob, title="bob ticket",
                                  description_raw="x", severity="sev3")
    # Wipe auto-triage runs to make this deterministic
    from aegis.models import AgentRun
    AgentRun.objects.all().delete()
    run_named("triage", alice_t)
    run_named("triage", bob_t)
    r = alice_client.get(reverse("aegis:agents_inbox"))
    assert r.status_code == 200
    assert b"alice ticket" in r.content
    assert b"bob ticket" not in r.content


@pytest.mark.django_db
def test_agents_inbox_admin_sees_all(admin_client, alice, bob):
    from aegis.models import Ticket, AgentRun
    from aegis.agents import run_named
    alice_t = Ticket.objects.create(owner=alice, title="alice ticket",
                                    description_raw="x", severity="sev3")
    bob_t = Ticket.objects.create(owner=bob, title="bob ticket",
                                  description_raw="x", severity="sev3")
    AgentRun.objects.all().delete()
    run_named("triage", alice_t)
    run_named("triage", bob_t)
    r = admin_client.get(reverse("aegis:agents_inbox"))
    assert r.status_code == 200
    assert b"alice ticket" in r.content
    assert b"bob ticket" in r.content


@pytest.mark.django_db
def test_run_agent_endpoint(alice_client, ticket):
    r = alice_client.post(
        reverse("aegis:action_run_agent", args=[ticket.id, "triage"])
    )
    assert r.status_code == 200
    from aegis.models import AgentRun
    assert AgentRun.objects.filter(ticket=ticket, agent="Triage").exists()


@pytest.mark.django_db
def test_run_pipeline_endpoint(alice_client, ticket):
    r = alice_client.post(reverse("aegis:action_run_pipeline", args=[ticket.id]))
    assert r.status_code == 200


@pytest.mark.django_db
def test_run_agent_other_user_blocked(bob_client, ticket):
    r = bob_client.post(
        reverse("aegis:action_run_agent", args=[ticket.id, "triage"])
    )
    assert r.status_code == 404
