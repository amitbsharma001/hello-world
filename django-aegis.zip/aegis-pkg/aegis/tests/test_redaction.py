"""Tests for the PII redaction boundary."""
import pytest
from aegis.services.redaction import sanitize, rehydrate, RedactionMap, redact_payload, rehydrate_payload


# ---- Emails ----

def test_redacts_single_email():
    text, rm = sanitize("Please contact alice@example.com about the issue.")
    assert "alice@example.com" not in text
    assert "<EMAIL_1>" in text
    assert rm.mapping["<EMAIL_1>"] == "alice@example.com"


def test_repeated_email_reuses_placeholder():
    text, rm = sanitize("Email alice@example.com. Reply to alice@example.com.")
    assert text.count("<EMAIL_1>") == 2
    assert "<EMAIL_2>" not in text
    assert len(rm.mapping) == 1


def test_multiple_emails_get_different_placeholders():
    text, rm = sanitize("From alice@example.com to bob@example.com.")
    assert "<EMAIL_1>" in text
    assert "<EMAIL_2>" in text
    assert len(rm.mapping) == 2


# ---- IPs ----

def test_redacts_ipv4():
    text, rm = sanitize("Server 192.168.1.100 is unreachable.")
    assert "192.168.1.100" not in text
    assert "<IP_1>" in text


def test_redacts_ipv6():
    text, rm = sanitize("Endpoint 2001:0db8:85a3:0000:0000:8a2e:0370:7334 down.")
    assert "<IPV6_1>" in text
    assert "2001" not in text


def test_redacts_public_ipv4():
    text, rm = sanitize("Connection refused from 8.8.8.8.")
    assert "8.8.8.8" not in text
    assert "<IP_1>" in text


# ---- Hostnames / URLs ----

def test_redacts_internal_hostnames():
    text, rm = sanitize("payment-svc.internal:8080 timed out")
    assert "payment-svc.internal" not in text
    assert "<HOST_1>" in text


def test_redacts_urls():
    text, rm = sanitize("Failed at https://api.example.com/v1/charge")
    assert "https://api.example.com/v1/charge" not in text
    assert "<URL_1>" in text


# ---- Secrets / Tokens ----

def test_redacts_aws_access_key():
    text, rm = sanitize("Key AKIAIOSFODNN7EXAMPLE was leaked")
    assert "AKIAIOSFODNN7EXAMPLE" not in text
    assert "<AWS_KEY_1>" in text


def test_redacts_github_token():
    text, rm = sanitize("Token ghp_abcdefghijklmnopqrstuvwxyz0123456789 found in repo")
    assert "ghp_abcdef" not in text
    assert "<GH_TOKEN_1>" in text


def test_redacts_jwt():
    jwt = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
           ".eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIn0"
           ".SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c")
    text, rm = sanitize(f"Authorization: {jwt}")
    assert jwt not in text
    assert "<JWT_1>" in text


def test_redacts_stripe_key():
    text, rm = sanitize("Webhook sig with sk_live_abc123def456ghi789jkl012mno345 failed")
    assert "sk_live_abc123def456ghi789jkl012mno345" not in text
    assert "<STRIPE_KEY_1>" in text


# ---- Phone / Card ----

def test_redacts_credit_card():
    text, rm = sanitize("Charge 4532-1234-5678-9010 declined.")
    assert "4532-1234-5678-9010" not in text
    assert "<CARD_1>" in text


def test_redacts_phone():
    text, rm = sanitize("Customer called +1 555-123-4567 about the outage.")
    assert "555-123-4567" not in text
    assert "<PHONE_1>" in text


# ---- UUIDs ----

def test_redacts_uuid():
    text, rm = sanitize("User ID 7f9c2ba4-ddc3-4d2c-b2fc-aaaeed3ce11e in error logs")
    assert "7f9c2ba4-ddc3-4d2c-b2fc-aaaeed3ce11e" not in text
    assert "<UUID_1>" in text


# ---- Filesystem paths with usernames ----

def test_redacts_unix_home_path_username():
    text, rm = sanitize("Error in /home/john_doe/app/server.log")
    assert "john_doe" not in text
    assert "<USERNAME_1>" in text
    # Path structure preserved
    assert "/home/" in text
    assert "/app/server.log" in text


def test_redacts_macos_users_path_username():
    text, rm = sanitize("Loaded from /Users/jsmith/.config/secrets")
    assert "jsmith" not in text
    assert "<USERNAME_1>" in text


def test_redacts_windows_users_path_username():
    text, rm = sanitize(r"File at C:\Users\BobAdmin\Documents\creds.txt")
    assert "BobAdmin" not in text
    assert "<USERNAME_1>" in text


# ---- Rehydration ----

def test_rehydrate_round_trip():
    original = "Email alice@example.com from 10.0.0.5"
    redacted, rm = sanitize(original)
    assert original != redacted
    restored = rehydrate(redacted, rm)
    assert restored == original


def test_rehydrate_from_dict():
    original = "Contact bob@example.com"
    redacted, rm = sanitize(original)
    # Round-trip the map through a dict (simulating DB persistence)
    serialized = rm.to_dict()
    assert rehydrate(redacted, serialized) == original


def test_rehydrate_safe_on_no_placeholders():
    """Rehydrating text that has no placeholders should be a no-op."""
    rm = RedactionMap.from_dict({"mapping": {"<EMAIL_1>": "a@b.c"}, "counts": {}})
    assert rm.rehydrate("Hello world") == "Hello world"


# ---- Nested payloads ----

def test_redact_nested_payload():
    rm = RedactionMap()
    payload = {
        "summary": "User alice@example.com complained about 192.168.1.5",
        "actions": ["Email alice@example.com", "Restart 192.168.1.5"],
        "meta": {"reporter": "bob@corp.com"},
    }
    redacted = redact_payload(payload, rm)
    # Email and IP should not appear anywhere in the redacted payload
    flat = str(redacted)
    assert "alice@example.com" not in flat
    assert "192.168.1.5" not in flat
    assert "bob@corp.com" not in flat
    # Placeholders are present
    assert "<EMAIL_1>" in redacted["summary"]
    assert "<IP_1>" in redacted["summary"]


def test_rehydrate_nested_payload():
    rm = RedactionMap()
    original = {
        "summary": "Contact alice@example.com about server 10.0.0.1",
        "tags": ["urgent", "alice@example.com"],
    }
    redacted = redact_payload(original, rm)
    restored = rehydrate_payload(redacted, rm)
    assert restored == original


# ---- Real-world ticket scenario ----

def test_realistic_incident_report_redaction():
    """An incident report containing every category of PII at once."""
    report = (
        "User jdoe@acme-corp.com (ID 7f9c2ba4-ddc3-4d2c-b2fc-aaaeed3ce11e) "
        "reported that payment-api.internal:443 is returning 500s when called "
        "from worker host 10.42.7.13. PR https://github.com/acme/pay/pull/2341 "
        "was the last deploy. Stripe key sk_live_abc123def456ghi789jkl012mno345 "
        "was rotated. Logs live in /home/jdoe/app/logs/."
    )
    redacted, rm = sanitize(report)

    # Verify every category is redacted
    assert "jdoe@acme-corp.com" not in redacted
    assert "7f9c2ba4" not in redacted
    assert "payment-api.internal" not in redacted
    assert "10.42.7.13" not in redacted
    assert "github.com/acme/pay" not in redacted
    assert "sk_live_abc123" not in redacted
    # Username masked in path but path structure kept
    assert "/jdoe/" not in redacted
    assert "/home/" in redacted

    # Round trip
    assert rehydrate(redacted, rm) == report

    # Counts
    assert rm.counts_by_category.get("EMAIL", 0) >= 1
    assert rm.counts_by_category.get("UUID", 0) >= 1
    assert rm.counts_by_category.get("HOST", 0) >= 1
    assert rm.counts_by_category.get("IP", 0) >= 1
    assert rm.counts_by_category.get("URL", 0) >= 1


# ---- Empty / edge cases ----

def test_empty_text():
    text, rm = sanitize("")
    assert text == ""
    assert len(rm) == 0


def test_none_text():
    text, rm = sanitize(None)
    assert text == ""
    assert len(rm) == 0


def test_no_pii_returns_unchanged():
    original = "The deploy went smoothly. No issues detected."
    text, rm = sanitize(original)
    assert text == original
    assert len(rm) == 0


# ---- Phone precision (regression guards from measured eval) ----

def test_hex_error_code_not_redacted_as_phone():
    """0x80004005 must NOT be treated as a phone (was a measured false positive)."""
    text, rm = sanitize("Error code 0x80004005 appeared in the logs")
    assert "0x80004005" in text
    assert not rm.mapping


def test_epoch_timestamp_not_redacted():
    """A 10-digit epoch must not trip the bare-digit phone fallback."""
    text, rm = sanitize("Unix epoch 1700000000 marks the cutover")
    assert "1700000000" in text


def test_order_codes_not_redacted():
    text, rm = sanitize("Order 90040055 shipped and request 80004005 failed")
    assert "90040055" in text and "80004005" in text


def test_bare_tollfree_is_redacted():
    """An 11-digit bare number (toll-free) should still be caught."""
    text, rm = sanitize("Hotline 18005551234 is toll-free")
    assert "18005551234" not in text
    assert "<PHONE_1>" in text


def test_formatted_phones_still_redacted():
    for p in ["415-555-0132", "(212) 555-7788", "+1 555-123-4567", "+91 98765 43210"]:
        text, rm = sanitize(f"call {p} now")
        assert rm.mapping, f"{p} should be redacted"
