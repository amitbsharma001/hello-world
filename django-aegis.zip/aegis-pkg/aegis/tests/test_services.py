import pytest
from decimal import Decimal

from aegis.models import AIArtifact, Ticket
from aegis.services import enhance_description, generate_plan, detect_missing_info
from aegis.services.enhance import run_full_analysis
from aegis.services.gemini import MockGeminiClient, get_client
from aegis.services.schemas import EnhancedDescription, ActionPlan, MissingInformationReport
from aegis.services import prompts


# ---- prompts ----

def test_prompt_renders_enhance(ticket):
    out = prompts.render("enhance", ticket=ticket)
    assert "Title:" in out
    assert ticket.title in out
    assert "<user_input>" in out
    # Schema mentioned so the model knows what to return
    assert "problem_summary" in out


def test_prompt_renders_plan(ticket):
    enhanced = EnhancedDescription(
        problem_summary="x", business_impact="y", technical_analysis="z",
        affected_systems=["api"], observed_symptoms=["503s"],
        recommended_investigation_areas=["check logs"],
    )
    out = prompts.render("plan", ticket=ticket, enhanced=enhanced)
    assert "actions" in out
    assert "api" in out


# ---- mock client ----

def test_mock_client_returns_valid_enhanced_description():
    client = MockGeminiClient()
    prompt = "Title: API down\nRaw description:\n---\npayments returning 503\n---"
    parsed, meta = client.generate(
        model="gemini-2.5-pro", prompt=prompt, schema=EnhancedDescription
    )
    assert isinstance(parsed, EnhancedDescription)
    assert 0 <= parsed.confidence <= 1
    assert parsed.severity_suggestion in ("sev1", "sev2", "sev3", "sev4")
    assert len(parsed.observed_symptoms) >= 1
    assert meta["cost_usd"] == 0
    assert meta["latency_ms"] >= 0


def test_mock_client_returns_valid_plan():
    client = MockGeminiClient()
    parsed, _ = client.generate(
        model="gemini-2.5-pro",
        prompt="Title: API down\nseverity: sev1\napi gateway",
        schema=ActionPlan,
    )
    assert isinstance(parsed, ActionPlan)
    assert 3 <= len(parsed.actions) <= 8
    for a in parsed.actions:
        assert a.priority in ("P0", "P1", "P2", "P3")
        assert a.effort_hours > 0


def test_mock_client_returns_valid_missing_info():
    client = MockGeminiClient()
    parsed, _ = client.generate(
        model="gemini-2.5-flash",
        prompt="Title: thing\nDescription: broken",
        schema=MissingInformationReport,
    )
    assert isinstance(parsed, MissingInformationReport)
    assert 0 <= parsed.priority_score <= 100


def test_mock_client_severity_outage_keyword():
    client = MockGeminiClient()
    p, _ = client.generate(
        model="gemini-2.5-pro",
        prompt="Title: production outage\nRaw description:\n---\nall customers down\n---",
        schema=EnhancedDescription,
    )
    assert p.severity_suggestion == "sev1"


def test_mock_client_higher_confidence_with_detail():
    client = MockGeminiClient()
    sparse, _ = client.generate(
        model="gemini-2.5-pro",
        prompt="Title: x\nRaw description:\n---\nbroken\n---",
        schema=EnhancedDescription,
    )
    rich, _ = client.generate(
        model="gemini-2.5-pro",
        prompt=("Title: API errors\nRaw description:\n---\n"
                "Started at 14:00 UTC. Endpoint /payments returning 503 with "
                "'connection refused'. Affects ~30% of traffic. Deploy at 13:55. "
                "Tried restart, no help. Logs show upstream timeout.\n---"),
        schema=EnhancedDescription,
    )
    assert rich.confidence > sparse.confidence


# ---- service layer ----

@pytest.mark.django_db
def test_enhance_creates_artifact_and_updates_ticket(ticket):
    artifact = enhance_description(ticket)

    assert artifact.kind == AIArtifact.Kind.ENHANCED_DESCRIPTION
    assert artifact.payload["problem_summary"]
    assert artifact.confidence is not None

    ticket.refresh_from_db()
    assert ticket.enhanced_payload
    assert ticket.description_enhanced
    assert "## Problem Summary" in ticket.description_enhanced


@pytest.mark.django_db
def test_enhance_is_idempotent_without_force(ticket):
    enhance_description(ticket)
    n1 = AIArtifact.objects.filter(ticket=ticket).count()
    enhance_description(ticket)  # second call
    n2 = AIArtifact.objects.filter(ticket=ticket).count()
    assert n1 == n2 == 1


@pytest.mark.django_db
def test_enhance_force_creates_new_artifact(ticket):
    enhance_description(ticket)
    enhance_description(ticket, force=True)
    assert AIArtifact.objects.filter(ticket=ticket).count() == 2


@pytest.mark.django_db
def test_generate_plan_creates_artifact(ticket):
    enhance_description(ticket)
    artifact = generate_plan(ticket)
    assert artifact.kind == AIArtifact.Kind.ACTION_PLAN
    assert len(artifact.payload["actions"]) >= 1
    ticket.refresh_from_db()
    assert ticket.plan_payload


@pytest.mark.django_db
def test_generate_plan_auto_enhances_if_missing(ticket):
    """Calling plan without prior enhancement should auto-enhance."""
    assert not ticket.enhanced_payload
    generate_plan(ticket)
    ticket.refresh_from_db()
    assert ticket.enhanced_payload
    assert ticket.plan_payload


@pytest.mark.django_db
def test_detect_missing_info(ticket_sparse):
    artifact = detect_missing_info(ticket_sparse)
    assert artifact.kind == AIArtifact.Kind.MISSING_INFO
    # Sparse ticket should score high (lots missing)
    assert artifact.payload["priority_score"] > 50


@pytest.mark.django_db
def test_run_full_analysis(ticket):
    out = run_full_analysis(ticket)
    assert "enhanced" in out
    assert "plan" in out
    assert "missing_info" in out
    assert AIArtifact.objects.filter(ticket=ticket).count() == 3


# ---- SLA scoring ----

def test_sla_score_no_sla_due():
    from aegis.models import Ticket
    from aegis.services.sla import score
    t = Ticket(severity="sev3")
    from django.utils import timezone
    t.opened_at = timezone.now()
    s = score(t)
    assert s["breach_probability"] == 0
    assert s["sla_remaining_hours"] is None


def test_sla_score_breached():
    from aegis.models import Ticket
    from aegis.services.sla import score, status_label
    from django.utils import timezone
    from datetime import timedelta
    t = Ticket(severity="sev1", impacted_users=1000)
    t.opened_at = timezone.now() - timedelta(hours=48)
    t.sla_due_at = timezone.now() - timedelta(hours=2)
    s = score(t)
    assert s["breach_probability"] == 1.0
    assert s["risk_score"] > 50
    assert status_label(s) in ("high", "critical")


def test_sla_score_fresh_sev4():
    from aegis.models import Ticket
    from aegis.services.sla import score, status_label
    from django.utils import timezone
    from datetime import timedelta
    t = Ticket(severity="sev4")
    t.opened_at = timezone.now()
    t.sla_due_at = timezone.now() + timedelta(hours=72)
    s = score(t)
    assert s["breach_probability"] < 0.1
    assert status_label(s) == "low"
