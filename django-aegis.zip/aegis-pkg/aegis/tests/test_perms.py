import pytest
from django.contrib.auth.models import AnonymousUser
from aegis.models import Ticket
from aegis.perms import can_view, can_edit, filter_for_user, is_admin


@pytest.mark.django_db
def test_anonymous_cannot_view(ticket):
    assert not can_view(AnonymousUser(), ticket)


@pytest.mark.django_db
def test_owner_can_view(ticket, alice):
    assert can_view(alice, ticket)


@pytest.mark.django_db
def test_other_user_cannot_view(ticket, bob):
    assert not can_view(bob, ticket)


@pytest.mark.django_db
def test_admin_can_view_anything(ticket, admin_user):
    assert can_view(admin_user, ticket)


@pytest.mark.django_db
def test_can_edit_matches_can_view(ticket, alice, bob, admin_user):
    assert can_edit(alice, ticket)
    assert not can_edit(bob, ticket)
    assert can_edit(admin_user, ticket)


@pytest.mark.django_db
def test_filter_for_user_anonymous_returns_none(ticket):
    qs = Ticket.objects.all()
    assert filter_for_user(qs, AnonymousUser()).count() == 0


@pytest.mark.django_db
def test_filter_for_user_owner(ticket, alice, bob):
    Ticket.objects.create(owner=bob, title="b", description_raw="x", severity="sev3")
    Ticket.objects.create(owner=None, title="unowned", description_raw="x", severity="sev3")
    qs = filter_for_user(Ticket.objects.all(), alice)
    assert qs.count() == 1
    assert qs.first().title == "API down"  # alice's ticket from fixture


@pytest.mark.django_db
def test_filter_for_user_admin_sees_all(ticket, admin_user, bob):
    Ticket.objects.create(owner=bob, title="b", description_raw="x", severity="sev3")
    Ticket.objects.create(owner=None, title="unowned", description_raw="x", severity="sev3")
    qs = filter_for_user(Ticket.objects.all(), admin_user)
    assert qs.count() == 3


@pytest.mark.django_db
def test_is_admin(alice, admin_user):
    assert not is_admin(AnonymousUser())
    assert not is_admin(alice)
    assert is_admin(admin_user)


@pytest.mark.django_db
def test_unowned_ticket_not_visible_to_regular_user(alice, db):
    """Tickets without owner are admin-only (safe default for synced tickets)."""
    t = Ticket.objects.create(owner=None, title="from jira sync",
                              description_raw="x", severity="sev3")
    assert not can_view(alice, t)


@pytest.mark.django_db
def test_unowned_ticket_visible_to_admin(admin_user, db):
    t = Ticket.objects.create(owner=None, title="from jira sync",
                              description_raw="x", severity="sev3")
    assert can_view(admin_user, t)
