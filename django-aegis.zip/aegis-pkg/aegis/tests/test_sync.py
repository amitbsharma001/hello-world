"""Tests for the manual 'pull from all connectors' sync."""
import pytest
from aegis.models import Project, Ticket
from aegis.services.sync_runner import run_all_pulls, pullable_connectors
from aegis.connectors import registry
from aegis.connectors.base import Connector, RawTicket


# ---- a fake pull-capable connector for deterministic testing ----

class _FakeConnector(Connector):
    name = "fake"
    supports_pull = True
    _rows = []
    _healthy = True

    def health_check(self):
        return self._healthy

    def fetch(self, cursor=None):
        yield from self._rows


@pytest.fixture
def fake_registered():
    registry.register(_FakeConnector)
    yield
    registry._connectors.pop("fake", None)
    _FakeConnector._rows = []
    _FakeConnector._healthy = True


# ---- runner ----

def test_pullable_connectors_lists_jira_servicenow():
    names = pullable_connectors()
    assert "jira" in names
    assert "servicenow" in names
    assert "csv" not in names  # CSV is not a pull connector


@pytest.mark.django_db
def test_unconfigured_connectors_are_skipped():
    summary = run_all_pulls()
    # jira + servicenow present but unconfigured -> skipped, not error
    statuses = {r["connector"]: r["status"] for r in summary["results"]}
    assert statuses.get("jira") == "skipped"
    assert statuses.get("servicenow") == "skipped"
    assert summary["totals"]["imported"] == 0


@pytest.mark.django_db
def test_fake_connector_pulls_into_enabled_project(fake_registered):
    Project.objects.create(key="PAY", name="Payments", external_key="PAY",
                           source="jira", sync_enabled=True)
    _FakeConnector._rows = [
        RawTicket(source="fake", source_id="F-1", title="hello", project="PAY"),
        RawTicket(source="fake", source_id="F-2", title="blocked", project="GHOST"),  # unconfigured
    ]
    summary = run_all_pulls()
    fake = next(r for r in summary["results"] if r["connector"] == "fake")
    assert fake["status"] == "ok"
    assert fake["imported"] == 1            # only the PAY ticket
    assert Ticket.objects.filter(source="fake", source_id="F-1").count() == 1
    assert Ticket.objects.filter(source="fake", source_id="F-2").count() == 0


@pytest.mark.django_db
def test_unhealthy_connector_skipped(fake_registered):
    _FakeConnector._healthy = False
    summary = run_all_pulls()
    fake = next(r for r in summary["results"] if r["connector"] == "fake")
    assert fake["status"] == "skipped"


# ---- views ----

@pytest.mark.django_db
def test_sync_page_admin(admin_client):
    r = admin_client.get("/sync/")
    assert r.status_code == 200
    assert b"Pull from connectors" in r.content
    assert b"jira" in r.content


@pytest.mark.django_db
def test_sync_page_user_blocked(alice_client):
    assert alice_client.get("/sync/").status_code == 404


@pytest.mark.django_db
def test_sync_run_returns_report(admin_client):
    r = admin_client.post("/sync/run/")
    assert r.status_code == 200
    # Shows the totals band
    assert b"Imported" in r.content


@pytest.mark.django_db
def test_sync_run_user_blocked(alice_client):
    assert alice_client.post("/sync/run/").status_code == 404


@pytest.mark.django_db
def test_incremental_saves_and_reuses_cursor(fake_registered):
    """After a pull, a SyncCursor is saved; the next pull resumes from it."""
    from aegis.models import SyncCursor, Project
    Project.objects.create(key="PAY", name="Payments", external_key="PAY",
                           source="jira", sync_enabled=True)
    _FakeConnector._rows = [RawTicket(source="fake", source_id="F-9", title="x", project="PAY")]
    run_all_pulls()  # incremental=True by default
    cur = SyncCursor.objects.filter(source="fake").first()
    assert cur is not None and cur.cursor  # cursor advanced


@pytest.mark.django_db
def test_full_repull_when_incremental_false(fake_registered):
    from aegis.models import SyncCursor
    run_all_pulls(incremental=False)
    # No cursor row should be written for a forced full re-pull
    assert SyncCursor.objects.filter(source="fake").count() == 0
