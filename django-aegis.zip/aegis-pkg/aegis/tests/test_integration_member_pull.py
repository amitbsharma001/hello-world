"""
Integration test for the flagship cross-project team-member pull.

THIS TEST IS EXPECTED TO FAIL on the current code. It encodes the requirement:

    "If a team member is configured with pull_all_projects=True, the app should
     pull ALL their tasks across EVERY project — including projects that are NOT
     in the configured project list."

The connector's planner (level 3) DOES fetch such tickets. But ingest()'s project
gate then SKIPS any ticket whose project is not enabled — so the ticket the
connector fetched for the member is discarded. This test pins that contradiction.

When the gate is fixed to admit member-matched tickets, remove the xfail.
"""
import pytest

from aegis.models import Project, TeamMember, Ticket
from aegis.connectors.base import ingest, RawTicket


@pytest.mark.django_db
def test_cross_project_member_ticket_is_ingested_even_if_project_unconfigured():
    """
    Setup:
      - Marco is a tracked member with pull_all_projects=True.
      - He has a ticket in project 'SECRET' which is NOT configured at all.
    Expectation (the feature):
      - The ticket is ingested because it belongs to a tracked member, even though
        SECRET is not an enabled project.
    Fixed behavior:
      - ingest() admits the ticket via the member-override path (S1 #1 fix).
    """
    TeamMember.objects.create(
        name="Marco", account="marco@org.com", source="jira",
        pull_all_projects=True, sync_enabled=True,
    )
    # No Project row for SECRET — it is deliberately unconfigured.
    raws = [
        RawTicket(source="jira", source_id="SECRET-1", title="cross-project task",
                  assignee="marco@org.com", project="SECRET"),
    ]

    tickets, report = ingest(raws)

    # The feature requires this ticket to land because Marco is tracked.
    assert Ticket.objects.filter(source="jira", source_id="SECRET-1").count() == 1, (
        "Cross-project member ticket was dropped by the project gate. "
        "ingest() needs a member-override: admit tickets whose assignee matches an "
        "enabled TeamMember(pull_all_projects=True), regardless of project config."
    )
    assert report.imported == 1


@pytest.mark.django_db
def test_baseline_unconfigured_project_ticket_without_member_is_skipped():
    """Control: a ticket with NO matching tracked member and an unconfigured
    project should still be skipped. This documents the intended gate behavior so
    the member-override fix does not accidentally open the gate for everyone."""
    raws = [
        RawTicket(source="jira", source_id="RANDOM-1", title="orphan",
                  assignee="nobody@org.com", project="RANDOM"),
    ]
    tickets, report = ingest(raws)
    assert Ticket.objects.filter(source="jira", source_id="RANDOM-1").count() == 0
    assert report.imported == 0
