"""Tests for the Sync console's scoped pull modes and time windows.

Pins:
  * build_scope(mode=...) — "projects" drops cross-project members; "teams"
    includes EVERY sync-enabled member (works with zero projects) and ignores
    open mode.
  * all_member_accounts — the ingest admit-set for teams mode.
  * run_all_pulls WINDOW_DAYS mapping.
  * JiraConnector._jql_time / ServiceNowConnector._sn_time — ISO cursors are
    converted to formats the APIs accept (the raw ISO cursor was a latent
    HTTP-400 on every second incremental pull).
"""
import pytest

from aegis.models import Project, TeamMember
from aegis.services.pull_planner import build_scope
from aegis.services.sync_gate import all_member_accounts
from aegis.services.sync_runner import WINDOW_DAYS


@pytest.fixture
def jira_world(db):
    p = Project.objects.create(key="OPS", name="Ops", source="jira",
                               external_key="OPS", sync_enabled=True)
    TeamMember.objects.create(name="Ravi", source="jira", account="ravi@x.com",
                              pull_all_projects=True, sync_enabled=True)
    TeamMember.objects.create(name="Mina", source="jira", account="mina@x.com",
                              pull_all_projects=False, sync_enabled=True)
    TeamMember.objects.create(name="Off", source="jira", account="off@x.com",
                              pull_all_projects=True, sync_enabled=False)
    return p


@pytest.mark.django_db
def test_mode_all_is_original_behavior(jira_world):
    s = build_scope("jira", mode="all")
    assert s.project_keys == ["OPS"]
    assert s.member_accounts == ["ravi@x.com"]  # only pull_all_projects=True


@pytest.mark.django_db
def test_mode_projects_drops_members(jira_world):
    s = build_scope("jira", mode="projects")
    assert s.project_keys == ["OPS"]
    assert s.member_accounts == []


@pytest.mark.django_db
def test_mode_teams_every_enabled_member_no_projects(jira_world):
    s = build_scope("jira", mode="teams")
    assert s.project_keys == [] and s.project_members == {}
    assert sorted(s.member_accounts) == ["mina@x.com", "ravi@x.com"]  # not the disabled one


@pytest.mark.django_db
def test_mode_teams_works_with_zero_projects(db):
    TeamMember.objects.create(name="Solo", source="jira", account="solo@x.com",
                              pull_all_projects=False, sync_enabled=True)
    s = build_scope("jira", mode="teams")
    assert s.member_accounts == ["solo@x.com"]
    assert not s.is_empty


@pytest.mark.django_db
def test_explicit_mode_ignores_open_mode(settings, jira_world):
    settings.AEGIS = {"SYNC_REQUIRE_CONFIGURED_PROJECT": False}
    assert build_scope("jira", mode="all").pull_everything is True
    assert build_scope("jira", mode="teams").pull_everything is False


@pytest.mark.django_db
def test_all_member_accounts_lowercased_enabled_only(jira_world):
    assert all_member_accounts("jira") == {"ravi@x.com", "mina@x.com"}


def test_window_days_mapping():
    assert WINDOW_DAYS == {"1m": 30, "3m": 90, "6m": 180, "1y": 365}


def test_jira_jql_time_is_api_safe():
    from aegis.connectors.jira import JiraConnector
    c = JiraConnector({})
    out = c._jql_time("2026-07-12T09:15:23.123456+00:00")
    assert "T" not in out and "+" not in out
    # 14h profile-timezone buffer applied
    assert out == "2026-07-11 19:15"
    # Non-ISO literals pass through untouched
    assert c._jql_time("2026-01-01") == "2026-01-01"


def test_servicenow_time_is_api_safe():
    from aegis.connectors.servicenow import ServiceNowConnector
    c = ServiceNowConnector({})
    out = c._sn_time("2026-07-12T09:15:23+00:00")
    assert "T" not in out and out == "2026-07-12 08:15:23"
