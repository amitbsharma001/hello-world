"""Tests for the extracted health score (services/health.py).

Pins the extraction (must equal the original inline math) and the measured
structural finding that the score is backlog-dominated despite the 40% SLA label.
Full sensitivity characterization: scripts/eval_health.py."""
from aegis.services.health import compute_health, subscores, grade_for


def test_matches_original_math():
    def orig(sla, nf, esc, stale):
        s_sla = sla; s_b = max(0, 100 - max(0, nf) * 8)
        s_e = max(0, 100 - esc * 6); s_a = max(0, 100 - stale)
        return round(0.40 * s_sla + 0.25 * s_b + 0.20 * s_e + 0.15 * s_a)
    for c in [(95, 2, 1, 10), (60, 12, 8, 50), (100, 0, 0, 0), (30, 20, 15, 80)]:
        assert compute_health(*c)["health"] == orig(*c)


def test_grade_boundaries():
    assert grade_for(90)[0] == "A"
    assert grade_for(85)[0] == "B"
    assert grade_for(70)[0] == "C"
    assert grade_for(60)[0] == "D"
    assert grade_for(59)[0] == "F"


def test_perfect_inputs_score_100():
    r = compute_health(100, 0, 0, 0)
    assert r["health"] == 100 and r["grade"] == "A"


def test_subscores_clamped():
    s = subscores(150, -10, 100, 200)   # out-of-range inputs
    assert 0 <= s["sla"] <= 100
    assert s["backlog"] == 100          # negative net_flow -> no penalty
    assert s["escalations"] == 0        # 100 escalations -> pinned to 0
    assert s["aging"] == 0


def test_backlog_dominates_more_than_its_nominal_weight():
    """Structural finding: a swing in backlog moves the score MORE than a swing
    in SLA of equal sub-score magnitude, because backlog's ×8 multiplier gives it
    a wider effective range. (Nominal weights: SLA 40% > backlog 25%.)"""
    base = dict(sla_pct=88, net_flow=2, escalations=2, pct_stale=18)
    # Worsen SLA sub-score by ~40 points (100->60 range) vs backlog by pushing net_flow
    sla_worse = compute_health(**{**base, "sla_pct": 60})["health"]
    backlog_worse = compute_health(**{**base, "net_flow": 12})["health"]  # s_backlog 84->4
    good = compute_health(**base)["health"]
    # Backlog swing should be at least comparable to SLA swing despite lower weight
    assert (good - backlog_worse) >= (good - sla_worse)
