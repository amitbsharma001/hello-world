"""Tests for per-user AI config, agent gating, Jira write-back, and customer email."""
import pytest
from aegis.models import UserAIConfig, TicketAction, Ticket
from aegis.services.crypto import encrypt, decrypt, mask
from aegis.services.gemini import get_client, AIConfigRequired, MockGeminiClient
from aegis.services.jira_client import JiraClient
from aegis.conf import conf


# ---- crypto ----

def test_encrypt_roundtrip():
    secret = "AIzaSy-super-secret-key-123"
    token = encrypt(secret)
    assert token != secret
    assert decrypt(token) == secret


def test_encrypt_empty():
    assert encrypt("") == ""
    assert decrypt("") == ""


def test_mask_hides_most():
    m = mask("abcdefghijklmnop")
    assert m.endswith("mnop")
    assert "abcdef" not in m


# ---- UserAIConfig model ----

@pytest.mark.django_db
def test_config_stores_key_encrypted(admin_user):
    cfg = UserAIConfig.objects.create(user=admin_user)
    cfg.set_api_key("my-key")
    cfg.save()
    assert cfg.api_key_enc != "my-key"
    assert cfg.get_api_key() == "my-key"
    assert cfg.is_configured is True


@pytest.mark.django_db
def test_config_unconfigured_by_default(admin_user):
    cfg = UserAIConfig.objects.create(user=admin_user)
    assert cfg.is_configured is False
    assert cfg.jira_configured is False


@pytest.mark.django_db
def test_jira_configured_requires_all_three(admin_user):
    cfg = UserAIConfig.objects.create(user=admin_user, jira_base_url="https://x.atlassian.net",
                                      jira_email="a@b.c")
    assert cfg.jira_configured is False
    cfg.set_jira_token("tok")
    assert cfg.jira_configured is True


# ---- client gating ----

@pytest.mark.django_db
def test_get_client_requires_config_for_user(alice, monkeypatch):
    monkeypatch.setattr(conf, "REQUIRE_USER_AI_CONFIG", True, raising=False)
    # alice has no config row
    with pytest.raises(AIConfigRequired):
        get_client(alice)


@pytest.mark.django_db
def test_get_client_ok_when_configured(alice, monkeypatch):
    monkeypatch.setattr(conf, "REQUIRE_USER_AI_CONFIG", True, raising=False)
    cfg = UserAIConfig.objects.create(user=alice)
    cfg.set_api_key("k")
    cfg.save()
    client = get_client(alice)
    assert isinstance(client, MockGeminiClient)  # MOCK_GEMINI True in tests


@pytest.mark.django_db
def test_get_client_no_user_uses_mock():
    # system tasks (no user) still work
    assert isinstance(get_client(None), MockGeminiClient)


# ---- Jira client ----

def test_jira_mock_when_no_creds():
    c = JiraClient()
    assert c.live is False
    r = c.update_description("PAY-1", "new desc")
    assert r.ok is True
    assert r.mock is True


def test_jira_comment_mock():
    c = JiraClient()
    r = c.add_comment("PAY-1", "steps here")
    assert r.mock is True
    assert "body" in r.request["body"] or "body" in str(r.request)


@pytest.mark.django_db
def test_jira_for_user_reads_config(admin_user):
    cfg = UserAIConfig.objects.create(user=admin_user, jira_base_url="https://x.atlassian.net",
                                      jira_email="a@b.c")
    cfg.set_jira_token("tok")
    cfg.save()
    c = JiraClient.for_user(admin_user)
    assert c.live is True
    assert c.base_url == "https://x.atlassian.net"


# ---- settings view ----

@pytest.mark.django_db
def test_ai_settings_page_loads(alice_client):
    r = alice_client.get("/settings/ai/")
    assert r.status_code == 200
    assert b"AI configuration" in r.content


@pytest.mark.django_db
def test_ai_settings_saves_key(alice_client, alice):
    r = alice_client.post("/settings/ai/", {
        "provider": "gemini", "model_name": "gemini-2.5-flash", "api_key": "secret-key-xyz",
    })
    assert r.status_code == 302
    cfg = UserAIConfig.objects.get(user=alice)
    assert cfg.is_configured is True
    assert cfg.get_api_key() == "secret-key-xyz"


@pytest.mark.django_db
def test_ai_settings_keeps_key_when_blank(alice_client, alice):
    cfg = UserAIConfig.objects.create(user=alice)
    cfg.set_api_key("original")
    cfg.save()
    alice_client.post("/settings/ai/", {"provider": "gemini", "model_name": "m", "api_key": ""})
    cfg.refresh_from_db()
    assert cfg.get_api_key() == "original"


# ---- ticket actions ----

@pytest.fixture
def configured_alice(alice):
    cfg = UserAIConfig.objects.create(user=alice)
    cfg.set_api_key("k")
    cfg.save()
    return alice


@pytest.mark.django_db
def test_push_description_records_action(alice_client, configured_alice):
    t = Ticket.objects.create(source="jira", source_id="PAY-1", title="x", owner=configured_alice,
                              description_enhanced="Enhanced text", severity="sev2", status="open")
    r = alice_client.post(f"/t/{t.id}/push-description/")
    assert r.status_code == 200
    action = TicketAction.objects.get(ticket=t, kind="push_description")
    assert action.status in ("mock", "success")


@pytest.mark.django_db
def test_push_description_requires_enhanced(alice_client, configured_alice):
    t = Ticket.objects.create(source="jira", source_id="PAY-2", title="x", owner=configured_alice,
                              severity="sev3", status="open")
    r = alice_client.post(f"/t/{t.id}/push-description/")
    # No enhanced description -> error partial, no action recorded
    assert TicketAction.objects.filter(ticket=t, kind="push_description").count() == 0


@pytest.mark.django_db
def test_post_steps_requires_plan(alice_client, configured_alice):
    t = Ticket.objects.create(source="jira", source_id="PAY-3", title="x", owner=configured_alice,
                              severity="sev3", status="open")
    r = alice_client.post(f"/t/{t.id}/post-steps/")
    assert TicketAction.objects.filter(ticket=t, kind="post_comment").count() == 0


@pytest.mark.django_db
def test_post_steps_with_plan(alice_client, configured_alice):
    t = Ticket.objects.create(
        source="jira", source_id="PAY-4", title="x", owner=configured_alice,
        severity="sev2", status="open",
        plan_payload={"actions": [{"title": "Roll back", "description": "revert", "priority": "P0"}]},
    )
    r = alice_client.post(f"/t/{t.id}/post-steps/")
    assert r.status_code == 200
    assert TicketAction.objects.filter(ticket=t, kind="post_comment").count() == 1


@pytest.mark.django_db
def test_customer_email_generates(alice_client, configured_alice):
    t = Ticket.objects.create(source="jira", source_id="PAY-5", title="Login failing",
                              owner=configured_alice, severity="sev2", status="open",
                              description_raw="Users cannot log in")
    r = alice_client.post(f"/t/{t.id}/customer-email/")
    assert r.status_code == 200
    assert b"Subject" in r.content
    action = TicketAction.objects.get(ticket=t, kind="customer_email")
    assert action.payload.get("subject")


@pytest.mark.django_db
def test_customer_email_blocked_without_config(alice_client, alice, monkeypatch):
    monkeypatch.setattr(conf, "REQUIRE_USER_AI_CONFIG", True, raising=False)
    t = Ticket.objects.create(source="jira", source_id="PAY-6", title="x", owner=alice,
                              severity="sev3", status="open", description_raw="d")
    r = alice_client.post(f"/t/{t.id}/customer-email/")
    # Renders the config-required prompt instead of an email
    assert b"Configure your AI API key" in r.content
