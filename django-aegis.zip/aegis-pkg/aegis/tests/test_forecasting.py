"""Tests for the extracted run-rate forecasting (services/forecasting.py).

These pin the documented behavior AND its documented limitations (systematic
lag on trends), so nobody later mistakes the run-rate for a real forecast.
Measured characterization lives in scripts/eval_forecast.py."""
from aegis.services.forecasting import predict_next, project_backlog


def test_predict_next_is_trailing_mean():
    assert predict_next([2, 4, 6, 8], window=4) == 5
    assert predict_next([10], window=4) == 10
    assert predict_next([], window=4) == 0


def test_predict_next_uses_only_window():
    # far history is ignored
    assert predict_next([100, 100, 1, 1, 1, 1], window=4) == 1


def test_clearing_state():
    r = project_backlog([5, 5, 5, 5], [8, 8, 8, 8], backlog_now=20, window=4)
    assert r["backlog"]["state"] == "clearing"
    assert r["backlog"]["weeks"] == 6.7  # 20 / 3


def test_growing_state():
    r = project_backlog([10, 10, 10, 10], [6, 6, 6, 6], 30, window=4)
    assert r["backlog"]["state"] == "growing"
    assert r["backlog"]["rate"] == 4


def test_steady_state():
    r = project_backlog([7, 7, 7, 7], [7, 7, 7, 7], 10, window=4)
    assert r["backlog"]["state"] == "steady"


def test_documented_limitation_lags_rising_trend():
    """On a strictly rising series the trailing mean UNDER-predicts the next
    value — this is the documented bias, asserted so it stays visible."""
    rising = [10, 12, 14, 16, 18, 20]  # +2/week
    pred = predict_next(rising, window=4)   # mean(14,16,18,20) = 17
    actual_next = 22
    assert pred < actual_next               # under-shoots by design (no trend term)
