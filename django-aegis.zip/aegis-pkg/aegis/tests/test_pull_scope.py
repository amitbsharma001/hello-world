"""Tests for project + team-member pull scoping (Jira & ServiceNow)."""
import pytest
from aegis.models import Project, TeamMember
from aegis.services.pull_planner import build_scope
from aegis.connectors.jira import JiraConnector
from aegis.connectors.servicenow import ServiceNowConnector
from aegis.conf import conf


# ---- planner ----

@pytest.mark.django_db
def test_full_project_in_scope():
    Project.objects.create(key="PAY", name="Payments", external_key="PAY",
                           source="jira", sync_enabled=True,
                           member_scope=Project.MemberScope.ALL)
    scope = build_scope("jira")
    assert "PAY" in scope.project_keys
    assert scope.project_members == {}


@pytest.mark.django_db
def test_team_scoped_project_uses_members():
    p = Project.objects.create(key="MOB", name="Mobile", external_key="MOB",
                               source="jira", sync_enabled=True,
                               member_scope=Project.MemberScope.TEAM)
    m = TeamMember.objects.create(name="Priya", account="priya@org.com", source="jira",
                                  sync_enabled=True)
    p.members.add(m)
    scope = build_scope("jira")
    assert "MOB" not in scope.project_keys              # not a full pull
    assert scope.project_members["MOB"] == ["priya@org.com"]


@pytest.mark.django_db
def test_team_scoped_project_with_no_members_pulls_nothing():
    Project.objects.create(key="X", name="X", external_key="X", source="jira",
                           sync_enabled=True, member_scope=Project.MemberScope.TEAM)
    scope = build_scope("jira")
    assert "X" not in scope.project_keys
    assert "X" not in scope.project_members


@pytest.mark.django_db
def test_cross_project_member_in_scope():
    TeamMember.objects.create(name="Marco", account="marco@org.com", source="jira",
                              pull_all_projects=True, sync_enabled=True)
    scope = build_scope("jira")
    assert "marco@org.com" in scope.member_accounts


@pytest.mark.django_db
def test_source_isolation():
    TeamMember.objects.create(name="J", account="j@org.com", source="jira", sync_enabled=True)
    TeamMember.objects.create(name="S", account="s@org.com", source="servicenow", sync_enabled=True)
    jira_scope = build_scope("jira")
    snow_scope = build_scope("servicenow")
    assert "j@org.com" in jira_scope.member_accounts
    assert "j@org.com" not in snow_scope.member_accounts
    assert "s@org.com" in snow_scope.member_accounts


@pytest.mark.django_db
def test_disabled_excluded():
    Project.objects.create(key="OFF", name="Off", external_key="OFF", source="jira",
                           sync_enabled=False)
    TeamMember.objects.create(name="Z", account="z@org.com", source="jira", sync_enabled=False)
    scope = build_scope("jira")
    assert "OFF" not in scope.project_keys
    assert "z@org.com" not in scope.member_accounts


@pytest.mark.django_db
def test_open_mode_pulls_everything(monkeypatch):
    monkeypatch.setattr(conf, "SYNC_REQUIRE_CONFIGURED_PROJECT", False, raising=False)
    scope = build_scope("jira")
    assert scope.pull_everything is True


# ---- Jira scoped JQL ----

@pytest.mark.django_db
def test_jira_jql_combines_levels():
    Project.objects.create(key="PAY", name="Payments", external_key="PAY", source="jira",
                           sync_enabled=True, member_scope=Project.MemberScope.ALL)
    p2 = Project.objects.create(key="MOB", name="Mobile", external_key="MOB", source="jira",
                                sync_enabled=True, member_scope=Project.MemberScope.TEAM)
    m = TeamMember.objects.create(name="Priya", account="priya@org.com", source="jira", sync_enabled=True)
    p2.members.add(m)
    TeamMember.objects.create(name="Marco", account="marco@org.com", source="jira",
                              pull_all_projects=True, sync_enabled=True)

    jql = JiraConnector()._build_scoped_jql("updated >= -7d")
    assert 'project in ("PAY")' in jql
    assert 'project = "MOB" AND assignee in ("priya@org.com")' in jql
    assert 'assignee in ("marco@org.com")' in jql
    assert " OR " in jql and "updated >= -7d" in jql


@pytest.mark.django_db
def test_jira_jql_none_when_empty():
    assert JiraConnector()._build_scoped_jql("updated >= -7d") is None


# ---- ServiceNow scoped query ----

@pytest.mark.django_db
def test_servicenow_query_combines_levels():
    Project.objects.create(key="NETW", name="Network", external_key="Network", source="servicenow",
                           sync_enabled=True, member_scope=Project.MemberScope.ALL)
    TeamMember.objects.create(name="Sam", account="sam@org.com", source="servicenow",
                              pull_all_projects=True, sync_enabled=True)
    q = ServiceNowConnector()._build_scoped_query(None)
    assert "assignment_group.nameINNetwork" in q
    assert "assigned_to.emailINsam@org.com" in q
    assert "sys_updated_on>=" in q


@pytest.mark.django_db
def test_servicenow_query_none_when_empty():
    assert ServiceNowConnector()._build_scoped_query(None) is None


# ---- team config views ----

@pytest.mark.django_db
def test_teams_page_admin(admin_client):
    TeamMember.objects.create(name="Priya", account="priya@org.com", source="jira")
    r = admin_client.get("/teams/")
    assert r.status_code == 200
    assert b"Team members" in r.content
    assert b"priya@org.com" in r.content


@pytest.mark.django_db
def test_teams_page_user_blocked(alice_client):
    assert alice_client.get("/teams/").status_code == 404


@pytest.mark.django_db
def test_team_create(admin_client):
    r = admin_client.post("/teams/new/", {
        "name": "Yuki", "account": "yuki@org.com", "source": "jira",
        "pull_all_projects": "on", "sync_enabled": "on",
    })
    assert r.status_code == 302
    m = TeamMember.objects.get(account="yuki@org.com")
    assert m.pull_all_projects is True


@pytest.mark.django_db
def test_team_toggle(admin_client):
    m = TeamMember.objects.create(name="Dana", account="dana@org.com", source="jira", sync_enabled=True)
    admin_client.post(f"/teams/{m.id}/toggle/")
    m.refresh_from_db()
    assert m.sync_enabled is False


@pytest.mark.django_db
def test_team_links_projects(admin_client):
    p = Project.objects.create(key="PAY", name="Payments", source="jira", sync_enabled=True)
    r = admin_client.post("/teams/new/", {
        "name": "Lee", "account": "lee@org.com", "source": "jira",
        "sync_enabled": "on", "projects": [str(p.id)],
    })
    assert r.status_code == 302
    m = TeamMember.objects.get(account="lee@org.com")
    assert p in m.projects.all()


# ---- dashboard member KPIs ----

@pytest.mark.django_db
def test_dashboard_shows_member_kpis(admin_client):
    from aegis.models import Ticket
    TeamMember.objects.create(name="Priya", account="priya@x.com", source="jira", sync_enabled=True)
    Ticket.objects.create(source="jira", source_id="A-1", title="t1", assignee="priya@x.com",
                          severity="sev1", status="open", team="Payments")
    Ticket.objects.create(source="jira", source_id="A-2", title="t2", assignee="priya@x.com",
                          severity="sev3", status="open", team="Mobile")
    r = admin_client.get("/dashboard/")
    assert r.status_code == 200
    assert b"Team member performance" in r.content
    assert b"priya@x.com" in r.content


# ---- Phase 1 fixes: member override + connector correctness ----

@pytest.mark.django_db
def test_member_override_admits_team_scoped_member_in_disabled_project():
    """A tracked member's ticket lands even when its project is explicitly disabled."""
    from aegis.connectors.base import ingest, RawTicket
    Project.objects.create(key="OFF", name="Disabled", external_key="OFF",
                           source="jira", sync_enabled=False)
    TeamMember.objects.create(name="Marco", account="marco@org.com", source="jira",
                              pull_all_projects=True, sync_enabled=True)
    tickets, report = ingest([
        RawTicket(source="jira", source_id="OFF-1", title="x",
                  assignee="marco@org.com", project="OFF"),
    ])
    assert Ticket.objects.filter(source_id="OFF-1").count() == 1
    assert report.imported == 1


@pytest.mark.django_db
def test_member_override_is_source_scoped():
    """A ServiceNow member must NOT admit a Jira ticket with the same email."""
    from aegis.connectors.base import ingest, RawTicket
    TeamMember.objects.create(name="Sam", account="sam@org.com", source="servicenow",
                              pull_all_projects=True, sync_enabled=True)
    tickets, report = ingest([
        RawTicket(source="jira", source_id="J-1", title="x",
                  assignee="sam@org.com", project="UNCONF"),
    ])
    assert Ticket.objects.filter(source_id="J-1").count() == 0


@pytest.mark.django_db
def test_member_override_ignores_non_pull_all_members():
    """A member with pull_all_projects=False does NOT override the project gate."""
    from aegis.connectors.base import ingest, RawTicket
    TeamMember.objects.create(name="Lee", account="lee@org.com", source="jira",
                              pull_all_projects=False, sync_enabled=True)
    tickets, report = ingest([
        RawTicket(source="jira", source_id="U-1", title="x",
                  assignee="lee@org.com", project="UNCONF"),
    ])
    assert Ticket.objects.filter(source_id="U-1").count() == 0


@pytest.mark.django_db
def test_jira_jql_escapes_quotes():
    """A value containing a double quote must be escaped, not break the query."""
    p = Project.objects.create(key="WEIRD", name='W"x', external_key='ABC"DEF',
                               source="jira", sync_enabled=True,
                               member_scope=Project.MemberScope.ALL)
    jql = JiraConnector()._build_scoped_jql("updated >= -7d")
    assert '\\"' in jql  # the embedded quote is backslash-escaped


@pytest.mark.django_db
def test_servicenow_time_clause_on_every_group():
    """Each OR-group must carry its own time bound, not just the last."""
    Project.objects.create(key="NETW", name="Network", external_key="Network",
                           source="servicenow", sync_enabled=True,
                           member_scope=Project.MemberScope.ALL)
    TeamMember.objects.create(name="Sam", account="sam@org.com", source="servicenow",
                              pull_all_projects=True, sync_enabled=True)
    q = ServiceNowConnector()._build_scoped_query(None)
    # Two OR-groups -> the time field must appear twice (once per group).
    assert q.count("sys_updated_on>=") == 2
    assert "^NQ" in q


def test_jira_assignee_identity_falls_back_to_account_id():
    """When email is absent (GDPR), accountId is used as the identity."""
    c = JiraConnector()
    assert c._assignee_identity({"accountId": "5b10ac", "displayName": "P"}) == "5b10ac"
    assert c._assignee_identity({"emailAddress": "p@org.com", "accountId": "x"}) == "p@org.com"
    assert c._assignee_identity(None) == ""
