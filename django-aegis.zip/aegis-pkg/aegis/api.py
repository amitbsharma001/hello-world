"""REST API. Mounted at /<aegis_prefix>/api/."""
from rest_framework import serializers, viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import NotFound

from .models import Ticket, AIArtifact
from .services import enhance_description, generate_plan, detect_missing_info
from .services.sla import score as sla_score
from .perms import filter_for_user, can_view


class TicketSerializer(serializers.ModelSerializer):
    score = serializers.SerializerMethodField()
    source = serializers.CharField(required=False, allow_blank=True)
    source_id = serializers.CharField(required=False, allow_blank=True)
    source_url = serializers.URLField(required=False, allow_blank=True)
    assignee = serializers.CharField(required=False, allow_blank=True)
    team = serializers.CharField(required=False, allow_blank=True)
    owner_username = serializers.SerializerMethodField()

    class Meta:
        model = Ticket
        fields = [
            "id", "source", "source_id", "source_url",
            "owner", "owner_username",
            "title", "description_raw", "description_enhanced",
            "enhanced_payload", "plan_payload", "missing_info_payload",
            "status", "severity", "priority_ai", "assignee", "team",
            "tags", "affected_systems", "impacted_users",
            "opened_at", "last_external_update_at", "sla_due_at",
            "created_at", "updated_at", "score",
        ]
        read_only_fields = [
            "id", "owner", "owner_username",
            "description_enhanced", "enhanced_payload",
            "plan_payload", "missing_info_payload",
            "created_at", "updated_at", "score",
        ]
        validators = []

    def get_score(self, obj):
        return sla_score(obj)

    def get_owner_username(self, obj):
        return obj.owner.username if obj.owner else None


class AIArtifactSerializer(serializers.ModelSerializer):
    class Meta:
        model = AIArtifact
        fields = ["id", "kind", "model", "payload", "confidence",
                  "tokens_in", "tokens_out", "cost_usd", "latency_ms",
                  "created_at"]


class TicketViewSet(viewsets.ModelViewSet):
    serializer_class = TicketSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return filter_for_user(
            Ticket.objects.all().order_by("-opened_at"),
            self.request.user,
        )

    def perform_create(self, serializer):
        serializer.save(source="api", owner=self.request.user)

    def _get_owned_ticket(self, pk):
        """Like get_object() but using the user-scoped queryset."""
        try:
            return self.get_queryset().get(pk=pk)
        except Ticket.DoesNotExist:
            raise NotFound()

    @action(detail=True, methods=["post"])
    def enhance(self, request, pk=None):
        ticket = self._get_owned_ticket(pk)
        artifact = enhance_description(ticket, force=True)
        return Response(AIArtifactSerializer(artifact).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def plan(self, request, pk=None):
        ticket = self._get_owned_ticket(pk)
        artifact = generate_plan(ticket, force=True)
        return Response(AIArtifactSerializer(artifact).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def missing_info(self, request, pk=None):
        ticket = self._get_owned_ticket(pk)
        artifact = detect_missing_info(ticket, force=True)
        return Response(AIArtifactSerializer(artifact).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def analyze(self, request, pk=None):
        ticket = self._get_owned_ticket(pk)
        enhance_description(ticket, force=True)
        ticket.refresh_from_db()
        generate_plan(ticket, force=True)
        detect_missing_info(ticket, force=True)
        ticket.refresh_from_db()
        return Response(TicketSerializer(ticket).data)

    @action(detail=True, methods=["get"])
    def artifacts(self, request, pk=None):
        ticket = self._get_owned_ticket(pk)
        return Response(AIArtifactSerializer(ticket.artifacts.all()[:50], many=True).data)
