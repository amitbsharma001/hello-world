"""Connector ABC, RawTicket DTO, and a registry."""
from __future__ import annotations
import hashlib
import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Iterable, Optional, Any
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from ..models import Ticket

log = logging.getLogger("assist.connectors.ingest")


@dataclass
class RawTicket:
    source: str
    source_id: str = ""
    source_url: str = ""
    title: str = ""
    description: str = ""
    status: str = "open"
    severity: str = "sev3"
    assignee: str = ""
    team: str = ""
    project: str = ""   # project key/code used for sync gating
    tags: list = field(default_factory=list)
    opened_at: Optional[datetime] = None
    last_external_update_at: Optional[datetime] = None
    extra: dict = field(default_factory=dict)

    def content_hash(self) -> str:
        payload = json.dumps(
            [self.title, self.description, self.status, self.severity, self.assignee],
            sort_keys=True,
        ).encode()
        return hashlib.sha256(payload).hexdigest()


class Connector(ABC):
    """All connectors implement this. Sync model — keep it simple."""
    name: str = ""
    supports_pull: bool = False   # True if this connector actively pulls from a source

    def __init__(self, config: dict | None = None):
        self.config = config or {}

    @abstractmethod
    def fetch(self, cursor: str | None = None) -> Iterable[RawTicket]:
        """Yield RawTickets. Cursor is opaque to the framework."""
        ...

    def health_check(self) -> bool:
        return True

    def update_source(self, source_id: str, new_description: str) -> None:
        """Optional: write enhanced description back to source. Default: no-op."""
        return None


class _Registry:
    def __init__(self):
        self._connectors: dict[str, type[Connector]] = {}

    def register(self, cls: type[Connector]):
        self._connectors[cls.name] = cls

    def get(self, name: str) -> type[Connector] | None:
        return self._connectors.get(name)

    def list(self) -> list[str]:
        return sorted(self._connectors.keys())


registry = _Registry()


# ---- Canonical upsert ----

def upsert_raw(raw: RawTicket, project=None) -> tuple[Ticket, bool, bool]:
    """
    Insert or update a Ticket from a RawTicket.

    Returns (ticket, created, content_changed).
    """
    new_hash = raw.content_hash()

    # Look up existing first so we can compare hashes BEFORE writing
    existing = None
    if raw.source_id:
        existing = Ticket.objects.filter(source=raw.source, source_id=raw.source_id).first()

    defaults = {
        "title": raw.title or "(untitled)",
        "description_raw": raw.description or "",
        "status": _normalize_status(raw.status),
        "severity": _normalize_severity(raw.severity),
        "assignee": raw.assignee or "",
        "team": raw.team or (project.default_team if project else ""),
        "tags": list(raw.tags or []),
        "source_url": raw.source_url or "",
        "opened_at": raw.opened_at or timezone.now(),
        "last_external_update_at": raw.last_external_update_at or timezone.now(),
        "content_hash": new_hash,
    }
    if project is not None:
        defaults["project"] = project

    if existing:
        # Don't overwrite opened_at for existing tickets
        defaults.pop("opened_at", None)
        changed = existing.content_hash != new_hash
        for k, v in defaults.items():
            setattr(existing, k, v)
        existing.save()
        return existing, False, changed
    elif raw.source_id:
        ticket = Ticket.objects.create(source=raw.source, source_id=raw.source_id, **defaults)
        return ticket, True, True
    else:
        ticket = Ticket.objects.create(source=raw.source, **defaults)
        return ticket, True, True


def ingest(raws, *, auto_register: bool = True, admit_assignees=None):
    """
    Gated ingest. A ticket is written if EITHER:
      (a) its project is configured AND enabled, OR
      (b) its assignee matches an enabled TeamMember(pull_all_projects=True) for
          the same source — a tracked person's work is pulled across every
          project, including projects that are not themselves configured, OR
      (c) its assignee is in `admit_assignees` — an explicit override used by
          scoped pulls (e.g. the Sync console's "Teams only" mode), where the
          fetch itself was already limited to those people.

    Otherwise it is skipped and counted. Returns (list_of_tickets, SyncReport).
    """
    from ..services.sync_gate import resolve_project, SyncReport, tracked_member_accounts
    from django.utils import timezone as _tz

    report = SyncReport()
    tickets = []
    touched_projects = {}

    admit = {a.strip().lower() for a in (admit_assignees or ()) if a and a.strip()}

    # Preload tracked cross-project member accounts per source (one query/source).
    member_accounts: dict[str, set] = {}

    def _is_tracked(raw) -> bool:
        acct = (raw.assignee or "").strip().lower()
        if not acct:
            return False
        if acct in admit:
            return True
        if raw.source not in member_accounts:
            member_accounts[raw.source] = tracked_member_accounts(raw.source)
        return acct in member_accounts[raw.source]

    raws = list(raws)
    log.info("ingest START — %d raw ticket(s) to gate%s", len(raws),
             " (admitting %d pull-scoped assignee(s))" % len(admit) if admit else "")

    for raw in raws:
        key = (raw.project or raw.team or "").strip()
        decision = resolve_project(raw.source, key, name=raw.team or key,
                                   auto_register=auto_register)

        if not decision.allowed:
            # Member override: admit a tracked person's ticket regardless of the
            # project gate. The (possibly auto-registered/discovered) project is
            # still attached for labeling.
            if _is_tracked(raw):
                log.debug("ingest ADMIT(member-override) id=%s project=%s assignee=%s",
                          raw.source_id, key, raw.assignee)
                ticket, created, _ = upsert_raw(raw, project=decision.project)
                tickets.append(ticket)
                if created:
                    report.imported += 1
                else:
                    report.updated += 1
                if decision.project:
                    touched_projects[decision.project.id] = decision.project
                continue

            # Not project-allowed and not a tracked member -> skip.
            log.debug("ingest SKIP id=%s project=%s reason=%s (assignee=%s not tracked)",
                      raw.source_id, key, decision.reason, raw.assignee)
            if decision.reason == "discovered":
                report.skipped_discovered += 1
                if decision.project and decision.project.key not in report.discovered_projects:
                    report.discovered_projects.append(decision.project.key)
            else:
                report.skipped_disabled += 1
            continue

        log.debug("ingest ADMIT(project) id=%s project=%s reason=%s",
                  raw.source_id, key, decision.reason)
        ticket, created, _ = upsert_raw(raw, project=decision.project)
        tickets.append(ticket)
        if created:
            report.imported += 1
        else:
            report.updated += 1
        if decision.project:
            touched_projects[decision.project.id] = decision.project

    for proj in touched_projects.values():
        proj.last_synced_at = _tz.now()
        proj.save(update_fields=["last_synced_at"])

    log.info("ingest END — imported=%d updated=%d skipped_disabled=%d "
             "skipped_discovered=%d discovered=%s",
             report.imported, report.updated, report.skipped_disabled,
             report.skipped_discovered, report.discovered_projects)
    return tickets, report


_STATUS_MAP = {
    "to do": "open", "todo": "open", "new": "open", "open": "open",
    "in progress": "in_progress", "in_progress": "in_progress", "doing": "in_progress",
    "blocked": "blocked",
    "waiting": "waiting_customer", "pending": "waiting_customer",
    "resolved": "resolved", "done": "resolved", "fixed": "resolved",
    "closed": "closed",
}


def _normalize_status(s: str) -> str:
    return _STATUS_MAP.get((s or "").lower().strip().replace("-", " "), "open")


def _normalize_severity(s: str) -> str:
    s = (s or "").lower().strip()
    if s in ("highest", "blocker", "critical", "p0", "sev1"):
        return "sev1"
    if s in ("high", "p1", "sev2"):
        return "sev2"
    if s in ("medium", "normal", "p2", "sev3"):
        return "sev3"
    if s in ("low", "lowest", "p3", "sev4"):
        return "sev4"
    return "sev3"
