from typing import Iterable
from .base import Connector, RawTicket


class ManualConnector(Connector):
    """No-op fetch. Manual tickets are created via the UI / REST API directly."""
    name = "manual"

    def fetch(self, cursor=None) -> Iterable[RawTicket]:
        return iter(())
