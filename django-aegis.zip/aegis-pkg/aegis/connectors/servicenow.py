"""
ServiceNow connector. Pulls incidents from the Table API, scoped to configured
projects and team members — mirroring the Jira connector's three-level control:

  1. Full project        -> assignment_group = <project external_key>
  2. Team-scoped project -> assignment_group = X AND assigned_to.email IN (members)
  3. Cross-project member -> assigned_to.email IN (members)  (any group)

In ServiceNow we map a "project" (Team) to an assignment_group name, and a team
member to an assigned_to email. The scope is OR-combined into one encoded query.
"""
from __future__ import annotations
import logging
from typing import Iterable

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from .base import Connector, RawTicket

log = logging.getLogger("assist.connectors.servicenow")

# ServiceNow incident priority (1..5) -> our severity
_PRIORITY_TO_SEV = {"1": "sev1", "2": "sev2", "3": "sev3", "4": "sev4", "5": "sev4"}
# ServiceNow incident state -> our status
_STATE_TO_STATUS = {
    "1": "open", "2": "in_progress", "3": "in_progress",
    "6": "resolved", "7": "closed", "8": "blocked",
}


class ServiceNowConnector(Connector):
    name = "servicenow"
    supports_pull = True

    def __init__(self, config=None):
        super().__init__(config)
        self.base_url = self.config.get("base_url", "").rstrip("/")
        self.user = self.config.get("user", "")
        self.password = self.config.get("password", "")
        self.table = self.config.get("table", "incident")
        self.page_size = int(self.config.get("page_size", 50))
        self.window = self.config.get("window", "javascript:gs.beginningOfLast7Days()")

    def _client(self) -> httpx.Client:
        return httpx.Client(
            base_url=self.base_url,
            auth=(self.user, self.password),
            timeout=30,
            headers={"Accept": "application/json"},
        )

    def health_check(self) -> bool:
        if not (self.base_url and self.user and self.password):
            return False
        try:
            with self._client() as c:
                r = c.get(f"/api/now/table/{self.table}", params={"sysparm_limit": 1})
                return r.status_code == 200
        except Exception:
            return False

    def _build_scoped_query(self, cursor: str | None) -> str | None:
        """Translate PullScope into a ServiceNow encoded query. None => nothing."""
        from ..services.pull_planner import build_scope
        scope = build_scope("servicenow")

        time_clause = f"sys_updated_on>={cursor}" if cursor else f"sys_updated_on>={self.window}"

        if scope.pull_everything:
            return time_clause

        ors: list[str] = []
        # 1. Full projects -> assignment_group.name IN (...)
        if scope.project_keys:
            groups = ",".join(scope.project_keys)
            ors.append(f"assignment_group.nameIN{groups}")
        # 2. Team-scoped projects -> group = X AND assigned_to.email IN (members)
        for grp, accounts in scope.project_members.items():
            emails = ",".join(accounts)
            # NQ separates OR groups in ServiceNow encoded queries
            ors.append(f"assignment_group.name={grp}^assigned_to.emailIN{emails}")
        # 3. Cross-project members -> assigned_to.email IN (members)
        if scope.member_accounts:
            emails = ",".join(scope.member_accounts)
            ors.append(f"assigned_to.emailIN{emails}")

        if not ors:
            return None

        # Each ^NQ starts a NEW query (OR at the top level). A single trailing
        # time clause would only constrain the LAST group, letting the others
        # pull unbounded history. So AND the time clause into EVERY group:
        #   (A AND time) OR (B AND time) OR (C AND time)
        scoped = "^NQ".join(f"{clause}^{time_clause}" for clause in ors)
        return scoped

    @retry(
        retry=retry_if_exception_type((httpx.TransportError,)),
        stop=stop_after_attempt(4),
        wait=wait_exponential_jitter(initial=1, max=10),
    )
    def _get(self, client: httpx.Client, path: str, **params):
        r = client.get(path, params=params)
        r.raise_for_status()
        return r.json()

    def fetch(self, cursor: str | None = None) -> Iterable[RawTicket]:
        if not self.health_check():
            log.warning("assist.servicenow.unconfigured_or_unreachable")
            return

        query = self._build_scoped_query(cursor)
        if query is None:
            log.info("assist.servicenow.nothing_in_scope — no enabled projects or members")
            return
        log.info("assist.servicenow.scoped_pull query=%s", query)

        offset = 0
        with self._client() as client:
            while True:
                data = self._get(
                    client, f"/api/now/table/{self.table}",
                    sysparm_query=query,
                    sysparm_offset=offset,
                    sysparm_limit=self.page_size,
                    sysparm_display_value="all",
                    sysparm_exclude_reference_link="true",
                )
                rows = data.get("result", [])
                if not rows:
                    return
                for row in rows:
                    yield self._to_raw(row)
                if len(rows) < self.page_size:
                    return
                offset += len(rows)

    # --- mapping ---

    def _dv(self, field) -> str:
        """ServiceNow display-value fields come back as {'value':..,'display_value':..}."""
        if isinstance(field, dict):
            return field.get("display_value") or field.get("value") or ""
        return field or ""

    @staticmethod
    def _aware(value: str):
        """Parse a ServiceNow timestamp ('YYYY-MM-DD HH:MM:SS', UTC) into an
        aware datetime so it is safe under USE_TZ=True. Uses stdlib UTC to remain
        compatible with Django 5 (which removed django.utils.timezone.utc)."""
        from datetime import timezone as _dt_tz
        if not value:
            return None
        dt = parse_datetime(value.replace(" ", "T"))
        if dt is None:
            return None
        if timezone.is_naive(dt):
            dt = timezone.make_aware(dt, _dt_tz.utc)
        return dt

    def _to_raw(self, row: dict) -> RawTicket:
        priority = self._dv(row.get("priority")) or "3"
        priority_code = priority.split(" ")[0] if priority else "3"
        state = self._dv(row.get("state")) or "1"
        state_code = state.split(" ")[0] if state else "1"
        group = self._dv(row.get("assignment_group"))
        assignee_email = ""
        at = row.get("assigned_to")
        if isinstance(at, dict):
            assignee_email = at.get("email", "") or at.get("display_value", "")

        number = self._dv(row.get("number"))
        return RawTicket(
            source="servicenow",
            source_id=number,
            source_url=f"{self.base_url}/nav_to.do?uri={self.table}.do?sys_id={self._dv(row.get('sys_id'))}",
            title=self._dv(row.get("short_description")),
            description=self._dv(row.get("description")),
            status=_STATE_TO_STATUS.get(state_code, "open"),
            severity=_PRIORITY_TO_SEV.get(priority_code, "sev3"),
            assignee=assignee_email,
            team=group,
            project=group,   # group maps to the project/team for gating
            tags=[],
            opened_at=self._aware(self._dv(row.get("opened_at"))),
            last_external_update_at=self._aware(self._dv(row.get("sys_updated_on"))),
            extra={"sys_id": self._dv(row.get("sys_id"))},
        )
