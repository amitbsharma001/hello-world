"""
Connector registry.

Each connector is imported and registered independently and defensively: if a
connector fails to import (e.g. an optional dependency for that source is not
installed), it is skipped with a warning and the rest of the registry still
loads. This prevents one connector's missing extra from breaking the whole app.
"""
import importlib
import logging

from .base import Connector, RawTicket, registry

log = logging.getLogger("aegis.connectors")

# (module, class) pairs — order controls registry listing only.
_CONNECTORS = [
    ("manual", "ManualConnector"),
    ("jira", "JiraConnector"),
    ("csv_connector", "CSVConnector"),
    ("servicenow", "ServiceNowConnector"),
]


def _try_register(module_name: str, class_name: str) -> bool:
    """Import and register one connector. Returns True on success; on any import
    error (including a missing optional dependency) logs a warning and returns
    False without raising."""
    try:
        mod = importlib.import_module(f".{module_name}", __name__)
        registry.register(getattr(mod, class_name))
        return True
    except Exception as e:  # noqa: BLE001 - deliberately broad: never break app load
        log.warning("aegis.connectors.skip module=%s class=%s err=%s",
                    module_name, class_name, e)
        return False


for _mod, _cls in _CONNECTORS:
    _try_register(_mod, _cls)

__all__ = ["Connector", "RawTicket", "registry", "_try_register"]
