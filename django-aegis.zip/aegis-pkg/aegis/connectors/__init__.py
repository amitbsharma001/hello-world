from .base import Connector, RawTicket, registry
from .jira import JiraConnector
from .manual import ManualConnector
from .csv_connector import CSVConnector

# Register
registry.register(ManualConnector)
registry.register(JiraConnector)
registry.register(CSVConnector)

__all__ = ["Connector", "RawTicket", "registry"]
