"""CSV connector. Headers: source_id,title,description,status,severity,assignee,team,tags"""
import csv
import io
from typing import Iterable
from django.utils import timezone

from .base import Connector, RawTicket


class CSVConnector(Connector):
    name = "csv"

    def __init__(self, config=None, *, content: str | bytes | None = None):
        super().__init__(config)
        self._content = content

    def fetch(self, cursor=None) -> Iterable[RawTicket]:
        if not self._content:
            return
        text = self._content.decode("utf-8") if isinstance(self._content, bytes) else self._content
        reader = csv.DictReader(io.StringIO(text))
        for row in reader:
            yield RawTicket(
                source="csv",
                source_id=row.get("source_id", "").strip(),
                title=row.get("title", "").strip(),
                description=row.get("description", "").strip(),
                status=row.get("status", "open").strip(),
                severity=row.get("severity", "sev3").strip(),
                assignee=row.get("assignee", "").strip(),
                team=row.get("team", "").strip(),
                project=(row.get("project", "") or row.get("team", "")).strip(),
                tags=[t.strip() for t in row.get("tags", "").split("|") if t.strip()],
                opened_at=timezone.now(),
                last_external_update_at=timezone.now(),
            )
