"""Jira Cloud connector. Polls JQL since cursor."""
from __future__ import annotations
import logging
from datetime import timedelta, timezone as _utc
from typing import Iterable
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
from django.utils.dateparse import parse_datetime

from .base import Connector, RawTicket

log = logging.getLogger("assist.connectors.jira")


class JiraConnector(Connector):
    name = "jira"
    supports_pull = True

    def __init__(self, config=None):
        super().__init__(config)
        self.base_url = self.config.get("base_url", "").rstrip("/")
        self.email = self.config.get("email", "")
        # Accept both "token" (from per-user Jira config) and "api_token" (settings).
        self.token = self.config.get("token") or self.config.get("api_token", "")
        self.jql = self.config.get("jql", "updated >= -7d")
        self.page_size = int(self.config.get("page_size", 50))
        log.debug(
            "jira.init base_url=%s email=%s token=%s page_size=%s default_jql=%s",
            self.base_url or "<empty>",
            (self.email or "<empty>"),
            ("<set:%d chars>" % len(self.token)) if self.token else "<empty>",
            self.page_size, self.jql,
        )

    def _client(self) -> httpx.Client:
        return httpx.Client(
            base_url=self.base_url,
            auth=(self.email, self.token),
            timeout=30,
            headers={"Accept": "application/json"},
        )

    def health_check(self) -> bool:
        # Log the SPECIFIC reason for failure so "pulls nothing" is debuggable.
        missing = [k for k, v in (("base_url", self.base_url), ("email", self.email),
                                  ("token", self.token)) if not v]
        if missing:
            log.warning("jira.health_check FAILED — missing config: %s "
                        "(set AEGIS['CONNECTORS']['jira'] or your Jira creds in AI Settings)",
                        ", ".join(missing))
            return False
        try:
            with self._client() as c:
                r = c.get("/rest/api/3/myself")
                if r.status_code == 200:
                    who = ""
                    try:
                        who = r.json().get("emailAddress") or r.json().get("displayName", "")
                    except Exception:
                        pass
                    log.info("jira.health_check OK — authenticated as %s at %s", who, self.base_url)
                    return True
                log.warning("jira.health_check FAILED — %s/rest/api/3/myself returned HTTP %s: %s",
                            self.base_url, r.status_code, (r.text or "")[:200])
                return False
        except Exception as e:
            log.warning("jira.health_check FAILED — request error to %s: %s: %s",
                        self.base_url, type(e).__name__, e)
            return False

    @retry(
        retry=retry_if_exception_type((httpx.TransportError,)),
        stop=stop_after_attempt(4),
        wait=wait_exponential_jitter(initial=1, max=10),
    )
    def _get(self, client: httpx.Client, path: str, **params):
        r = client.get(path, params=params)
        r.raise_for_status()
        return r.json()

    @staticmethod
    def _assignee_identity(assignee) -> str:
        """Jira Cloud often nulls emailAddress under GDPR and exposes only
        accountId. Match TeamMembers configured by either: prefer email, fall
        back to accountId, then displayName."""
        a = assignee or {}
        return (a.get("emailAddress") or a.get("accountId") or a.get("displayName") or "").strip()

    @staticmethod
    def _jql_str(value: str) -> str:
        r"""Quote+escape a value for JQL. Backslash and double-quote are escaped
        per Atlassian's reserved-character rules to prevent breakage/injection."""
        v = (value or "").replace("\\", "\\\\").replace('"', '\\"')
        return f'"{v}"'

    def _jql_time(self, cursor: str) -> str:
        """Convert a stored ISO-8601 cursor into a JQL-safe time literal.

        Jira REJECTS ISO strings with 'T'/offset (e.g. 2026-07-12T09:15:23+00:00
        -> HTTP 400). JQL wants 'yyyy-MM-dd HH:mm', interpreted in the Jira
        *profile* timezone. We normalise to UTC and subtract a 14h buffer (the
        max UTC offset) so no profile timezone can cause missed updates — the
        overlap is harmless because ingest upserts by source_id.
        """
        dt = parse_datetime(cursor)
        if dt is None:
            return cursor  # already a plain JQL literal like '2026-01-01'
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=_utc.utc)
        dt = dt.astimezone(_utc.utc) - timedelta(hours=14)
        return dt.strftime("%Y-%m-%d %H:%M")

    def _build_scoped_jql(self, time_clause: str) -> str | None:
        """Translate the PullScope into JQL. Returns None if nothing to pull."""
        from ..services.pull_planner import build_scope
        mode = self.config.get("pull_mode") or "all"
        scope = build_scope("jira", mode=mode)
        log.debug("jira.scope mode=%s pull_everything=%s project_keys=%s project_members=%s member_accounts=%s",
                  mode, scope.pull_everything, scope.project_keys,
                  dict(scope.project_members), scope.member_accounts)

        if scope.pull_everything:
            log.info("jira.scope OPEN MODE (SYNC_REQUIRE_CONFIGURED_PROJECT=False) — pulling all")
            return time_clause

        clauses: list[str] = []
        # 1. Full projects
        if scope.project_keys:
            keys = ", ".join(self._jql_str(k) for k in scope.project_keys)
            clauses.append(f"project in ({keys})")
        # 2. Team-scoped projects: project = X AND assignee in (members)
        for pk, accounts in scope.project_members.items():
            members = ", ".join(self._jql_str(a) for a in accounts)
            clauses.append(f"(project = {self._jql_str(pk)} AND assignee in ({members}))")
        # 3. Cross-project members: assignee in (members) across ALL projects
        if scope.member_accounts:
            members = ", ".join(self._jql_str(a) for a in scope.member_accounts)
            clauses.append(f"assignee in ({members})")

        if not clauses:
            if (self.config.get("pull_mode") or "all") == "teams":
                log.warning("jira.scope EMPTY (mode=teams) — no sync-enabled team members "
                            "with source 'jira'. Add one in /teams. Nothing will be pulled.")
            else:
                log.warning("jira.scope EMPTY — no enabled Jira projects and no tracked Jira "
                            "members. Enable a project in /projects or add a member in /teams, "
                            "and ensure their source is 'jira'. Nothing will be pulled.")
            return None
        jql = f"({' OR '.join(clauses)}) AND ({time_clause})"
        return jql

    def fetch(self, cursor: str | None = None) -> Iterable[RawTicket]:
        log.info("jira.fetch START cursor=%s", cursor or "<none/full>")
        if not self.health_check():
            log.warning("jira.fetch ABORT — health_check failed (see reason above)")
            return

        time_clause = f"updated >= '{self._jql_time(cursor)}'" if cursor else self.jql
        jql = self._build_scoped_jql(time_clause)
        if jql is None:
            log.info("jira.fetch END — nothing in scope, 0 issues")
            return
        log.info("jira.fetch JQL: %s", jql)

        start_at = 0
        page = 0
        yielded = 0
        with self._client() as client:
            while True:
                page += 1
                log.debug("jira.fetch requesting page=%d startAt=%d maxResults=%d",
                          page, start_at, self.page_size)
                try:
                    data = self._get(
                        client, "/rest/api/3/search",
                        jql=jql, startAt=start_at, maxResults=self.page_size,
                        fields="summary,description,status,priority,assignee,labels,components,project,created,updated",
                    )
                except httpx.HTTPStatusError as e:
                    log.error("jira.fetch HTTP ERROR on page=%d: %s — body: %s",
                              page, e.response.status_code, (e.response.text or "")[:300])
                    return
                except Exception as e:
                    log.exception("jira.fetch request failed on page=%d: %s", page, e)
                    return

                issues = data.get("issues", [])
                total = data.get("total", 0)
                log.info("jira.fetch page=%d got %d issues (total matching JQL=%d)",
                         page, len(issues), total)
                if not issues:
                    if total == 0 and page == 1:
                        log.warning("jira.fetch JQL matched 0 issues. Check that the project "
                                    "keys/assignees in the JQL exist in Jira and have recent "
                                    "activity within the time window (%s).", time_clause)
                    break
                for issue in issues:
                    yielded += 1
                    yield self._to_raw(issue)
                start_at += len(issues)
                if start_at >= total:
                    break
        log.info("jira.fetch END — yielded %d issues across %d page(s)", yielded, page)

    def _to_raw(self, issue: dict) -> RawTicket:
        f = issue.get("fields", {}) or {}
        components = f.get("components") or []
        team = components[0]["name"] if components else ""
        project_key = (f.get("project") or {}).get("key", "")
        return RawTicket(
            source="jira",
            source_id=issue.get("key", ""),
            source_url=f"{self.base_url}/browse/{issue.get('key', '')}",
            title=f.get("summary") or "",
            description=self._adf_to_text(f.get("description")),
            status=(f.get("status") or {}).get("name", "open"),
            severity=(f.get("priority") or {}).get("name", "Medium"),
            assignee=self._assignee_identity(f.get("assignee")),
            team=team,
            project=project_key,
            tags=list(f.get("labels", []) or []),
            opened_at=parse_datetime(f.get("created", "")) if f.get("created") else None,
            last_external_update_at=parse_datetime(f.get("updated", "")) if f.get("updated") else None,
            extra={"jira_id": issue.get("id")},
        )

    def _adf_to_text(self, adf) -> str:
        """Atlassian Document Format → flat text. Best-effort."""
        if not adf:
            return ""
        if isinstance(adf, str):
            return adf
        out = []

        def walk(node):
            if isinstance(node, dict):
                if node.get("type") == "text":
                    out.append(node.get("text", ""))
                for child in node.get("content", []) or []:
                    walk(child)
                if node.get("type") in ("paragraph", "heading"):
                    out.append("\n")
            elif isinstance(node, list):
                for n in node:
                    walk(n)

        walk(adf)
        return "".join(out).strip()
