"""Jira Cloud connector. Polls JQL since cursor."""
from __future__ import annotations
import logging
from typing import Iterable
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential_jitter, retry_if_exception_type
from django.utils.dateparse import parse_datetime

from .base import Connector, RawTicket

log = logging.getLogger("aegis.connectors.jira")


class JiraConnector(Connector):
    name = "jira"
    supports_pull = True

    def __init__(self, config=None):
        super().__init__(config)
        self.base_url = self.config.get("base_url", "").rstrip("/")
        self.email = self.config.get("email", "")
        self.token = self.config.get("api_token", "")
        self.jql = self.config.get("jql", "updated >= -7d")
        self.page_size = int(self.config.get("page_size", 50))

    def _client(self) -> httpx.Client:
        return httpx.Client(
            base_url=self.base_url,
            auth=(self.email, self.token),
            timeout=30,
            headers={"Accept": "application/json"},
        )

    def health_check(self) -> bool:
        if not (self.base_url and self.email and self.token):
            return False
        try:
            with self._client() as c:
                r = c.get("/rest/api/3/myself")
                return r.status_code == 200
        except Exception:
            return False

    @retry(
        retry=retry_if_exception_type((httpx.TransportError,)),
        stop=stop_after_attempt(4),
        wait=wait_exponential_jitter(initial=1, max=10),
    )
    def _get(self, client: httpx.Client, path: str, **params):
        r = client.get(path, params=params)
        r.raise_for_status()
        return r.json()

    @staticmethod
    def _assignee_identity(assignee) -> str:
        """Jira Cloud often nulls emailAddress under GDPR and exposes only
        accountId. Match TeamMembers configured by either: prefer email, fall
        back to accountId, then displayName."""
        a = assignee or {}
        return (a.get("emailAddress") or a.get("accountId") or a.get("displayName") or "").strip()

    @staticmethod
    def _jql_str(value: str) -> str:
        r"""Quote+escape a value for JQL. Backslash and double-quote are escaped
        per Atlassian's reserved-character rules to prevent breakage/injection."""
        v = (value or "").replace("\\", "\\\\").replace('"', '\\"')
        return f'"{v}"'

    def _build_scoped_jql(self, time_clause: str) -> str | None:
        """Translate the PullScope into JQL. Returns None if nothing to pull."""
        from ..services.pull_planner import build_scope
        scope = build_scope("jira")

        if scope.pull_everything:
            return time_clause

        clauses: list[str] = []
        # 1. Full projects
        if scope.project_keys:
            keys = ", ".join(self._jql_str(k) for k in scope.project_keys)
            clauses.append(f"project in ({keys})")
        # 2. Team-scoped projects: project = X AND assignee in (members)
        for pk, accounts in scope.project_members.items():
            members = ", ".join(self._jql_str(a) for a in accounts)
            clauses.append(f"(project = {self._jql_str(pk)} AND assignee in ({members}))")
        # 3. Cross-project members: assignee in (members) across ALL projects
        if scope.member_accounts:
            members = ", ".join(self._jql_str(a) for a in scope.member_accounts)
            clauses.append(f"assignee in ({members})")

        if not clauses:
            return None
        return f"({' OR '.join(clauses)}) AND ({time_clause})"

    def fetch(self, cursor: str | None = None) -> Iterable[RawTicket]:
        if not self.health_check():
            log.warning("aegis.jira.unconfigured_or_unreachable")
            return

        time_clause = f"updated >= '{cursor}'" if cursor else self.jql
        jql = self._build_scoped_jql(time_clause)
        if jql is None:
            log.info("aegis.jira.nothing_in_scope — no enabled projects or members")
            return
        log.info("aegis.jira.scoped_pull jql=%s", jql)

        start_at = 0
        with self._client() as client:
            while True:
                data = self._get(
                    client, "/rest/api/3/search",
                    jql=jql, startAt=start_at, maxResults=self.page_size,
                    fields="summary,description,status,priority,assignee,labels,components,project,created,updated",
                )
                issues = data.get("issues", [])
                if not issues:
                    return
                for issue in issues:
                    yield self._to_raw(issue)
                total = data.get("total", 0)
                start_at += len(issues)
                if start_at >= total:
                    return

    def _to_raw(self, issue: dict) -> RawTicket:
        f = issue.get("fields", {}) or {}
        components = f.get("components") or []
        team = components[0]["name"] if components else ""
        project_key = (f.get("project") or {}).get("key", "")
        return RawTicket(
            source="jira",
            source_id=issue.get("key", ""),
            source_url=f"{self.base_url}/browse/{issue.get('key', '')}",
            title=f.get("summary") or "",
            description=self._adf_to_text(f.get("description")),
            status=(f.get("status") or {}).get("name", "open"),
            severity=(f.get("priority") or {}).get("name", "Medium"),
            assignee=self._assignee_identity(f.get("assignee")),
            team=team,
            project=project_key,
            tags=list(f.get("labels", []) or []),
            opened_at=parse_datetime(f.get("created", "")) if f.get("created") else None,
            last_external_update_at=parse_datetime(f.get("updated", "")) if f.get("updated") else None,
            extra={"jira_id": issue.get("id")},
        )

    def _adf_to_text(self, adf) -> str:
        """Atlassian Document Format → flat text. Best-effort."""
        if not adf:
            return ""
        if isinstance(adf, str):
            return adf
        out = []

        def walk(node):
            if isinstance(node, dict):
                if node.get("type") == "text":
                    out.append(node.get("text", ""))
                for child in node.get("content", []) or []:
                    walk(child)
                if node.get("type") in ("paragraph", "heading"):
                    out.append("\n")
            elif isinstance(node, list):
                for n in node:
                    walk(n)

        walk(adf)
        return "".join(out).strip()
