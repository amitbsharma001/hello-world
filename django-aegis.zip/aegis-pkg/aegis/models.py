import uuid
from django.conf import settings as dj_settings
from django.db import models
from django.utils import timezone


class Ticket(models.Model):
    class Status(models.TextChoices):
        OPEN = "open", "Open"
        IN_PROGRESS = "in_progress", "In progress"
        WAITING_CUSTOMER = "waiting_customer", "Waiting on customer"
        WAITING_ENGINEERING = "waiting_engineering", "Waiting on eng"
        BLOCKED = "blocked", "Blocked"
        RESOLVED = "resolved", "Resolved"
        CLOSED = "closed", "Closed"

    class Severity(models.TextChoices):
        SEV1 = "sev1", "Sev 1 — critical"
        SEV2 = "sev2", "Sev 2 — high"
        SEV3 = "sev3", "Sev 3 — medium"
        SEV4 = "sev4", "Sev 4 — low"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    source = models.CharField(max_length=32, default="manual")
    source_id = models.CharField(max_length=128, blank=True)
    source_url = models.URLField(blank=True)

    # Owner — the user who owns / can see this ticket.
    # Staff users see everything; non-staff see only their own.
    owner = models.ForeignKey(
        dj_settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="aegis_tickets",
        db_index=True,
    )

    title = models.CharField(max_length=500)
    description_raw = models.TextField()
    description_enhanced = models.TextField(blank=True)
    enhanced_payload = models.JSONField(default=dict, blank=True)
    plan_payload = models.JSONField(default=dict, blank=True)
    missing_info_payload = models.JSONField(default=dict, blank=True)

    status = models.CharField(max_length=32, choices=Status.choices, default=Status.OPEN, db_index=True)
    severity = models.CharField(max_length=8, choices=Severity.choices, default=Severity.SEV3, db_index=True)
    priority_ai = models.FloatField(null=True, blank=True, db_index=True)
    assignee = models.CharField(max_length=128, blank=True, db_index=True)
    team = models.CharField(max_length=64, blank=True, db_index=True)
    tags = models.JSONField(default=list, blank=True)
    affected_systems = models.JSONField(default=list, blank=True)
    impacted_users = models.PositiveIntegerField(default=0)

    opened_at = models.DateTimeField(default=timezone.now, db_index=True)
    last_external_update_at = models.DateTimeField(null=True, blank=True, db_index=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    sla_due_at = models.DateTimeField(null=True, blank=True, db_index=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    content_hash = models.CharField(max_length=64, blank=True, db_index=True)

    class Meta:
        ordering = ["-opened_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["source", "source_id"],
                name="aegis_ticket_source_unique",
                condition=~models.Q(source_id=""),
            ),
        ]
        indexes = [
            models.Index(fields=["status", "team", "-opened_at"]),
            models.Index(fields=["status", "priority_ai"]),
        ]

    def __str__(self):
        return f"[{self.source_id or str(self.id)[:8]}] {self.title[:60]}"

    @property
    def is_open(self):
        return self.status not in (self.Status.RESOLVED, self.Status.CLOSED)

    @property
    def age_hours(self):
        return (timezone.now() - self.opened_at).total_seconds() / 3600


class TicketHistory(models.Model):
    id = models.BigAutoField(primary_key=True)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="history")
    event_type = models.CharField(max_length=64)
    actor = models.CharField(max_length=128, blank=True)
    payload = models.JSONField(default=dict)
    occurred_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ["-occurred_at"]
        indexes = [models.Index(fields=["ticket", "-occurred_at"])]


class AIArtifact(models.Model):
    class Kind(models.TextChoices):
        ENHANCED_DESCRIPTION = "enhanced_description", "Enhanced description"
        ACTION_PLAN = "action_plan", "Action plan"
        MISSING_INFO = "missing_info", "Missing information"
        RESOLUTION_PREDICTION = "resolution_prediction", "Resolution prediction"

    id = models.BigAutoField(primary_key=True)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="artifacts")
    kind = models.CharField(max_length=32, choices=Kind.choices, db_index=True)
    prompt_version = models.CharField(max_length=32, default="v1")
    model = models.CharField(max_length=64)
    payload = models.JSONField()
    raw_response = models.TextField(blank=True)
    confidence = models.FloatField(null=True, blank=True)
    tokens_in = models.IntegerField(default=0)
    tokens_out = models.IntegerField(default=0)
    cost_usd = models.DecimalField(max_digits=10, decimal_places=6, default=0)
    latency_ms = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["ticket", "kind", "-created_at"])]


class AgentRun(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending"
        RUNNING = "running"
        SUCCEEDED = "succeeded"
        FAILED = "failed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    agent = models.CharField(max_length=64, db_index=True)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="agent_runs", null=True)
    trigger = models.CharField(max_length=64, default="manual")
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING, db_index=True)
    input = models.JSONField(default=dict)
    output = models.JSONField(default=dict)
    error = models.TextField(blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    idempotency_key = models.CharField(max_length=128, unique=True, blank=True, null=True)

    class Meta:
        ordering = ["-started_at"]


class AgentStep(models.Model):
    """One ReAct step within an agent run."""
    id = models.BigAutoField(primary_key=True)
    run = models.ForeignKey(AgentRun, on_delete=models.CASCADE, related_name="steps")
    seq = models.PositiveIntegerField()
    name = models.CharField(max_length=128, help_text="Tool / action name")
    input = models.JSONField(default=dict, help_text="Thought + action_input")
    output = models.JSONField(default=dict, help_text="Observation from the tool")
    error = models.TextField(blank=True)
    started_at = models.DateTimeField()
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["run", "seq"]
        unique_together = [("run", "seq")]
        indexes = [models.Index(fields=["run", "seq"])]


class SyncCursor(models.Model):
    source = models.CharField(max_length=32, primary_key=True)
    cursor = models.CharField(max_length=128, blank=True)
    last_run_at = models.DateTimeField(null=True, blank=True)
