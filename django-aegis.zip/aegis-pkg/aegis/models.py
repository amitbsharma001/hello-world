import uuid
from django.conf import settings as dj_settings
from django.db import models
from django.utils import timezone


class Project(models.Model):
    """A configured project/source. Only projects with sync_enabled=True are
    ingested during sync; everything else is skipped (and surfaced in config)."""

    class Source(models.TextChoices):
        JIRA = "jira", "Jira"
        SERVICENOW = "servicenow", "ServiceNow"
        ZENDESK = "zendesk", "Zendesk"
        CSV = "csv", "CSV import"
        MANUAL = "manual", "Manual"
        API = "api", "REST API"

    class MemberScope(models.TextChoices):
        ALL = "all", "All assignees in the project"
        TEAM = "team", "Only my configured team members"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    key = models.CharField(max_length=32, unique=True,
                           help_text="Short code, e.g. PAY. Matched against incoming ticket project/team.")
    name = models.CharField(max_length=120)
    source = models.CharField(max_length=16, choices=Source.choices, default=Source.MANUAL)
    external_key = models.CharField(max_length=64, blank=True,
                                    help_text="Project key in the source system (e.g. the Jira project key).")
    default_team = models.CharField(max_length=64, blank=True)
    description = models.TextField(blank=True)

    # Pull scope: everyone in the project, or only my configured team members.
    member_scope = models.CharField(max_length=8, choices=MemberScope.choices,
                                    default=MemberScope.ALL,
                                    help_text="Restrict the pull to specific team members within this project.")

    sync_enabled = models.BooleanField(default=True, db_index=True)
    discovered = models.BooleanField(default=False,
                                     help_text="Auto-registered from an inbound sync; not yet enabled by an admin.")

    last_synced_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-sync_enabled", "name"]

    def __str__(self):
        return f"{self.key} · {self.name}"


class TeamMember(models.Model):
    """A person to pull work for, independent of project configuration.

    When enabled with pull_all_projects=True, the app pulls ALL of this person's
    assigned tasks across EVERY project they touch — including projects that are
    not in the configured project list. This makes the pull person-centric, not
    only project-centric: configure the people you manage and follow their work
    wherever it lives.
    """

    class Source(models.TextChoices):
        JIRA = "jira", "Jira"
        SERVICENOW = "servicenow", "ServiceNow"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=120)
    source = models.CharField(max_length=16, choices=Source.choices, default=Source.JIRA)

    # Identity in the source system used to match assigned work.
    # Jira: accountId or email. ServiceNow: assigned_to email / sys_id.
    account = models.CharField(max_length=200,
                               help_text="The person's identity in the source (email or account id).")
    # Optional per-member instance URL (for members on a different instance).
    source_url = models.URLField(blank=True,
                                 help_text="Base URL of this member's source instance, e.g. https://org.atlassian.net")

    # Pull ALL of this member's tasks across every project, even unconfigured ones.
    pull_all_projects = models.BooleanField(default=True)

    # Projects this member belongs to (used when a project restricts to 'team').
    projects = models.ManyToManyField(Project, blank=True, related_name="members")

    default_team = models.CharField(max_length=64, blank=True)
    sync_enabled = models.BooleanField(default=True, db_index=True)

    last_synced_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-sync_enabled", "name"]

    def __str__(self):
        return f"{self.name} <{self.account}>"


class Ticket(models.Model):
    class Status(models.TextChoices):
        OPEN = "open", "Open"
        IN_PROGRESS = "in_progress", "In progress"
        WAITING_CUSTOMER = "waiting_customer", "Waiting on customer"
        WAITING_ENGINEERING = "waiting_engineering", "Waiting on eng"
        BLOCKED = "blocked", "Blocked"
        RESOLVED = "resolved", "Resolved"
        CLOSED = "closed", "Closed"

    class Severity(models.TextChoices):
        SEV1 = "sev1", "Sev 1 — critical"
        SEV2 = "sev2", "Sev 2 — high"
        SEV3 = "sev3", "Sev 3 — medium"
        SEV4 = "sev4", "Sev 4 — low"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    source = models.CharField(max_length=32, default="manual")
    source_id = models.CharField(max_length=128, blank=True)
    source_url = models.URLField(blank=True)

    # The configured project this ticket belongs to (gate for sync).
    project = models.ForeignKey(
        "Project", on_delete=models.SET_NULL,
        null=True, blank=True, related_name="tickets", db_index=True,
    )

    # Owner — the user who owns / can see this ticket.
    # Staff users see everything; non-staff see only their own.
    owner = models.ForeignKey(
        dj_settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="aegis_tickets",
        db_index=True,
    )

    title = models.CharField(max_length=500)
    description_raw = models.TextField()
    description_enhanced = models.TextField(blank=True)
    enhanced_payload = models.JSONField(default=dict, blank=True)
    plan_payload = models.JSONField(default=dict, blank=True)
    missing_info_payload = models.JSONField(default=dict, blank=True)

    status = models.CharField(max_length=32, choices=Status.choices, default=Status.OPEN, db_index=True)
    severity = models.CharField(max_length=8, choices=Severity.choices, default=Severity.SEV3, db_index=True)
    priority_ai = models.FloatField(null=True, blank=True, db_index=True)
    assignee = models.CharField(max_length=128, blank=True, db_index=True)
    team = models.CharField(max_length=64, blank=True, db_index=True)
    tags = models.JSONField(default=list, blank=True)
    affected_systems = models.JSONField(default=list, blank=True)
    impacted_users = models.PositiveIntegerField(default=0)

    opened_at = models.DateTimeField(default=timezone.now, db_index=True)
    last_external_update_at = models.DateTimeField(null=True, blank=True, db_index=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    sla_due_at = models.DateTimeField(null=True, blank=True, db_index=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    content_hash = models.CharField(max_length=64, blank=True, db_index=True)

    class Meta:
        ordering = ["-opened_at"]
        constraints = [
            models.UniqueConstraint(
                fields=["source", "source_id"],
                name="aegis_ticket_source_unique",
                condition=~models.Q(source_id=""),
            ),
        ]
        indexes = [
            models.Index(fields=["status", "team", "-opened_at"]),
            models.Index(fields=["status", "priority_ai"]),
        ]

    def __str__(self):
        return f"[{self.source_id or str(self.id)[:8]}] {self.title[:60]}"

    @property
    def is_open(self):
        return self.status not in (self.Status.RESOLVED, self.Status.CLOSED)

    @property
    def age_hours(self):
        return (timezone.now() - self.opened_at).total_seconds() / 3600


class TicketHistory(models.Model):
    id = models.BigAutoField(primary_key=True)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="history")
    event_type = models.CharField(max_length=64)
    actor = models.CharField(max_length=128, blank=True)
    payload = models.JSONField(default=dict)
    occurred_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ["-occurred_at"]
        indexes = [models.Index(fields=["ticket", "-occurred_at"])]


class AIArtifact(models.Model):
    class Kind(models.TextChoices):
        ENHANCED_DESCRIPTION = "enhanced_description", "Enhanced description"
        ACTION_PLAN = "action_plan", "Action plan"
        MISSING_INFO = "missing_info", "Missing information"
        RESOLUTION_PREDICTION = "resolution_prediction", "Resolution prediction"

    id = models.BigAutoField(primary_key=True)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="artifacts")
    kind = models.CharField(max_length=32, choices=Kind.choices, db_index=True)
    prompt_version = models.CharField(max_length=32, default="v1")
    model = models.CharField(max_length=64)
    payload = models.JSONField()
    raw_response = models.TextField(blank=True)
    confidence = models.FloatField(null=True, blank=True)
    tokens_in = models.IntegerField(default=0)
    tokens_out = models.IntegerField(default=0)
    cost_usd = models.DecimalField(max_digits=10, decimal_places=6, default=0)
    latency_ms = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["ticket", "kind", "-created_at"])]


class AgentRun(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending"
        RUNNING = "running"
        SUCCEEDED = "succeeded"
        FAILED = "failed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    agent = models.CharField(max_length=64, db_index=True)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="agent_runs", null=True)
    trigger = models.CharField(max_length=64, default="manual")
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.PENDING, db_index=True)
    input = models.JSONField(default=dict)
    output = models.JSONField(default=dict)
    error = models.TextField(blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    idempotency_key = models.CharField(max_length=128, unique=True, blank=True, null=True)

    class Meta:
        ordering = ["-started_at"]


class AgentStep(models.Model):
    """One ReAct step within an agent run."""
    id = models.BigAutoField(primary_key=True)
    run = models.ForeignKey(AgentRun, on_delete=models.CASCADE, related_name="steps")
    seq = models.PositiveIntegerField()
    name = models.CharField(max_length=128, help_text="Tool / action name")
    input = models.JSONField(default=dict, help_text="Thought + action_input")
    output = models.JSONField(default=dict, help_text="Observation from the tool")
    error = models.TextField(blank=True)
    started_at = models.DateTimeField()
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["run", "seq"]
        unique_together = [("run", "seq")]
        indexes = [models.Index(fields=["run", "seq"])]


class SyncCursor(models.Model):
    source = models.CharField(max_length=32, primary_key=True)
    cursor = models.CharField(max_length=128, blank=True)
    last_run_at = models.DateTimeField(null=True, blank=True)


class UserAIConfig(models.Model):
    """Per-user AI + Jira credentials. Agents require this to be configured.

    Secrets are stored encrypted (see services/crypto.py). Each user brings
    their own API key, so usage and cost are attributable per person.
    """

    class Provider(models.TextChoices):
        GEMINI = "gemini", "Google Gemini"
        OPENAI = "openai", "OpenAI"
        ANTHROPIC = "anthropic", "Anthropic"

    user = models.OneToOneField(dj_settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name="ai_config")
    provider = models.CharField(max_length=16, choices=Provider.choices, default=Provider.GEMINI)
    model_name = models.CharField(max_length=64, default="gemini-2.5-flash")
    api_key_enc = models.TextField(blank=True)        # encrypted

    # Optional Jira write-back credentials (per user)
    jira_base_url = models.URLField(blank=True)
    jira_email = models.CharField(max_length=160, blank=True)
    jira_token_enc = models.TextField(blank=True)     # encrypted

    last_verified_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"AIConfig({self.user}, {self.provider})"

    # --- secret accessors ---
    def set_api_key(self, raw: str):
        from .services.crypto import encrypt
        self.api_key_enc = encrypt(raw or "")

    def get_api_key(self) -> str:
        from .services.crypto import decrypt
        return decrypt(self.api_key_enc)

    def set_jira_token(self, raw: str):
        from .services.crypto import encrypt
        self.jira_token_enc = encrypt(raw or "")

    def get_jira_token(self) -> str:
        from .services.crypto import decrypt
        return decrypt(self.jira_token_enc)

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key_enc)

    @property
    def jira_configured(self) -> bool:
        return bool(self.jira_base_url and self.jira_email and self.jira_token_enc)

    @property
    def api_key_masked(self) -> str:
        from .services.crypto import decrypt, mask
        return mask(decrypt(self.api_key_enc))


class TicketAction(models.Model):
    """Record of an outbound action taken on a ticket (Jira write-back, email)."""

    class Kind(models.TextChoices):
        PUSH_DESCRIPTION = "push_description", "Pushed description to Jira"
        POST_COMMENT = "post_comment", "Posted resolution steps to Jira"
        CUSTOMER_EMAIL = "customer_email", "Generated customer email"

    class Status(models.TextChoices):
        SUCCESS = "success", "Success"
        MOCK = "mock", "Mock (no live credentials)"
        FAILED = "failed", "Failed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, related_name="actions")
    user = models.ForeignKey(dj_settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                             null=True, related_name="ticket_actions")
    kind = models.CharField(max_length=24, choices=Kind.choices)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.SUCCESS)
    detail = models.TextField(blank=True)             # external ref / error / note
    payload = models.JSONField(default=dict)          # what was sent / generated
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["ticket", "-created_at"])]
