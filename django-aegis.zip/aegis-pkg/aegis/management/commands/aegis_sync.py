"""
Sync tickets from configured connectors.

    python manage.py aegis_sync                  # all configured connectors
    python manage.py aegis_sync --source jira    # one
"""
from django.core.management.base import BaseCommand
from django.utils import timezone

from aegis.conf import conf
from aegis.connectors import registry
from aegis.connectors.base import upsert_raw
from aegis.models import SyncCursor


class Command(BaseCommand):
    help = "Sync tickets from configured external connectors."

    def add_arguments(self, parser):
        parser.add_argument("--source", default=None)
        parser.add_argument("--analyze", action="store_true")

    def handle(self, *args, source, analyze, **opts):
        sources = [source] if source else list(conf.CONNECTORS.keys())
        if not sources:
            self.stdout.write(self.style.WARNING(
                "No connectors configured. Add AEGIS['CONNECTORS'] in settings."
            ))
            return

        for src in sources:
            cls = registry.get(src)
            if not cls:
                self.stdout.write(self.style.ERROR(f"Unknown connector: {src}"))
                continue
            cfg = conf.CONNECTORS.get(src, {})
            connector = cls(cfg)

            cursor_obj, _ = SyncCursor.objects.get_or_create(source=src)
            created = updated = errors = 0
            self.stdout.write(f"Syncing {src}...")
            try:
                for raw in connector.fetch(cursor_obj.cursor or None):
                    try:
                        t, was_created, _ = upsert_raw(raw)
                        if was_created:
                            created += 1
                        else:
                            updated += 1
                        if analyze:
                            from aegis.services import enhance_description
                            try:
                                enhance_description(t)
                            except Exception:
                                pass
                    except Exception as e:
                        errors += 1
                        self.stdout.write(self.style.ERROR(f"  upsert failed: {e}"))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f"  fetch failed: {e}"))

            cursor_obj.last_run_at = timezone.now()
            cursor_obj.save()
            self.stdout.write(self.style.SUCCESS(
                f"  {src}: created={created} updated={updated} errors={errors}"
            ))
