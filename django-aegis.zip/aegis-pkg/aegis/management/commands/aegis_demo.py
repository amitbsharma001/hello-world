"""
Seed realistic demo tickets, users, and (optionally) run AI analysis on them.

    python manage.py aegis_demo --count 12 --analyze
"""
import random
from datetime import timedelta
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone

from aegis.models import Ticket
from aegis.services import enhance_description, generate_plan, detect_missing_info


SEED = [
    ("api down", "payments not working, customers complaining. tried restarting still no luck. please fix asap", "sev1", "Payments"),
    ("Checkout 500 errors after deploy", "Started seeing 5xx on /checkout endpoint immediately after the 14:00 deploy. Maybe related to PR #2341 which changed the order validation.", "sev2", "Checkout"),
    ("Search returns no results for some queries", "intermittent. like 1 in 20 searches returns empty even for popular products. cache issue?", "sev3", "Search"),
    ("Login slow", "users on the mobile app are saying login takes 10+ seconds. only some users. mostly EU region.", "sev2", "Auth"),
    ("kafka consumer lag rising", "order-events consumer group lag has been climbing for the last hour. 50k messages behind now.", "sev2", "Platform"),
    ("Customer XYZ Corp can't export reports", "Their enterprise admin says CSV exports are failing with 'request timed out'. Their account has >2M rows.", "sev3", "Reporting"),
    ("Email notifications not delivering", "Some users not receiving password reset emails. Maybe SendGrid issue?", "sev2", "Notifications"),
    ("Dashboard widgets blank on Safari", "Specific to Safari 16+. Charts don't render. Console shows nothing useful.", "sev3", "Frontend"),
    ("Stripe webhook signature failures", "Suddenly seeing 401 on Stripe webhook verification. Started at 09:15 UTC. Did we rotate keys?", "sev1", "Payments"),
    ("Redis memory at 92%", "redis-primary is at 92% memory used. Eviction policy is allkeys-lru but we're seeing cache misses spike.", "sev2", "Platform"),
    ("Mobile app crashes on cold start, Android 13", "Crash-free rate dropped from 99.7% to 96.1% in last release. Stack trace points to firebase init.", "sev2", "Mobile"),
    ("Need new feature: bulk user invite", "Customer success team is asking. Should accept CSV of emails, send invites with custom message.", "sev4", "Growth"),
    ("Postmortem doc still TODO from last week's incident", "INC-7821 mitigation done but no writeup yet. Compliance is asking.", "sev4", "On-call"),
    ("Intermittent 502 on api gateway", "5-10 per minute, no clear pattern. Started yesterday.", "sev3", "Platform"),
    ("DB replica lag spiked to 45s", "primary-replica-2 lag is up. Causing stale reads in some endpoints.", "sev2", "DBRE"),
]


DEMO_USERS = [
    # (username, password, is_staff, label)
    ("admin", "admin", True,  "platform admin"),
    ("alice", "demo",  False, "engineer"),
    ("bob",   "demo",  False, "engineer"),
]


class Command(BaseCommand):
    help = "Seed demo users + tickets and optionally run AI analysis on them."

    def add_arguments(self, parser):
        parser.add_argument("--count", type=int, default=12)
        parser.add_argument("--analyze", action="store_true",
                            help="Run AI analysis on each ticket after creation")
        parser.add_argument("--clear", action="store_true",
                            help="Delete existing demo tickets first")

    def handle(self, *args, count, analyze, clear, **opts):
        User = get_user_model()

        # 1. Users
        users = []
        for uname, pw, is_staff, _label in DEMO_USERS:
            u, created = User.objects.get_or_create(
                username=uname,
                defaults={"is_staff": is_staff, "is_superuser": is_staff,
                          "email": f"{uname}@example.com"},
            )
            u.set_password(pw)
            u.is_staff = is_staff
            u.is_superuser = is_staff
            u.save()
            users.append(u)
            tag = "admin" if is_staff else "user"
            self.stdout.write(f"  {'+' if created else '~'} user {uname} ({tag})")

        # Non-staff users are the candidate "owners" for demo tickets
        owner_pool = [u for u in users if not u.is_staff]

        if clear:
            n = Ticket.objects.filter(source="demo").delete()
            self.stdout.write(f"Deleted {n[0]} demo tickets")

        sample = random.sample(SEED, min(count, len(SEED)))
        if count > len(SEED):
            sample.extend(random.choices(SEED, k=count - len(SEED)))

        now = timezone.now()
        created = []
        for i, (title, desc, sev, team) in enumerate(sample):
            owner = random.choice(owner_pool)
            age_h = random.uniform(0.5, 72)
            opened = now - timedelta(hours=age_h)
            t = Ticket.objects.create(
                source="demo",
                source_id=f"DEMO-{1000 + i}",
                owner=owner,
                title=title,
                description_raw=desc,
                severity=sev,
                team=team,
                status=random.choice([
                    Ticket.Status.OPEN, Ticket.Status.OPEN, Ticket.Status.OPEN,
                    Ticket.Status.IN_PROGRESS, Ticket.Status.WAITING_CUSTOMER,
                ]),
                opened_at=opened,
                last_external_update_at=opened + timedelta(hours=random.uniform(0, age_h / 2)),
                sla_due_at=opened + timedelta(hours=24 if sev in ("sev1", "sev2") else 72),
                impacted_users=random.choice([0, 0, 50, 500, 5000]),
            )
            created.append(t)
            self.stdout.write(f"  + {t.source_id}: [{owner.username}] {t.title}")

        self.stdout.write(self.style.SUCCESS(f"Created {len(created)} tickets"))

        # Summary per owner
        from collections import Counter
        per_owner = Counter(t.owner.username for t in created)
        for u, n in per_owner.items():
            self.stdout.write(f"    {u}: {n} tickets")

        if analyze:
            self.stdout.write("Running AI analysis + agent pipeline (mock mode unless GEMINI_API_KEY set)...")
            from aegis.agents import run_pipeline
            for t in created:
                try:
                    enhance_description(t, force=True)
                    t.refresh_from_db()
                    generate_plan(t, force=True)
                    detect_missing_info(t, force=True)
                    runs = run_pipeline(t, trigger="demo_seed")
                    self.stdout.write(
                        f"  ✓ {t.source_id}: enhanced + plan + missing + "
                        f"{len(runs)} agent runs ({', '.join(r.agent for r in runs)})"
                    )
                except Exception as e:
                    self.stdout.write(self.style.WARNING(f"  ✗ {t.source_id}: {e}"))
            self.stdout.write(self.style.SUCCESS("Done."))

        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("Demo accounts:"))
        for uname, pw, is_staff, label in DEMO_USERS:
            tag = "admin · sees all" if is_staff else "user · sees own only"
            self.stdout.write(f"    {uname} / {pw}  ({tag})")
