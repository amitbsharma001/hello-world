"""
Visibility rules.

Rule:
    Staff users (is_staff=True) see ALL tickets.
    Non-staff users see only tickets where owner == request.user.
    Anonymous users see nothing through the normal UI / API.

Tickets with owner=None are visible only to staff. This is safe by default —
auto-ingested tickets (from Jira sync, etc.) without an explicit owner will
not leak to a random end user, but staff/operators can still triage them.
"""
from django.db.models import QuerySet


def can_view(user, ticket) -> bool:
    if not user or not user.is_authenticated:
        return False
    if user.is_staff:
        return True
    return ticket.owner_id == user.id


def can_edit(user, ticket) -> bool:
    return can_view(user, ticket)


def filter_for_user(qs: QuerySet, user) -> QuerySet:
    if not user or not user.is_authenticated:
        return qs.none()
    if user.is_staff:
        return qs
    return qs.filter(owner=user)


def is_admin(user) -> bool:
    return bool(user and user.is_authenticated and user.is_staff)
