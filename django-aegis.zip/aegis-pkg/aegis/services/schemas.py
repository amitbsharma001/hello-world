from typing import List, Literal, Optional
from pydantic import BaseModel, Field


class EnhancedDescription(BaseModel):
    problem_summary: str = Field(..., max_length=600)
    business_impact: str
    technical_analysis: str
    affected_systems: List[str] = Field(default_factory=list)
    observed_symptoms: List[str] = Field(default_factory=list)
    expected_behavior: str = ""
    current_behavior: str = ""
    dependencies: List[str] = Field(default_factory=list)
    risks: List[str] = Field(default_factory=list)
    missing_information: List[str] = Field(default_factory=list)
    recommended_investigation_areas: List[str] = Field(default_factory=list)
    severity_suggestion: Literal["sev1", "sev2", "sev3", "sev4"] = "sev3"
    confidence: float = Field(0.5, ge=0, le=1)


class ActionItem(BaseModel):
    title: str
    description: str = ""
    priority: Literal["P0", "P1", "P2", "P3"] = "P2"
    effort_hours: float = Field(1.0, ge=0.1, le=160)
    risk: Literal["low", "medium", "high"] = "medium"
    suggested_owner_team: str = ""
    dependencies: List[str] = Field(default_factory=list)
    automatable: bool = False
    success_criteria: str = ""


class ActionPlan(BaseModel):
    summary: str
    actions: List[ActionItem] = Field(..., min_length=1)
    blockers: List[str] = Field(default_factory=list)
    escalation_recommendation: Optional[str] = None
    confidence: float = Field(0.5, ge=0, le=1)


class MissingInformationReport(BaseModel):
    categories: List[str] = Field(default_factory=list)
    follow_up_questions: List[str] = Field(default_factory=list)
    investigation_checklist: List[str] = Field(default_factory=list)
    can_proceed_without: bool = True
    priority_score: float = Field(0.0, ge=0, le=100)


class AgentDecisionStep(BaseModel):
    """One ReAct step produced by an agent."""
    thought: str = Field(..., max_length=500)
    action: str = Field(..., description="Name of the tool to call")
    action_input: dict = Field(default_factory=dict)
    is_final: bool = False


class CustomerEmail(BaseModel):
    """A customer-facing communication drafted from a ticket."""
    subject: str = Field(..., max_length=200)
    body: str = Field(..., max_length=4000)
    tone: str = Field("empathetic", max_length=40)
    next_update: str = Field("", max_length=500)
