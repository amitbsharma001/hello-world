"""
PII redaction layer.

Boundary: anything that crosses into a third-party AI API (Gemini, OpenAI,
Anthropic, etc.) is sanitized first. Only generic, redacted content leaves
this system. The full mapping is persisted on the AIArtifact for audit.

Redactions are deterministic per-call: the same email becomes <EMAIL_1>
within a single prompt, so the AI can still reason about identity
("the user from <EMAIL_1> tried…") without seeing the real value.

After the AI responds, the response is rehydrated so the UI shows real
values back to the original user (who is already authorized to see them).

This module is dependency-free. To plug in a heavier engine (Microsoft
Presidio, spaCy NER, AWS Comprehend), replace `sanitize()` while keeping
the same return signature.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class RedactionMap:
    """Bidirectional map between placeholder tokens and original values."""
    mapping: Dict[str, str] = field(default_factory=dict)
    counts_by_category: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "mapping": self.mapping,
            "counts": self.counts_by_category,
            "total_redactions": len(self.mapping),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "RedactionMap":
        if not data:
            return cls()
        return cls(
            mapping=data.get("mapping", {}),
            counts_by_category=data.get("counts", {}),
        )

    def rehydrate(self, text: str) -> str:
        """Swap placeholders back to original values. Safe to call on
        text that contains no placeholders."""
        if not text or not self.mapping:
            return text
        # Sort by length descending so longer placeholders match first
        # (avoids <EMAIL_1> being matched as <EMAIL_> by a hypothetical
        # shorter pattern)
        for ph in sorted(self.mapping, key=len, reverse=True):
            text = text.replace(ph, self.mapping[ph])
        return text

    def __len__(self) -> int:
        return len(self.mapping)


# ----------------------------------------------------------------------
# Patterns — ordered by specificity (most specific first to avoid
# greedy patterns swallowing tokens they shouldn't).
# ----------------------------------------------------------------------

# Important: order matters. CARD before PHONE (both numeric).
# JWT before TOKEN (JWTs would otherwise match TOKEN).
# AWS_KEY / GH_TOKEN / SLACK_TOKEN before generic TOKEN.

_PATTERNS: List[Tuple[str, "re.Pattern"]] = [
    # ----- Secrets / credentials -----
    ("AWS_KEY",
     re.compile(r"\b(?:AKIA|ASIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASCA)[A-Z0-9]{16}\b")),
    ("GH_TOKEN",
     re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}\b")),
    ("SLACK_TOKEN",
     re.compile(r"\bxox[abposr]-[A-Za-z0-9-]{10,}\b")),
    ("JWT",
     re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b")),
    ("STRIPE_KEY",
     re.compile(r"\b(?:sk|pk|rk)_(?:test|live)_[A-Za-z0-9]{20,}\b")),

    # Generic high-entropy tokens (40+ hex/base64 chars)
    ("API_KEY",
     re.compile(r"\b[A-Za-z0-9_\-]{40,}\b")),

    # ----- Financial -----
    # Credit-card-like: 13-19 digits with optional separators (Luhn-eligible)
    ("CARD",
     re.compile(r"\b(?:\d[ -]?){13,19}\b")),

    # ----- Identifiers -----
    # UUID v4 — often customer/user IDs
    ("UUID",
     re.compile(r"\b[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\b",
                re.IGNORECASE)),

    # ----- Contact info -----
    ("EMAIL",
     re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")),

    ("PHONE",
     # Require phone-like STRUCTURE — separators or a (area) group — so bare
     # digit runs (error codes like 0x80004005, order numbers, hashes) are NOT
     # matched. Two forms: separated/intl, and the parenthesised-area form.
     re.compile(
         r"\+?\d{1,4}(?:[-.\s]\d{2,5}){1,5}\b"
         r"|\(\d{1,4}\)\s*\d{2,5}(?:[-.\s]\d{2,5}){0,3}\b"
     )),

    ("PHONE",
     # Bounded bare-digit fallback: 11-15 consecutive digits (optionally +).
     # Catches unformatted numbers like a toll-free 1-800 written 18005551234,
     # while deliberately NOT matching 10-digit epoch timestamps or <=8-digit
     # error/order codes. Over-redaction of long bare IDs is accepted as the
     # privacy-safe failure mode.
     re.compile(r"\+?\d{11,15}\b")),

    # ----- Network / infrastructure -----
    # IPv4
    ("IP",
     re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b")),

    # IPv6 (full or compact form)
    ("IPV6",
     re.compile(r"\b(?:[A-F0-9]{1,4}:){7}[A-F0-9]{1,4}\b", re.IGNORECASE)),

    # URLs (full URLs first, then bare hostnames)
    ("URL",
     re.compile(r"https?://[^\s<>\"]+", re.IGNORECASE)),

    # Internal-looking hostnames
    ("HOST",
     re.compile(r"\b[a-z0-9][a-z0-9\-]{0,62}\.(?:internal|corp|local|prod|staging|dev|svc\.cluster\.local)(?::\d+)?\b",
                re.IGNORECASE)),

    # ----- Filesystem paths that contain usernames -----
    ("UNIX_HOME_PATH",
     re.compile(r"(/(?:home|Users))/([A-Za-z0-9_\-.]+)")),
    ("WIN_HOME_PATH",
     re.compile(r"([A-Z]:\\Users\\)([A-Za-z0-9_\-.]+)")),
]


# ----------------------------------------------------------------------
# Public API
# ----------------------------------------------------------------------

def sanitize(text: str) -> Tuple[str, RedactionMap]:
    """
    Replace sensitive substrings in ``text`` with stable placeholder tokens.

    Returns the redacted text and a :class:`RedactionMap` that can rehydrate
    the original values later.

    The same substring within one call always becomes the same placeholder
    (so the model can reason about identity), but two different emails
    become two different placeholders (<EMAIL_1>, <EMAIL_2>).
    """
    if not text:
        return text or "", RedactionMap()

    rm = RedactionMap()
    # Reverse lookup so we can re-use placeholders for repeated values
    reverse: Dict[str, str] = {}

    def _replace(match: "re.Match", category: str) -> str:
        original = match.group(0)
        # Already seen this exact value? Re-use placeholder.
        if original in reverse:
            return reverse[original]
        n = rm.counts_by_category.get(category, 0) + 1
        rm.counts_by_category[category] = n
        placeholder = f"<{category}_{n}>"
        rm.mapping[placeholder] = original
        reverse[original] = placeholder
        return placeholder

    def _replace_user_in_path(match: "re.Match", category: str) -> str:
        """Special handler for filesystem paths — keep the path prefix,
        mask only the username component."""
        prefix, username = match.group(1), match.group(2)
        if username in reverse:
            return f"{prefix}/{reverse[username]}" if category == "UNIX_HOME_PATH" \
                else f"{prefix}{reverse[username]}"
        n = rm.counts_by_category.get("USERNAME", 0) + 1
        rm.counts_by_category["USERNAME"] = n
        placeholder = f"<USERNAME_{n}>"
        rm.mapping[placeholder] = username
        reverse[username] = placeholder
        sep = "/" if category == "UNIX_HOME_PATH" else ""
        return f"{prefix}{sep}{placeholder}"

    for category, pattern in _PATTERNS:
        if category in ("UNIX_HOME_PATH", "WIN_HOME_PATH"):
            text = pattern.sub(lambda m, c=category: _replace_user_in_path(m, c), text)
        else:
            text = pattern.sub(lambda m, c=category: _replace(m, c), text)

    return text, rm


def rehydrate(text: str, rm: RedactionMap | dict) -> str:
    """Replace placeholders back with original values."""
    if isinstance(rm, dict):
        rm = RedactionMap.from_dict(rm)
    return rm.rehydrate(text)


def redact_payload(payload: dict, rm: RedactionMap) -> dict:
    """Walk a nested JSON-like dict and sanitize all string leaves."""
    if isinstance(payload, dict):
        return {k: redact_payload(v, rm) for k, v in payload.items()}
    if isinstance(payload, list):
        return [redact_payload(v, rm) for v in payload]
    if isinstance(payload, str):
        sanitized, sub_rm = sanitize(payload)
        # Merge sub-mapping into the running map
        for ph, orig in sub_rm.mapping.items():
            if ph not in rm.mapping:
                rm.mapping[ph] = orig
        for cat, count in sub_rm.counts_by_category.items():
            rm.counts_by_category[cat] = max(
                rm.counts_by_category.get(cat, 0), count
            )
        return sanitized
    return payload


def rehydrate_payload(payload: dict, rm: RedactionMap | dict) -> dict:
    """Walk a nested JSON-like dict and rehydrate all string leaves."""
    if isinstance(rm, dict):
        rm = RedactionMap.from_dict(rm)
    if isinstance(payload, dict):
        return {k: rehydrate_payload(v, rm) for k, v in payload.items()}
    if isinstance(payload, list):
        return [rehydrate_payload(v, rm) for v in payload]
    if isinstance(payload, str):
        return rm.rehydrate(payload)
    return payload
