"""
Backlog forecasting — extracted from the dashboard view so it can be unit-tested
and backtested in isolation (pure Python, no Django).

IMPORTANT — what this is and is NOT:
This is a **trailing-window run-rate**, not a statistical forecast. It predicts
"next week looks like the average of the last N weeks" and projects backlog
clearance linearly from the current net flow. It has no trend term, no
seasonality, and no confidence interval. `scripts/eval_forecast.py` measures where
that assumption holds (roughly stationary series) and where it fails (trends,
turning points). Treat the output as a **run-rate indicator**, not a prediction
with guarantees.
"""
from __future__ import annotations
from statistics import mean


def predict_next(series: list[float], *, window: int = 4) -> float:
    """Predict the next value as the mean of the trailing `window` values.
    This is the core assumption behind the backlog outlook."""
    if not series:
        return 0.0
    recent = series[-window:] if len(series) >= window else series
    return mean(recent)


def project_backlog(weekly_created: list[float], weekly_resolved: list[float],
                    backlog_now: float, *, window: int = 4) -> dict:
    """
    Project backlog trajectory from trailing run-rates.

    Returns a dict with:
      - state: "clearing" | "growing" | "steady"
      - weeks (if clearing): estimated weeks to reach zero backlog
      - rate  (if growing): net tickets added per week
      - expected_intake_7d / expected_resolutions_7d: next-week point estimates
      - net_per_week: avg_created - avg_resolved over the window
    """
    avg_c = predict_next(weekly_created, window=window)
    avg_r = predict_next(weekly_resolved, window=window)
    net = avg_c - avg_r

    if net < -0.01 and avg_r > 0:
        weeks_to_clear = round(backlog_now / abs(net), 1)
        outlook = {"state": "clearing", "weeks": weeks_to_clear,
                   "text": f"Clears in ~{weeks_to_clear} wk at current burn rate."}
    elif net > 0.01:
        outlook = {"state": "growing", "rate": round(net, 1),
                   "text": f"Growing ~+{round(net, 1)}/wk — no clearance at current rate."}
    else:
        outlook = {"state": "steady", "text": "Steady — intake matches resolution."}

    return {
        "backlog": outlook,
        "expected_intake_7d": round(avg_c),
        "expected_resolutions_7d": round(avg_r),
        "net_per_week": net,
    }
