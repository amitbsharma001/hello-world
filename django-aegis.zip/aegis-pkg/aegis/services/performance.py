"""
Team-member performance signals.

Rule-based, transparent, and deliberately conservative:

  * Every flag carries the actual numbers AND the threshold that tripped it —
    the "reason" is the arithmetic, not a judgment.
  * Members with too little data in the window are never flagged (min-sample
    guard) — one bad ticket is noise, not a pattern.
  * Signals are computed from ticket data only. They can reflect assignment
    volume, ticket difficulty, leave, or team topology just as easily as
    individual performance, so the UI presents them as "needs attention",
    never as verdicts.

Thresholds are configurable via AEGIS["PERFORMANCE"].
"""
from __future__ import annotations

from statistics import median

from ..conf import conf

DEFAULTS = {
    "MIN_SAMPLE": 3,                # open + created + resolved before any flag
    "SLA_FLAG_PCT": 70,             # flag when SLA compliance is below this
    "MIN_RESOLVED": 3,              # resolved-with-SLA sample the SLA signal needs
    "AT_RISK_FLAG": 3,              # open tickets breached / at SLA risk
    "NET_FLOW_FLAG": 3,             # backlog growth (created - resolved) in window
    "STALE_DAYS": 7,                # open ticket untouched this long is "stale"
    "STALE_FLAG": 3,                # stale open tickets needed to flag
    "ZERO_THROUGHPUT_MIN_OPEN": 3,  # open needed before "0 resolved" flags
    "OVERLOAD_FACTOR": 2.0,         # open >= factor x team median open
    "OVERLOAD_MIN_OPEN": 5,
}


def thresholds() -> dict:
    """DEFAULTS overlaid with AEGIS['PERFORMANCE'] (if provided)."""
    cfg = dict(DEFAULTS)
    cfg.update(getattr(conf, "PERFORMANCE", {}) or {})
    return cfg


def evaluate_member(row: dict, team_median_open: float, cfg: dict | None = None) -> list[dict]:
    """Return the list of tripped signals for one member row.

    Expects row keys: open, at_risk, sla_pct, sla_met, sla_total, resolved_p,
    created_p, net_flow, stale_open. Returns [] under the min-sample guard.
    Each signal: {"code", "severity" ('danger'|'warning'), "reason"}.
    """
    cfg = cfg or thresholds()
    flags: list[dict] = []

    sample = row.get("open", 0) + row.get("created_p", 0) + row.get("resolved_p", 0)
    if sample < cfg["MIN_SAMPLE"]:
        return flags  # too little data to say anything

    # -- danger signals ------------------------------------------------------
    if row.get("sla_total", 0) >= cfg["MIN_RESOLVED"] and row.get("sla_pct", 100) < cfg["SLA_FLAG_PCT"]:
        flags.append({
            "code": "sla_low", "severity": "danger",
            "reason": (f"SLA compliance {row['sla_pct']}% — below the {cfg['SLA_FLAG_PCT']}% "
                       f"target ({row.get('sla_met', 0)}/{row['sla_total']} met)"),
        })
    if row.get("at_risk", 0) >= cfg["AT_RISK_FLAG"]:
        flags.append({
            "code": "sla_exposure", "severity": "danger",
            "reason": (f"{row['at_risk']} open ticket(s) breached or at SLA risk "
                       f"(flags at {cfg['AT_RISK_FLAG']}+)"),
        })

    # -- warning signals -----------------------------------------------------
    if row.get("net_flow", 0) >= cfg["NET_FLOW_FLAG"]:
        flags.append({
            "code": "backlog_growth", "severity": "warning",
            "reason": (f"Backlog grew +{row['net_flow']} this window "
                       f"(created {row.get('created_p', 0)}, resolved {row.get('resolved_p', 0)})"),
        })
    if row.get("stale_open", 0) >= cfg["STALE_FLAG"]:
        flags.append({
            "code": "stale_tickets", "severity": "warning",
            "reason": (f"{row['stale_open']} open ticket(s) untouched for over "
                       f"{cfg['STALE_DAYS']} days (flags at {cfg['STALE_FLAG']}+)"),
        })
    if row.get("open", 0) >= cfg["ZERO_THROUGHPUT_MIN_OPEN"] and row.get("resolved_p", 0) == 0:
        flags.append({
            "code": "zero_throughput", "severity": "warning",
            "reason": f"0 resolved this window despite {row['open']} open",
        })
    if (row.get("open", 0) >= cfg["OVERLOAD_MIN_OPEN"] and team_median_open > 0
            and row["open"] >= cfg["OVERLOAD_FACTOR"] * team_median_open):
        ratio = round(row["open"] / team_median_open, 1)
        flags.append({
            "code": "overload", "severity": "warning",
            "reason": (f"{row['open']} open — {ratio}× the team median ({round(team_median_open)}); "
                       f"workload may need rebalancing"),
        })
    return flags


def team_rollup(rows: list[dict]) -> dict:
    """Aggregate the member rows into a whole-team view (same metric family)."""
    if not rows:
        return {"members": 0, "active": 0, "open": 0, "critical": 0, "at_risk": 0,
                "resolved_p": 0, "created_p": 0, "net_flow": 0, "sla_pct": None,
                "median_open": 0, "avg_age": 0, "busiest": None}
    sla_met = sum(r.get("sla_met", 0) for r in rows)
    sla_total = sum(r.get("sla_total", 0) for r in rows)
    open_total = sum(r.get("open", 0) for r in rows)
    weighted_age = sum(r.get("avg_age", 0) * r.get("open", 0) for r in rows)
    busiest = max(rows, key=lambda r: r.get("open", 0))
    return {
        "members": len(rows),
        "active": sum(1 for r in rows if r.get("open", 0) > 0),
        "open": open_total,
        "critical": sum(r.get("critical", 0) for r in rows),
        "at_risk": sum(r.get("at_risk", 0) for r in rows),
        "resolved_p": sum(r.get("resolved_p", 0) for r in rows),
        "created_p": sum(r.get("created_p", 0) for r in rows),
        "net_flow": sum(r.get("net_flow", 0) for r in rows),
        "sla_pct": round(sla_met / sla_total * 100) if sla_total else None,
        "median_open": median([r.get("open", 0) for r in rows]),
        "avg_age": round(weighted_age / open_total, 1) if open_total else 0,
        "busiest": busiest["name"] if busiest.get("open", 0) > 0 else None,
    }


def build_performance(rows: list[dict], cfg: dict | None = None) -> dict:
    """Attach flags to each row and return {flagged, rollup, cfg}.

    Mutates rows in place (adds "flags") and returns flagged rows sorted by
    danger-count, then total flag count.
    """
    cfg = cfg or thresholds()
    med = median([r.get("open", 0) for r in rows]) if rows else 0
    for r in rows:
        r["flags"] = evaluate_member(r, med, cfg)
    flagged = [r for r in rows if r["flags"]]
    flagged.sort(key=lambda r: (sum(1 for f in r["flags"] if f["severity"] == "danger"),
                                len(r["flags"])), reverse=True)
    return {"flagged": flagged, "rollup": team_rollup(rows), "cfg": cfg}
