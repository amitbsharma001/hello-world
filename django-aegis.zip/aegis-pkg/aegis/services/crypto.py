"""
Symmetric encryption for secrets at rest (per-user API keys, Jira tokens).

Uses Fernet (AES-128-CBC + HMAC) when `cryptography` is available, deriving the
key from Django's SECRET_KEY. Falls back to django.core.signing if the library
is not installed — in that mode values are signed+compressed but NOT encrypted,
so install `cryptography` for production. The public interface is stable either
way: encrypt(str) -> str, decrypt(str) -> str.
"""
from __future__ import annotations
import base64
import hashlib
import logging

from django.conf import settings

log = logging.getLogger("assist.crypto")

_BACKEND = None
_FERNET = None


def _fernet():
    global _FERNET
    if _FERNET is not None:
        return _FERNET
    from cryptography.fernet import Fernet  # may raise ImportError
    key = base64.urlsafe_b64encode(hashlib.sha256(settings.SECRET_KEY.encode()).digest())
    _FERNET = Fernet(key)
    return _FERNET


def _backend() -> str:
    global _BACKEND
    if _BACKEND is None:
        try:
            _fernet()
            _BACKEND = "fernet"
        except Exception:
            # cryptography is unavailable. Storing secrets via django signing is
            # NOT encryption (recoverable base64). Refuse silently degrading to it
            # unless an operator has explicitly opted in for development.
            from .. conf import conf
            allow = getattr(conf, "ALLOW_INSECURE_SECRET_FALLBACK", False)
            if not allow:
                from django.core.exceptions import ImproperlyConfigured
                raise ImproperlyConfigured(
                    "aegis: secret encryption requires the `cryptography` package "
                    "(install django-aegis with the [secrets] extra). To run WITHOUT "
                    "encryption in development only, set "
                    "AEGIS['ALLOW_INSECURE_SECRET_FALLBACK']=True — this stores API "
                    "keys in a recoverable (NOT encrypted) form and must never be "
                    "used in production."
                )
            log.error("assist.crypto.INSECURE_FALLBACK — secrets are NOT encrypted "
                      "(ALLOW_INSECURE_SECRET_FALLBACK is on). Do not use in production.")
            _BACKEND = "signing"
    return _BACKEND


def encrypt(value: str) -> str:
    """Encrypt a plaintext string. Returns an opaque token (str)."""
    if not value:
        return ""
    if _backend() == "fernet":
        return _fernet().encrypt(value.encode()).decode()
    from django.core import signing
    return signing.dumps(value, salt="assist.secret", compress=True)


def decrypt(token: str) -> str:
    """Decrypt a token produced by encrypt(). Returns "" on failure."""
    if not token:
        return ""
    try:
        if _backend() == "fernet":
            return _fernet().decrypt(token.encode()).decode()
        from django.core import signing
        return signing.loads(token, salt="assist.secret")
    except Exception:
        log.exception("assist.crypto.decrypt_failed")
        return ""


def mask(value: str, show: int = 4) -> str:
    """Return a masked preview like '••••••••cd34' for display."""
    if not value:
        return ""
    tail = value[-show:] if len(value) > show else value
    return "•" * 8 + tail
