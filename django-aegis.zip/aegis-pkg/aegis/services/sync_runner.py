"""
Sync runner — pull from every configured connector, across all configured
projects and team members, in one operation.

Each pulling connector (Jira, ServiceNow, ...) already scopes its own fetch to
the enabled projects + team members via services/pull_planner. This runner just
orchestrates them: build config, health-check, fetch, and write through the
gated ingest(), collecting a per-connector report.

Connector credentials come from AEGIS["CONNECTORS"][<name>]. For Jira we also
fall back to the requesting user's saved Jira credentials (UserAIConfig), so an
admin can pull using the same creds they configured for write-back.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass, field

from .. conf import conf
from ..connectors import registry
from ..connectors.base import ingest

log = logging.getLogger("aegis.sync")


@dataclass
class ConnectorResult:
    connector: str
    status: str                 # "ok" | "skipped" | "error"
    reason: str = ""
    imported: int = 0
    updated: int = 0
    skipped: int = 0
    discovered: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "connector": self.connector, "status": self.status, "reason": self.reason,
            "imported": self.imported, "updated": self.updated, "skipped": self.skipped,
            "discovered": self.discovered,
        }


def _config_for(name: str, user=None) -> dict:
    """Resolve connector config from AEGIS settings, with a per-user Jira fallback."""
    cfg = dict((conf.CONNECTORS or {}).get(name, {}))
    if name == "jira" and not cfg and user is not None:
        uc = getattr(user, "ai_config", None)
        if uc and getattr(uc, "jira_configured", False):
            cfg = {"base_url": uc.jira_base_url, "email": uc.jira_email,
                   "token": uc.get_jira_token()}
    return cfg


def run_all_pulls(*, user=None, cursor: str | None = None, incremental: bool = True) -> dict:
    """Pull from every pull-capable connector. Returns a summary dict.

    When `incremental` is True (default) and no explicit `cursor` is given, each
    connector resumes from its last saved SyncCursor and the cursor is advanced
    to the run start time on success — so subsequent runs only fetch what changed.
    Pass `cursor=...` or `incremental=False` to force a full re-pull.
    """
    from ..models import SyncCursor
    from django.utils import timezone as _tz
    results: list[ConnectorResult] = []
    run_started = _tz.now()

    for cname in registry.list():
        cls = registry.get(cname)
        if not cls or not getattr(cls, "supports_pull", False):
            continue

        config = _config_for(cname, user)
        try:
            conn = cls(config)
        except Exception as e:
            log.exception("aegis.sync.init_failed connector=%s", cname)
            results.append(ConnectorResult(cname, "error", reason=str(e)))
            continue

        # Not configured / unreachable -> skip with a clear reason (not an error).
        try:
            healthy = conn.health_check()
        except Exception as e:
            healthy = False
            log.warning("aegis.sync.health_failed connector=%s err=%s", cname, e)
        if not healthy:
            results.append(ConnectorResult(cname, "skipped",
                                           reason="Not configured or unreachable"))
            continue

        # Resolve the cursor: explicit arg > saved cursor (when incremental) > None.
        use_cursor = cursor
        saved = None
        if use_cursor is None and incremental:
            saved = SyncCursor.objects.filter(source=cname).first()
            use_cursor = saved.cursor if (saved and saved.cursor) else None

        try:
            raws = list(conn.fetch(use_cursor))
            tickets, report = ingest(raws)
            results.append(ConnectorResult(
                cname, "ok",
                imported=report.imported, updated=report.updated,
                skipped=report.skipped_disabled + report.skipped_discovered,
                discovered=list(report.discovered_projects),
            ))
            # Advance the cursor to the run-start instant only on a clean pull.
            if incremental:
                SyncCursor.objects.update_or_create(
                    source=cname,
                    defaults={"cursor": run_started.isoformat(), "last_run_at": run_started},
                )
        except Exception as e:
            log.exception("aegis.sync.pull_failed connector=%s", cname)
            results.append(ConnectorResult(cname, "error", reason=str(e)))

    totals = {
        "imported": sum(r.imported for r in results),
        "updated": sum(r.updated for r in results),
        "skipped": sum(r.skipped for r in results),
        "connectors_run": sum(1 for r in results if r.status == "ok"),
        "connectors_total": len(results),
    }
    return {"results": [r.as_dict() for r in results], "totals": totals}


def pullable_connectors() -> list[str]:
    """Names of connectors that can be pulled (for display)."""
    out = []
    for cname in registry.list():
        cls = registry.get(cname)
        if cls and getattr(cls, "supports_pull", False):
            out.append(cname)
    return out
