"""
Sync runner — pull from every configured connector, across all configured
projects and team members, in one operation.

Each pulling connector (Jira, ServiceNow, ...) already scopes its own fetch to
the enabled projects + team members via services/pull_planner. This runner just
orchestrates them: build config, health-check, fetch, and write through the
gated ingest(), collecting a per-connector report.

Connector credentials come from AEGIS["CONNECTORS"][<name>]. For Jira we also
fall back to the requesting user's saved Jira credentials (UserAIConfig), so an
admin can pull using the same creds they configured for write-back.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass, field

from .. conf import conf
from ..connectors import registry
from ..connectors.base import ingest

log = logging.getLogger("assist.sync")


@dataclass
class ConnectorResult:
    connector: str
    status: str                 # "ok" | "skipped" | "error"
    reason: str = ""
    imported: int = 0
    updated: int = 0
    skipped: int = 0
    discovered: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "connector": self.connector, "status": self.status, "reason": self.reason,
            "imported": self.imported, "updated": self.updated, "skipped": self.skipped,
            "discovered": self.discovered,
        }


def _config_for(name: str, user=None) -> dict:
    """Resolve connector config from AEGIS settings, with a per-user Jira fallback."""
    cfg = dict((conf.CONNECTORS or {}).get(name, {}))
    if name == "jira" and not cfg and user is not None:
        uc = getattr(user, "ai_config", None)
        if uc and getattr(uc, "jira_configured", False):
            cfg = {"base_url": uc.jira_base_url, "email": uc.jira_email,
                   "token": uc.get_jira_token()}
    return cfg


WINDOW_DAYS = {"1m": 30, "3m": 90, "6m": 180, "1y": 365}


def run_all_pulls(*, user=None, cursor: str | None = None, incremental: bool = True,
                  mode: str = "all", window: str | None = None) -> dict:
    """Pull from every pull-capable connector. Returns a summary dict.

    When `incremental` is True (default) and no explicit `cursor` is given, each
    connector resumes from its last saved SyncCursor and the cursor is advanced
    to the run start time on success — so subsequent runs only fetch what changed.
    Pass `cursor=...` or `incremental=False` to force a full re-pull.

    mode:   "all" (projects + cross-project members), "projects" (projects only),
            or "teams" (every sync-enabled tracked member, across all projects —
            works with zero projects configured).
    window: "1m" | "3m" | "6m" | "1y" — re-pull that period in full, overriding
            the saved cursor. The cursor still advances afterwards, so the next
            default run resumes incrementally from this run.
    """
    from ..models import SyncCursor
    from .sync_gate import all_member_accounts
    from django.utils import timezone as _tz
    from datetime import timedelta
    results: list[ConnectorResult] = []
    run_started = _tz.now()

    if mode not in ("all", "projects", "teams"):
        log.warning("sync.run unknown mode=%r — falling back to 'all'", mode)
        mode = "all"
    if window:
        days = WINDOW_DAYS.get(window)
        if days:
            cursor = (run_started - timedelta(days=days)).isoformat()
            log.info("sync.run window=%s -> pulling since %s (overrides saved cursor)",
                     window, cursor)
        else:
            log.warning("sync.run unknown window=%r — ignoring", window)
            window = None

    pull_capable = [n for n in registry.list()
                    if registry.get(n) and getattr(registry.get(n), "supports_pull", False)]
    log.info("sync.run START user=%s mode=%s window=%s incremental=%s pull_capable_connectors=%s",
             getattr(user, "username", None), mode, window, incremental, pull_capable)

    for cname in registry.list():
        cls = registry.get(cname)
        if not cls or not getattr(cls, "supports_pull", False):
            continue

        log.info("sync.connector[%s] --- begin ---", cname)
        config = _config_for(cname, user)
        # Log which config keys are present (NEVER the secret values).
        present = {k: ("<set>" if ("token" in k or "password" in k) and v else v)
                   for k, v in config.items()}
        log.info("sync.connector[%s] config keys=%s", cname, present or "<EMPTY — not configured>")
        if not config:
            log.warning("sync.connector[%s] has NO config. Set AEGIS['CONNECTORS']['%s'] "
                        "(or, for jira, your Jira creds in AI Settings).", cname, cname)
        if mode != "all":
            config = dict(config)
            config["pull_mode"] = mode  # connectors pass this to build_scope()

        try:
            conn = cls(config)
        except Exception as e:
            log.exception("sync.connector[%s] init_failed", cname)
            results.append(ConnectorResult(cname, "error", reason=f"init failed: {e}"))
            continue

        # Not configured / unreachable -> skip with a clear reason (not an error).
        try:
            healthy = conn.health_check()
        except Exception as e:
            healthy = False
            log.warning("sync.connector[%s] health_check raised: %s: %s", cname, type(e).__name__, e)
        log.info("sync.connector[%s] health_check -> %s", cname, "OK" if healthy else "FAILED")
        if not healthy:
            results.append(ConnectorResult(cname, "skipped",
                                           reason="Not configured or unreachable (see logs)"))
            log.info("sync.connector[%s] --- skipped (not healthy) ---", cname)
            continue

        # Resolve the cursor: explicit arg > saved cursor (when incremental) > None.
        use_cursor = cursor
        saved = None
        if use_cursor is None and incremental:
            saved = SyncCursor.objects.filter(source=cname).first()
            use_cursor = saved.cursor if (saved and saved.cursor) else None
        log.info("sync.connector[%s] cursor=%s (%s)", cname, use_cursor or "<none/full pull>",
                 "resumed from saved" if saved and saved.cursor else "no saved cursor")

        try:
            log.info("sync.connector[%s] fetching...", cname)
            raws = list(conn.fetch(use_cursor))
            log.info("sync.connector[%s] fetch returned %d raw ticket(s)", cname, len(raws))
            admit = all_member_accounts(cname) if mode == "teams" else None
            tickets, report = ingest(raws, admit_assignees=admit)
            log.info("sync.connector[%s] ingest -> imported=%d updated=%d "
                     "skipped_disabled=%d skipped_discovered=%d discovered=%s",
                     cname, report.imported, report.updated, report.skipped_disabled,
                     report.skipped_discovered, report.discovered_projects)
            if raws and report.imported == 0 and report.updated == 0:
                log.warning("sync.connector[%s] fetched %d but wrote 0 — the project GATE "
                            "skipped them all. Enable their projects in /projects, or track "
                            "the assignees in /teams (pull_all_projects).", cname, len(raws))
            results.append(ConnectorResult(
                cname, "ok",
                imported=report.imported, updated=report.updated,
                skipped=report.skipped_disabled + report.skipped_discovered,
                discovered=list(report.discovered_projects),
            ))
            # Advance the cursor to the run-start instant only on a clean pull.
            if incremental:
                SyncCursor.objects.update_or_create(
                    source=cname,
                    defaults={"cursor": run_started.isoformat(), "last_run_at": run_started},
                )
                log.debug("sync.connector[%s] cursor advanced to %s", cname, run_started.isoformat())
        except Exception as e:
            log.exception("sync.connector[%s] pull_failed", cname)
            results.append(ConnectorResult(cname, "error", reason=str(e)))
        log.info("sync.connector[%s] --- end ---", cname)

    totals = {
        "imported": sum(r.imported for r in results),
        "updated": sum(r.updated for r in results),
        "skipped": sum(r.skipped for r in results),
        "connectors_run": sum(1 for r in results if r.status == "ok"),
        "connectors_total": len(results),
    }
    log.info("sync.run END totals=%s", totals)
    return {"results": [r.as_dict() for r in results], "totals": totals,
            "mode": mode, "window": window}


def pullable_connectors() -> list[str]:
    """Names of connectors that can be pulled (for display)."""
    out = []
    for cname in registry.list():
        cls = registry.get(cname)
        if cls and getattr(cls, "supports_pull", False):
            out.append(cname)
    return out
