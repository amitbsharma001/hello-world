"""
Project-based sync gating.

Only projects that have been configured AND enabled (sync_enabled=True) are
ingested. Inbound items whose project is disabled are skipped. Items whose
project is unknown are auto-registered as `discovered` (disabled) so an admin
can review and enable them — they do not sync until enabled.

This gives a PM explicit control: connect a source, then choose exactly which
projects flow into the workspace.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional

from ..conf import conf
from ..models import Project


@dataclass
class SyncDecision:
    """Outcome of evaluating one inbound item against project config."""
    allowed: bool
    project: Optional[Project]
    reason: str   # "enabled" | "disabled" | "discovered" | "unconfigured" | "open"


@dataclass
class SyncReport:
    """Aggregate counts for a sync run."""
    imported: int = 0
    updated: int = 0
    skipped_disabled: int = 0
    skipped_discovered: int = 0
    discovered_projects: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "imported": self.imported,
            "updated": self.updated,
            "skipped_disabled": self.skipped_disabled,
            "skipped_discovered": self.skipped_discovered,
            "discovered_projects": self.discovered_projects,
            "total_skipped": self.skipped_disabled + self.skipped_discovered,
        }


def resolve_project(source: str, key: str, *, name: str = "",
                    auto_register: bool = True) -> SyncDecision:
    """
    Resolve an inbound item's project and decide whether it may sync.

    `key` is the project code/key from the inbound data (e.g. a Jira project
    key, or the CSV `project`/`team` column).
    """
    require = getattr(conf, "SYNC_REQUIRE_CONFIGURED_PROJECT", True)

    # Legacy / open mode: everything syncs, no gating.
    if not require:
        proj = None
        if key:
            proj = (Project.objects.filter(key__iexact=key).first()
                    or Project.objects.filter(external_key__iexact=key).first())
        return SyncDecision(allowed=True, project=proj, reason="open")

    if not key:
        # No project info on the item — cannot gate it; treat as unconfigured.
        return SyncDecision(allowed=False, project=None, reason="unconfigured")

    proj = (Project.objects.filter(key__iexact=key).first()
            or Project.objects.filter(external_key__iexact=key).first())

    if proj is None:
        if auto_register:
            proj = Project.objects.create(
                key=key.upper()[:32],
                name=name or key,
                source=source if source in dict(Project.Source.choices) else Project.Source.MANUAL,
                external_key=key,
                sync_enabled=False,
                discovered=True,
            )
            return SyncDecision(allowed=False, project=proj, reason="discovered")
        return SyncDecision(allowed=False, project=None, reason="unconfigured")

    if not proj.sync_enabled:
        reason = "discovered" if proj.discovered else "disabled"
        return SyncDecision(allowed=False, project=proj, reason=reason)

    return SyncDecision(allowed=True, project=proj, reason="enabled")


def tracked_member_accounts(source: str) -> set:
    """Lowercased accounts of enabled cross-project members for a source.

    These are people configured with pull_all_projects=True — their work is
    pulled across EVERY project, so their tickets must be admitted even when the
    ticket's project is not itself configured/enabled.
    """
    from ..models import TeamMember
    return {
        (m.account or "").strip().lower()
        for m in TeamMember.objects.filter(sync_enabled=True, pull_all_projects=True,
                                           source=source)
        if (m.account or "").strip()
    }
