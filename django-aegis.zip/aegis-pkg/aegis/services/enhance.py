"""High-level AI services. These are what views and tasks call."""
from __future__ import annotations
from decimal import Decimal
from django.db import transaction

from ..conf import conf
from ..models import Ticket, AIArtifact
from . import prompts
from .gemini import get_client, GeminiError
from .schemas import EnhancedDescription, ActionPlan, MissingInformationReport


def enhance_description(ticket: Ticket, *, force: bool = False) -> AIArtifact:
    """Generate or refresh the enhanced description for a ticket."""
    if (not force) and ticket.enhanced_payload:
        existing = ticket.artifacts.filter(
            kind=AIArtifact.Kind.ENHANCED_DESCRIPTION
        ).first()
        if existing:
            return existing

    client = get_client()
    prompt = prompts.render("enhance", ticket=ticket)
    parsed, meta = client.generate(
        model=conf.GEMINI_MODEL_PRO,
        prompt=prompt,
        schema=EnhancedDescription,
    )

    with transaction.atomic():
        artifact = AIArtifact.objects.create(
            ticket=ticket,
            kind=AIArtifact.Kind.ENHANCED_DESCRIPTION,
            model=meta["model"],
            payload=parsed.model_dump(),
            raw_response=meta["raw"],
            confidence=parsed.confidence,
            tokens_in=meta["tokens_in"],
            tokens_out=meta["tokens_out"],
            cost_usd=Decimal(str(meta["cost_usd"])),
            latency_ms=meta["latency_ms"],
        )
        ticket.enhanced_payload = parsed.model_dump()
        ticket.description_enhanced = _render_enhanced_markdown(parsed)
        ticket.affected_systems = parsed.affected_systems
        # Don't auto-overwrite severity, just suggest
        ticket.save(update_fields=[
            "enhanced_payload", "description_enhanced",
            "affected_systems", "updated_at",
        ])
    return artifact


def generate_plan(ticket: Ticket, *, force: bool = False) -> AIArtifact:
    """Generate the action plan. Requires enhanced description first."""
    if not ticket.enhanced_payload:
        enhance_description(ticket)
        ticket.refresh_from_db()

    if (not force) and ticket.plan_payload:
        existing = ticket.artifacts.filter(
            kind=AIArtifact.Kind.ACTION_PLAN
        ).first()
        if existing:
            return existing

    client = get_client()
    enhanced = EnhancedDescription(**ticket.enhanced_payload)
    prompt = prompts.render("plan", ticket=ticket, enhanced=enhanced)
    parsed, meta = client.generate(
        model=conf.GEMINI_MODEL_PRO,
        prompt=prompt,
        schema=ActionPlan,
    )

    with transaction.atomic():
        artifact = AIArtifact.objects.create(
            ticket=ticket,
            kind=AIArtifact.Kind.ACTION_PLAN,
            model=meta["model"],
            payload=parsed.model_dump(),
            raw_response=meta["raw"],
            confidence=parsed.confidence,
            tokens_in=meta["tokens_in"],
            tokens_out=meta["tokens_out"],
            cost_usd=Decimal(str(meta["cost_usd"])),
            latency_ms=meta["latency_ms"],
        )
        ticket.plan_payload = parsed.model_dump()
        ticket.save(update_fields=["plan_payload", "updated_at"])
    return artifact


def detect_missing_info(ticket: Ticket, *, force: bool = False) -> AIArtifact:
    """Detect missing information."""
    if (not force) and ticket.missing_info_payload:
        existing = ticket.artifacts.filter(
            kind=AIArtifact.Kind.MISSING_INFO
        ).first()
        if existing:
            return existing

    client = get_client()
    prompt = prompts.render("missing_info", ticket=ticket)
    parsed, meta = client.generate(
        model=conf.GEMINI_MODEL_FLASH,
        prompt=prompt,
        schema=MissingInformationReport,
    )

    with transaction.atomic():
        artifact = AIArtifact.objects.create(
            ticket=ticket,
            kind=AIArtifact.Kind.MISSING_INFO,
            model=meta["model"],
            payload=parsed.model_dump(),
            raw_response=meta["raw"],
            confidence=None,
            tokens_in=meta["tokens_in"],
            tokens_out=meta["tokens_out"],
            cost_usd=Decimal(str(meta["cost_usd"])),
            latency_ms=meta["latency_ms"],
        )
        ticket.missing_info_payload = parsed.model_dump()
        ticket.save(update_fields=["missing_info_payload", "updated_at"])
    return artifact


def run_full_analysis(ticket: Ticket, *, force: bool = False) -> dict:
    """Convenience: run all three in sequence."""
    enhance_description(ticket, force=force)
    ticket.refresh_from_db()
    generate_plan(ticket, force=force)
    detect_missing_info(ticket, force=force)
    ticket.refresh_from_db()
    return {
        "enhanced": ticket.enhanced_payload,
        "plan": ticket.plan_payload,
        "missing_info": ticket.missing_info_payload,
    }


def _render_enhanced_markdown(p: EnhancedDescription) -> str:
    """Render the structured enhancement as nice markdown for display."""
    def li(items):
        return "\n".join(f"- {x}" for x in items) if items else "_None identified._"

    return f"""## Problem Summary
{p.problem_summary}

## Business Impact
{p.business_impact}

## Technical Analysis
{p.technical_analysis}

## Affected Systems
{li(p.affected_systems)}

## Observed Symptoms
{li(p.observed_symptoms)}

## Expected Behavior
{p.expected_behavior or "_Unspecified._"}

## Current Behavior
{p.current_behavior or "_Unspecified._"}

## Risks
{li(p.risks)}

## Missing Information
{li(p.missing_information)}

## Recommended Investigation
{li(p.recommended_investigation_areas)}
"""
