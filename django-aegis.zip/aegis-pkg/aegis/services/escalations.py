"""
Bulk-escalation service.

One escalation = one message applied to N tickets. Each ticket becomes an
EscalationItem carrying its own notification state (pending/sent/failed/
skipped) and lifecycle state (pending -> notified -> acknowledged -> resolved,
or cancelled), so the whole cycle is auditable per ticket.

Recipient resolution is honest about its limits: an assignee string is used
directly when it already looks like an email; otherwise we try to match a
configured TeamMember whose account is an email. Anything else is SKIPPED with
the reason recorded — never guessed.
"""
from __future__ import annotations

import logging

from django.utils import timezone

from ..conf import conf

log = logging.getLogger("assist.escalations")

# Allowed EscalationItem.status transitions (end-to-end cycle).
ITEM_TRANSITIONS = {
    "pending": {"notified", "acknowledged", "resolved", "cancelled"},
    "notified": {"acknowledged", "resolved", "cancelled"},
    "acknowledged": {"resolved", "cancelled"},
    "resolved": set(),
    "cancelled": set(),
}

ESCALATION_DEFAULTS = {
    "SUBJECT_PREFIX": "[Escalation]",
    "MAX_TICKETS": 500,   # safety cap for one bulk escalation
}


def settings_for() -> dict:
    cfg = dict(ESCALATION_DEFAULTS)
    cfg.update(getattr(conf, "ESCALATION", {}) or {})
    return cfg


def looks_like_email(value: str) -> bool:
    v = (value or "").strip()
    return "@" in v and "." in v.rsplit("@", 1)[-1] and " " not in v


def resolve_recipient(assignee: str | None, member_emails: dict[str, str]) -> tuple[str | None, str]:
    """Resolve an assignee string to an email. Returns (email|None, reason).

    member_emails maps lowercased TeamMember.account -> that account (only for
    accounts that are themselves emails).
    """
    a = (assignee or "").strip()
    if not a:
        return None, "no assignee on ticket"
    if looks_like_email(a):
        return a, "assignee is an email"
    hit = member_emails.get(a.lower())
    if hit:
        return hit, "matched team member account"
    return None, "assignee has no known email (not an email, no matching team member)"


def can_transition(current: str, new: str) -> bool:
    return new in ITEM_TRANSITIONS.get(current, set())


def best_email(accounts) -> str | None:
    """First account that is an email — a member's reachable address."""
    return next((a for a in accounts if looks_like_email(a)), None)


def _member_email_map() -> dict[str, str]:
    """Map EVERY known identity of a member (Jira accountId, ServiceNow email,
    legacy account) to that member's best email. This is what lets a bare Jira
    accountId assignee resolve to a real inbox via the same person's other
    configured account."""
    from ..models import TeamMember
    out: dict[str, str] = {}
    for m in TeamMember.objects.all():
        accts = m.all_accounts
        email = best_email(accts)
        if not email:
            continue
        for a in accts:
            out[a.lower()] = email
    return out


def comment_target(ticket, post_to_source: bool) -> tuple[str, str]:
    """Decide the write-back state for one ticket: (comment_status, note)."""
    if not post_to_source:
        return "skipped", "write-back disabled"
    src = (ticket.source or "").strip().lower()
    if src not in ("jira", "servicenow"):
        return "skipped", f"source '{src or 'manual'}' has no write-back"
    if not (ticket.source_id or "").strip():
        return "skipped", "ticket has no source id"
    return "pending", ""


def create_escalation(*, title: str, message: str, level: str, tickets, user=None,
                      notify: bool = True, post_to_source: bool = True):
    """Create an Escalation + one EscalationItem per ticket (bulk).

    Does NOT send emails or post comments — call send_escalation_emails() and
    post_escalation_comments() (or the Celery task) afterwards so the caller
    controls sync vs async.
    """
    from ..models import Escalation, EscalationItem

    tickets = list(tickets)
    esc = Escalation.objects.create(title=title.strip(), message=message,
                                    level=level, created_by=user, notify=notify,
                                    post_to_source=post_to_source)
    emails = _member_email_map()
    items = []
    resolvable = comment_targets = 0
    for t in tickets:
        email, why = resolve_recipient(t.assignee, emails)
        if email and notify:
            estat, note = EscalationItem.EmailStatus.PENDING, ""
            resolvable += 1
        elif email:
            estat, note = EscalationItem.EmailStatus.SKIPPED, "notifications disabled"
        else:
            estat, note = EscalationItem.EmailStatus.SKIPPED, why
        cstat, cnote = comment_target(t, post_to_source)
        if cstat == "pending":
            comment_targets += 1
        items.append(EscalationItem(
            escalation=esc, ticket=t, assignee=(t.assignee or "").strip(),
            email_to=email or "", email_status=estat, email_note=note,
            comment_status=cstat, comment_note=cnote,
        ))
    EscalationItem.objects.bulk_create(items, batch_size=500)
    log.info("escalation CREATED id=%s title=%r level=%s tickets=%d "
             "email_resolvable=%d comment_targets=%d notify=%s post_to_source=%s by=%s",
             esc.id, esc.title, level, len(items), resolvable, comment_targets,
             notify, post_to_source, getattr(user, "username", None))
    return esc


def _email_body(escalation, item) -> str:
    t = item.ticket
    ref = t.source_id or str(t.id)
    lines = [
        escalation.message.strip(),
        "",
        "-" * 40,
        f"Ticket:   {ref} — {t.title}",
        f"Severity: {t.get_severity_display()}   Status: {t.get_status_display()}",
    ]
    if t.sla_due_at:
        lines.append(f"SLA due:  {t.sla_due_at:%Y-%m-%d %H:%M} UTC")
    if t.source_url:
        lines.append(f"Link:     {t.source_url}")
    lines += ["-" * 40, "",
              f"Escalation level: {escalation.get_level_display()}",
              "Please acknowledge or update the ticket."]
    return "\n".join(lines)


def send_escalation_emails(escalation, only_items=None) -> dict:
    """Send the escalation email to each item's recipient, one ticket per mail.

    Sends items whose email_status is pending or failed (retries). Pass
    only_items (ids) to restrict. Per-item errors are recorded, never raised —
    one bad address must not sink the other 99. Returns counters.
    """
    from django.core.mail import send_mail
    from ..models import EscalationItem

    cfg = settings_for()
    qs = escalation.items.select_related("ticket").filter(
        email_status__in=[EscalationItem.EmailStatus.PENDING,
                          EscalationItem.EmailStatus.FAILED])
    if only_items:
        qs = qs.filter(id__in=only_items)
    items = list(qs)
    subject = f"{cfg['SUBJECT_PREFIX']} {escalation.title}"
    log.info("escalation.send START id=%s items=%d subject=%r",
             escalation.id, len(items), subject)

    sent = failed = 0
    now = timezone.now()
    for item in items:
        if not item.email_to:
            continue
        try:
            send_mail(subject, _email_body(escalation, item), None,
                      [item.email_to], fail_silently=False)
            item.email_status = EscalationItem.EmailStatus.SENT
            item.email_sent_at = now
            item.email_note = ""
            if can_transition(item.status, EscalationItem.Status.NOTIFIED):
                item.status = EscalationItem.Status.NOTIFIED
            sent += 1
            log.debug("escalation.send OK item=%s to=%s ticket=%s",
                      item.id, item.email_to, item.ticket_id)
        except Exception as e:  # record and continue
            item.email_status = EscalationItem.EmailStatus.FAILED
            item.email_note = f"{type(e).__name__}: {e}"[:300]
            failed += 1
            log.warning("escalation.send FAILED item=%s to=%s err=%s",
                        item.id, item.email_to, item.email_note)
        item.save(update_fields=["email_status", "email_sent_at", "email_note",
                                 "status", "updated_at"])

    if sent and escalation.status == escalation.Status.OPEN:
        escalation.status = escalation.Status.IN_PROGRESS
        escalation.save(update_fields=["status", "updated_at"])
    summary = {"sent": sent, "failed": failed, "attempted": len(items)}
    log.info("escalation.send END id=%s %s", escalation.id, summary)
    return summary


def _comment_text(escalation) -> str:
    return (f"[{escalation.get_level_display()}] ESCALATION: {escalation.title}\n\n"
            f"{escalation.message.strip()}\n\n"
            f"Please acknowledge or update this ticket. "
            f"(Sent via Assist bulk escalation.)")


def post_escalation_comments(escalation, only_items=None) -> dict:
    """Post the escalation message onto each source ticket — a Jira comment or
    a ServiceNow work note. Processes items with comment_status pending or
    failed (retries). Per-item errors are recorded, never raised. Runs in MOCK
    mode per system when live credentials are absent, and records a
    TicketAction audit row either way.
    """
    from ..models import EscalationItem, TicketAction
    from .jira_client import JiraClient
    from .servicenow_client import ServiceNowClient

    qs = escalation.items.select_related("ticket").filter(
        comment_status__in=[EscalationItem.CommentStatus.PENDING,
                            EscalationItem.CommentStatus.FAILED])
    if only_items:
        qs = qs.filter(id__in=only_items)
    items = list(qs)
    text = _comment_text(escalation)
    jira = JiraClient.for_user(escalation.created_by)
    snow = ServiceNowClient.from_settings()
    log.info("escalation.comments START id=%s items=%d jira_live=%s snow_live=%s",
             escalation.id, len(items), jira.live, snow.live)

    posted = mocked = failed = 0
    now = timezone.now()
    for item in items:
        t = item.ticket
        src = (t.source or "").lower()
        try:
            if src == "jira":
                res = jira.add_comment(t.source_id, text)
                ok, mock, detail = res.ok, res.mock, res.detail
            elif src == "servicenow":
                res = snow.add_work_note(t.source_id, text)
                ok, mock, detail = res.ok, res.mock, res.detail
            else:  # defensive; create_escalation should have skipped these
                item.comment_status = EscalationItem.CommentStatus.SKIPPED
                item.comment_note = f"source '{src}' has no write-back"
                item.save(update_fields=["comment_status", "comment_note", "updated_at"])
                continue
        except Exception as e:
            ok, mock, detail = False, False, f"{type(e).__name__}: {e}"[:300]

        if ok and mock:
            item.comment_status = EscalationItem.CommentStatus.MOCK
            item.comment_posted_at = now
            mocked += 1
        elif ok:
            item.comment_status = EscalationItem.CommentStatus.POSTED
            item.comment_posted_at = now
            posted += 1
        else:
            item.comment_status = EscalationItem.CommentStatus.FAILED
            failed += 1
        item.comment_note = (detail or "")[:300]
        item.save(update_fields=["comment_status", "comment_note",
                                 "comment_posted_at", "updated_at"])
        try:
            TicketAction.objects.create(
                ticket=t, user=escalation.created_by,
                kind=TicketAction.Kind.POST_COMMENT,
                status=(TicketAction.Status.MOCK if (ok and mock)
                        else TicketAction.Status.SUCCESS if ok
                        else TicketAction.Status.FAILED),
                detail=(detail or "")[:500],
                payload={"escalation": str(escalation.id), "kind": "escalation_comment"},
            )
        except Exception:  # audit must never break the run
            log.exception("escalation.comments audit_row_failed item=%s", item.id)
        log.debug("escalation.comments item=%s src=%s -> %s", item.id, src,
                  item.comment_status)

    if (posted or mocked) and escalation.status == escalation.Status.OPEN:
        escalation.status = escalation.Status.IN_PROGRESS
        escalation.save(update_fields=["status", "updated_at"])
    summary = {"posted": posted, "mock": mocked, "failed": failed,
               "attempted": len(items)}
    log.info("escalation.comments END id=%s %s", escalation.id, summary)
    return summary
