"""
Gemini client.

Two implementations:
- GeminiClient: real google-genai SDK
- MockGeminiClient: deterministic, realistic outputs for demos and tests

The factory get_client() picks based on settings.AEGIS["MOCK_GEMINI"] or
the absence of an API key. This is what makes the demo "just work" without
credentials.
"""
from __future__ import annotations
import json
import time
import logging
import hashlib
import re
from typing import Type, Tuple, Any
from pydantic import BaseModel, ValidationError
from tenacity import retry, stop_after_attempt, wait_exponential_jitter

from ..conf import conf

log = logging.getLogger("aegis.gemini")

PRICING = {
    "gemini-2.5-pro":   {"in": 1.25e-6, "out": 5.00e-6},
    "gemini-2.5-flash": {"in": 0.075e-6, "out": 0.30e-6},
}


class GeminiError(Exception):
    pass


class GeminiClient:
    """Real Gemini client. Requires google-genai installed and an API key."""

    def __init__(self, api_key: str):
        try:
            from google import genai
        except ImportError as e:
            raise GeminiError(
                "google-genai not installed. `pip install django-aegis[gemini]`"
            ) from e
        self._genai = genai
        self._client = genai.Client(api_key=api_key)

    @retry(stop=stop_after_attempt(conf.MAX_RETRIES),
           wait=wait_exponential_jitter(initial=1, max=15))
    def generate(self, *, model: str, prompt: str,
                 schema: Type[BaseModel]) -> Tuple[BaseModel, dict]:
        from google.genai import types
        t0 = time.perf_counter()
        try:
            resp = self._client.models.generate_content(
                model=model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0.2,
                    response_mime_type="application/json",
                ),
            )
        except Exception as e:
            log.exception("gemini.call_failed")
            raise GeminiError(str(e)) from e

        latency_ms = int((time.perf_counter() - t0) * 1000)
        text = resp.text or "{}"
        try:
            data = json.loads(text)
            parsed = schema(**data)
        except (json.JSONDecodeError, ValidationError) as e:
            log.warning("gemini.bad_json", extra={"text": text[:500]})
            raise GeminiError(f"Schema validation failed: {e}") from e

        usage = getattr(resp, "usage_metadata", None)
        tokens_in = getattr(usage, "prompt_token_count", 0) or 0
        tokens_out = getattr(usage, "candidates_token_count", 0) or 0
        cost = (tokens_in * PRICING.get(model, {}).get("in", 0) +
                tokens_out * PRICING.get(model, {}).get("out", 0))
        meta = {
            "model": model,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost_usd": cost,
            "latency_ms": latency_ms,
            "raw": text,
        }
        return parsed, meta


class MockGeminiClient:
    """
    Deterministic mock that returns realistic, schema-valid responses.

    Produces different outputs based on input text so the UI looks
    plausible across multiple tickets without any API call.
    """

    def generate(self, *, model: str, prompt: str,
                 schema: Type[BaseModel]) -> Tuple[BaseModel, dict]:
        t0 = time.perf_counter()
        # Tiny "AI thinking" delay so the UI looks alive in the demo
        time.sleep(0.05)

        # Find what we're generating from the schema name
        name = schema.__name__
        if name == "EnhancedDescription":
            data = self._mock_enhanced(prompt)
        elif name == "ActionPlan":
            data = self._mock_plan(prompt)
        elif name == "MissingInformationReport":
            data = self._mock_missing(prompt)
        elif name == "AgentDecisionStep":
            data = self._mock_agent_step(prompt)
        else:
            raise GeminiError(f"No mock for schema {name}")

        parsed = schema(**data)
        text = json.dumps(data, indent=2)
        meta = {
            "model": f"{model}-mock",
            "tokens_in": len(prompt) // 4,
            "tokens_out": len(text) // 4,
            "cost_usd": 0.0,
            "latency_ms": int((time.perf_counter() - t0) * 1000),
            "raw": text,
        }
        return parsed, meta

    # ---- Mock content generators ----

    def _extract_input(self, prompt: str) -> dict:
        """Pull title / description out of the prompt so mock is content-aware."""
        m = re.search(r"Title:\s*([^\n]+)", prompt)
        title = m.group(1).strip() if m else ""
        m = re.search(r"Raw description:\s*\n---\s*\n(.*?)\n---", prompt, re.DOTALL)
        desc = m.group(1).strip() if m else ""
        if not desc:
            m = re.search(r"Description:\s*([^\n]+)", prompt)
            desc = m.group(1).strip() if m else ""
        return {"title": title, "description": desc}

    def _keywords(self, text: str) -> list[str]:
        t = text.lower()
        kw = []
        for term, sys in [
            ("api", "api-gateway"), ("database", "primary-db"), ("db", "primary-db"),
            ("payment", "payments-service"), ("auth", "auth-service"),
            ("kafka", "kafka-cluster"), ("redis", "redis-cache"),
            ("nginx", "nginx-ingress"), ("queue", "task-queue"),
            ("login", "auth-service"), ("checkout", "checkout-service"),
            ("email", "notification-service"), ("search", "search-cluster"),
        ]:
            if term in t and sys not in kw:
                kw.append(sys)
        return kw or ["unknown-system"]

    def _severity_from(self, text: str) -> str:
        t = text.lower()
        if any(w in t for w in ["outage", "down", "p0", "critical", "all customers", "production down"]):
            return "sev1"
        if any(w in t for w in ["error", "fail", "broken", "503", "500", "5xx"]):
            return "sev2"
        if any(w in t for w in ["slow", "intermittent", "occasional"]):
            return "sev3"
        return "sev3"

    def _mock_enhanced(self, prompt: str) -> dict:
        inp = self._extract_input(prompt)
        title = inp["title"] or "Untitled issue"
        desc = inp["description"]
        systems = self._keywords(title + " " + desc)
        sev = self._severity_from(title + " " + desc)
        # Confidence proportional to description length
        conf = max(0.3, min(0.9, len(desc) / 400))

        return {
            "problem_summary": (
                f"{title}. Reporter indicates {desc[:120]}..."
                if len(desc) > 120 else f"{title}. {desc}"
            )[:600],
            "business_impact": (
                "Customer-facing functionality is degraded. Revenue and trust"
                " impact depends on traffic share and duration; recommend treating"
                f" as {sev.upper()} until scope is confirmed."
            ),
            "technical_analysis": (
                f"Symptoms point to {systems[0]} as the most likely first place"
                " to look. The reporter did not provide error codes or timestamps,"
                " so the analysis is provisional. Likely candidates: a recent"
                " deploy regression, a downstream dependency failure, or capacity"
                " exhaustion under traffic."
            ),
            "affected_systems": systems[:5],
            "observed_symptoms": [
                s for s in [
                    "Requests failing from customer perspective" if "fail" in desc.lower() or "error" in desc.lower() else None,
                    "Service did not recover after restart" if "restart" in desc.lower() else None,
                    "Intermittent failures" if "intermittent" in desc.lower() or "sometimes" in desc.lower() else None,
                    "Increased latency" if "slow" in desc.lower() else None,
                ] if s
            ] or ["Symptoms underspecified — see missing_information"],
            "expected_behavior": "Service operates within published latency and error SLOs.",
            "current_behavior": desc[:200] or "Unspecified failure mode.",
            "dependencies": [],
            "risks": [
                "Continued impact while unresolved",
                "Cascading failure if retry storms occur downstream",
            ],
            "missing_information": [
                m for m in [
                    "HTTP status codes / error rates" if "error" in desc.lower() and "5" not in desc else None,
                    "Time the issue started (UTC)",
                    "Recent deployments or config changes in the last 24h",
                    "Affected endpoints / customer segments",
                    "Logs or trace IDs for failing requests",
                ] if m
            ],
            "recommended_investigation_areas": [
                f"Compare error rate by endpoint on {systems[0]} pre/post latest deploy",
                "Check APM traces for slowest dependency",
                "Inspect connection pool saturation on primary datastores",
                "Review recent infrastructure events (autoscaling, node restarts)",
            ],
            "severity_suggestion": sev,
            "confidence": round(conf, 2),
        }

    def _mock_plan(self, prompt: str) -> dict:
        inp = self._extract_input(prompt)
        systems = self._keywords(prompt)
        sys0 = systems[0]
        return {
            "summary": (
                f"Stabilize {sys0} by isolating root cause: deploy regression vs."
                " dependency failure vs. capacity."
            ),
            "actions": [
                {
                    "title": "Confirm scope of impact",
                    "description": "Pull error rate by endpoint and customer segment for the last 60 minutes.",
                    "priority": "P0", "effort_hours": 0.25, "risk": "low",
                    "suggested_owner_team": "On-call",
                    "dependencies": [], "automatable": True,
                    "success_criteria": "Quantified % failing and affected endpoints attached to the ticket.",
                },
                {
                    "title": "Correlate with recent deploys",
                    "description": f"Diff {sys0} deploys in the last 24h; check rollout health.",
                    "priority": "P0", "effort_hours": 0.5, "risk": "low",
                    "suggested_owner_team": "On-call",
                    "dependencies": [], "automatable": True,
                    "success_criteria": "List of recent deploys with traffic-shift timestamps attached.",
                },
                {
                    "title": f"Inspect {sys0} dependencies",
                    "description": "Check DB connection pool, downstream APIs, cache hit rates.",
                    "priority": "P1", "effort_hours": 0.5, "risk": "medium",
                    "suggested_owner_team": "Platform",
                    "dependencies": ["Confirm scope of impact"],
                    "automatable": True,
                    "success_criteria": "Dependency metrics captured for the failure window.",
                },
                {
                    "title": "If deploy correlated, roll back",
                    "description": "Revert to last known-good revision; verify error rate.",
                    "priority": "P0", "effort_hours": 0.5, "risk": "medium",
                    "suggested_owner_team": "On-call",
                    "dependencies": ["Correlate with recent deploys"],
                    "automatable": False,
                    "success_criteria": "Error rate returns to baseline within 10 minutes of rollback.",
                },
                {
                    "title": "Write incident summary",
                    "description": "Post-mortem-ready writeup once mitigated.",
                    "priority": "P2", "effort_hours": 1.0, "risk": "low",
                    "suggested_owner_team": "On-call",
                    "dependencies": ["If deploy correlated, roll back"],
                    "automatable": False,
                    "success_criteria": "Doc with timeline, root cause, action items.",
                },
            ],
            "blockers": [],
            "escalation_recommendation": (
                "Escalate to service owner lead if error rate > 5% after 15 minutes"
                " of investigation."
            ),
            "confidence": 0.7,
        }

    def _mock_missing(self, prompt: str) -> dict:
        inp = self._extract_input(prompt)
        desc = inp["description"]
        score = max(0, min(100, 100 - len(desc) / 3))
        return {
            "categories": [
                c for c in [
                    "error_messages" if "error" not in desc.lower() else None,
                    "logs",
                    "environment" if "prod" not in desc.lower() and "staging" not in desc.lower() else None,
                    "reproduction_steps" if "steps" not in desc.lower() else None,
                    "deployment_reference",
                ] if c
            ],
            "follow_up_questions": [
                "What HTTP status codes / error messages are being returned?",
                "When did the issue start (UTC timestamp)?",
                "Were any deploys or config changes made in the last 24h?",
                "Which endpoints / customer segments are affected?",
                "Approximate % of traffic failing?",
            ],
            "investigation_checklist": [
                "Capture 5 representative failing request IDs",
                "Attach Grafana / APM link showing error-rate vs. time",
                "Attach last deploy SHA and rollout time",
            ],
            "can_proceed_without": score < 60,
            "priority_score": round(score, 1),
        }

    # ---- Agent step (ReAct) ----

    def _mock_agent_step(self, prompt: str) -> dict:
        """
        Produce the next plausible ReAct step.

        Reads the prompt to figure out:
        - Which agent (triage / investigator / resolver)
        - What tools are available
        - What steps have been done already
        - What the ticket is about

        Picks an unused tool that makes sense as the next step.
        """
        import re
        # Pull what's been done so far ("Action: tool_name(...)" lines)
        used = set(re.findall(r"Action:\s*(\w+)\(", prompt))
        agent_name = "agent"
        m = re.search(r"You are the (\w+)", prompt)
        if m:
            agent_name = m.group(1).lower()

        # Pull ticket signals
        title = ""
        m = re.search(r"Title:\s*([^\n]+)", prompt)
        if m: title = m.group(1).strip()
        desc = ""
        m = re.search(r"Reporter said:\s*\n---\s*\n(.*?)\n---", prompt, re.DOTALL)
        if m: desc = m.group(1).strip()
        sev = "sev3"
        m = re.search(r"Severity \(current\):\s*(\w+)", prompt)
        if m: sev = m.group(1).strip()
        combined = (title + " " + desc).lower()

        # Build a deterministic-feeling sequence of next steps based on what's been used.
        # Each agent has its own preferred ordering.

        # Pick a service / partner from the content
        systems = self._keywords(combined)
        primary_system = systems[0] if systems else "unknown-service"
        partner = None
        for p in ["stripe", "sendgrid", "twilio", "aws", "datadog"]:
            if p in combined:
                partner = p
                break

        # Triage agent ordering
        triage_steps = [
            ("search_similar_tickets", {
                "query": title or "incident",
                "k": 5,
            }, f"Let me see if similar tickets have been seen recently, to ground this in historical data."),
            ("check_recent_deployments", {
                "service": primary_system, "hours": 24,
            }, f"The reporter's description hints at a possible deploy regression — checking recent deploys for {primary_system}."),
            ("query_metrics", {
                "service": primary_system, "metric": "error_rate", "window_minutes": 60,
            }, f"Let me look at the actual error rate on {primary_system} over the last hour to quantify the impact."),
        ]
        if partner:
            triage_steps.insert(2, (
                "check_partner_status", {"partner": partner},
                f"The ticket mentions {partner} — checking their public status page before going deeper."
            ))

        # Investigator goes deeper
        investigator_steps = [
            ("query_metrics", {
                "service": primary_system, "metric": "latency_p95", "window_minutes": 60,
            }, f"Latency profile of {primary_system} will tell us if this is throughput-bound or downstream."),
            ("query_metrics", {
                "service": primary_system, "metric": "throughput", "window_minutes": 60,
            }, "Checking throughput to see if traffic dropped (degraded) or held (still failing)."),
            ("search_similar_tickets", {
                "query": "after deploy", "k": 5,
            }, "Looking for past tickets with similar deploy-regression patterns."),
        ]

        # Resolver proposes communications + actions
        resolver_steps = [
            ("post_to_slack", {
                "channel": "#incidents",
                "message": f"Aegis: investigating {title}. Affected: {primary_system}. Will update in 15 min.",
            }, "Posting an initial heads-up to #incidents so the on-call team is aware."),
            ("request_info_from_user", {
                "questions": [
                    "What HTTP status codes are you seeing?",
                    "When did this start (UTC)?",
                    "Approximate % of traffic affected?",
                ],
            }, "Asking the reporter for the specific missing details so we can confirm scope."),
        ]

        if "triage" in agent_name:
            sequence = triage_steps
            final_summary = self._triage_summary(title, primary_system, sev, partner, combined)
        elif "investigator" in agent_name:
            sequence = investigator_steps
            final_summary = self._investigator_summary(title, primary_system, sev, combined)
        elif "resolver" in agent_name:
            sequence = resolver_steps
            final_summary = self._resolver_summary(title, primary_system, sev, combined)
        else:
            sequence = triage_steps
            final_summary = self._triage_summary(title, primary_system, sev, partner, combined)

        # Find the first step we haven't done yet
        for tool_name, args, thought in sequence:
            if tool_name not in used:
                return {
                    "thought": thought,
                    "action": tool_name,
                    "action_input": args,
                    "is_final": False,
                }

        # We've used everything — time to finish
        return {
            "thought": "I have enough signal to summarize and recommend next steps.",
            "action": "finish",
            "action_input": final_summary,
            "is_final": True,
        }

    def _triage_summary(self, title, system, sev, partner, combined) -> dict:
        if any(w in combined for w in ["outage", "down", "all customers", "production down"]):
            rec_sev = "sev1"
        elif any(w in combined for w in ["error", "fail", "503", "500", "5xx", "broken"]):
            rec_sev = "sev2"
        else:
            rec_sev = "sev3"
        cause = ("recent deploy regression on " + system) if "deploy" in combined or "after" in combined \
                else (partner + " partner degradation") if partner \
                else f"unknown — needs further investigation in {system}"
        return {
            "summary": (
                f"Triage of '{title}': symptoms point to {cause}. "
                f"Recommended severity {rec_sev.upper()}. "
                "Investigator agent should pick up the deeper analysis."
            ),
            "root_cause_hypothesis": cause,
            "recommended_severity": rec_sev,
            "recommended_actions": [
                f"Hand off to Investigator agent for deep-dive on {system}",
                "Drop on-call team a Slack heads-up",
                ("Rollback last deploy if error rate stays elevated"
                 if "deploy" in combined else
                 f"Open a war-room channel if {rec_sev} confirmed"),
            ],
            "confidence": 0.72,
        }

    def _investigator_summary(self, title, system, sev, combined) -> dict:
        return {
            "summary": (
                f"Investigation: {system} error rate is elevated and trending up. "
                "Throughput stable, so this is a quality-of-service degradation, not a load issue. "
                "Strongly correlates with the most recent deploy."
            ),
            "root_cause_hypothesis": f"Regression introduced by the latest deploy on {system}",
            "recommended_severity": "sev2" if sev in ("sev3", "sev4") else sev,
            "recommended_actions": [
                "Compare current revision against last-known-good revision",
                "Run targeted rollback on a canary subset",
                "Capture failing request traces for the Resolver agent",
            ],
            "confidence": 0.81,
        }

    def _resolver_summary(self, title, system, sev, combined) -> dict:
        return {
            "summary": (
                "Stakeholders notified, follow-up info requested from reporter. "
                "Ready for engineering action: targeted rollback recommended."
            ),
            "root_cause_hypothesis": f"Pending engineering confirmation on {system}",
            "recommended_severity": sev,
            "recommended_actions": [
                "Engineering: roll back to last-known-good revision",
                "Verify error rate returns to baseline within 10 minutes",
                "Post-mitigation: write incident summary",
            ],
            "confidence": 0.78,
        }


_singleton = None


def get_client():
    """Factory. Returns mock when MOCK_GEMINI=True or no API key configured."""
    global _singleton
    if _singleton is not None:
        return _singleton
    if conf.MOCK_GEMINI or not conf.GEMINI_API_KEY:
        log.info("aegis.gemini.using_mock_client")
        _singleton = MockGeminiClient()
    else:
        _singleton = GeminiClient(conf.GEMINI_API_KEY)
    return _singleton


def reset_client():
    """For tests."""
    global _singleton
    _singleton = None
