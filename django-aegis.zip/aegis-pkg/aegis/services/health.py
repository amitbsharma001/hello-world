"""
Portfolio health score — extracted from the dashboard view so its behavior can
be analyzed in isolation (pure Python, no Django).

The score is a weighted blend of four sub-scores, each mapped to 0-100:
    health = 0.40*SLA + 0.25*backlog + 0.20*escalations + 0.15*aging

CAVEAT (see scripts/eval_health.py): the nominal weights are NOT validated
against any ground truth of "was this project actually in trouble", and — because
the four sub-scores have different realistic ranges and use hand-picked
multipliers (×8 for net backlog, ×6 per escalation) — a factor's nominal weight
does not equal its effective influence on the score. Treat the score as a
transparent, tunable heuristic, not a calibrated risk model.
"""
from __future__ import annotations

# Defaults mirror the original inline computation.
DEFAULT_WEIGHTS = {"sla": 0.40, "backlog": 0.25, "escalations": 0.20, "aging": 0.15}
DEFAULT_SCALES = {"backlog_per_net": 8, "per_escalation": 6}

GRADES = [(90, "A", "Healthy"), (80, "B", "Healthy"), (70, "C", "Watch"),
          (60, "D", "Watch"), (0, "F", "At risk")]


def _clamp(x: float) -> float:
    return max(0.0, min(100.0, x))


def subscores(sla_pct: float, net_flow: float, escalations: int, pct_stale: float,
              scales: dict = DEFAULT_SCALES) -> dict:
    """Map raw inputs to the four 0-100 sub-scores."""
    return {
        "sla": _clamp(sla_pct),
        "backlog": max(0.0, 100 - max(0.0, net_flow) * scales["backlog_per_net"]),
        "escalations": max(0.0, 100 - escalations * scales["per_escalation"]),
        "aging": max(0.0, 100 - pct_stale),
    }


def grade_for(health: float) -> tuple[str, str]:
    for threshold, letter, status in GRADES:
        if health >= threshold:
            return letter, status
    return "F", "At risk"


def compute_health(sla_pct: float, net_flow: float, escalations: int, pct_stale: float,
                   weights: dict = DEFAULT_WEIGHTS, scales: dict = DEFAULT_SCALES) -> dict:
    """Return the composite health score plus its parts and grade."""
    s = subscores(sla_pct, net_flow, escalations, pct_stale, scales)
    health = round(weights["sla"] * s["sla"]
                   + weights["backlog"] * s["backlog"]
                   + weights["escalations"] * s["escalations"]
                   + weights["aging"] * s["aging"])
    letter, status = grade_for(health)
    return {"health": health, "grade": letter, "status": status, "subscores": s}
