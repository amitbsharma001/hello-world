"""Aging, risk, and priority scoring. Pure functions over Ticket."""
import math
from django.utils import timezone

from ..models import Ticket


SEVERITY_WEIGHT = {"sev1": 1.0, "sev2": 0.7, "sev3": 0.4, "sev4": 0.2}


def score(ticket: Ticket) -> dict:
    """Compute aging, risk, and operational-priority for a ticket."""
    now = timezone.now()
    age_h = max(0.0, (now - ticket.opened_at).total_seconds() / 3600)
    last_touch = ticket.last_external_update_at or ticket.opened_at
    idle_h = max(0.0, (now - last_touch).total_seconds() / 3600)

    if ticket.sla_due_at:
        sla_rem_h = (ticket.sla_due_at - now).total_seconds() / 3600
        if sla_rem_h <= 0:
            breach_prob = 1.0
        else:
            breach_prob = 1.0 / (1.0 + math.exp(sla_rem_h / 4 - 2))
    else:
        sla_rem_h = None
        breach_prob = 0.0

    aging = min(100.0, age_h * 0.6 + idle_h * 1.2)
    sev_w = SEVERITY_WEIGHT.get(ticket.severity, 0.4)
    impact_w = math.log1p(ticket.impacted_users) / 10
    risk = 100 * (0.5 * breach_prob + 0.3 * sev_w + 0.2 * impact_w)

    missing_score = (ticket.missing_info_payload or {}).get("priority_score", 0)
    if missing_score > 60:
        risk = max(risk, 60.0)

    priority = 0.5 * risk + 0.3 * aging + 0.2 * (ticket.priority_ai or sev_w * 100)

    return {
        "age_hours": round(age_h, 2),
        "idle_hours": round(idle_h, 2),
        "sla_remaining_hours": round(sla_rem_h, 2) if sla_rem_h is not None else None,
        "breach_probability": round(breach_prob, 3),
        "aging_score": round(aging, 1),
        "risk_score": round(risk, 1),
        "operational_priority": round(priority, 1),
    }


def status_label(s: dict) -> str:
    """Human label for the risk score, for UI badges."""
    r = s["risk_score"]
    if r >= 75:
        return "critical"
    if r >= 50:
        return "high"
    if r >= 25:
        return "medium"
    return "low"
