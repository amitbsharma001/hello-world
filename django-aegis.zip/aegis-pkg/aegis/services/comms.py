"""
Customer communication.

Generates a customer-facing status/resolution email from a ticket, using the
requesting user's own AI configuration (their key/provider/model). The draft is
returned for review — nothing is sent automatically.
"""
from __future__ import annotations
import logging

from .gemini import get_client, model_for
from .schemas import CustomerEmail

log = logging.getLogger("assist.comms")


def _prompt_for(ticket) -> str:
    enhanced = ticket.description_enhanced or ticket.description_raw or ""
    plan = ticket.plan_payload or {}
    plan_summary = plan.get("summary", "") if isinstance(plan, dict) else ""
    return (
        "Draft a concise, empathetic customer-facing email about the support "
        "ticket below. Do not expose internal system names, stack traces, or "
        "engineer names. Acknowledge impact, state what is being done, and set "
        "expectations. If the ticket is resolved/closed, frame it as a resolution "
        "note.\n\n"
        f"Title: {ticket.title}\n"
        f"Status: {ticket.get_status_display()}\n"
        f"Severity: {ticket.severity}\n"
        f"Description:\n---\n{enhanced[:1500]}\n---\n"
        f"Resolution summary (internal): {plan_summary[:500]}\n"
    )


def generate_customer_email(ticket, user=None) -> tuple[CustomerEmail, dict]:
    """Return (CustomerEmail, meta). Raises AIConfigRequired if user unconfigured."""
    client = get_client(user)
    email, meta = client.generate(
        model=model_for(user, tier="flash"),
        prompt=_prompt_for(ticket),
        schema=CustomerEmail,
    )
    return email, meta
