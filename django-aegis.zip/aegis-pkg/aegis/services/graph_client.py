"""
Microsoft Graph client for bulk team-member import.

Given a group's email (or id), resolve the group and list its members
(transitive), returning normalized people we can turn into TeamMembers.

Honest degradation: with no tenant_id/client_id/client_secret under
AEGIS["GRAPH"], `live` is False and `fetch_group_members` returns a small
deterministic MOCK set flagged mock=True — so the feature is demonstrable and
testable offline, and never fabricates a real directory. Auth uses the OAuth2
client-credentials flow; all network paths are guarded and errors surfaced,
never raised into the request.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

import httpx

from ..conf import conf

log = logging.getLogger("assist.graph")

GRAPH = "https://graph.microsoft.com/v1.0"
TOKEN_URL = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"


@dataclass
class GraphPerson:
    name: str
    email: str
    account_id: str = ""       # Azure AD object id (stable)
    job_title: str = ""


@dataclass
class GraphResult:
    ok: bool
    mock: bool
    people: list = field(default_factory=list)
    detail: str = ""
    group_name: str = ""


def _mock_people(group_email: str) -> list:
    stem = (group_email.split("@", 1)[0] or "team").replace(".", " ").title()
    base = group_email.split("@", 1)[-1] or "example.com"
    return [
        GraphPerson(f"{stem} Lead", f"lead@{base}", "mock-oid-1", "Team Lead"),
        GraphPerson(f"{stem} Engineer A", f"eng.a@{base}", "mock-oid-2", "Engineer"),
        GraphPerson(f"{stem} Engineer B", f"eng.b@{base}", "mock-oid-3", "Engineer"),
        GraphPerson(f"{stem} Analyst", f"analyst@{base}", "mock-oid-4", "Analyst"),
    ]


class GraphClient:
    def __init__(self, *, tenant_id: str = "", client_id: str = "",
                 client_secret: str = ""):
        self.tenant_id = tenant_id
        self.client_id = client_id
        self.client_secret = client_secret
        self._token: str | None = None

    @property
    def live(self) -> bool:
        return bool(self.tenant_id and self.client_id and self.client_secret)

    @classmethod
    def from_settings(cls) -> "GraphClient":
        cfg = (getattr(conf, "GRAPH", {}) or {})
        return cls(tenant_id=cfg.get("tenant_id", ""),
                   client_id=cfg.get("client_id", ""),
                   client_secret=cfg.get("client_secret", ""))

    def _get_token(self, client: httpx.Client) -> str:
        r = client.post(
            TOKEN_URL.format(tenant=self.tenant_id),
            data={"client_id": self.client_id,
                  "client_secret": self.client_secret,
                  "scope": "https://graph.microsoft.com/.default",
                  "grant_type": "client_credentials"},
            headers={"Content-Type": "application/x-www-form-urlencoded"})
        r.raise_for_status()
        return r.json()["access_token"]

    @staticmethod
    def _person_from_graph(u: dict) -> GraphPerson | None:
        email = (u.get("mail") or u.get("userPrincipalName") or "").strip()
        name = (u.get("displayName") or email).strip()
        if not email:
            return None
        return GraphPerson(name=name, email=email, account_id=u.get("id", ""),
                           job_title=u.get("jobTitle") or "")

    def fetch_group_members(self, group_email: str) -> GraphResult:
        """Resolve a group by email/id and list its transitive user members."""
        group_email = (group_email or "").strip()
        if not group_email:
            return GraphResult(ok=False, mock=False, detail="No group email provided")

        if not self.live:
            log.info("graph.mock group=%s", group_email)
            return GraphResult(ok=True, mock=True, people=_mock_people(group_email),
                               group_name=group_email,
                               detail="Mock — no Microsoft Graph credentials configured")
        try:
            with httpx.Client(timeout=30) as client:
                token = self._get_token(client)
                auth = {"Authorization": f"Bearer {token}"}

                # Resolve group id: treat an input containing '@' as a mail filter,
                # otherwise as an object id.
                if "@" in group_email:
                    gr = client.get(f"{GRAPH}/groups", headers=auth,
                                    params={"$filter": f"mail eq '{group_email}'",
                                            "$select": "id,displayName"})
                    gr.raise_for_status()
                    groups = (gr.json() or {}).get("value") or []
                    if not groups:
                        return GraphResult(ok=False, mock=False,
                                           detail=f"No group found with mail {group_email}")
                    gid, gname = groups[0]["id"], groups[0].get("displayName", group_email)
                else:
                    gid, gname = group_email, group_email

                # Transitive members, paged.
                people, url = [], (f"{GRAPH}/groups/{gid}/transitiveMembers/"
                                   f"microsoft.graph.user"
                                   f"?$select=id,displayName,mail,userPrincipalName,jobTitle"
                                   f"&$top=100")
                while url:
                    mr = client.get(url, headers=auth)
                    mr.raise_for_status()
                    body = mr.json() or {}
                    for u in body.get("value", []):
                        p = self._person_from_graph(u)
                        if p:
                            people.append(p)
                    url = body.get("@odata.nextLink")
                log.info("graph.fetch group=%s (%s) members=%d", gname, gid, len(people))
                return GraphResult(ok=True, mock=False, people=people, group_name=gname)
        except httpx.HTTPStatusError as e:
            detail = f"HTTP {e.response.status_code}: {(e.response.text or '')[:200]}"
            log.warning("graph.fetch FAILED group=%s %s", group_email, detail)
            return GraphResult(ok=False, mock=False, detail=detail)
        except Exception as e:
            log.warning("graph.fetch FAILED group=%s err=%s", group_email, e)
            return GraphResult(ok=False, mock=False,
                               detail=f"{type(e).__name__}: {e}"[:300])
