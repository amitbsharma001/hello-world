"""
Pull-scope planner.

Computes what to pull from a source, combining three levels of control:

  1. Full project       — an enabled Project with member_scope = ALL.
                          Pull every issue in that project.
  2. Team-scoped project — an enabled Project with member_scope = TEAM.
                          Pull only issues assigned to that project's configured
                          team members.
  3. Cross-project member — an enabled TeamMember with pull_all_projects = True.
                          Pull ALL of that person's assigned work across EVERY
                          project, including projects not in the configured list.

Each connector (Jira, ServiceNow, ...) translates the resulting PullScope into
its own query language. The planner is source-aware so Jira members don't leak
into ServiceNow pulls and vice-versa.
"""
from __future__ import annotations
from dataclasses import dataclass, field

from .. conf import conf
from ..models import Project, TeamMember


@dataclass
class PullScope:
    # Projects to pull in full (member_scope = ALL)
    project_keys: list[str] = field(default_factory=list)
    # project_key -> [member accounts]  (member_scope = TEAM)
    project_members: dict[str, list[str]] = field(default_factory=dict)
    # Members to pull across ALL projects (pull_all_projects = True)
    member_accounts: list[str] = field(default_factory=list)
    # When True (open mode) the connector should pull everything, ignoring scope.
    pull_everything: bool = False

    @property
    def is_empty(self) -> bool:
        return not (self.project_keys or self.project_members or self.member_accounts)


def _project_key(p: Project) -> str:
    return (p.external_key or p.key or "").strip()


def build_scope(source: str, mode: str = "all") -> PullScope:
    """Build the pull scope for a given source ('jira' | 'servicenow').

    mode:
      "all"      — projects + cross-project members (default; original behavior).
      "projects" — only enabled projects (full or team-scoped); no
                   cross-project member clause.
      "teams"    — only tracked people: EVERY sync-enabled TeamMember for the
                   source, across all projects. Works with zero projects
                   configured — this is the "I have no projects yet, pull my
                   team's work" mode.

    An explicit "projects"/"teams" choice always stays scoped: open mode
    (SYNC_REQUIRE_CONFIGURED_PROJECT=False) is only honoured for mode="all".
    """
    scope = PullScope()

    # Open mode — gating disabled, pull the whole instance.
    if mode == "all" and not getattr(conf, "SYNC_REQUIRE_CONFIGURED_PROJECT", True):
        scope.pull_everything = True
        return scope

    # --- Projects for this source ---
    if mode in ("all", "projects"):
        projects = Project.objects.filter(sync_enabled=True, source=source).prefetch_related("members")
        for p in projects:
            key = _project_key(p)
            if not key:
                continue
            if p.member_scope == Project.MemberScope.TEAM:
                accounts = [m.account.strip() for m in p.members.all()
                            if m.sync_enabled and m.account.strip()]
                if accounts:
                    scope.project_members[key] = accounts
                # If TEAM scope but no members configured, pull nothing for this project.
            else:
                scope.project_keys.append(key)

    # --- Members for this source ---
    if mode == "teams":
        # Teams mode: every sync-enabled member, across all projects.
        members = TeamMember.objects.filter(sync_enabled=True, source=source)
    elif mode == "all":
        # Default: only members explicitly marked pull_all_projects.
        members = TeamMember.objects.filter(sync_enabled=True, source=source,
                                            pull_all_projects=True)
    else:  # "projects"
        members = TeamMember.objects.none()

    seen = set()
    for m in members:
        acct = m.account.strip()
        if acct and acct not in seen:
            seen.add(acct)
            scope.member_accounts.append(acct)

    return scope
