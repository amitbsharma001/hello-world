"""
Minimal ServiceNow write client (work notes), mirroring JiraClient's contract:
if no live credentials are configured under AEGIS["CONNECTORS"]["servicenow"],
it runs in MOCK mode — the action is logged and reported as mock, never faked
as a real write.

Tickets store the incident *number* as source_id (sys_id only in the raw
extra), so writes resolve number -> sys_id first.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx

from ..conf import conf

log = logging.getLogger("assist.servicenow.client")


@dataclass
class SNResult:
    ok: bool
    mock: bool
    detail: str = ""
    status_code: int | None = None


class ServiceNowClient:
    def __init__(self, *, base_url: str = "", user: str = "", password: str = "",
                 table: str = "incident"):
        self.base_url = (base_url or "").rstrip("/")
        self.user = user
        self.password = password
        self.table = table or "incident"

    @property
    def live(self) -> bool:
        return bool(self.base_url and self.user and self.password)

    @classmethod
    def from_settings(cls) -> "ServiceNowClient":
        cfg = (getattr(conf, "CONNECTORS", {}) or {}).get("servicenow", {}) or {}
        return cls(base_url=cfg.get("base_url", ""), user=cfg.get("user", ""),
                   password=cfg.get("password", ""),
                   table=cfg.get("table", "incident"))

    def _client(self) -> httpx.Client:
        return httpx.Client(base_url=self.base_url, auth=(self.user, self.password),
                            timeout=30, headers={"Accept": "application/json"})

    def _sys_id_for(self, client: httpx.Client, number: str) -> str | None:
        r = client.get(f"/api/now/table/{self.table}",
                       params={"sysparm_query": f"number={number}",
                               "sysparm_fields": "sys_id", "sysparm_limit": 1})
        r.raise_for_status()
        rows = (r.json() or {}).get("result") or []
        return rows[0].get("sys_id") if rows else None

    def add_work_note(self, number: str, note: str) -> SNResult:
        """Append a work note to the incident identified by its number."""
        if not self.live:
            log.info("servicenow.mock work_note number=%s", number)
            return SNResult(ok=True, mock=True,
                            detail="Mock — no live ServiceNow credentials configured")
        try:
            with self._client() as c:
                sys_id = self._sys_id_for(c, number)
                if not sys_id:
                    return SNResult(ok=False, mock=False,
                                    detail=f"No {self.table} found with number={number}")
                r = c.patch(f"/api/now/table/{self.table}/{sys_id}",
                            json={"work_notes": note})
                if r.status_code in (200, 204):
                    return SNResult(ok=True, mock=False,
                                    detail=f"{self.base_url}/nav_to.do?uri="
                                           f"{self.table}.do?sys_id={sys_id}",
                                    status_code=r.status_code)
                return SNResult(ok=False, mock=False, status_code=r.status_code,
                                detail=f"HTTP {r.status_code}: {(r.text or '')[:200]}")
        except Exception as e:
            log.warning("servicenow.work_note FAILED number=%s err=%s", number, e)
            return SNResult(ok=False, mock=False, detail=f"{type(e).__name__}: {e}"[:300])
