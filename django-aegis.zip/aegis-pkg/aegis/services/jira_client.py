"""
Jira write-back client.

Pushes AI output back to the source system: updates an issue's description and
posts resolution steps as a comment. Uses each user's own Jira credentials
(stored encrypted on their UserAIConfig).

If the user has not configured live Jira credentials, the client runs in MOCK
mode: it records what *would* be sent and returns a synthetic success, so the
end-to-end flow is demonstrable without a real Jira instance.
"""
from __future__ import annotations
import logging
from dataclasses import dataclass

log = logging.getLogger("aegis.jira")


@dataclass
class JiraResult:
    ok: bool
    mock: bool
    detail: str          # external URL / ref, or error
    request: dict        # what we sent (for audit / display)


def _to_adf(text: str) -> dict:
    """Convert plain text to a minimal Atlassian Document Format payload."""
    paragraphs = []
    for block in (text or "").split("\n\n"):
        block = block.strip()
        if not block:
            continue
        paragraphs.append({
            "type": "paragraph",
            "content": [{"type": "text", "text": block}],
        })
    if not paragraphs:
        paragraphs = [{"type": "paragraph", "content": [{"type": "text", "text": text or ""}]}]
    return {"type": "doc", "version": 1, "content": paragraphs}


class JiraClient:
    def __init__(self, *, base_url: str = "", email: str = "", token: str = ""):
        self.base_url = (base_url or "").rstrip("/")
        self.email = email
        self.token = token

    @property
    def live(self) -> bool:
        return bool(self.base_url and self.email and self.token)

    @classmethod
    def for_user(cls, user) -> "JiraClient":
        cfg = getattr(user, "ai_config", None)
        if cfg and cfg.jira_configured:
            return cls(base_url=cfg.jira_base_url, email=cfg.jira_email, token=cfg.get_jira_token())
        return cls()

    # ---- API ----

    def update_description(self, issue_key: str, description: str) -> JiraResult:
        body = {"fields": {"description": _to_adf(description)}}
        return self._send("PUT", f"/rest/api/3/issue/{issue_key}", body,
                          ok_detail=f"{self.base_url}/browse/{issue_key}")

    def add_comment(self, issue_key: str, comment: str) -> JiraResult:
        body = {"body": _to_adf(comment)}
        return self._send("POST", f"/rest/api/3/issue/{issue_key}/comment", body,
                          ok_detail=f"{self.base_url}/browse/{issue_key}")

    # ---- transport ----

    def _send(self, method: str, path: str, body: dict, *, ok_detail: str) -> JiraResult:
        if not self.live:
            log.info("aegis.jira.mock %s %s", method, path)
            return JiraResult(ok=True, mock=True,
                              detail="Mock mode — no live Jira credentials configured.",
                              request={"method": method, "path": path, "body": body})
        try:
            import requests  # optional dependency for live mode
            url = f"{self.base_url}{path}"
            resp = requests.request(
                method, url, json=body, timeout=20,
                auth=(self.email, self.token),
                headers={"Accept": "application/json", "Content-Type": "application/json"},
            )
            if resp.status_code in (200, 201, 204):
                return JiraResult(ok=True, mock=False, detail=ok_detail,
                                  request={"method": method, "path": path})
            return JiraResult(ok=False, mock=False,
                              detail=f"Jira returned {resp.status_code}: {resp.text[:300]}",
                              request={"method": method, "path": path})
        except Exception as e:
            log.exception("aegis.jira.send_failed")
            return JiraResult(ok=False, mock=False, detail=str(e),
                              request={"method": method, "path": path})
