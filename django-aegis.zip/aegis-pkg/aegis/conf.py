"""
Aegis configuration.

In your Django project's settings.py, define a single AEGIS dict to override:

    AEGIS = {
        "GEMINI_API_KEY": os.environ.get("GEMINI_API_KEY", ""),
        "GEMINI_MODEL_PRO":   "gemini-2.5-pro",
        "GEMINI_MODEL_FLASH": "gemini-2.5-flash",
        "MOCK_GEMINI":        False,         # True for offline demo / tests
        "USE_CELERY":         False,         # True in production
        "DEFAULT_SLA_HOURS":  24,
        "TICKET_LIST_PAGE_SIZE": 50,
        "CONNECTORS": {
            "jira": {
                "base_url": "https://your-org.atlassian.net",
                "email": "...",
                "api_token": "...",
                "jql": "updated >= -7d",
            },
        },
    }

Everything has a default so you can drop the app in with zero config.
"""
from django.conf import settings as dj_settings

DEFAULTS = {
    "GEMINI_API_KEY": "",
    "GEMINI_MODEL_PRO": "gemini-2.5-pro",
    "GEMINI_MODEL_FLASH": "gemini-2.5-flash",
    "MOCK_GEMINI": True,
    "USE_CELERY": False,
    "DEFAULT_SLA_HOURS": 24,
    "TICKET_LIST_PAGE_SIZE": 50,
    "REQUEST_TIMEOUT_SECONDS": 30,
    "MAX_RETRIES": 4,
    "CONNECTORS": {},
    "BRAND_NAME": "Aegis",
    "ENABLE_REST_API": True,
    "ENABLE_UI": True,
    "AUTO_TRIAGE": True,        # autonomous agent pipeline on new tickets
    "MAX_AGENT_STEPS": 8,
}


class _Settings:
    def __getattr__(self, name):
        user = getattr(dj_settings, "AEGIS", {})
        if name not in DEFAULTS:
            raise AttributeError(f"Unknown AEGIS setting: {name}")
        return user.get(name, DEFAULTS[name])


conf = _Settings()
