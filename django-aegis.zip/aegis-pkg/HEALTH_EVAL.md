# Health-score evidence

Measured by `scripts/eval_health.py` (reproduce: `make eval-health`). We have no
ground-truth labels of "was this project actually at risk", so this does NOT
validate whether the score is correct. What it DOES measure — and what turns out
to matter — is whether each factor's **nominal weight** matches its **effective
influence** on the score. It does not.

## Nominal weight vs measured influence

| Factor | Nominal weight | OAT swing | Variance share |
|---|---|---|---|
| sla | 40% | 16pt | 17% |
| backlog | 25% | 25pt | 71% |
| escalations | 20% | 12pt | 9% |
| aging | 15% | 9pt | 4% |

- **OAT swing**: health points moved when that factor goes best→worst with the
  others typical.
- **Variance share**: fraction of total score variance the factor explains under
  realistic input distributions (Monte-Carlo, 20,000 samples).

## The finding

**The score is backlog-dominated, not SLA-dominated as the labels imply.**
SLA carries the largest nominal weight (40%) but explains only ~17% of the
variance, while backlog flow — labelled 25% — drives ~71%. The cause is
the hand-picked multipliers: net backlog is scaled ×8 over a wide realistic range
(net flow −5..+15), so it swings the composite far more than SLA (which moves over
a 60–100 band). Escalations and aging contribute far less than their headline
percentages.

In short: a viewer reading "SLA compliance — 40%" would reasonably assume SLA is
the main driver. It isn't. The displayed weights are **not** self-explanatory.

## What was changed
- The math was extracted to `services/health.py` (pure, tested) and the view now
  calls it — no behavior change.
- The dashboard health card now shows each factor's **actual point contribution**
  (weight × sub-score) rather than only a nominal %, so the breakdown is honest
  for a given project.

## What was deliberately NOT changed
We did **not** re-tune the weights/multipliers to force influence to match the
nominal weights. Doing so would only be "better" if the nominal weights were
themselves validated — and they are not. Making the weights meaningful requires
calibrating against labelled "was-at-risk" outcomes. Until then, the score should
be presented as a **transparent, tunable heuristic**, and the grade boundaries
(A/B/C/D/F) should not be treated as calibrated risk thresholds.

## Caveat on this evidence
The input distributions are plausible but assumed. Re-run with distributions
drawn from your real portfolio to get numbers specific to your data.
