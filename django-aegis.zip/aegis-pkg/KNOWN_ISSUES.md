# KNOWN_ISSUES.md

Status of the `django-aegis` codebase as of this writing. **No part of this code
has been executed.** Every prior "validated" claim rests on `ast.parse()` (syntax)
plus symbol grep. That catches typos, not behavior. This register lists what
reasoning and source inspection found; severities assume the code has *not* yet
been run.

Legend: **S1** = breaks a core feature / data loss / won't boot · **S2** = wrong
behavior under real conditions · **S3** = quality / maintainability · **S4** = docs / polish.

---

## Verification gaps (the meta-issue)

- **No test has ever passed.** No `migrate` has ever applied. No live API call has
  been made. Treat all green claims as unproven until Phase 0 runs. **(S1 to trust, not code)**
- Hand-written migrations `0004`–`0006` were never checked against
  `makemigrations --check`. The invented index name (`aegis_ticke_ticket__idx`)
  and the `BigAutoField` PK on `UserAIConfig` are guesses. **(S2)**

---

## S1 — Breaks a core feature

### 1. Cross-project member pull contradicts the ingest gate  *(the flagship bug)*  — **FIXED (pending test run)**
`connectors/*.fetch()` deliberately pulls a `pull_all_projects` member's tickets
from **any** project, including unconfigured ones (planner level 3). Those tickets
then pass through `connectors/base.ingest()`, whose gate **skips any ticket whose
project is not enabled**. Result: the connector fetches exactly the tickets the
gate discards. The headline feature ("pull their tasks from projects not in my
list") is self-defeating.
**Fixed:** `services/sync_gate.tracked_member_accounts()` + a member-override in
`connectors/base.ingest()`: a ticket is admitted when its assignee matches an
enabled `TeamMember(pull_all_projects=True)` for the same source, regardless of
project config. The integration test xfail was removed and now asserts the fixed
behavior; `test_pull_scope.py` adds source-scoping and pull_all_projects=False
guards. **Confirm with `make test`.**

---

## S2 — Wrong behavior under real conditions

### 2. ServiceNow encoded-query grouping is likely wrong  — **FIXED (pending test run)**
`servicenow._build_scoped_query` joins OR-groups with `^NQ` then appends one
trailing `sys_updated_on>=…`. In ServiceNow, `^NQ` starts a **new** query, so
`A^NQB^time` parses as `A OR (B AND time)` — the time bound constrains only the
last group; the others pull unbounded history. **Fixed:** the time clause is now
AND-ed into every OR-group: `(A AND time)^NQ(B AND time)^NQ(C AND time)`. Test
`test_servicenow_time_clause_on_every_group` asserts the time field appears once
per group.

### 3. Jira API may be deprecated
Uses `startAt`/`maxResults` offset pagination on `/rest/api/3/search`. Atlassian
has been retiring that for token-paginated `/rest/api/3/search/jql`. **Action:**
verify against current Jira Cloud; migrate pagination if removed.

### 4. Jira assignee identity mismatch  — **FIXED (pending test run)**
`jira._to_raw` extracts only `assignee.emailAddress`. Jira Cloud frequently nulls
email under GDPR and exposes `accountId` instead. `TeamMember.account` claims
"email or accountId," but matching is email-only. Configure a member by accountId
→ zero matches. **Fix:** capture both `accountId` and `emailAddress`; match on
either; normalize. **Fixed:** `JiraConnector._assignee_identity()` prefers email,
falls back to accountId, then displayName. Test asserts the fallback.

### 5. Naive datetimes from ServiceNow  — **FIXED (pending test run)**
`servicenow._to_raw` parses timestamps without tzinfo. With `USE_TZ=True` (Django
default) this warns or errors on save/filter. **Fixed:** `ServiceNowConnector._aware()`
makes timestamps UTC-aware using stdlib UTC (Django-5-safe).

### 6. Synchronous multi-connector pull in a web request  — **FIXED (opt-in; pending test run)**
`views.sync_run` runs the full paginated pull inline. Against real Jira/ServiceNow
volume this blocks the worker and times out. **Fix:** enqueue via Celery (the
`USE_CELERY` flag and `tasks.py` exist but the sync path doesn't use them).
**Fixed:** added `tasks.pull_all_connectors`; `views.sync_run` enqueues it when
`USE_CELERY=True` (returns a 'queued' panel) and runs inline otherwise. The
synchronous default remains the tested path; Celery is the opt-in scaling path.

### 7. Query interpolation is unescaped  — **PARTIALLY FIXED (Jira; pending test run)**
JQL and ServiceNow queries are built with raw f-strings around project keys and
member accounts. An embedded quote breaks the query or injects. **Fixed (Jira):**
`JiraConnector._jql_str()` backslash-escapes `\` and `"`; test asserts escaping.
**Still TODO:** ServiceNow encoded-query values (commas/`^`/`=` in group names or
emails) are not yet escaped — lower risk since emails/group names rarely contain
them, but should be validated.

### 8. Manual pull is never incremental  — **FIXED (pending test run)**
`run_all_pulls` always calls `fetch(cursor=None)` → full re-pull every run. The
`SyncCursor` model exists but is unused. **Fixed:** `run_all_pulls(incremental=True)`
(default) restores each connector's saved `SyncCursor`, passes it to `fetch()`, and
advances it to the run-start time on a clean pull. `incremental=False` or an explicit
`cursor=` forces a full re-pull. Tests cover save/reuse and forced full re-pull.

---

## S3 — Quality / maintainability

### 9. Dashboard aggregates in Python, not the DB
`views.dashboard` does `list(Ticket.objects.select_related(...).all())` and computes
every metric in Python — a memory/CPU cliff at scale. **(S3, S2 at volume)**

### 10. ~~No index on `Ticket.assignee`~~  **— CORRECTED, NOT AN ISSUE**
**This earlier claim was WRONG.** Source check:
`assignee = models.CharField(max_length=128, blank=True, db_index=True)` — it is
**already indexed**. Second false defect from reasoning without checking. (Other
hot columns may still warrant review, but the specific claim was incorrect.)

### 11. Blanket exception swallowing
`_maybe_run_ai`, CSV import, and agent paths use `except Exception: log.exception`
then continue. Real failures vanish. **Fix:** narrow the catch; surface to the user.

### 12. ~~Undeclared optional dependency: `celery`~~  **— CORRECTED, NOT AN ISSUE**
**This earlier claim was WRONG.** Verified by reading the full `pyproject.toml`
and running `scripts/audit_deps.py`: `celery` *is* declared under
`[project.optional-dependencies] celery = ["celery>=5.3", "redis>=5.0"]`, and the
`dev` extra declares `pytest`, `pytest-django`, `pytest-cov`, `factory-boy`,
`respx`. `cryptography` is intentionally lazy-imported. `audit_deps.py` reports
**no undeclared module-top imports**. Recorded here as a lesson: the original
"undeclared celery" critique came from a truncated `sed` of the file, not the file
itself — reasoning over partial evidence produced a false defect.

### 13. Gating lives in the transport layer
`ingest()` + project gating sit in `connectors/base.py`. Gating is policy. **Fix:**
move to `services/` so connectors only transport.

### 14. Eager connector imports  — **FIXED (pending test run)**
`connectors/__init__.py` imports every connector (incl. ServiceNow, which imports
`httpx`/`tenacity`) at package load. A missing optional dep would break the whole
registry, not one connector. **Fix:** register lazily / guard imports.

---

## S2/Reviewer — Security

### 15. Secret "encryption" has a plaintext-equivalent fallback  — **FIXED (pending test run)**
`crypto.py` uses Fernet when `cryptography` is present, else falls back to
`django.core.signing` — which is **signed base64, not encryption** (readable by
anyone with the blob). Storing API keys this way fails review. **Fix:** require
`cryptography` for the key-storage feature; remove the signing fallback for secrets.
**Fixed:** `cryptography>=42` is now a declared core dependency (plus a `[secrets]`
extra). `crypto._backend()` raises `ImproperlyConfigured` if cryptography is absent,
UNLESS `AEGIS['ALLOW_INSECURE_SECRET_FALLBACK']=True` is explicitly set for dev — in
which case it logs an ERROR. No more silent insecure storage.

### 16. No key-rotation story
Both paths derive from `SECRET_KEY`. Rotating it orphans every stored secret with
no migration path. **Fix:** versioned key + re-encrypt management command.

---

## Research-grade claims that overstate evidence

### 17. PII "privacy boundary" is unmeasured regex  — **MEASURED + improved (run `make eval-redaction`)**
17-category regex. Regex has high false-negative rates and structurally cannot
catch names, freeform/non-US addresses, etc. Presented as a privacy boundary with
no recall/precision. **Done:** `scripts/eval_redaction.py` measures it on a
labeled set (reproducible, wired into CI). **Measured: 100% recall on designed
categories, 0% false positives** on benign technical text; overall recall 80%
(the 20% gap is names/addresses/passport/plate, which regex structurally cannot
catch). The harness also FOUND and FIXED two real bugs — a hex-code false
positive and a bare-digit-phone regression — both verified by re-measurement.
See `REDACTION_EVAL.md`. Honest relabel: this is **structured-secret scrubbing**,
not a complete PII boundary; add NER for person PII. Pinned by regression tests
in `test_redaction.py`.

### 18. "Forecast" is linear run-rate, not a model  — **MEASURED + relabelled (run `make eval-forecast`)**
No model, confidence interval, or backtest. **Done:** extracted to
`services/forecasting.py` (pure, testable); `scripts/eval_forecast.py` backtests it
on known processes. **Measured:** ~14% error and beats naive-1 on stationary data
(its happy path); systematic bias on trends (~2.5/wk lag); **worse than naive-1 on
seasonal (45% error)**; backlog weeks-to-clear off ~1 week with no interval. UI card
relabelled "Run-rate outlook — indicative, not a forecast." See `FORECAST_EVAL.md`.
Pinned by `test_forecasting.py` (incl. an explicit trend-lag test).

### 19. Health-score weights are arbitrary  — **MEASURED: weights are misleading (run `make eval-health`)**
SLA 40% / backlog 25% / escalations 20% / aging 15% with no validation that the
composite correlates with anything. **Measured (stronger than 'arbitrary'):**
extracted to `services/health.py`; `scripts/eval_health.py` shows the displayed
weights don't reflect influence — **SLA is labelled 40% but drives ~17% of score
variance; backlog is labelled 25% but drives ~71%** (the ×8 backlog multiplier
dominates). The score is backlog-flow in disguise. UI now shows each factor's
actual point contribution; deliberately did NOT re-tune weights (that needs
labelled 'was-at-risk' data to be meaningful). Grade boundaries should not be
treated as calibrated. See `HEALTH_EVAL.md`; pinned by `test_health.py`.

### 20. Agent tests assert the mock
Tests confirm the mock returns what the mock is coded to return. No eval of triage
accuracy, hallucination rate, or resolution quality on labeled data. **Fix:** small
labeled eval harness.

---

## S4 — Docs / polish

- Deck (`aegis-demo.pptx`) and contact sheet depict an **earlier** feature set;
  no screenshots of Sync, Teams, AI Settings, or member KPIs.
- No CI config; no coverage report.
- README/QUICKSTART should carry the "not yet executed" caveat until Phase 0 passes.

---

## Burn-down order

1. Phase 0 (run it) → reclassifies everything below from "suspected" to "confirmed/closed".
2. S1 #1, then S2 #2–#8.
3. S3 #9–#14, Security #15–#16.
4. Research #17–#20, Docs.
