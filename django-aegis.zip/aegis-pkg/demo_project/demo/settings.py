"""
Minimal demo project settings.

Run:
    cd demo_project
    python manage.py migrate
    python manage.py aegis_demo --analyze
    python manage.py runserver

Then open http://127.0.0.1:8000/
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-key-do-not-use-in-prod-aegis")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "rest_framework",
    "aegis",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "demo.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "demo.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

REST_FRAMEWORK = {
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.IsAuthenticated",
    ],
}

LOGIN_URL = "/accounts/login/"
LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/accounts/login/"

# ---- Aegis configuration ----
AEGIS = {
    # Set GEMINI_API_KEY env var to use real Gemini; otherwise mock mode.
    "GEMINI_API_KEY": os.environ.get("GEMINI_API_KEY", ""),
    "MOCK_GEMINI": not bool(os.environ.get("GEMINI_API_KEY")),
    "GEMINI_MODEL_PRO": "gemini-2.5-pro",
    "GEMINI_MODEL_FLASH": "gemini-2.5-flash",
    "USE_CELERY": False,  # synchronous for demo
    "DEFAULT_SLA_HOURS": 24,
    "TICKET_LIST_PAGE_SIZE": 50,
    "CONNECTORS": {
        "jira": {
            "base_url": os.environ.get("JIRA_BASE_URL", ""),
            "email":    os.environ.get("JIRA_EMAIL", ""),
            "api_token": os.environ.get("JIRA_API_TOKEN", ""),
            "jql":       os.environ.get("JIRA_JQL", "updated >= -7d"),
        },
    },
}

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {"format": "%(asctime)s %(levelname)s %(name)s: %(message)s"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "simple"},
    },
    "loggers": {
        # All Assist loggers -> console. DEBUG surfaces the detailed pull/ingest
        # stage logs (config, health-check reason, JQL, per-page counts, gate
        # decisions). Override with ASSIST_LOG_LEVEL=INFO to quiet it down.
        "assist": {
            "handlers": ["console"],
            "level": os.environ.get("ASSIST_LOG_LEVEL", "DEBUG"),
            "propagate": False,
        },
    },
}

# Escalation emails: print to console in the demo. Point this at your SMTP
# relay (django.core.mail.backends.smtp.EmailBackend + EMAIL_HOST...) for real
# delivery.
EMAIL_BACKEND = os.environ.get("DJANGO_EMAIL_BACKEND",
                               "django.core.mail.backends.console.EmailBackend")
DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "assist@localhost")
