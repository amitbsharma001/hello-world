#!/usr/bin/env python3
"""
Dependency audit — flags third-party modules imported by the package that are not
declared in pyproject.toml. Pure stdlib; does not require Django or the deps.

Run: python scripts/audit_deps.py
Exit code 1 if any undeclared (non-test, module-top) import is found.
"""
from __future__ import annotations
import ast
import pathlib
import sys
import tomllib  # py3.11+

ROOT = pathlib.Path(__file__).resolve().parents[1]
PKG = ROOT / "aegis"

# Authoritative stdlib list (py3.10+). Fall back to a hand list on older pythons.
try:
    STDLIB = set(sys.stdlib_module_names)  # type: ignore[attr-defined]
except AttributeError:  # < py3.10
    STDLIB = {
        "__future__", "abc", "argparse", "base64", "collections", "contextlib",
        "csv", "dataclasses", "datetime", "decimal", "enum", "functools", "hashlib",
        "importlib", "io", "itertools", "json", "logging", "math", "os", "pathlib",
        "random", "re", "secrets", "statistics", "string", "sys", "time", "typing",
        "uuid", "warnings", "urllib", "tomllib", "textwrap",
    }
# import-name -> distribution name (when they differ)
DIST_ALIASES = {
    "rest_framework": "djangorestframework",
    "django_filter": "django-filter",
    "dateutil": "python-dateutil",
    "jinja2": "Jinja2",
    "yaml": "PyYAML",
    "google": "google-genai",
}
# Known optional/extra deps that are allowed to be lazily imported (not in core).
OPTIONAL_OK = {"celery", "cryptography", "google", "requests"}


def declared_dists() -> set[str]:
    data = tomllib.loads((ROOT / "pyproject.toml").read_text())
    proj = data.get("project", {})
    dists = set()
    for spec in proj.get("dependencies", []):
        dists.add(_name(spec))
    for group in proj.get("optional-dependencies", {}).values():
        for spec in group:
            dists.add(_name(spec))
    return {d.lower() for d in dists}


def _name(spec: str) -> str:
    for sep in ("==", ">=", "<=", "~=", ">", "<", "[", ";", " "):
        spec = spec.split(sep)[0]
    return spec.strip()


def top_imports(path: pathlib.Path) -> set[str]:
    """Module-top imports only (depth-0 in the AST body)."""
    tree = ast.parse(path.read_text())
    names = set()
    for node in tree.body:  # only top level
        if isinstance(node, ast.Import):
            for n in node.names:
                names.add(n.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.level == 0 and node.module:
                names.add(node.module.split(".")[0])
    return names


def main() -> int:
    declared = declared_dists()
    declared |= {a.lower() for a in DIST_ALIASES.values()}

    findings = []
    for py in PKG.rglob("*.py"):
        if "/tests/" in str(py) or py.name.startswith("test_"):
            continue
        for mod in top_imports(py):
            if mod in STDLIB or mod == "aegis":
                continue
            dist = DIST_ALIASES.get(mod, mod).lower()
            if dist in declared:
                continue
            findings.append((mod, dist, py.relative_to(ROOT)))

    if not findings:
        print("audit_deps: OK — all module-top imports are declared.")
        return 0

    print("audit_deps: UNDECLARED module-top imports found:\n")
    rc = 0
    for mod, dist, rel in sorted(findings):
        optional = mod in OPTIONAL_OK
        tag = "OPTIONAL (should be in [optional-dependencies])" if optional else "MISSING (core dep)"
        print(f"  - {mod:14s} -> dist '{dist}'  [{tag}]  in {rel}")
        if not optional:
            rc = 1
    print()
    if rc:
        print("FAIL: add the MISSING dependencies to pyproject.toml.")
    else:
        print("WARN: optional imports are not declared as extras; not fatal.")
    return rc


if __name__ == "__main__":
    sys.exit(main())
