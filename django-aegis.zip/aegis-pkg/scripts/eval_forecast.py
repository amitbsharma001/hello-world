#!/usr/bin/env python3
"""
Forecast backtest — REAL measurement of the run-rate "forecast" (KNOWN_ISSUES #18).

The dashboard's outlook predicts "next week ~= trailing 4-week average" and
projects backlog clearance linearly. This harness generates synthetic weekly
series with KNOWN generating processes, walk-forward predicts each next week, and
reports error — so we can state honestly where the run-rate holds and where it
breaks.

Baseline comparison: we also score "naive-1" (predict next = last observed) so a
reader can see whether the 4-week window actually helps.

Run: python scripts/eval_forecast.py            (report)
     python scripts/eval_forecast.py --json
Pure-stdlib; imports services/forecasting.py standalone (no Django).
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import math
import os
import random
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FC_PATH = os.path.join(HERE, "..", "aegis", "services", "forecasting.py")
random.seed(1234)  # reproducible


def _load_fc():
    spec = importlib.util.spec_from_file_location("forecasting", FC_PATH)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["forecasting"] = mod
    spec.loader.exec_module(mod)
    return mod


# --- synthetic weekly series (n weeks of a single metric, e.g. "created") ---

def gen_stationary(n=40, level=20, noise=3):
    return [max(0, round(level + random.gauss(0, noise))) for _ in range(n)]

def gen_trend_up(n=40, start=10, slope=1.0, noise=3):
    return [max(0, round(start + slope * i + random.gauss(0, noise))) for i in range(n)]

def gen_trend_down(n=40, start=40, slope=-0.8, noise=3):
    return [max(0, round(start + slope * i + random.gauss(0, noise))) for i in range(n)]

def gen_seasonal(n=40, level=20, amp=10, period=8, noise=2):
    return [max(0, round(level + amp * math.sin(2 * math.pi * i / period) + random.gauss(0, noise)))
            for i in range(n)]

def gen_stepchange(n=40, low=12, high=28, switch=20, noise=2):
    return [max(0, round((low if i < switch else high) + random.gauss(0, noise))) for i in range(n)]


PROCESSES = {
    "stationary": gen_stationary,
    "trend_up": gen_trend_up,
    "trend_down": gen_trend_down,
    "seasonal": gen_seasonal,
    "step_change": gen_stepchange,
}


def walk_forward(series, predict_fn, window):
    """Predict each week t+1 from history up to t; collect (pred, actual)."""
    errs, preds, actuals = [], [], []
    for t in range(window, len(series)):
        hist = series[:t]
        pred = predict_fn(hist, window)
        actual = series[t]
        errs.append(abs(pred - actual))
        preds.append(pred)
        actuals.append(actual)
    return errs, preds, actuals


def bias(preds, actuals):
    """Mean signed error (pred - actual). Nonzero => systematic over/under-shoot."""
    return statistics.mean(p - a for p, a in zip(preds, actuals)) if preds else 0.0


def run(mod, trials=200):
    window = 4
    runrate = lambda hist, w: mod.predict_next(hist, window=w)   # 4-week mean
    naive1 = lambda hist, w: hist[-1] if hist else 0.0            # last value

    out = {}
    for name, gen in PROCESSES.items():
        rr_mae, n1_mae, rr_bias = [], [], []
        for _ in range(trials):
            s = gen()
            e_rr, p_rr, a = walk_forward(s, runrate, window)
            e_n1, _, _ = walk_forward(s, naive1, window)
            if e_rr:
                rr_mae.append(statistics.mean(e_rr))
                n1_mae.append(statistics.mean(e_n1))
                rr_bias.append(bias(p_rr, a))
        # mean level for normalizing MAE into a % error
        level = statistics.mean(statistics.mean(gen()) for _ in range(20)) or 1
        out[name] = {
            "runrate_mae": round(statistics.mean(rr_mae), 2),
            "naive1_mae": round(statistics.mean(n1_mae), 2),
            "runrate_mae_pct_of_level": round(statistics.mean(rr_mae) / level * 100, 1),
            "runrate_bias": round(statistics.mean(rr_bias), 2),
            "beats_naive1": statistics.mean(rr_mae) < statistics.mean(n1_mae),
            "level": round(level, 1),
        }

    # Backlog-clearance accuracy: a genuinely declining backlog, does the linear
    # "weeks to clear" match reality? Build backlog from created/resolved.
    clear_err = []
    for _ in range(trials):
        created = gen_stationary(24, level=15, noise=2)
        resolved = gen_trend_up(24, start=15, slope=0.6, noise=2)  # resolution improving
        backlog = [50]
        for c, r in zip(created, resolved):
            backlog.append(max(0, backlog[-1] + c - r))
        # predict at week 12 using history so far
        t = 12
        proj = mod.project_backlog(created[:t], resolved[:t], backlog[t], window=4)
        if proj["backlog"]["state"] == "clearing":
            predicted_weeks = proj["backlog"]["weeks"]
            # actual weeks until backlog hits ~0 after t
            actual_weeks = None
            for k in range(t, len(backlog)):
                if backlog[k] <= 0:
                    actual_weeks = k - t
                    break
            if actual_weeks is not None:
                clear_err.append(abs(predicted_weeks - actual_weeks))
    clearance = {
        "cases": len(clear_err),
        "mae_weeks": round(statistics.mean(clear_err), 2) if clear_err else None,
    }

    return {"per_process": out, "backlog_clearance": clearance, "window": window, "trials": trials}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--trials", type=int, default=200)
    args = ap.parse_args()

    mod = _load_fc()
    res = run(mod, trials=args.trials)

    if args.json:
        print(json.dumps(res, indent=2))
        return 0

    print("=" * 68)
    print("FORECAST BACKTEST — run-rate (trailing 4-wk mean) vs naive-1")
    print(f"{res['trials']} trials per process, walk-forward one-step-ahead")
    print("=" * 68)
    print(f"{'process':14s} {'MAE':>7s} {'%level':>7s} {'bias':>7s} {'naive1':>7s} {'helps?':>7s}")
    for name, m in res["per_process"].items():
        helps = "yes" if m["beats_naive1"] else "no"
        print(f"{name:14s} {m['runrate_mae']:7.2f} {m['runrate_mae_pct_of_level']:6.1f}% "
              f"{m['runrate_bias']:7.2f} {m['naive1_mae']:7.2f} {helps:>7s}")
    c = res["backlog_clearance"]
    print()
    print(f"Backlog 'weeks-to-clear' error: MAE {c['mae_weeks']} weeks over {c['cases']} declining cases")
    print()
    print("HONEST READ:")
    print("- Stationary/noisy series: run-rate is near the noise floor and beats")
    print("  naive-1 (the 4-week smoothing helps). This is its happy path.")
    print("- Trends & step-changes: run-rate LAGS — note the nonzero bias (it")
    print("  systematically under/over-shoots because it has no trend term).")
    print("- Seasonal: it misses turning points; error tracks the amplitude.")
    print("- Backlog 'weeks-to-clear' is a point estimate with material error and")
    print("  NO confidence interval.")
    print("=> Label it a 'run-rate indicator', not a forecast. For real prediction")
    print("   use a model with a trend/seasonal term (e.g. Holt/Holt-Winters) and")
    print("   report an interval.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
