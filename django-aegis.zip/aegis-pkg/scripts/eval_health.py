#!/usr/bin/env python3
"""
Health-score sensitivity analysis (KNOWN_ISSUES #19).

We cannot validate the score against ground truth ("was this project really in
trouble") because there are no labels. But we CAN measure something concrete and
usually-overlooked: does each factor's NOMINAL weight (SLA 40%, backlog 25%,
escalations 20%, aging 15%) match its EFFECTIVE influence on the score, once you
account for (a) the different realistic ranges of the four inputs and (b) the
hand-picked ×8 / ×6 multipliers?

Two analyses, both runnable (pure stdlib, imports services/health.py):

1. One-at-a-time (OAT) swing: move each input across its realistic range with the
   others held at a typical value; report how many health points that swings.
   A factor with a big nominal weight but a small swing is not actually driving
   the score.

2. Variance share: Monte-Carlo over realistic input distributions; attribute
   output variance to each of the four SUB-scores via squared-correlation
   (a first-order sensitivity proxy). Compare each factor's variance share to its
   nominal weight.

Run: python scripts/eval_health.py [--json]
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
import random
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
H_PATH = os.path.join(HERE, "..", "aegis", "services", "health.py")
random.seed(7)


def _load():
    spec = importlib.util.spec_from_file_location("health", H_PATH)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["health"] = mod
    spec.loader.exec_module(mod)
    return mod


# Realistic input ranges/distributions (what a real portfolio looks like):
#   sla_pct  : 60-100 %, skewed high
#   net_flow : -5..+15 tickets/period (often small)
#   escalations: 0..10 (usually low)
#   pct_stale: 0..60 %
def _sample_inputs():
    sla = min(100, max(40, random.gauss(88, 10)))
    net = random.triangular(-5, 15, 2)
    esc = max(0, round(random.triangular(0, 10, 2)))
    stale = min(80, max(0, random.gauss(18, 12)))
    return sla, net, esc, stale


TYPICAL = (88, 2, 2, 18)   # a "held at typical" baseline for OAT
RANGES = {                 # realistic min/max per raw input for the OAT sweep
    "sla": (60, 100),
    "backlog": (-5, 15),      # net_flow
    "escalations": (0, 10),
    "aging": (0, 60),         # pct_stale
}
NOMINAL = {"sla": 0.40, "backlog": 0.25, "escalations": 0.20, "aging": 0.15}


def oat_swing(mod) -> dict:
    """Health-point swing when each input moves lo->hi, others at TYPICAL."""
    base_sla, base_net, base_esc, base_stale = TYPICAL
    out = {}
    for factor, (lo, hi) in RANGES.items():
        args_lo = dict(sla_pct=base_sla, net_flow=base_net, escalations=base_esc, pct_stale=base_stale)
        args_hi = dict(args_lo)
        key = {"sla": "sla_pct", "backlog": "net_flow", "escalations": "escalations", "aging": "pct_stale"}[factor]
        # "best" end vs "worst" end for that factor
        best, worst = (hi, lo) if factor == "sla" else (lo, hi)
        args_lo[key] = best
        args_hi[key] = worst
        h_best = mod.compute_health(**args_lo)["health"]
        h_worst = mod.compute_health(**args_hi)["health"]
        out[factor] = abs(h_best - h_worst)
    return out


def variance_share(mod, n=20000) -> dict:
    """Share of health variance attributable to each sub-score (squared corr)."""
    hs, subs = [], {"sla": [], "backlog": [], "escalations": [], "aging": []}
    for _ in range(n):
        sla, net, esc, stale = _sample_inputs()
        r = mod.compute_health(sla, net, esc, stale)
        hs.append(r["health"])
        for k in subs:
            subs[k].append(r["subscores"][k])

    def corr(a, b):
        ma, mb = statistics.mean(a), statistics.mean(b)
        va = sum((x - ma) ** 2 for x in a)
        vb = sum((x - mb) ** 2 for x in b)
        if va == 0 or vb == 0:
            return 0.0
        cov = sum((x - ma) * (y - mb) for x, y in zip(a, b))
        return cov / (va ** 0.5 * vb ** 0.5)

    r2 = {k: corr(subs[k], hs) ** 2 for k in subs}
    total = sum(r2.values()) or 1
    return {k: r2[k] / total for k in r2}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    mod = _load()

    swing = oat_swing(mod)
    share = variance_share(mod)
    result = {
        "nominal_weight": NOMINAL,
        "oat_swing_points": {k: round(v, 1) for k, v in swing.items()},
        "variance_share": {k: round(v, 3) for k, v in share.items()},
    }
    if args.json:
        print(json.dumps(result, indent=2))
        return 0

    print("=" * 72)
    print("HEALTH SCORE — nominal weight vs EFFECTIVE influence")
    print("=" * 72)
    print(f"{'factor':13s} {'nominal':>8s} {'OAT swing':>11s} {'var share':>10s}  verdict")
    for f in ["sla", "backlog", "escalations", "aging"]:
        nom = NOMINAL[f]
        vs = share[f]
        delta = vs - nom
        verdict = "≈ as weighted" if abs(delta) < 0.07 else (
            "OVER-influential" if delta > 0 else "UNDER-influential")
        print(f"{f:13s} {nom:7.0%} {swing[f]:9.1f}pt {vs:9.1%}   {verdict}")
    print()
    print("READ (measured, reproducible):")
    print("- 'OAT swing' = health points moved when that factor goes best->worst,")
    print("  others typical. 'Var share' = fraction of score variance it explains")
    print("  under realistic inputs.")
    print("- Where var-share diverges from the nominal weight, the label misleads:")
    print("  the ×8/×6 multipliers and the inputs' real ranges — not the weights —")
    print("  decide influence. In particular a small-range factor (e.g. escalations")
    print("  rarely large) contributes less than its headline % suggests.")
    print("- This does NOT tell you the score is right or wrong (no ground truth).")
    print("  It shows the weights are not self-explanatory. Publish the score as a")
    print("  transparent heuristic and, ideally, calibrate against labelled")
    print("  'was-at-risk' outcomes before trusting the grade boundaries.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
