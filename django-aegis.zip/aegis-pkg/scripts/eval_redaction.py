#!/usr/bin/env python3
"""
PII redaction evaluation — REAL measurement, not assertion.

Addresses KNOWN_ISSUES #17: the redaction layer was presented as a "privacy
boundary" with no measured recall/precision. This harness runs the actual
`services/redaction.sanitize()` over a labeled set and reports per-category and
overall recall, plus a false-positive rate on benign text.

It is deliberately honest: the labeled set includes HARD cases that regex is
expected to MISS (names, freeform addresses, non-US phone formats, IBANs, SSNs,
etc.) so the measured recall reflects the real boundary, not a flattering subset.

Run: python scripts/eval_redaction.py            (human-readable report)
     python scripts/eval_redaction.py --json      (machine-readable)
This script imports redaction.py standalone (it is pure-stdlib, no Django).
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RED_PATH = os.path.join(HERE, "..", "aegis", "services", "redaction.py")


def _load_redaction():
    spec = importlib.util.spec_from_file_location("redaction", RED_PATH)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["redaction"] = mod  # required so @dataclass can resolve __module__
    spec.loader.exec_module(mod)
    return mod


# ---------------------------------------------------------------------------
# Labeled set. Each positive case: (text, [spans that MUST be redacted]).
# "expected_catchable" marks whether the current regex design *could* catch it;
# we still score recall over ALL positives so the headline number is honest.
# ---------------------------------------------------------------------------

POSITIVES = [
    # --- cases the regex design SHOULD catch ---
    ("Contact john.doe@acme.com for access", ["john.doe@acme.com"], True, "EMAIL"),
    ("Reach me at jane_smith+tag@sub.example.co.uk", ["jane_smith+tag@sub.example.co.uk"], True, "EMAIL"),
    ("Call 415-555-0132 after noon", ["415-555-0132"], True, "PHONE_US"),
    ("Phone: (212) 555-7788", ["(212) 555-7788"], True, "PHONE_US"),
    ("Hotline 18005551234 is toll-free", ["18005551234"], True, "PHONE_BARE"),
    ("AWS key AKIAIOSFODNN7EXAMPLE leaked", ["AKIAIOSFODNN7EXAMPLE"], True, "AWS_KEY"),
    ("token ghp_16C7e42F292c6912E7710c838347Ae178B4a", ["ghp_16C7e42F292c6912E7710c838347Ae178B4a"], True, "GH_TOKEN"),
    ("card 4111 1111 1111 1111 declined", ["4111 1111 1111 1111"], True, "CARD"),
    ("server at 10.0.12.44 is down", ["10.0.12.44"], True, "IP"),
    ("see https://internal.corp.example.com/runbook", ["https://internal.corp.example.com/runbook"], True, "URL"),
    ("stripe sk_live_4eC39HqLyjWDarjtT1zdp7dc", ["sk_live_4eC39HqLyjWDarjtT1zdp7dc"], True, "STRIPE_KEY"),
    ("home dir /home/amit/.ssh/id_rsa", ["/home/amit/.ssh/id_rsa"], True, "UNIX_HOME_PATH"),
    ("path C:\\Users\\amit\\secret.txt", ["C:\\Users\\amit\\secret.txt"], True, "WIN_HOME_PATH"),
    ("request id 550e8400-e29b-41d4-a716-446655440000", ["550e8400-e29b-41d4-a716-446655440000"], True, "UUID"),
    ("jwt eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N", ["eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"], True, "JWT"),

    # --- HARD cases the regex design is EXPECTED TO MISS (the honest part) ---
    ("Please follow up with Amit Sharma about the invoice", ["Amit Sharma"], False, "PERSON_NAME"),
    ("The customer, Dr. Elena Vasquez, reported the bug", ["Elena Vasquez"], False, "PERSON_NAME"),
    ("Ship to 742 Evergreen Terrace, Springfield, IL 62704", ["742 Evergreen Terrace, Springfield, IL 62704"], False, "ADDRESS"),
    ("SSN on file is 123-45-6789", ["123-45-6789"], False, "SSN"),
    ("UK mobile +44 7700 900123 unreachable", ["+44 7700 900123"], False, "PHONE_INTL"),
    ("India number +91 98765 43210 bounced", ["+91 98765 43210"], False, "PHONE_INTL"),
    ("IBAN DE89 3704 0044 0532 0130 00 for refund", ["DE89 3704 0044 0532 0130 00"], False, "IBAN"),
    ("passport number X1234567 attached", ["X1234567"], False, "PASSPORT"),
    ("DOB 1987-03-14 per records", ["1987-03-14"], False, "DOB"),
    ("license plate 7XYZ123 seen on camera", ["7XYZ123"], False, "PLATE"),
]

# Negatives: benign text that must NOT trigger redaction (false-positive check).
NEGATIVES = [
    "The release is scheduled for version 4.2.1 next week",
    "We saw a 200 OK and then a 503 from the gateway",
    "Increase the pool size from 10 to 50 connections",
    "Ticket priority moved from P3 to P1 this morning",
    "The meeting is at 3:30 PM in room 204",
    "CPU spiked to 95% for about 12 minutes",
    "Refactor the parser to handle 1,024 byte chunks",
    "Error code 0x80004005 appeared in the logs",
    "Latency p99 was 1200 ms under load",
    "The commit SHA prefix was abc123 (short form)",
    "Unix epoch 1700000000 marks the cutover",
    "Order 90040055 shipped and request 80004005 failed",
]


def _redacted_spans(original: str, clean: str, rmap) -> list:
    """Return the original substrings that were replaced (from the rmap)."""
    return list(rmap.mapping.values())


def evaluate(mod) -> dict:
    sanitize = mod.sanitize

    # Recall over positives
    caught = 0
    caught_catchable = 0
    total_catchable = 0
    missed = []
    per_cat = {}  # category -> [caught, total]
    for text, spans, catchable, cat in POSITIVES:
        clean, rmap = sanitize(text)
        redacted_values = " | ".join(rmap.mapping.values())
        hit = all(any(s in v or v in s or s == v for v in rmap.mapping.values())
                  or s not in clean  # the span no longer appears verbatim
                  for s in spans)
        per_cat.setdefault(cat, [0, 0])
        per_cat[cat][1] += 1
        if catchable:
            total_catchable += 1
        if hit:
            caught += 1
            per_cat[cat][0] += 1
            if catchable:
                caught_catchable += 1
        else:
            missed.append({"text": text, "expected": spans, "category": cat,
                           "design_expects_catch": catchable})

    # False positives over negatives
    fp = 0
    fp_examples = []
    for text in NEGATIVES:
        clean, rmap = sanitize(text)
        if rmap.mapping:
            fp += 1
            fp_examples.append({"text": text, "flagged": rmap.counts_by_category})

    n_pos = len(POSITIVES)
    n_neg = len(NEGATIVES)
    return {
        "positives_total": n_pos,
        "positives_caught": caught,
        "recall_overall": round(caught / n_pos, 3),
        "recall_on_designed_categories": round(caught_catchable / total_catchable, 3) if total_catchable else None,
        "designed_categories_total": total_catchable,
        "negatives_total": n_neg,
        "false_positives": fp,
        "false_positive_rate": round(fp / n_neg, 3),
        "per_category": {k: {"caught": v[0], "total": v[1]} for k, v in sorted(per_cat.items())},
        "missed": missed,
        "false_positive_examples": fp_examples,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    mod = _load_redaction()
    res = evaluate(mod)

    if args.json:
        print(json.dumps(res, indent=2))
        return 0

    print("=" * 64)
    print("PII REDACTION — MEASURED PERFORMANCE")
    print("=" * 64)
    print(f"Positives: {res['positives_caught']}/{res['positives_total']} caught"
          f"  ->  overall recall {res['recall_overall']:.0%}")
    print(f"On the categories the regex is DESIGNED for: "
          f"{res['recall_on_designed_categories']:.0%} "
          f"({res['designed_categories_total']} cases)")
    print(f"False positives on benign text: {res['false_positives']}/{res['negatives_total']}"
          f"  ->  FP rate {res['false_positive_rate']:.0%}")
    print()
    print("Per-category recall:")
    for cat, v in res["per_category"].items():
        bar = "ok " if v["caught"] == v["total"] else "MISS"
        print(f"  [{bar}] {cat:14s} {v['caught']}/{v['total']}")
    print()
    if res["missed"]:
        print("MISSED (the honest boundary — what this layer does NOT catch):")
        for m in res["missed"]:
            tag = "regex-not-designed-for" if not m["design_expects_catch"] else "REGRESSION (designed but missed)"
            print(f"  - {m['category']:14s} [{tag}]  e.g. {m['expected']}")
    print()
    if res["false_positive_examples"]:
        print("FALSE POSITIVES:")
        for e in res["false_positive_examples"]:
            print(f"  - {e['flagged']}  in: {e['text'][:60]}")
    print()
    print("INTERPRETATION: recall on structured tokens (keys, emails, IPs) is the")
    print("layer's real strength. It structurally CANNOT catch names, freeform")
    print("addresses, or non-US/intl formats — so 'privacy boundary' overstates it.")
    print("Treat it as 'structured-secret scrubbing', and add NER for names if PII")
    print("of people is in scope.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
