#!/usr/bin/env python
"""
Smoke test — the cheapest possible "does it actually load" check. Unlike
ast.parse(), this imports the real modules under Django, so it catches:
  - import-time errors (missing deps, bad imports, circular imports)
  - URL config errors (every named route must reverse)
  - app/registry wiring (all connectors importable and registered)

Run AFTER `make migrate` (it needs settings + apps loaded), e.g. `make smoke`.
Exit 1 on any failure. This is intentionally not a pytest test so it can run
before/around the suite as a fast gate.
"""
from __future__ import annotations
import os
import sys

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "demo_project.demo.settings")
# Ensure both the package root and demo_project are importable.
sys.path[:0] = [os.path.dirname(os.path.abspath(__file__)) + "/..", "demo_project", "."]

failures: list[str] = []


def check(label, fn):
    try:
        fn()
        print(f"  ok   {label}")
    except Exception as e:  # noqa: BLE001 - smoke test reports everything
        print(f"  FAIL {label}: {type(e).__name__}: {e}")
        failures.append(label)


def _setup_django():
    import django
    django.setup()


def _import_app():
    import aegis  # noqa: F401
    import aegis.models  # noqa: F401
    import aegis.views  # noqa: F401
    import aegis.urls  # noqa: F401
    import aegis.admin  # noqa: F401


def _import_services():
    from aegis.services import sync_runner, pull_planner, crypto, comms  # noqa: F401
    from aegis.services import jira_client  # noqa: F401


def _import_connectors():
    from aegis.connectors import registry
    from aegis.connectors import jira, servicenow, csv_connector, manual  # noqa: F401
    names = registry.list()
    assert "jira" in names and "servicenow" in names, f"registry missing connectors: {names}"
    # pull-capable flags
    assert registry.get("jira").supports_pull is True
    assert registry.get("servicenow").supports_pull is True


def _reverse_all_urls():
    from django.urls import reverse, NoReverseMatch
    import uuid
    # Named routes and a sample of args for parameterized ones.
    fake = uuid.uuid4()
    routes = {
        "aegis:queue": [], "aegis:dashboard": [], "aegis:projects": [],
        "aegis:project_create": [], "aegis:teams": [], "aegis:team_create": [],
        "aegis:sync": [], "aegis:sync_run": [], "aegis:ai_settings": [],
        "aegis:csv_upload": [], "aegis:create": [],
        "aegis:detail": [fake], "aegis:action_push_description": [fake],
        "aegis:action_post_steps": [fake], "aegis:action_customer_email": [fake],
        "aegis:project_edit": [fake], "aegis:project_toggle": [fake],
        "aegis:team_edit": [fake], "aegis:team_toggle": [fake],
    }
    missing = []
    for name, args in routes.items():
        try:
            reverse(name, args=args)
        except NoReverseMatch as e:
            missing.append(f"{name} ({e})")
    assert not missing, "unreversible routes: " + "; ".join(missing)


def _models_importable():
    from aegis.models import (Project, TeamMember, Ticket, UserAIConfig,  # noqa: F401
                              TicketAction, AgentRun, AgentStep)


def main() -> int:
    check("django.setup()", _setup_django)
    if failures:
        print("\nFAIL: Django could not start — fix settings/deps first.")
        return 1
    check("import app (models/views/urls/admin)", _import_app)
    check("import services", _import_services)
    check("import + register connectors", _import_connectors)
    check("import models", _models_importable)
    check("reverse all named URLs", _reverse_all_urls)

    print()
    if failures:
        print(f"SMOKE FAILED: {len(failures)} check(s) failed.")
        return 1
    print("SMOKE PASSED.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
