# Demo quickstart (5 minutes)

## On a fresh machine

```bash
cd aegis-pkg
python -m venv .venv && source .venv/bin/activate
pip install -e .
cd demo_project
python manage.py migrate
python manage.py aegis_demo --count 10 --analyze
python manage.py runserver
```

Open **http://127.0.0.1:8000/**  → it redirects to `/accounts/login/`.

## Three demo accounts

| Username | Password | Role | What they see |
|---|---|---|---|
| `admin` | `admin` | staff | **All tickets** from all users + Owner column |
| `alice` | `demo`  | user  | **Only her tickets** (about 7 of 10) |
| `bob`   | `demo`  | user  | **Only his tickets** (about 3 of 10) |

## What to demo (3 minutes)

1. **Sign in as alice** — `/` shows ~7 tickets, pill says "your tickets".
2. **Open a Sev 1 ticket** — show side-by-side original vs AI-enhanced, action plan, missing info.
3. **Click ⚡ Re-run all AI** — live HTMX regeneration.
4. **Sign out** (sidebar) → **sign in as admin** — same `/` URL now shows all 10 tickets, pill says "admin · all tickets", new **Owner** column shows alice / bob.
5. **Sign in as bob** — only ~3 tickets visible. Bob can't see alice's URLs either: try going to a URL you saw as alice; you get 404.
6. **Cost transparency** — go to `/admin/aegis/aiartifact/` (as admin) — every Gemini call with tokens, latency, $ cost.

## How the access control works

Single helper in `aegis/perms.py`:

```python
def filter_for_user(qs, user):
    if not user.is_authenticated:    return qs.none()
    if user.is_staff:                return qs           # admins see all
    return qs.filter(owner=user)                          # users see own
```

Called in:
- `views.queue` — main list
- `views.detail` (via `can_view`) — 404 if not allowed
- All HTMX action endpoints — 404 if not allowed
- `TicketViewSet.get_queryset` — REST API enforces same rule
- CSV upload — owner = current user (unless admin)
- Ticket create — `owner = request.user`

Unowned tickets (e.g. auto-synced from Jira) are admin-only by default. Safe-by-default.

## Reset

```bash
rm demo_project/db.sqlite3
python demo_project/manage.py migrate
python demo_project/manage.py aegis_demo --count 10 --analyze
```
