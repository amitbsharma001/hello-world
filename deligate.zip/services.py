    @action(detail=True, methods=["post"])
    def delegate(self, request, pk=None):
        from django.contrib.auth import get_user_model
        from rest_framework.exceptions import NotFound

        serializer = _ActionInput(data=request.data)
        serializer.is_valid(raise_exception=True)
        to_id = serializer.validated_data.get("to_user")
        if not to_id:
            raise ValidationError("to_user is required.")
        to_user = get_user_model().objects.filter(pk=to_id).first()
        if not to_user:
            raise ValidationError("Target user not found.")

        task = ApprovalTask.objects.filter(pk=pk).first()
        if task is None:
            raise NotFound("Task not found.")
        try:
            ApprovalService.delegate(
                task_id=task.pk, actor=request.user, to_user=to_user,
                comment=serializer.validated_data["comment"],
            )
        except PermissionDenied as exc:
            raise DRFPermissionDenied(str(exc))
        except ApprovalError as exc:
            raise ValidationError(str(exc))
        return Response({"status": "delegated"})