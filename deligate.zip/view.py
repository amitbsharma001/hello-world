    @classmethod
    @transaction.atomic
    def delegate(cls, *, task_id, actor, to_user, comment=""):
        task = (
            ApprovalTask.objects.select_for_update()
            .select_related("request", "step", "request__initiated_by")
            .get(pk=task_id)
        )
        is_assignee = task.assignee_id == getattr(actor, "pk", None)
        if not is_assignee and not cls._can_override_delegate(actor, task.request):
            raise PermissionDenied(
                "Only the assignee, an admin, or the request owner may delegate this task."
            )
        if not task.step.allow_delegation:
            raise ApprovalError("Delegation disabled for this step.")
        if task.status != TaskStatus.PENDING:
            raise ApprovalError("Task already actioned.")

        original_assignee = task.assignee   # who this moves AWAY from (audit trail)
        task.status = TaskStatus.DELEGATED
        task.acted_at = timezone.now()
        task.save()
        new_task = ApprovalTask.objects.create(
            request=task.request, step=task.step, assignee=to_user,
            delegated_from=original_assignee,
        )
        who = ("the assignee" if is_assignee else
               "an admin" if getattr(actor, "is_staff", False) else "the request owner")
        cls._log(
            task.request, actor=actor, action=ApprovalAction.DELEGATE, task=task,
            comment=f"Reassigned to user {to_user.pk} by {who}. {comment}".strip(),
        )
        notify(to_user, "task_assigned", target=task.request)
        return new_task

    @staticmethod
    def _can_override_delegate(actor, request):
        if getattr(actor, "is_staff", False):
            return True
        if request.initiated_by_id and request.initiated_by_id == getattr(actor, "pk", None):
            return True
        from .models import ExternalApproval
        subject = request.subject
        if isinstance(subject, ExternalApproval) and subject.creator_email:
            actor_email = (getattr(actor, "email", "") or "").strip().lower()
            if actor_email and actor_email == subject.creator_email.strip().lower():
                return True
        return False