# ── one-time login (reuse across all calls below) ──────────────────────────
curl -c cookies.txt http://localhost:8000/api-auth/login/ > login.html
CSRF=$(grep -o "csrfmiddlewaretoken[^>]*value='[^']*'" login.html | grep -o "value='[^']*'" | tr -d "value='")
curl -b cookies.txt -c cookies.txt \
  -H "Referer: http://localhost:8000/api-auth/login/" \
  -d "username=YOUR_USERNAME&password=YOUR_PASSWORD&csrfmiddlewaretoken=$CSRF" \
  http://localhost:8000/api-auth/login/
CSRF=$(grep csrftoken cookies.txt | awk '{print $7}')

# ── find the task id + a substitute user id first ───────────────────────────
curl -b cookies.txt "http://localhost:8000/api/v1/approval-tasks/?all=1"
# -> look for "id" (the task) and, separately, the substitute's user id
#    (Django admin /admin/auth/user/ is the easiest place to find a user id)


As admin/staff — delegate anyone's task:

curl -X POST http://localhost:8000/api/v1/approval-tasks/7/delegate/ \
  -b cookies.txt -H "X-CSRFToken: $CSRF" -H "Content-Type: application/json" \
  -d '{"to_user": 42, "comment": "On leave, reassigning to Priya"}'
# -> 200 {"status": "delegated"}

As the request owner (logged in as whoever initiated it, not the assignee) — same call, same endpoint:

curl -X POST http://localhost:8000/api/v1/approval-tasks/7/delegate/ \
  -b cookies.txt -H "X-CSRFToken: $CSRF" -H "Content-Type: application/json" \
  -d '{"to_user": 42, "comment": "Owner reassigning while approver is away"}'
# -> 200 {"status": "delegated"}

As a random unrelated user — correctly rejected:

curl -X POST http://localhost:8000/api/v1/approval-tasks/7/delegate/ \
  -b cookies.txt -H "X-CSRFToken: $CSRF" -H "Content-Type: application/json" \
  -d '{"to_user": 42, "comment": "trying anyway"}'
# -> 403 {"detail": "Only the assignee, an admin, or the request owner may delegate this task."}