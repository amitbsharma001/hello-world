/* ============================================================
 * Flowforge Visual Builder
 *
 * Single-file vanilla JS app. The flow definition (a tree of
 * step objects) is the source of truth. Steps are addressed by
 * a `path` array: e.g. [2, "then", 0] means
 *   state.flow.definition.steps[2].then[0].
 *
 * On any structural change (add / remove / reorder), we
 * re-render the canvas. The inspector is rendered once when
 * selection changes; its inputs commit to state in-place
 * without forcing a canvas re-render unless the change is
 * structural (e.g. step id, condition expression, items).
 * ============================================================ */

(function () {
"use strict";

// ============================================================
// 1. Palette definitions
// ============================================================

const STEP_TYPES = {
  action:       { icon: "▶", label: "Action",        kind: "leaf" },
  condition:    { icon: "◇", label: "Condition",     kind: "branch" },  // then/else
  foreach:      { icon: "↻", label: "Foreach",       kind: "container" }, // steps
  parallel:     { icon: "║", label: "Parallel",      kind: "parallel" },  // branches[][]
  try:          { icon: "✦", label: "Try / catch",   kind: "trycatch" },  // steps/catch/finally
  compose:      { icon: "≡", label: "Compose",       kind: "leaf" },
  delay:        { icon: "⏱", label: "Delay",         kind: "leaf" },
  set_variable: { icon: "⊕", label: "Set variable",  kind: "leaf" },
  call_flow:    { icon: "↗", label: "Call flow",     kind: "leaf" },
  terminate:    { icon: "■", label: "Terminate",     kind: "leaf" },
};

// What each palette item creates when dropped onto the canvas
const PALETTE = [
  {
    group: "Connectors",
    items: [
      { id: "http",    label: "HTTP request",  sub: "http.request",     icon: "🌐", make: () => ({ id: newId("http"),    type: "action", connector: "http.request",     inputs: { method: "GET", url: "" } }) },
      { id: "slack",   label: "Slack webhook", sub: "slack.webhook",    icon: "💬", make: () => ({ id: newId("slack"),   type: "action", connector: "slack.webhook",    inputs: { url: "", text: "" } }) },
      { id: "email",   label: "Send email",    sub: "email.send",       icon: "✉",  make: () => ({ id: newId("email"),   type: "action", connector: "email.send",       inputs: { to: "", subject: "", body: "" } }) },
      { id: "python",  label: "Python code",   sub: "python.exec",      icon: "🐍", make: () => ({ id: newId("python"),  type: "action", connector: "python.exec",      inputs: { code: "result = inputs.get('x')" } }) },
      { id: "log",     label: "Log message",   sub: "log.info",         icon: "📝", make: () => ({ id: newId("log"),     type: "action", connector: "log.info",         inputs: { message: "" } }) },
    ],
  },
  {
    group: "Enterprise",
    items: [
      { id: "outlook",   label: "Outlook mail",     sub: "outlook.send_mail",      icon: "📧", make: () => ({ id: newId("outlook"),   type: "action", connector: "outlook.send_mail",      inputs: { connection: "", to: "", subject: "", body: "" } }) },
      { id: "teams_wh",  label: "Teams webhook",    sub: "teams.webhook",          icon: "💼", make: () => ({ id: newId("teams"),     type: "action", connector: "teams.webhook",          inputs: { url: "", text: "", title: "" } }) },
      { id: "teams_ch",  label: "Teams channel",    sub: "teams.send_channel_message", icon: "💼", make: () => ({ id: newId("teams_ch"),  type: "action", connector: "teams.send_channel_message", inputs: { connection: "", team_id: "", channel_id: "", content: "" } }) },
      { id: "sp_up",     label: "SharePoint upload",sub: "sharepoint.upload_file", icon: "📁", make: () => ({ id: newId("sp_up"),     type: "action", connector: "sharepoint.upload_file", inputs: { connection: "", path: "", content: "" } }) },
      { id: "sp_dl",     label: "SharePoint read",  sub: "sharepoint.download_file", icon: "📁", make: () => ({ id: newId("sp_dl"),     type: "action", connector: "sharepoint.download_file", inputs: { connection: "", path: "" } }) },
      { id: "db_q",      label: "DB query",         sub: "db.query",               icon: "🗄", make: () => ({ id: newId("db_q"),      type: "action", connector: "db.query",               inputs: { sql: "SELECT 1", params: [] } }) },
      { id: "db_x",      label: "DB execute",       sub: "db.execute",             icon: "🗄", make: () => ({ id: newId("db_x"),      type: "action", connector: "db.execute",             inputs: { sql: "", params: [] } }) },
      { id: "s3_up",     label: "S3 upload",        sub: "s3.upload",              icon: "☁",  make: () => ({ id: newId("s3_up"),     type: "action", connector: "s3.upload",              inputs: { connection: "", bucket: "", key: "", body: "" } }) },
      { id: "s3_dl",     label: "S3 download",      sub: "s3.download",            icon: "☁",  make: () => ({ id: newId("s3_dl"),     type: "action", connector: "s3.download",            inputs: { connection: "", bucket: "", key: "" } }) },
    ],
  },
  {
    group: "Logic",
    items: [
      { id: "condition",    label: "Condition",   sub: "if / else",      icon: "◇", make: () => ({ id: newId("if"),     type: "condition", condition: "{{ }}", then: [], else: [] }) },
      { id: "foreach",      label: "Foreach",     sub: "loop",           icon: "↻", make: () => ({ id: newId("loop"),   type: "foreach", items: "{{ }}", item_var: "item", steps: [] }) },
      { id: "parallel",     label: "Parallel",    sub: "fan-out",        icon: "║", make: () => ({ id: newId("par"),    type: "parallel", branches: [[], []] }) },
      { id: "try",          label: "Try / catch", sub: "error handling", icon: "✦", make: () => ({ id: newId("try"),    type: "try", steps: [], catch: [], finally: [] }) },
      { id: "terminate",    label: "Terminate",   sub: "stop flow",      icon: "■", make: () => ({ id: newId("end"),    type: "terminate", status: "succeeded", message: "" }) },
    ],
  },
  {
    group: "Data",
    items: [
      { id: "compose",      label: "Compose",     sub: "build value",    icon: "≡", make: () => ({ id: newId("compose"),  type: "compose", value: {} }) },
      { id: "set_variable", label: "Set variable",sub: "write to vars",  icon: "⊕", make: () => ({ id: newId("set"),      type: "set_variable", name: "", value: "" }) },
      { id: "delay",        label: "Delay",       sub: "sleep",          icon: "⏱", make: () => ({ id: newId("wait"),     type: "delay", seconds: 1 }) },
      { id: "call_flow",    label: "Call flow",   sub: "sub-flow",       icon: "↗", make: () => ({ id: newId("subflow"),  type: "call_flow", flow: "", input: {} }) },
      { id: "csv_parse",    label: "CSV parse",   sub: "csv.parse",      icon: "📊", make: () => ({ id: newId("csv_p"),    type: "action", connector: "csv.parse",    inputs: { text: "", header: true } }) },
      { id: "csv_str",      label: "CSV write",   sub: "csv.stringify",  icon: "📊", make: () => ({ id: newId("csv_s"),    type: "action", connector: "csv.stringify", inputs: { rows: [] } }) },
    ],
  },
];

// ============================================================
// 2. State
// ============================================================

const state = {
  flow: null,             // {id, name, definition, ...}
  selectedPath: null,     // e.g. [0] or [1, "then", 2]
  dragSource: null,       // {kind: "palette", make: fn} | {kind: "card", path: [...]}
  dirty: false,
  loadError: null,
};

// ============================================================
// 3. Path utilities — navigate the nested step tree
// ============================================================

/**
 * A path is an array that alternates [index, key, index, key, ...]
 *   - At top level the path is [index].
 *   - Inside a "condition" you can have [..., "then", index] or [..., "else", index].
 *   - Inside a "foreach" you have [..., "steps", index].
 *   - Inside a "parallel" you have [..., "branches", branchIdx, index].
 *   - Inside a "try" you have [..., "steps"|"catch"|"finally", index].
 */

function getStepArray(path) {
  // Walks the path until just before the final index → returns
  // the array that contains that step + the final index.
  let arr = state.flow.definition.steps;
  let i = 0;
  while (i < path.length - 1) {
    const idx = path[i++];
    const step = arr[idx];
    const key = path[i++];
    if (step.type === "parallel" && key === "branches") {
      const branchIdx = path[i++];
      arr = step.branches[branchIdx];
    } else {
      arr = step[key];
    }
  }
  return { arr, idx: path[path.length - 1] };
}

function getStepByPath(path) {
  const { arr, idx } = getStepArray(path);
  return arr[idx];
}

function setStepByPath(path, patch) {
  const step = getStepByPath(path);
  Object.assign(step, patch);
  state.dirty = true;
  updateStatusPill();
}

function removeStepByPath(path) {
  const { arr, idx } = getStepArray(path);
  arr.splice(idx, 1);
  state.dirty = true;
}

function insertStepAt(parentArr, idx, newStep) {
  parentArr.splice(idx, 0, newStep);
  state.dirty = true;
}

// Resolves a "drop target" descriptor to the actual array to insert into.
//
//   { kind: "between", path: [...path of position] }
//      Insert at that exact index (everything from that index shifts right).
//   { kind: "inside-empty", parentPath: [...], slot: "then" | "else" | "steps" | "catch" | "finally", branchIdx?: number }
//      Insert into a currently empty branch/container of a container step.
function resolveDropTarget(target) {
  if (target.kind === "between") {
    const { arr, idx } = getStepArray(target.path);
    return { arr, idx };
  }
  // inside-empty
  let parent = state.flow.definition.steps;
  if (target.parentPath.length) {
    parent = getStepByPath(target.parentPath);
  }
  let container;
  if (parent.type === "parallel" && target.slot === "branches") {
    container = parent.branches[target.branchIdx];
  } else if (target.parentPath.length === 0) {
    container = state.flow.definition.steps;
  } else {
    container = parent[target.slot];
  }
  return { arr: container, idx: container.length };
}

// ============================================================
// 4. ID generation — keep step IDs unique-ish per flow
// ============================================================

const _idCounter = { n: 1 };
function newId(prefix) {
  // Collect all existing IDs to avoid collisions
  if (state.flow) {
    const used = new Set();
    walkAllSteps(state.flow.definition.steps, (s) => used.add(s.id));
    let i = 1;
    while (used.has(`${prefix}_${i}`)) i++;
    return `${prefix}_${i}`;
  }
  return `${prefix}_${_idCounter.n++}`;
}

function walkAllSteps(steps, fn) {
  for (const s of (steps || [])) {
    fn(s);
    if (s.type === "condition") { walkAllSteps(s.then, fn); walkAllSteps(s.else, fn); }
    else if (s.type === "foreach") walkAllSteps(s.steps, fn);
    else if (s.type === "parallel") (s.branches || []).forEach((b) => walkAllSteps(b, fn));
    else if (s.type === "try") { walkAllSteps(s.steps, fn); walkAllSteps(s.catch, fn); walkAllSteps(s.finally, fn); }
  }
}

// ============================================================
// 5. API
// ============================================================

function apiLoadFlow() {
  return fetch("/api/flows/" + window.FLOW_ID + "/").then(function (resp) {
    if (!resp.ok) throw new Error("Load failed: HTTP " + resp.status);
    return resp.json();
  });
}

function apiSaveFlow() {
  var body = {
    name: state.flow.name,
    description: state.flow.description || "",
    definition: state.flow.definition,
    is_active: state.flow.is_active,
    schedule: state.flow.schedule || "",
    webhook_enabled: !!state.flow.webhook_enabled,
  };
  return fetch("/api/flows/" + window.FLOW_ID + "/", {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      "X-CSRFToken": window.CSRF_TOKEN,
    },
    body: JSON.stringify(body),
  }).then(function (resp) {
    if (!resp.ok) {
      return resp.text().then(function (text) {
        throw new Error("Save failed: HTTP " + resp.status + " — " + text.slice(0, 200));
      });
    }
    return resp.json();
  });
}

// ============================================================
// 6. Render — Palette
// ============================================================

function renderPalette() {
  const el = document.getElementById("palette");
  const html = PALETTE.map((group) => `
    <div class="pal-group">
      <h3>${escapeHtml(group.group)}</h3>
      ${group.items.map((item) => `
        <div class="pal-item" draggable="true" data-pal="${item.id}">
          <span class="icon">${item.icon}</span>
          <div>
            <div class="label">${escapeHtml(item.label)}</div>
            <small class="sub">${escapeHtml(item.sub)}</small>
          </div>
        </div>
      `).join("")}
    </div>
  `).join("");
  el.innerHTML = html;

  // Wire drag-start on every palette item
  Array.from(el.querySelectorAll(".pal-item")).forEach((node) => {
    const palId = node.dataset.pal;
    const item = findPaletteItem(palId);
    node.addEventListener("dragstart", (e) => {
      state.dragSource = { kind: "palette", make: item.make };
      node.classList.add("dragging");
      e.dataTransfer.effectAllowed = "copy";
      e.dataTransfer.setData("text/plain", "pal:" + palId);
    });
    node.addEventListener("dragend", () => {
      node.classList.remove("dragging");
      state.dragSource = null;
    });
  });
}

function findPaletteItem(id) {
  for (const g of PALETTE) for (const i of g.items) if (i.id === id) return i;
  return null;
}

// ============================================================
// 7. Render — Canvas (the step tree)
// ============================================================

function renderCanvas() {
  const canvas = document.getElementById("canvas");
  const def = state.flow.definition || {};
  const triggerType = (def.trigger && def.trigger.type) || "manual";
  const triggerIcon = triggerType === "schedule" ? "⏰" : triggerType === "webhook" ? "🪝" : "▶";

  let html = `
    <div class="flow-trigger">
      <span class="icon">${triggerIcon}</span>
      <div>
        <b>Trigger:</b> ${escapeHtml(triggerType)}
        ${triggerType === "schedule" && state.flow.schedule ? `<code>${escapeHtml(state.flow.schedule)}</code>` : ""}
        ${triggerType === "webhook" ? `<small> · token-protected webhook</small>` : ""}
      </div>
    </div>
  `;

  html += renderStepList(def.steps || [], []);
  canvas.innerHTML = html;

  wireCanvasEvents();
}

function renderStepList(steps, parentPath, parentType = null, slotKey = null, branchIdx = null) {
  // The list of cards + drop-zones for one container.
  const out = [];

  // Top drop-zone (insert at position 0)
  out.push(renderDropZone(parentPath, slotKey, branchIdx, 0));

  steps.forEach((step, i) => {
    const path = parentPath.concat([i]);
    if (slotKey !== null) {
      // We're inside a slot — the path we pass to renderStepCard is from the
      // parent step's slot. Build full path = parentPath + slot + ... ?
      // Actually parentPath already includes navigation through prior slot keys
      // and the parent index. Slot insertion happens in the *renderDropZone*
      // which understands the parent context.
    }
    out.push(renderStepCard(step, path, parentType, slotKey, branchIdx));
    out.push(renderDropZone(parentPath, slotKey, branchIdx, i + 1));
  });

  return `<ul class="step-list ${parentPath.length ? "nested" : ""}">${out.join("")}</ul>`;
}

function renderDropZone(parentPath, slotKey, branchIdx, position) {
  // Encode the drop-target descriptor into data attributes.
  const data = {
    parentPath: JSON.stringify(parentPath),
    slot: slotKey || "",
    branchIdx: branchIdx === null ? "" : String(branchIdx),
    position: String(position),
  };
  const attrs = Object.keys(data).map((k) => `data-${k}="${escapeHtml(data[k])}"`).join(" ");
  return `<li class="drop-zone" ${attrs}>+ drop here</li>`;
}

function renderStepCard(step, path, parentType, slotKey, branchIdx) {
  const meta = STEP_TYPES[step.type] || { icon: "?", label: step.type, kind: "leaf" };
  const isSelected = pathEquals(path, state.selectedPath);
  const seq = path[path.length - 1] + 1;

  const headerHtml = `
    <div class="step-head" data-action="select">
      <span class="handle" data-action="grip" draggable="true">⋮⋮</span>
      <span class="seq">${seq}</span>
      <span class="icon">${meta.icon}</span>
      <span class="id">${escapeHtml(step.id || "(no id)")}</span>
      <span class="type">${escapeHtml(step.type)}</span>
      ${step.connector ? `<span class="conn">${escapeHtml(step.connector)}</span>` : ""}
      <button class="menu" data-action="delete" title="Delete step">✕</button>
    </div>
  `;

  let bodyHtml = "";
  if (meta.kind === "branch") {
    // condition: then + else
    bodyHtml = `
      <div class="step-body">
        <div class="branch-label then-label">▷ THEN</div>
        ${renderStepList(step.then || [], path.concat(["then"]), "condition", "then")}
        <div class="branch-label else-label">▽ ELSE</div>
        ${renderStepList(step.else || [], path.concat(["else"]), "condition", "else")}
      </div>
    `;
  } else if (meta.kind === "container") {
    // foreach
    bodyHtml = `
      <div class="step-body">
        <div class="branch-label">↻ FOR EACH ITEM (${escapeHtml(step.item_var || "item")})</div>
        ${renderStepList(step.steps || [], path.concat(["steps"]), "foreach", "steps")}
      </div>
    `;
  } else if (meta.kind === "parallel") {
    const branches = step.branches || [];
    bodyHtml = `
      <div class="step-body">
        ${branches.map((br, bi) => `
          <div class="parallel-branch">
            <div class="branch-label">║ BRANCH ${bi + 1}</div>
            ${renderStepList(br, path.concat(["branches", bi]), "parallel", "branches", bi)}
          </div>
        `).join("")}
      </div>
    `;
  } else if (meta.kind === "trycatch") {
    bodyHtml = `
      <div class="step-body">
        <div class="branch-label">↦ TRY</div>
        ${renderStepList(step.steps || [], path.concat(["steps"]), "try", "steps")}
        <div class="branch-label catch-label">⚠ CATCH</div>
        ${renderStepList(step.catch || [], path.concat(["catch"]), "try", "catch")}
        <div class="branch-label finally-label">⊙ FINALLY</div>
        ${renderStepList(step.finally || [], path.concat(["finally"]), "try", "finally")}
      </div>
    `;
  }

  return `
    <li class="step-card ${isSelected ? "selected" : ""}" data-path='${JSON.stringify(path)}'>
      ${headerHtml}
      ${bodyHtml}
    </li>
  `;
}

function pathEquals(a, b) {
  if (!a || !b) return false;
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}

// ============================================================
// 8. Canvas events — selection, delete, drag/drop
// ============================================================

function wireCanvasEvents() {
  const canvas = document.getElementById("canvas");

  // Click → select / delete
  canvas.addEventListener("click", (e) => {
    const action = e.target.closest("[data-action]");
    const card = e.target.closest(".step-card");
    if (action && card) {
      const path = JSON.parse(card.dataset.path);
      const verb = action.dataset.action;
      if (verb === "delete") {
        e.stopPropagation();
        if (confirm(`Delete step "${getStepByPath(path).id}"?`)) {
          removeStepByPath(path);
          state.selectedPath = null;
          renderCanvas();
          renderInspector();
          updateStatusPill();
        }
      } else if (verb === "select") {
        state.selectedPath = path;
        renderCanvas();
        renderInspector();
      }
    }
  });

  // --- drag from card handle (reorder) -------------------
  Array.from(canvas.querySelectorAll(".step-head .handle")).forEach((handle) => {
    handle.addEventListener("dragstart", (e) => {
      const card = handle.closest(".step-card");
      const path = JSON.parse(card.dataset.path);
      state.dragSource = { kind: "card", path };
      card.classList.add("dragging");
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", "card:" + path.join(","));
      e.stopPropagation();
    });
    handle.addEventListener("dragend", () => {
      Array.from(canvas.querySelectorAll(".dragging")).forEach((n) => n.classList.remove("dragging"));
      state.dragSource = null;
    });
  });

  // --- drop zones ----------------------------------------
  Array.from(canvas.querySelectorAll(".drop-zone")).forEach((zone) => {
    zone.addEventListener("dragover", (e) => {
      if (!state.dragSource) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = state.dragSource.kind === "palette" ? "copy" : "move";
      zone.classList.add("over");
    });
    zone.addEventListener("dragleave", () => {
      zone.classList.remove("over");
    });
    zone.addEventListener("drop", (e) => {
      e.preventDefault();
      zone.classList.remove("over");
      handleDrop(zone);
    });
  });
}

function handleDrop(zone) {
  if (!state.dragSource) return;

  const parentPath = JSON.parse(zone.dataset.parentpath);
  const slot = zone.dataset.slot || null;
  const branchIdx = zone.dataset.branchidx === "" ? null : parseInt(zone.dataset.branchidx, 10);
  let position = parseInt(zone.dataset.position, 10);

  // Resolve the target array
  let targetArr;
  if (slot) {
    const parent = parentPath.length ? getStepByPath(parentPath) : null;
    if (parent && parent.type === "parallel" && slot === "branches") {
      targetArr = parent.branches[branchIdx];
    } else if (parent) {
      targetArr = parent[slot];
      if (!Array.isArray(targetArr)) { parent[slot] = []; targetArr = parent[slot]; }
    }
  } else {
    if (parentPath.length === 0) {
      targetArr = state.flow.definition.steps;
    } else {
      // Shouldn't happen but defensive
      const parent = getStepByPath(parentPath);
      targetArr = parent.steps || [];
    }
  }

  if (state.dragSource.kind === "palette") {
    const newStep = state.dragSource.make();
    targetArr.splice(position, 0, newStep);
    // Select the new step
    state.selectedPath = buildPathForInsert(parentPath, slot, branchIdx, position);
  } else if (state.dragSource.kind === "card") {
    const fromPath = state.dragSource.path;
    const { arr: srcArr, idx: srcIdx } = getStepArray(fromPath);
    const movedStep = srcArr[srcIdx];

    // Same-array move with index adjustment
    if (srcArr === targetArr && srcIdx < position) position -= 1;

    srcArr.splice(srcIdx, 1);
    targetArr.splice(position, 0, movedStep);
    state.selectedPath = buildPathForInsert(parentPath, slot, branchIdx, position);
  }

  state.dragSource = null;
  state.dirty = true;
  renderCanvas();
  renderInspector();
  updateStatusPill();
}

function buildPathForInsert(parentPath, slot, branchIdx, position) {
  if (!slot) return parentPath.concat([position]);
  if (branchIdx !== null) {
    return parentPath.concat([slot, branchIdx, position]);
  }
  return parentPath.concat([slot, position]);
}

// ============================================================
// 9. Render — Inspector
// ============================================================

function renderInspector() {
  const el = document.getElementById("inspector");
  if (!state.selectedPath) {
    el.innerHTML = `
      <h2>Inspector</h2>
      <div class="empty">
        Select a step to configure it.<br><br>
        Drag from the palette on the left to add new steps.
      </div>
    `;
    return;
  }

  const step = getStepByPath(state.selectedPath);
  const meta = STEP_TYPES[step.type] || { icon: "?", label: step.type };

  let fieldsHtml = `
    <div class="step-title">
      <span class="icon">${meta.icon}</span>
      <div class="meta">
        <b>${escapeHtml(step.id || "(no id)")}</b>
        <small>${escapeHtml(meta.label)}${step.connector ? ` · ${escapeHtml(step.connector)}` : ""}</small>
      </div>
    </div>
  `;

  // ID — always editable
  fieldsHtml += textField("step_id", "Step ID", step.id || "", { mono: true, structural: true });

  // Per-type fields
  if (step.type === "action") {
    fieldsHtml += textField("connector", "Connector", step.connector || "", { mono: true, structural: true });
    fieldsHtml += jsonField("inputs", "Inputs (JSON)", step.inputs || {});
    fieldsHtml += jsonField("retry", "Retry policy (optional JSON)", step.retry || null, { allowNull: true });
  } else if (step.type === "condition") {
    fieldsHtml += textField("condition", "Condition (expression)", step.condition || "", { mono: true, structural: true,
      hint: 'Truthy → THEN branch; falsy → ELSE. Example: {{ steps.fetch.output.status == 200 }}' });
  } else if (step.type === "foreach") {
    fieldsHtml += textField("items", "Items (expression)", step.items || "", { mono: true, structural: true,
      hint: 'Should evaluate to a list. Example: {{ vars.symbols }}' });
    fieldsHtml += textField("item_var", "Item variable name", step.item_var || "item", { mono: true, structural: true });
  } else if (step.type === "parallel") {
    fieldsHtml += `
      <div class="field">
        <label>Branches</label>
        <div class="hint">${step.branches.length} branches. Use the canvas to add/remove.</div>
      </div>
      <div class="field">
        <button class="btn ghost" id="add-branch">+ Add branch</button>
      </div>
    `;
  } else if (step.type === "try") {
    fieldsHtml += `<div class="field"><div class="hint">No config. Drag steps into the TRY, CATCH, and FINALLY slots on the canvas.</div></div>`;
  } else if (step.type === "compose") {
    fieldsHtml += jsonField("value", "Value (JSON)", step.value || {});
  } else if (step.type === "delay") {
    fieldsHtml += textField("seconds", "Seconds", String(step.seconds || 0), { mono: true });
  } else if (step.type === "set_variable") {
    fieldsHtml += textField("var_name", "Variable name", step.name || "", { mono: true, structural: true });
    fieldsHtml += textField("var_value", "Value (expression or literal)", String(step.value == null ? "" : step.value), { mono: true });
  } else if (step.type === "call_flow") {
    fieldsHtml += textField("sub_flow", "Flow name", step.flow || "", { mono: true, structural: true });
    fieldsHtml += jsonField("sub_input", "Input (JSON)", step.input || {});
  } else if (step.type === "terminate") {
    fieldsHtml += `
      <div class="field">
        <label>Status</label>
        <select id="f-status">
          ${["succeeded", "failed", "cancelled"].map((s) =>
            `<option value="${s}" ${s === step.status ? "selected" : ""}>${s}</option>`
          ).join("")}
        </select>
      </div>
    `;
    fieldsHtml += textField("term_message", "Message", step.message || "", {});
  }

  fieldsHtml += `
    <div class="delete-row">
      <button class="btn danger" id="del-step">Delete step</button>
    </div>
  `;

  el.innerHTML = fieldsHtml;
  wireInspectorEvents(step);
}

function textField(id, label, value, opts) {
  opts = opts || {};
  return `
    <div class="field">
      <label for="f-${id}">${escapeHtml(label)}</label>
      <input id="f-${id}" type="text" value="${escapeHtml(value)}"
             ${opts.mono ? "style=\"font-family: ui-monospace, monospace;\"" : ""}
             data-structural="${opts.structural ? "1" : "0"}">
      ${opts.hint ? `<div class="hint">${escapeHtml(opts.hint)}</div>` : ""}
    </div>
  `;
}

function jsonField(id, label, value, opts) {
  opts = opts || {};
  const text = value === null || value === undefined ? "" : JSON.stringify(value, null, 2);
  return `
    <div class="field">
      <label for="f-${id}">${escapeHtml(label)}</label>
      <textarea id="f-${id}" spellcheck="false">${escapeHtml(text)}</textarea>
      <div class="err" id="err-${id}" style="display:none"></div>
      ${opts.allowNull ? `<div class="hint">Leave empty to remove this field.</div>` : ""}
    </div>
  `;
}

function wireInspectorEvents(step) {
  const el = document.getElementById("inspector");
  const path = state.selectedPath.slice();

  // Text inputs commit on blur
  const bind = (selector, apply) => {
    const node = el.querySelector(selector);
    if (!node) return;
    const commit = () => {
      apply(node.value);
      state.dirty = true;
      updateStatusPill();
      if (node.dataset.structural === "1") renderCanvas();
    };
    node.addEventListener("blur", commit);
    node.addEventListener("change", commit);
  };

  bind("#f-step_id", (v) => { step.id = v.trim() || step.id; });
  bind("#f-connector", (v) => { step.connector = v.trim(); });
  bind("#f-condition", (v) => { step.condition = v; });
  bind("#f-items", (v) => { step.items = v; });
  bind("#f-item_var", (v) => { step.item_var = v.trim() || "item"; });
  bind("#f-seconds", (v) => { step.seconds = parseFloat(v) || 0; });
  bind("#f-var_name", (v) => { step.name = v.trim(); });
  bind("#f-var_value", (v) => { step.value = v; });
  bind("#f-sub_flow", (v) => { step.flow = v.trim(); });
  bind("#f-status", (v) => { step.status = v; });
  bind("#f-term_message", (v) => { step.message = v; });

  // JSON textareas with validation
  const bindJson = (id, apply, allowNull) => {
    const node = el.querySelector(`#f-${id}`);
    const err = el.querySelector(`#err-${id}`);
    if (!node) return;
    const commit = () => {
      const raw = node.value.trim();
      if (raw === "") {
        if (allowNull) {
          apply(null);
          err.style.display = "none";
          state.dirty = true; updateStatusPill();
        } else {
          apply({});
          err.style.display = "none";
        }
        return;
      }
      try {
        const parsed = JSON.parse(raw);
        apply(parsed);
        err.style.display = "none";
        state.dirty = true;
        updateStatusPill();
      } catch (e) {
        err.textContent = "Invalid JSON: " + e.message;
        err.style.display = "block";
      }
    };
    node.addEventListener("blur", commit);
  };
  bindJson("inputs", (v) => { step.inputs = v; });
  bindJson("retry",  (v) => { if (v === null) { delete step.retry; } else { step.retry = v; } }, true);
  bindJson("value",  (v) => { step.value = v; });
  bindJson("sub_input", (v) => { step.input = v; });

  // Add branch button (parallel)
  const addBranch = el.querySelector("#add-branch");
  if (addBranch) {
    addBranch.addEventListener("click", () => {
      step.branches.push([]);
      state.dirty = true;
      renderCanvas();
      renderInspector();
      updateStatusPill();
    });
  }

  // Delete from inspector
  const del = el.querySelector("#del-step");
  if (del) {
    del.addEventListener("click", () => {
      if (confirm(`Delete step "${step.id}"?`)) {
        removeStepByPath(path);
        state.selectedPath = null;
        renderCanvas();
        renderInspector();
        updateStatusPill();
      }
    });
  }
}

// ============================================================
// 10. Save / status / JSON dialog
// ============================================================

function updateStatusPill() {
  const pill = document.getElementById("status-pill");
  if (state.loadError) {
    pill.textContent = "Error";
    pill.className = "status-pill error";
    return;
  }
  if (state.dirty) {
    pill.textContent = "Unsaved";
    pill.className = "status-pill dirty";
  } else {
    pill.textContent = "Saved";
    pill.className = "status-pill saved";
  }
}

function onSave() {
  document.getElementById("btn-save").disabled = true;
  apiSaveFlow().then(function () {
    state.dirty = false;
    updateStatusPill();
    toast("Saved", "ok");
  }).catch(function (e) {
    toast(e.message, "err");
  }).then(function () {
    document.getElementById("btn-save").disabled = false;
  });
}

function onValidate() {
  const issues = validateFlow(state.flow.definition);
  if (issues.length === 0) {
    toast("✓ Definition is valid", "ok");
  } else {
    toast(`⚠ ${issues.length} issue(s): ${issues[0]}`, "err");
    console.warn("Validation issues:", issues);
  }
}

function validateFlow(def) {
  const issues = [];
  const ids = new Map();
  walkAllSteps(def.steps || [], (s) => {
    if (!s.id) issues.push(`Step is missing id (type=${s.type})`);
    else if (ids.has(s.id)) issues.push(`Duplicate step id: ${s.id}`);
    else ids.set(s.id, true);
    if (!s.type) issues.push(`Step ${s.id || "?"} missing type`);
    if (s.type === "action" && !s.connector) issues.push(`Action ${s.id} missing connector`);
    if (s.type === "condition" && !s.condition) issues.push(`Condition ${s.id} missing condition expression`);
    if (s.type === "foreach" && !s.items) issues.push(`Foreach ${s.id} missing 'items'`);
    if (s.type === "call_flow" && !s.flow && !s.flow_id) issues.push(`Call_flow ${s.id} missing target`);
  });
  return issues;
}

function onShowJson() {
  const dlg = document.getElementById("json-dialog");
  const ta = document.getElementById("json-area");
  ta.value = JSON.stringify(state.flow.definition, null, 2);
  dlg.showModal();
}

function onApplyJson() {
  const ta = document.getElementById("json-area");
  try {
    const parsed = JSON.parse(ta.value);
    if (!parsed || typeof parsed !== "object") throw new Error("Must be a JSON object");
    state.flow.definition = parsed;
    state.dirty = true;
    state.selectedPath = null;
    document.getElementById("json-dialog").close();
    renderCanvas();
    renderInspector();
    updateStatusPill();
    toast("JSON applied", "ok");
  } catch (e) {
    toast("Invalid JSON: " + e.message, "err");
  }
}

function toast(message, kind) {
  const existing = document.querySelector(".toast");
  if (existing) existing.remove();
  const div = document.createElement("div");
  div.className = `toast ${kind || ""}`;
  div.textContent = message;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 2400);
}

// ============================================================
// 11. Misc
// ============================================================

function escapeHtml(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ============================================================
// 12. Bootstrap
// ============================================================

function init() {
  try {
    if (window.INITIAL_FLOW) {
      state.flow = window.INITIAL_FLOW;
    } else if (typeof fetch === "function") {
      // Lazy network fallback for fresh refreshes without inlined data
      apiLoadFlow().then(function (f) {
        state.flow = f;
        bootUI();
      }).catch(function (e) {
        state.loadError = e.message;
        document.getElementById("canvas").innerHTML =
          '<div style="color: var(--err); padding: 40px;">Failed to load flow: ' + escapeHtml(e.message) + '</div>';
        updateStatusPill();
      });
      return;
    } else {
      throw new Error("No initial flow data and fetch unavailable");
    }
    if (!state.flow.definition || typeof state.flow.definition !== "object") {
      state.flow.definition = { trigger: { type: "manual" }, steps: [] };
    }
    if (!Array.isArray(state.flow.definition.steps)) state.flow.definition.steps = [];
    state.dirty = false;
  } catch (e) {
    state.loadError = e.message;
    document.getElementById("canvas").innerHTML =
      '<div style="color: var(--err); padding: 40px;">Failed to load flow: ' + escapeHtml(e.message) + '</div>';
    updateStatusPill();
    return;
  }
  bootUI();
}

function bootUI() {
  document.getElementById("btn-save").addEventListener("click", onSave);
  document.getElementById("btn-validate").addEventListener("click", onValidate);
  document.getElementById("btn-json").addEventListener("click", onShowJson);
  document.getElementById("json-close").addEventListener("click", function () {
    document.getElementById("json-dialog").close();
  });
  document.getElementById("json-apply").addEventListener("click", onApplyJson);

  // Cmd/Ctrl-S to save
  document.addEventListener("keydown", function (e) {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
      e.preventDefault();
      onSave();
    }
  });

  renderPalette();
  renderCanvas();
  renderInspector();
  updateStatusPill();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}

})();
