from django.db import models

from flows.models import Flow


class Status(models.TextChoices):
    PENDING = "pending", "Pending"
    RUNNING = "running", "Running"
    SUCCEEDED = "succeeded", "Succeeded"
    FAILED = "failed", "Failed"
    SKIPPED = "skipped", "Skipped"
    CANCELLED = "cancelled", "Cancelled"


class FlowRun(models.Model):
    TRIGGER_CHOICES = (
        ("manual", "Manual"),
        ("schedule", "Schedule"),
        ("api", "API"),
        ("webhook", "Webhook"),
    )

    flow = models.ForeignKey(Flow, related_name="runs", on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    trigger_type = models.CharField(max_length=20, choices=TRIGGER_CHOICES, default="manual")
    trigger_data = models.JSONField(default=dict, blank=True)

    output = models.JSONField(default=dict, blank=True)
    error = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Run #{self.pk} of {self.flow.name} [{self.status}]"

    @property
    def duration_seconds(self):
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


class StepRun(models.Model):
    run = models.ForeignKey(FlowRun, related_name="step_runs", on_delete=models.CASCADE)
    step_id = models.CharField(max_length=200)
    step_type = models.CharField(max_length=50)
    connector = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)

    inputs = models.JSONField(default=dict, blank=True)
    output = models.JSONField(default=dict, blank=True)
    error = models.TextField(blank=True)

    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    sequence = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["sequence", "id"]

    def __str__(self):
        return f"{self.step_id} [{self.status}]"
