from django.shortcuts import get_object_or_404, render

from rest_framework import viewsets

from .models import FlowRun
from .serializers import FlowRunSerializer


class FlowRunViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = FlowRun.objects.all().select_related("flow").prefetch_related("step_runs")
    serializer_class = FlowRunSerializer


def run_list(request):
    status_filter = request.GET.get("status") or ""
    qs = FlowRun.objects.select_related("flow").order_by("-created_at")
    if status_filter:
        qs = qs.filter(status=status_filter)
    runs = qs[:100]
    return render(
        request,
        "runs/list.html",
        {"runs": runs, "status_filter": status_filter},
    )


def run_detail(request, pk):
    run = get_object_or_404(
        FlowRun.objects.select_related("flow").prefetch_related("step_runs"),
        pk=pk,
    )
    return render(request, "runs/detail.html", {"run": run})
