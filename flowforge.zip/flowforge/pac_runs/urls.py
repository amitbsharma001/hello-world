from django.urls import path

from . import views

urlpatterns = [
    path("", views.run_list, name="run-list"),
    path("<int:pk>/", views.run_detail, name="run-detail"),
]
