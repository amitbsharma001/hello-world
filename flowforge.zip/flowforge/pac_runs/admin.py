from django.contrib import admin

from .models import FlowRun, StepRun


class StepRunInline(admin.TabularInline):
    model = StepRun
    extra = 0
    readonly_fields = (
        "step_id", "step_type", "connector", "status",
        "inputs", "output", "error", "started_at", "completed_at",
    )
    can_delete = False


@admin.register(FlowRun)
class FlowRunAdmin(admin.ModelAdmin):
    list_display = ("id", "flow", "status", "trigger_type", "created_at", "duration_seconds")
    list_filter = ("status", "trigger_type", "flow")
    inlines = [StepRunInline]
    readonly_fields = ("created_at", "started_at", "completed_at")


@admin.register(StepRun)
class StepRunAdmin(admin.ModelAdmin):
    list_display = ("id", "run", "step_id", "step_type", "status", "completed_at")
    list_filter = ("status", "step_type")
