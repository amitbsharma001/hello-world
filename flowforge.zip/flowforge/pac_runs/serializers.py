from rest_framework import serializers

from .models import FlowRun, StepRun


class StepRunSerializer(serializers.ModelSerializer):
    class Meta:
        model = StepRun
        fields = [
            "id", "step_id", "step_type", "connector", "status",
            "inputs", "output", "error",
            "started_at", "completed_at", "sequence",
        ]


class FlowRunSerializer(serializers.ModelSerializer):
    step_runs = StepRunSerializer(many=True, read_only=True)
    duration_seconds = serializers.FloatField(read_only=True)

    class Meta:
        model = FlowRun
        fields = [
            "id", "flow", "status", "trigger_type", "trigger_data",
            "output", "error",
            "created_at", "started_at", "completed_at",
            "duration_seconds", "step_runs",
        ]
        read_only_fields = fields
