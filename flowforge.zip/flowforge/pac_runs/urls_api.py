from rest_framework.routers import DefaultRouter

from .views import FlowRunViewSet

router = DefaultRouter()
router.register("runs", FlowRunViewSet, basename="api-run")

urlpatterns = router.urls
