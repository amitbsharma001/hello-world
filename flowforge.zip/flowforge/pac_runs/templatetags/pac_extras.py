import json
from django import template

register = template.Library()


@register.filter
def pretty_json(value):
    """Render a dict/list (or JSON-ish value) as indented JSON for display."""
    if value in (None, "", {}, []):
        return ""
    try:
        return json.dumps(value, indent=2, ensure_ascii=False, default=str, sort_keys=False)
    except (TypeError, ValueError):
        return str(value)


@register.filter
def step_duration(step):
    """Best-effort per-step duration in seconds (StepRun has started/completed)."""
    try:
        if step.started_at and step.completed_at:
            return round((step.completed_at - step.started_at).total_seconds(), 3)
    except Exception:
        pass
    return None
