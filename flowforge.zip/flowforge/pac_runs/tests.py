"""pac_runs tests: FlowRun/StepRun models, run history views + API."""
from django.test import TestCase
from django.urls import reverse

from pac_flows.models import Flow
from pac_runs.models import FlowRun, Status, StepRun


class RunModelTests(TestCase):
    def setUp(self):
        self.flow = Flow.objects.create(name="f", definition={"steps": []})

    def test_flowrun_defaults(self):
        fr = FlowRun.objects.create(flow=self.flow)
        self.assertEqual(fr.status, Status.PENDING)
        self.assertEqual(fr.trigger_type, "manual")

    def test_steprun_ordering_by_sequence(self):
        fr = FlowRun.objects.create(flow=self.flow)
        StepRun.objects.create(run=fr, step_id="b", step_type="action", sequence=2)
        StepRun.objects.create(run=fr, step_id="a", step_type="action", sequence=1)
        seqs = list(
            StepRun.objects.filter(run=fr).order_by("sequence").values_list("step_id", flat=True)
        )
        self.assertEqual(seqs, ["a", "b"])

    def test_cascade_delete(self):
        fr = FlowRun.objects.create(flow=self.flow)
        StepRun.objects.create(run=fr, step_id="s", step_type="action", sequence=1)
        fr.delete()
        self.assertEqual(StepRun.objects.count(), 0)


class RunViewTests(TestCase):
    def setUp(self):
        self.flow = Flow.objects.create(name="f", definition={"steps": []})
        self.run = FlowRun.objects.create(flow=self.flow, status=Status.SUCCEEDED)

    def test_run_list_view(self):
        resp = self.client.get(reverse("run-list"))
        self.assertEqual(resp.status_code, 200)

    def test_run_detail_view(self):
        resp = self.client.get(reverse("run-detail", args=[self.run.pk]))
        self.assertEqual(resp.status_code, 200)

    def test_run_api_list(self):
        resp = self.client.get("/api/runs/")
        self.assertEqual(resp.status_code, 200)
