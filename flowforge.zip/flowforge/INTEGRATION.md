# Integrating Flowforge into an existing Django project

Flowforge is built so you can drop it into a host Django application as a
set of reusable apps — no project-level template/static wiring, no
hard-coded Celery app, broker-agnostic. This guide gets it running inside
your project in about five minutes.

The reusable pieces are three apps:

| App      | What it is                                             |
| -------- | ------------------------------------------------------ |
| `pac_flows`  | Flow + Connection models, UI, REST API, visual builder |
| `pac_runs`   | FlowRun + StepRun models, run history UI + API         |
| `pac_engine` | The executor, connectors, Celery tasks, config, logging (library code — also exposes `pac_engine.urls`) |

---

## 1. Add the code

Copy the `flows/`, `runs/`, and `engine/` directories into your project
(or `pip install` it once packaged). They have no dependency on the
standalone `flowforge/` project package — that's only here so the repo runs
on its own.

## 2. Install apps

```python
# settings.py
INSTALLED_APPS = [
    # ... your apps ...
    "rest_framework",
    "django_celery_beat",

    "pac_flows.apps.FlowsConfig",
    "pac_runs.apps.RunsConfig",
    "pac_engine.apps.EngineConfig",
]
```

Templates and static files ship **inside** these apps, so with
`APP_DIRS=True` (the Django default) and the app-directories static finder
(also default) there is nothing else to configure. Static assets are
namespaced under `static/flowforge/` and the base template under
`templates/flowforge/`, so they won't collide with yours.

## 3. Mount the URLs — one line

```python
# urls.py
from django.urls import include, path

urlpatterns = [
    # ...
    path("automation/", include("pac_engine.urls")),
]
```

That mounts the whole thing under `/automation/`:

```
/automation/                  flow list
/automation/<id>/builder/     visual builder
/automation/runs/             run history
/automation/api/flows/        REST API
/automation/api/connectors/   connector catalog (drives the builder UI)
/automation/webhooks/<token>/ inbound webhook receiver
```

Prefer to wire pieces yourself? Include `flows.urls`, `runs.urls`,
`flows.urls_api`, `runs.urls_api` individually instead.

## 4. Migrate

```bash
python manage.py migrate
```

This creates the `flows_*` and `runs_*` tables plus the
`django_celery_beat` schedule tables.

## 5. Celery (RabbitMQ)

Flowforge's tasks are plain `@shared_task`s, so your **existing Celery app**
discovers them automatically — you don't create a second Celery app. If you
already run Celery, you're done; just make sure your Celery app calls
`autodiscover_tasks()` (the standard setup does).

If you don't have Celery yet, the standard Django integration is:

```python
# yourproject/celery.py
import os
from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "yourproject.settings")
app = Celery("yourproject")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
```

```python
# yourproject/__init__.py
from .celery import app as celery_app
__all__ = ("celery_app",)
```

Broker settings (RabbitMQ is the default Flowforge assumes):

```python
# settings.py
CELERY_BROKER_URL = "amqp://guest:guest@localhost:5672//"
# Flowforge stores all run state in its own models, so a result backend is
# optional. Leave unset, or use "rpc://" / django-celery-results if you want
# per-task results.
CELERY_BEAT_SCHEDULER = "django_celery_beat.schedulers:DatabaseScheduler"
```

Run the workers:

```bash
celery -A yourproject worker -l info
celery -A yourproject beat   -l info     # only if you use scheduled triggers
```

Scheduled flows are kept in sync with `django_celery_beat` automatically by
a signal on the `Flow` model — no manual periodic-task management.

## 6. Logging

Flowforge logs everything under the `flowforge` logger with run/flow/step
context on each record, e.g.:

```
[2026-05-28 09:32:09] INFO    flowforge.executor [flow=3 run=1] Flow 'Nightly ETL' started (4 top-level steps, trigger=schedule)
[2026-05-28 09:32:09] INFO    flowforge.steps    [flow=3 run=1 step=fetch] Step start: action (http.request)
[2026-05-28 09:32:10] INFO    flowforge.steps    [flow=3 run=1 step=fetch] Step succeeded: action duration=0.412s
```

Add it to your `LOGGING` config in one of two ways.

**Option A — call the helper from settings:**

```python
# settings.py (at the end)
from pac_engine.logging import configure_logging
configure_logging(level="INFO")   # or os.environ["FLOWFORGE_LOG_LEVEL"]
```

**Option B — merge the fragment into your own `LOGGING` dict:**

```python
from pac_engine.logging import logging_config
LOGGING = {  # ... your config ...
}
# merge the flowforge logger/handler/filter/formatter
_ff = logging_config(level="INFO")
LOGGING["filters"].update(_ff["filters"])
LOGGING["formatters"].update(_ff["formatters"])
LOGGING["handlers"].update(_ff["handlers"])
LOGGING["loggers"].update(_ff["loggers"])
```

The `RunContextFilter` guarantees `flow_id`, `run_id`, `step_id` and a
preformatted `ctx` attribute exist on every record, so you can route
Flowforge logs to JSON, Sentry, Datadog, etc. with your own handlers.

## 7. Settings reference

All optional. Set only what you want to change.

| Setting                       | Default            | Purpose                                              |
| ----------------------------- | ------------------ | ---------------------------------------------------- |
| `FLOWFORGE_ENCRYPTION_KEY`    | falls back to `SECRET_KEY` | Fernet key for encrypting `Connection` credentials. Set explicitly in prod so rotating `SECRET_KEY` doesn't orphan rows. |
| `FLOWFORGE_ALLOW_PYTHON_EXEC` | `True`             | Master switch for the `python.exec` connector.       |
| `FLOWFORGE_ALLOW_DB_QUERY`    | `True`             | Master switch for `db.query`.                        |
| `FLOWFORGE_ALLOW_DB_EXECUTE`  | `True`             | Master switch for `db.execute`.                      |
| `FLOWFORGE_REDIS_URL`         | `None`             | Redis URL for the `redis.*` connectors (NOT the broker). |
| `FLOWFORGE_LOG_LEVEL`         | `"INFO"`           | Level for the `flowforge` logger.                    |

Read them anywhere via the central accessor:

```python
from pac_engine.conf import conf
if conf.ALLOW_PYTHON_EXEC:
    ...
```

## 8. Optional connector dependencies

The core install needs no broker driver beyond what Celery bundles. Install
extras only for the connectors you use:

```bash
pip install redis      # redis.* connectors
pip install boto3       # s3.* connectors
```

Both are imported lazily — the app boots fine without them; a step using
one raises a clear error telling you what to install.

## 9. Permissions

The REST API ships with `AllowAny` for easy local trials. Before exposing
it, set a real DRF permission class — either globally or by subclassing the
viewsets. Webhook endpoints are always token-protected.

---

That's it. Create a flow at `/automation/`, open the visual builder, and
trigger it — the worker logs will show the per-step trace with full run
context.
