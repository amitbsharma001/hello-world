# Theming Flowforge

The entire UI — every page plus the visual builder — is driven by a single
set of colour/brand tokens. You rebrand it from config; no CSS edits, no
template edits.

## How it works

`pac_engine/theme.py` defines `DEFAULT_THEME` (a clean, neutral
industrial/enterprise palette). A context processor injects the active
theme into every page as CSS custom properties (`:root { --primary: … }`),
which the stylesheets consume. Override any subset of tokens from your
Django settings and they cascade across the whole app.

## Customizing

Add a `FLOWFORGE_THEME` dict to your settings. Only the keys you set are
overridden; the rest fall back to defaults.

```python
# settings.py
FLOWFORGE_THEME = {
    "brand_name":    "Acme Automate",
    "primary":       "#c8102e",   # buttons, links, active states, logo
    "primary_600":   "#a50d26",   # hover
    "primary_700":   "#86091f",   # gradient end / strong text
    "primary_weak":  "#fbe7ea",   # tints, badges, icon chips
    "accent":        "#0b7285",   # connector names / secondary accent
    "header_bg":     "#0d1b2a",   # a dark top bar
    "header_fg":     "#ffffff",
    "header_border": "#0d1b2a",
}
```

That single block produces a fully rebranded UI: coloured header, recoloured
buttons/links/logo, retinted chips and badges — consistently, everywhere.

### Loading the palette from a JSON file

Keep the palette outside code if you prefer:

```python
# settings.py
import json, pathlib
FLOWFORGE_THEME = json.loads(
    pathlib.Path(BASE_DIR / "flowforge_theme.json").read_text()
)
```

```json
{
  "brand_name": "Acme Automate",
  "primary": "#c8102e",
  "primary_700": "#86091f",
  "header_bg": "#0d1b2a",
  "header_fg": "#ffffff"
}
```

## Full token reference

| Key | Default | Drives |
| --- | --- | --- |
| `brand_name` | `Flowforge` | Wordmark next to the logo |
| `brand_show` | `True` | Hide the wordmark (logo only) with `False` |
| `primary` | `#1763d6` | Primary buttons, links, focus rings, logo |
| `primary_600` | `#1257be` | Primary hover |
| `primary_700` | `#0f4aa3` | Logo gradient end, strong accents |
| `primary_ink` | `#ffffff` | Text on primary buttons |
| `primary_weak` | `#e7f0fc` | Tints: icon chips, badges, drop-zone highlight |
| `accent` | `#0b7285` | Connector names, secondary accent |
| `bg` | `#eef1f6` | App background |
| `surface` | `#ffffff` | Cards, panels, inputs |
| `surface_2` / `surface_3` | greys | Subtle fills, hovers |
| `header_bg` / `header_fg` / `header_border` | white / dark / grey | The top bar (set these for a dark or coloured header) |
| `text` / `text_2` / `muted` | dark → grey | Body text hierarchy |
| `border` / `border_2` | greys | Lines and control borders |
| `ok` / `warn` / `err` (+ `_weak`) | green / amber / red | Status badges & messages |
| `radius` / `radius_sm` / `radius_lg` | `8/6/12px` | Corner rounding (lower = squarer/industrial) |
| `font` | Inter + system stack | Font family. Point it at your own webfont; **no proprietary fonts are bundled** |

## A note on brand assets

The default look is an original, neutral industrial/enterprise design — it
is **not** a copy of any company's brand. The logo (`pac/_logo.svg`),
colours, and typography are all swappable so you can apply *your own*
licensed brand kit (logo, fonts, palette). To change the mark, replace
`pac_flows/templates/pac/_logo.svg`; to change the font, set `font` in
`FLOWFORGE_THEME` and load the webfont in your base template.
