from rest_framework import serializers

from .models import Connection, Flow


class FlowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flow
        fields = [
            "id",
            "name",
            "description",
            "definition",
            "is_active",
            "schedule",
            "webhook_enabled",
            "webhook_token",
            "created_at",
            "updated_at",
        ]
        read_only_fields = ["created_at", "updated_at", "webhook_token"]


class ConnectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Connection
        fields = ["id", "name", "connector_type", "config", "created_at"]
        read_only_fields = ["created_at"]
