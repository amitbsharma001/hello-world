import secrets

from django.conf import settings
from django.db import models

from .fields import EncryptedJSONField


def _new_webhook_token() -> str:
    return secrets.token_urlsafe(24)


class Flow(models.Model):
    """
    A workflow definition. `definition` holds the JSON tree of steps.

    Expected schema::

        {
            "trigger": {"type": "manual"},
            "variables": {"foo": "bar"},
            "steps": [
                {"id": "s1", "type": "action", "connector": "http.request",
                 "inputs": {"method": "GET", "url": "https://api.example.com"}},
                {"id": "s2", "type": "condition",
                 "condition": "{{ steps.s1.output.status }} == 200",
                 "then": [...],
                 "else": [...]}
            ]
        }
    """

    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    color = models.CharField(
        max_length=7, blank=True, default="",
        help_text="Optional category colour (hex), e.g. #008ECF",
    )
    definition = models.JSONField(default=dict, blank=True)
    is_active = models.BooleanField(default=True)
    schedule = models.CharField(
        max_length=100,
        blank=True,
        help_text="Cron expression (5 fields). Leave blank for manual-only.",
    )

    webhook_enabled = models.BooleanField(default=False)
    webhook_token = models.CharField(
        max_length=64,
        unique=True,
        null=True,
        blank=True,
        help_text="Auto-generated when webhook_enabled is set.",
    )

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="flows",
    )
    periodic_task = models.OneToOneField(
        "django_celery_beat.PeriodicTask",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="flow",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-updated_at"]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.webhook_enabled and not self.webhook_token:
            self.webhook_token = _new_webhook_token()
        super().save(*args, **kwargs)


class Connection(models.Model):
    """Reusable named credential bag for a connector type. Encrypted at rest."""

    name = models.CharField(max_length=200, unique=True)
    connector_type = models.CharField(max_length=100)
    config = EncryptedJSONField(blank=True, default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.connector_type})"
