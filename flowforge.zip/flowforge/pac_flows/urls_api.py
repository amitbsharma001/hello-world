from rest_framework.routers import DefaultRouter

from .views import ConnectionViewSet, ConnectorCatalogView, FlowViewSet
from django.urls import path

router = DefaultRouter()
router.register("flows", FlowViewSet, basename="api-flow")
router.register("connections", ConnectionViewSet, basename="api-connection")

urlpatterns = router.urls + [
    path("connectors/", ConnectorCatalogView.as_view(), name="api-connectors"),
]
