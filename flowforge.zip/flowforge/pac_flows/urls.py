from django.urls import path

from . import views

urlpatterns = [
    path("", views.flow_list, name="flow-list"),
    path("new/", views.flow_new, name="flow-new"),
    path("<int:pk>/", views.flow_detail, name="flow-detail"),
    path("<int:pk>/edit/", views.flow_edit, name="flow-edit"),
    path("<int:pk>/builder/", views.flow_builder, name="flow-builder"),
    path("<int:pk>/trigger/", views.flow_trigger, name="flow-trigger"),
    path("<int:pk>/delete/", views.flow_delete, name="flow-delete"),
    path("<int:pk>/rotate-webhook/", views.flow_rotate_webhook, name="flow-rotate-webhook"),
]
