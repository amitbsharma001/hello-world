"""
Bridge between ``Flow.schedule`` and django-celery-beat's PeriodicTask.

Calling :func:`sync_schedule` is idempotent. It deletes a stale PeriodicTask
if one is attached, and creates a fresh one when the flow is active and has
a valid cron expression.
"""
import json

from croniter import croniter
from django_celery_beat.models import CrontabSchedule, PeriodicTask


def sync_schedule(flow):
    # Drop existing schedule first
    if flow.periodic_task_id:
        try:
            flow.periodic_task.delete()
        except Exception:  # noqa: BLE001 - already gone
            pass
        flow.periodic_task = None

    if not (flow.is_active and flow.schedule.strip()):
        # Persist the cleared link without re-firing post_save side effects
        type(flow).objects.filter(pk=flow.pk).update(periodic_task=None)
        return

    cron_expr = flow.schedule.strip()
    if not croniter.is_valid(cron_expr):
        raise ValueError(f"Invalid cron expression: {cron_expr!r}")

    parts = cron_expr.split()
    if len(parts) != 5:
        raise ValueError("Cron expression must have exactly 5 fields")
    minute, hour, day_of_month, month_of_year, day_of_week = parts

    crontab, _ = CrontabSchedule.objects.get_or_create(
        minute=minute,
        hour=hour,
        day_of_month=day_of_month,
        month_of_year=month_of_year,
        day_of_week=day_of_week,
    )

    pt = PeriodicTask.objects.create(
        crontab=crontab,
        name=f"flow-{flow.pk}-{flow.name}"[:200],
        task="pac_engine.trigger_scheduled_flow",
        args=json.dumps([flow.pk]),
        enabled=True,
    )

    type(flow).objects.filter(pk=flow.pk).update(periodic_task=pt)
