from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_http_methods

from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from pac_engine.connectors import list_connectors
from pac_engine.schemas import build_catalog

from pac_runs.models import FlowRun
from pac_runs.serializers import FlowRunSerializer

from .forms import FlowForm
from .models import Connection, Flow
from .serializers import ConnectionSerializer, FlowSerializer


# ---------------------------------------------------------------------------
# REST API
# ---------------------------------------------------------------------------
class FlowViewSet(viewsets.ModelViewSet):
    queryset = Flow.objects.all()
    serializer_class = FlowSerializer

    @action(detail=True, methods=["post"])
    def trigger(self, request, pk=None):
        """Manually trigger a flow. POST body becomes ``trigger.body`` in expressions."""
        from pac_engine.tasks import execute_flow_run_task

        flow = self.get_object()
        if not flow.is_active:
            return Response({"detail": "Flow is inactive"}, status=status.HTTP_400_BAD_REQUEST)
        run = FlowRun.objects.create(
            flow=flow,
            trigger_type="manual",
            trigger_data={"body": request.data or {}},
        )
        execute_flow_run_task.delay(run.id)
        return Response(FlowRunSerializer(run).data, status=status.HTTP_202_ACCEPTED)

    @action(detail=True, methods=["get"])
    def runs(self, request, pk=None):
        flow = self.get_object()
        qs = flow.runs.order_by("-created_at")[:50]
        return Response(FlowRunSerializer(qs, many=True).data)


class ConnectionViewSet(viewsets.ModelViewSet):
    queryset = Connection.objects.all()
    serializer_class = ConnectionSerializer


class ConnectorCatalogView(APIView):
    """GET /api/connectors/ — the connector registry plus field schemas.

    Powers the visual builder's connector dropdown and schema-driven
    inspector forms. Connectors without a schema return an empty
    ``fields`` list and fall back to a raw JSON editor in the UI.
    """

    def get(self, request):
        return Response({"connectors": build_catalog(list_connectors())})


# ---------------------------------------------------------------------------
# HTML UI
# ---------------------------------------------------------------------------
def flow_list(request):
    from django.db.models import Count, Q
    from pac_runs.models import FlowRun, Status
    flows = Flow.objects.all()
    runs = FlowRun.objects.all()
    total_runs = runs.count()
    succeeded = runs.filter(status=Status.SUCCEEDED).count()
    failed = runs.filter(status=Status.FAILED).count()
    success_rate = round(100 * succeeded / total_runs) if total_runs else None
    stats = {
        "flows": flows.count(),
        "active": flows.filter(is_active=True).count(),
        "runs": total_runs,
        "failed": failed,
        "success_rate": success_rate,
    }
    return render(request, "pac_flows/list.html", {"flows": flows, "stats": stats})


def flow_new(request):
    if request.method == "POST":
        form = FlowForm(request.POST)
        if form.is_valid():
            flow = form.save()
            messages.success(request, f"Created flow {flow.name!r}.")
            return redirect(reverse("flow-detail", args=[flow.pk]))
    else:
        form = FlowForm()
    return render(request, "pac_flows/edit.html", {"form": form, "flow": None})


def flow_detail(request, pk):
    flow = get_object_or_404(Flow, pk=pk)
    recent_runs = flow.runs.order_by("-created_at")[:20]
    return render(request, "pac_flows/detail.html", {"flow": flow, "recent_runs": recent_runs})


def flow_edit(request, pk):
    flow = get_object_or_404(Flow, pk=pk)
    if request.method == "POST":
        form = FlowForm(request.POST, instance=flow)
        if form.is_valid():
            form.save()
            messages.success(request, "Saved.")
            return redirect(reverse("flow-detail", args=[flow.pk]))
    else:
        form = FlowForm(instance=flow)
    return render(request, "pac_flows/edit.html", {"form": form, "flow": flow})


def flow_builder(request, pk):
    """Visual drag-and-drop flow builder. All interactivity happens client-side
    via builder.js; saves go through the existing REST API."""
    flow = get_object_or_404(Flow, pk=pk)
    flow_json = {
        "id": flow.pk,
        "name": flow.name,
        "description": flow.description or "",
        "is_active": flow.is_active,
        "schedule": flow.schedule or "",
        "webhook_enabled": flow.webhook_enabled,
        "definition": flow.definition or {"trigger": {"type": "manual"}, "steps": []},
    }
    catalog = build_catalog(list_connectors())
    # Sample outputs from the most recent run, so the builder's data picker can
    # show real field names for each upstream step.
    samples = {}
    last = FlowRun.objects.filter(flow=flow).order_by("-id").first()
    if last:
        for sid, info in (last.output or {}).get("steps", {}).items():
            if isinstance(info, dict) and "output" in info:
                samples[sid] = info["output"]
        if last.trigger_data:
            samples["__trigger__"] = last.trigger_data
    return render(request, "pac_flows/builder.html",
                  {"flow": flow, "flow_json": flow_json, "catalog": catalog,
                   "step_samples": samples})


@require_http_methods(["POST"])
def flow_trigger(request, pk):
    from pac_engine.tasks import execute_flow_run_task

    flow = get_object_or_404(Flow, pk=pk)
    if not flow.is_active:
        messages.error(request, "Flow is inactive.")
        return redirect(reverse("flow-detail", args=[flow.pk]))
    run = FlowRun.objects.create(
        flow=flow,
        trigger_type="manual",
        trigger_data={"body": {}},
    )
    execute_flow_run_task.delay(run.id)
    messages.success(request, f"Run #{run.id} queued.")
    return redirect(reverse("run-detail", args=[run.id]))


@require_http_methods(["POST"])
def flow_delete(request, pk):
    flow = get_object_or_404(Flow, pk=pk)
    flow.delete()
    messages.success(request, "Flow deleted.")
    return redirect(reverse("flow-list"))


@require_http_methods(["POST"])
def flow_rotate_webhook(request, pk):
    from .models import _new_webhook_token

    flow = get_object_or_404(Flow, pk=pk)
    flow.webhook_enabled = True
    flow.webhook_token = _new_webhook_token()
    flow.save()
    messages.success(request, "Webhook URL regenerated.")
    return redirect(reverse("flow-detail", args=[flow.pk]))


# ---------------------------------------------------------------------------
# Webhook trigger (public, token-authenticated)
# ---------------------------------------------------------------------------
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json


@csrf_exempt
@require_http_methods(["POST", "GET"])
def webhook_trigger(request, token):
    """
    Public endpoint that fires a flow when posted to.

    URL: /webhooks/<token>/

    Body (any JSON) becomes ``{{ trigger.body }}`` in the flow.
    Headers and query params are exposed at ``{{ trigger.headers }}``
    and ``{{ trigger.query }}``.
    """
    from pac_engine.tasks import execute_flow_run_task

    try:
        flow = Flow.objects.get(webhook_token=token, webhook_enabled=True, is_active=True)
    except Flow.DoesNotExist:
        return JsonResponse({"detail": "Unknown or disabled webhook"}, status=404)

    body = {}
    if request.method == "POST":
        ctype = request.headers.get("Content-Type", "")
        if "application/json" in ctype:
            try:
                body = json.loads(request.body.decode() or "{}")
            except json.JSONDecodeError:
                return JsonResponse({"detail": "Invalid JSON"}, status=400)
        else:
            body = dict(request.POST.items())

    run = FlowRun.objects.create(
        flow=flow,
        trigger_type="webhook",
        trigger_data={
            "body": body,
            "headers": {k: v for k, v in request.headers.items()},
            "query": dict(request.GET.items()),
        },
    )
    execute_flow_run_task.delay(run.id)
    return JsonResponse({"run_id": run.id, "status": "accepted"}, status=202)
