from django.apps import AppConfig


class FlowsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "pac_flows"

    def ready(self):
        from . import signals  # noqa: F401
