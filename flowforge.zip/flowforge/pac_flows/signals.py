from django.db.models.signals import post_save, pre_delete
from django.dispatch import receiver

from .models import Flow
from .schedule import sync_schedule


@receiver(post_save, sender=Flow)
def flow_post_save(sender, instance, update_fields=None, **kwargs):
    # Avoid recursion: schedule.py uses .update() so post_save isn't fired,
    # but defensively short-circuit if only the link field changed.
    if update_fields and set(update_fields) == {"periodic_task"}:
        return
    sync_schedule(instance)


@receiver(pre_delete, sender=Flow)
def flow_pre_delete(sender, instance, **kwargs):
    if instance.periodic_task_id:
        try:
            instance.periodic_task.delete()
        except Exception:  # noqa: BLE001
            pass
