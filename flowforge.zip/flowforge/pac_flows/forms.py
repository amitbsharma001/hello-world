import json

from django import forms

from .models import Flow


class FlowForm(forms.ModelForm):
    definition_text = forms.CharField(
        widget=forms.Textarea(attrs={"rows": 24, "class": "mono"}),
        required=False,
        label="Definition (JSON)",
    )

    class Meta:
        model = Flow
        fields = ["name", "description", "color", "is_active", "schedule", "webhook_enabled"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields["definition_text"].initial = json.dumps(
                self.instance.definition or {}, indent=2
            )
        else:
            self.fields["definition_text"].initial = json.dumps(
                {
                    "trigger": {"type": "manual"},
                    "variables": {},
                    "steps": [],
                },
                indent=2,
            )

    def clean_definition_text(self):
        raw = self.cleaned_data["definition_text"] or "{}"
        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            raise forms.ValidationError(f"Invalid JSON: {e}")

    def save(self, commit=True):
        flow = super().save(commit=False)
        flow.definition = self.cleaned_data["definition_text"]
        if commit:
            flow.save()
        return flow
