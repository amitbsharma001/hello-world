from django.contrib import admin

from .models import Connection, Flow


@admin.register(Flow)
class FlowAdmin(admin.ModelAdmin):
    list_display = ("name", "is_active", "schedule", "updated_at")
    list_filter = ("is_active",)
    search_fields = ("name", "description")
    readonly_fields = ("created_at", "updated_at", "periodic_task")


@admin.register(Connection)
class ConnectionAdmin(admin.ModelAdmin):
    list_display = ("name", "connector_type", "created_at")
    search_fields = ("name",)
