"""
Celery tasks.

* ``engine.execute_flow_run`` runs a previously-created FlowRun.
* ``engine.trigger_scheduled_flow`` is invoked by Celery Beat (via
  django-celery-beat PeriodicTask) and creates a new FlowRun before
  delegating to ``execute_flow_run``.
"""
import logging

from celery import shared_task
from django.utils import timezone

logger = logging.getLogger("flowforge.tasks")


@shared_task(name="pac_engine.execute_flow_run", bind=True, max_retries=0)
def execute_flow_run_task(self, flow_run_id):
    from .executor import execute_run

    logger.info("Executing flow run %s", flow_run_id)
    execute_run(flow_run_id)


@shared_task(name="pac_engine.trigger_scheduled_flow", bind=True, max_retries=0)
def trigger_scheduled_flow(self, flow_id):
    from pac_flows.models import Flow
    from pac_runs.models import FlowRun

    try:
        flow = Flow.objects.get(pk=flow_id)
    except Flow.DoesNotExist:
        logger.warning("Scheduled flow %s no longer exists", flow_id)
        return

    if not flow.is_active:
        logger.info("Skipping scheduled flow %s (inactive)", flow_id)
        return

    run = FlowRun.objects.create(
        flow=flow,
        trigger_type="schedule",
        trigger_data={"fired_at": timezone.now().isoformat()},
    )
    execute_flow_run_task.delay(run.id)
