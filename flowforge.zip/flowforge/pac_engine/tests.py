"""
Engine test suite: expression evaluator, connector registry, the executor
(every step type), built-in connectors, and the schema catalog.
"""
from unittest import mock

from django.test import TestCase, override_settings

from pac_flows.models import Connection, Flow
from pac_runs.models import FlowRun, Status, StepRun
from pac_engine.connectors import (
    get_connector, list_connectors, register_connector, resolve_credentials,
)
from pac_engine.executor import execute_run
from pac_engine.expressions import evaluate, evaluate_condition, resolve
from pac_engine.schemas import build_catalog


def run_flow(definition, trigger_data=None):
    """Helper: create a flow + run it eagerly, returning the FlowRun."""
    flow = Flow.objects.create(name="t", definition=definition)
    fr = FlowRun.objects.create(
        flow=flow, trigger_type="manual", trigger_data=trigger_data or {}
    )
    return execute_run(fr.id)


# ===========================================================================
# Expressions
# ===========================================================================
class ExpressionTests(TestCase):
    def test_plain_interpolation(self):
        ctx = {"vars": {"name": "Amit"}, "steps": {}}
        self.assertEqual(resolve("Hello {{ vars.name }}", ctx), "Hello Amit")

    def test_numeric_and_comparison(self):
        ctx = {"steps": {"s1": {"output": {"status": 200}}}, "vars": {}}
        self.assertTrue(evaluate_condition("{{ steps.s1.output.status == 200 }}", ctx))
        self.assertFalse(evaluate_condition("{{ steps.s1.output.status == 404 }}", ctx))
        self.assertTrue(evaluate_condition("{{ steps.s1.output.status >= 200 }}", ctx))

    def test_nested_access_and_typed_return(self):
        ctx = {"vars": {"items": [10, 20, 30]}, "steps": {}}
        # A bare expression returns the typed value, not a string.
        self.assertEqual(resolve("{{ vars.items[1] }}", ctx), 20)

    def test_missing_key_is_safe(self):
        ctx = {"vars": {}, "steps": {}}
        # Missing keys resolve to empty rather than raising.
        self.assertIsNone(resolve("{{ vars.nope }}", ctx))

    def test_no_arbitrary_code_execution(self):
        ctx = {"vars": {}, "steps": {}}
        with self.assertRaises(Exception):
            evaluate("__import__('os').system('echo hi')", ctx)

    def test_resolve_walks_dicts_and_lists(self):
        ctx = {"vars": {"x": 5}, "steps": {}}
        out = resolve({"a": "{{ vars.x }}", "b": ["{{ vars.x }}", "lit"]}, ctx)
        self.assertEqual(out, {"a": 5, "b": [5, "lit"]})


# ===========================================================================
# Connector registry
# ===========================================================================
class RegistryTests(TestCase):
    def test_builtin_count_and_lookup(self):
        names = list_connectors()
        self.assertIn("http.request", names)
        self.assertIn("log.info", names)
        self.assertTrue(callable(get_connector("log.info")))

    def test_unknown_connector_raises(self):
        with self.assertRaises(Exception):
            get_connector("does.not.exist")

    def test_register_and_dispatch(self):
        @register_connector("test.echo")
        def _echo(inputs, context):
            return {"echoed": inputs.get("msg")}

        self.assertIn("test.echo", list_connectors())
        r = run_flow({"steps": [
            {"id": "e", "type": "action", "connector": "test.echo",
             "inputs": {"msg": "hi"}},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertEqual(r.output["steps"]["e"]["output"]["echoed"], "hi")

    def test_resolve_credentials_merges_connection(self):
        Connection.objects.create(
            name="creds1", connector_type="generic",
            config={"token": "secret", "base": "https://x"},
        )
        merged = resolve_credentials({"connection": "creds1", "base": "override"})
        self.assertEqual(merged["token"], "secret")
        self.assertEqual(merged["base"], "override")  # input wins

    def test_resolve_credentials_missing_connection(self):
        with self.assertRaises(ValueError):
            resolve_credentials({"connection": "nope"})


# ===========================================================================
# Executor — every step type
# ===========================================================================
class ExecutorTests(TestCase):
    def test_sequential_actions(self):
        r = run_flow({"steps": [
            {"id": "a", "type": "action", "connector": "log.info", "inputs": {"message": "1"}},
            {"id": "b", "type": "action", "connector": "log.info", "inputs": {"message": "2"}},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertEqual(StepRun.objects.filter(run=r).count(), 2)

    def test_condition_then_branch(self):
        r = run_flow({"steps": [
            {"id": "set", "type": "set_variable", "name": "x", "value": 10},
            {"id": "cond", "type": "condition", "condition": "{{ vars.x > 5 }}",
             "then": [{"id": "yes", "type": "set_variable", "name": "hit", "value": "then"}],
             "else": [{"id": "no", "type": "set_variable", "name": "hit", "value": "else"}]},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertEqual(r.output["vars"]["hit"], "then")

    def test_condition_else_branch(self):
        r = run_flow({"steps": [
            {"id": "set", "type": "set_variable", "name": "x", "value": 1},
            {"id": "cond", "type": "condition", "condition": "{{ vars.x > 5 }}",
             "then": [{"id": "yes", "type": "set_variable", "name": "hit", "value": "then"}],
             "else": [{"id": "no", "type": "set_variable", "name": "hit", "value": "else"}]},
        ]})
        self.assertEqual(r.output["vars"]["hit"], "else")

    def test_foreach(self):
        flow = Flow.objects.create(name="fe", definition={
            "variables": {"nums": [1, 2, 3]},
            "steps": [
                {"id": "loop", "type": "foreach", "items": "{{ vars.nums }}", "item_var": "n",
                 "steps": [{"id": "log", "type": "action", "connector": "log.info",
                            "inputs": {"message": "n={{ vars.n }}"}}]},
            ],
        })
        r2 = execute_run(FlowRun.objects.create(flow=flow, trigger_type="manual").id)
        self.assertEqual(r2.status, Status.SUCCEEDED)
        # 3 iterations of the inner log step
        self.assertEqual(StepRun.objects.filter(run=r2, step_id="log").count(), 3)

    def test_parallel(self):
        # Parallel branches use real threads; see ParallelExecutorTests
        # for the threaded assertion (needs TransactionTestCase).
        pass

    def test_try_catch_recovers(self):
        r = run_flow({"steps": [
            {"id": "wrap", "type": "try",
             "steps": [{"id": "boom", "type": "action", "connector": "python.exec",
                        "inputs": {"code": "raise ValueError('boom')"}}],
             "catch": [{"id": "caught", "type": "set_variable", "name": "handled", "value": True}],
             "finally": [{"id": "fin", "type": "set_variable", "name": "ran_finally", "value": True}]},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertTrue(r.output["vars"]["handled"])
        self.assertTrue(r.output["vars"]["ran_finally"])

    def test_terminate(self):
        r = run_flow({"steps": [
            {"id": "stop", "type": "terminate", "status": "succeeded", "message": "done early"},
            {"id": "never", "type": "set_variable", "name": "reached", "value": True},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertNotIn("reached", r.output["vars"])

    def test_compose_and_set_variable(self):
        r = run_flow({"steps": [
            {"id": "v", "type": "set_variable", "name": "greeting", "value": "hi"},
            {"id": "c", "type": "compose", "value": {"msg": "{{ vars.greeting }}", "n": 42}},
        ]})
        self.assertEqual(r.output["steps"]["c"]["output"]["msg"], "hi")
        self.assertEqual(r.output["steps"]["c"]["output"]["n"], 42)

    def test_failure_marks_run_failed(self):
        @register_connector("test.boom")
        def _boom(inputs, context):
            raise RuntimeError("kaboom")

        r = run_flow({"steps": [
            {"id": "boom", "type": "action", "connector": "test.boom", "inputs": {}},
        ]})
        self.assertEqual(r.status, Status.FAILED)
        self.assertIn("kaboom", r.error)

    def test_retry_then_succeed(self):
        calls = {"n": 0}

        @register_connector("test.flaky")
        def _flaky(inputs, context):
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("transient")
            return {"ok": True, "attempts": calls["n"]}

        r = run_flow({"steps": [
            {"id": "f", "type": "action", "connector": "test.flaky",
             "inputs": {}, "retry": {"max_attempts": 3, "delay_seconds": 0}},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertEqual(calls["n"], 3)

    def test_call_flow(self):
        sub = Flow.objects.create(name="sub", definition={
            "steps": [{"id": "s", "type": "compose", "value": {"from_sub": True}}],
        })
        parent = Flow.objects.create(name="parent", definition={
            "steps": [{"id": "call", "type": "call_flow", "flow": "sub", "input": {}}],
        })
        r = execute_run(FlowRun.objects.create(flow=parent, trigger_type="manual").id)
        self.assertEqual(r.status, Status.SUCCEEDED)


from django.test import TransactionTestCase


class ParallelExecutorTests(TransactionTestCase):
    """Parallel steps spawn real threads; TransactionTestCase commits rows so
    the worker threads' separate DB connections can see/write them."""

    def test_parallel_branches_all_run(self):
        flow = Flow.objects.create(name="par", definition={"steps": [
            {"id": "par", "type": "parallel", "branches": [
                [{"id": "a", "type": "action", "connector": "log.info", "inputs": {"message": "A"}}],
                [{"id": "b", "type": "action", "connector": "log.info", "inputs": {"message": "B"}}],
                [{"id": "c", "type": "action", "connector": "log.info", "inputs": {"message": "C"}}],
            ]},
        ]})
        r = execute_run(FlowRun.objects.create(flow=flow, trigger_type="manual").id)
        self.assertEqual(r.status, Status.SUCCEEDED)
        for sid in ("a", "b", "c"):
            self.assertTrue(StepRun.objects.filter(run=r, step_id=sid).exists())


# ===========================================================================
# Built-in connectors (no network)
# ===========================================================================
class ConnectorTests(TestCase):
    def test_csv_roundtrip(self):
        r = run_flow({"steps": [
            {"id": "p", "type": "action", "connector": "csv.parse",
             "inputs": {"text": "a,b\n1,2\n3,4"}},
            {"id": "s", "type": "action", "connector": "csv.stringify",
             "inputs": {"rows": "{{ steps.p.output.rows }}"}},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertEqual(r.output["steps"]["p"]["output"]["count"], 2)
        self.assertIn("a,b", r.output["steps"]["s"]["output"]["text"])

    def test_db_query(self):
        Flow.objects.create(name="extra1")
        r = run_flow({"steps": [
            {"id": "q", "type": "action", "connector": "db.query",
             "inputs": {"sql": "SELECT COUNT(*) AS n FROM pac_flows_flow"}},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertGreaterEqual(r.output["steps"]["q"]["output"]["rows"][0]["n"], 1)

    @override_settings(FLOWFORGE_ALLOW_DB_QUERY=False)
    def test_db_query_disabled(self):
        r = run_flow({"steps": [
            {"id": "q", "type": "action", "connector": "db.query",
             "inputs": {"sql": "SELECT 1"}},
        ]})
        self.assertEqual(r.status, Status.FAILED)

    def test_json_and_data_pick(self):
        r = run_flow({"steps": [
            {"id": "j", "type": "action", "connector": "json.parse",
             "inputs": {"text": '{"a": 1, "b": 2, "c": 3}'}},
            {"id": "pick", "type": "action", "connector": "data.pick",
             "inputs": {"data": "{{ steps.j.output.value }}", "keys": ["a", "c"]}},
        ]})
        self.assertEqual(r.status, Status.SUCCEEDED)

    def test_http_request_mocked(self):
        fake = mock.MagicMock()
        fake.status_code = 200
        fake.ok = True
        fake.url = "https://example.com"
        fake.json.return_value = {"hello": "world"}
        fake.headers = {"Content-Type": "application/json"}
        fake.text = '{"hello": "world"}'
        fake.elapsed.total_seconds.return_value = 0.05
        with mock.patch("requests.request", return_value=fake):
            r = run_flow({"steps": [
                {"id": "h", "type": "action", "connector": "http.request",
                 "inputs": {"method": "GET", "url": "https://example.com"}},
            ]})
        self.assertEqual(r.status, Status.SUCCEEDED)
        self.assertEqual(r.output["steps"]["h"]["output"]["status"], 200)

    @override_settings(FLOWFORGE_ALLOW_PYTHON_EXEC=False)
    def test_python_exec_disabled(self):
        r = run_flow({"steps": [
            {"id": "p", "type": "action", "connector": "python.exec",
             "inputs": {"code": "result = 1"}},
        ]})
        self.assertEqual(r.status, Status.FAILED)


# ===========================================================================
# Schema catalog
# ===========================================================================
class SchemaTests(TestCase):
    def test_catalog_covers_all_connectors(self):
        catalog = build_catalog(list_connectors())
        self.assertEqual(len(catalog), len(list_connectors()))
        names = {c["name"] for c in catalog}
        self.assertIn("http.request", names)

    def test_http_schema_has_typed_fields(self):
        catalog = {c["name"]: c for c in build_catalog(list_connectors())}
        http = catalog["http.request"]
        keys = {f["key"] for f in http["fields"]}
        self.assertIn("method", keys)
        self.assertIn("url", keys)
        method = next(f for f in http["fields"] if f["key"] == "method")
        self.assertEqual(method["type"], "select")

    def test_unknown_connector_falls_back_to_empty_fields(self):
        catalog = build_catalog(["totally.unknown"])
        self.assertEqual(catalog[0]["fields"], [])
