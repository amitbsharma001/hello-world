"""
Seed example flows so a fresh install has something runnable.

    python manage.py seed_flows
"""
from django.core.management.base import BaseCommand

from pac_flows.models import Flow


HTTPBIN_FLOW = {
    "trigger": {"type": "manual"},
    "variables": {"endpoint": "https://httpbin.org/get"},
    "steps": [
        {
            "id": "fetch",
            "type": "action",
            "connector": "http.request",
            "inputs": {
                "method": "GET",
                "url": "{{ vars.endpoint }}",
                "params": {"flow_id": "{{ flow_id }}", "run_id": "{{ run_id }}"},
            },
            "retry": {"max_attempts": 3, "delay_seconds": 1, "backoff": 2.0},
        },
        {
            "id": "check_ok",
            "type": "condition",
            "condition": "{{ steps.fetch.output.status == 200 }}",
            "then": [
                {
                    "id": "log_ok",
                    "type": "action",
                    "connector": "log.info",
                    "inputs": {"message": "OK from {{ vars.endpoint }}"},
                }
            ],
            "else": [
                {
                    "id": "log_bad",
                    "type": "action",
                    "connector": "log.error",
                    "inputs": {"message": "Bad status: {{ steps.fetch.output.status }}"},
                }
            ],
        },
        {
            "id": "summary",
            "type": "compose",
            "value": {
                "endpoint": "{{ vars.endpoint }}",
                "status": "{{ steps.fetch.output.status }}",
                "fetched_at": "{{ now() }}",
            },
        },
    ],
}


LOOP_FLOW = {
    "trigger": {"type": "manual"},
    "variables": {"users": ["alice", "bob", "carol"]},
    "steps": [
        {
            "id": "greet_each",
            "type": "foreach",
            "items": "{{ vars.users }}",
            "item_var": "user",
            "steps": [
                {
                    "id": "greet",
                    "type": "action",
                    "connector": "log.info",
                    "inputs": {"message": "Hello, {{ user }}!"},
                }
            ],
        }
    ],
}


PARALLEL_FLOW = {
    "trigger": {"type": "manual"},
    "steps": [
        {
            "id": "fanout",
            "type": "parallel",
            "branches": [
                [{"id": "a", "type": "action", "connector": "log.info",
                  "inputs": {"message": "branch A running"}}],
                [{"id": "b", "type": "action", "connector": "log.info",
                  "inputs": {"message": "branch B running"}}],
                [{"id": "c", "type": "action", "connector": "log.info",
                  "inputs": {"message": "branch C running"}}],
            ],
        },
        {"id": "done", "type": "compose",
         "value": {"completed_at": "{{ now() }}", "branches": 3}},
    ],
}


TRY_CATCH_FLOW = {
    "trigger": {"type": "manual"},
    "steps": [
        {
            "id": "wrap",
            "type": "try",
            "steps": [
                {"id": "fetch", "type": "action", "connector": "http.request",
                 "inputs": {"method": "GET", "url": "https://this-domain-does-not-exist.invalid"}},
            ],
            "catch": [
                {"id": "log_err", "type": "action", "connector": "log.error",
                 "inputs": {"message": "Caught {{ error.type }}: {{ error.message }}"}}
            ],
            "finally": [
                {"id": "cleanup", "type": "compose",
                 "value": {"cleaned_at": "{{ now() }}"}}
            ],
        },
        {"id": "after", "type": "action", "connector": "log.info",
         "inputs": {"message": "Flow continued past try/catch"}},
    ],
}


WEBHOOK_ECHO_FLOW = {
    "trigger": {"type": "webhook"},
    "steps": [
        {
            "id": "render",
            "type": "action",
            "connector": "text.template",
            "inputs": {
                "template": "Received from {{ get(trigger.headers, \"User-Agent\", \"?\") }}: {{ trigger.body }}",
            },
        },
        {
            "id": "echo",
            "type": "compose",
            "value": {
                "body": "{{ trigger.body }}",
                "summary": "{{ steps.render.output.text }}",
            },
        },
    ],
}


PYTHON_DEMO_FLOW = {
    "trigger": {"type": "manual"},
    "variables": {"prices": [101.2, 99.8, 102.5, 98.1, 105.4, 100.0, 97.7]},
    "steps": [
        {
            "id": "stats",
            "type": "action",
            "connector": "python.exec",
            "inputs": {
                "prices": "{{ vars.prices }}",
                "code": (
                    "prices = inputs['prices']\n"
                    "returns = [(prices[i] - prices[i-1]) / prices[i-1]\n"
                    "           for i in range(1, len(prices))]\n"
                    "result = {\n"
                    "    'mean': round(statistics.mean(prices), 2),\n"
                    "    'stdev': round(statistics.stdev(prices), 4),\n"
                    "    'volatility': round(statistics.stdev(returns), 4),\n"
                    "    'as_of': datetime.datetime.now().isoformat(),\n"
                    "}\n"
                ),
            },
        },
        {
            "id": "log_it",
            "type": "action",
            "connector": "log.info",
            "inputs": {"message": "Stats: {{ steps.stats.output.result }}"},
        },
    ],
}


class Command(BaseCommand):
    help = "Create example flows."

    def handle(self, *args, **options):
        seeds = [
            ("Demo: HTTPBin fetch + branch", HTTPBIN_FLOW, "", False),
            ("Demo: Foreach greeting",       LOOP_FLOW,     "", False),
            ("Demo: Parallel branches",      PARALLEL_FLOW, "", False),
            ("Demo: Try / catch / finally",  TRY_CATCH_FLOW, "", False),
            ("Demo: Webhook echo",           WEBHOOK_ECHO_FLOW, "", True),
            ("Demo: Python stats",           PYTHON_DEMO_FLOW, "", False),
        ]
        for name, defn, schedule, webhook in seeds:
            obj, was_created = Flow.objects.get_or_create(
                name=name,
                defaults={
                    "definition": defn,
                    "schedule": schedule,
                    "is_active": True,
                    "webhook_enabled": webhook,
                },
            )
            if not was_created:
                obj.definition = defn
                obj.schedule = schedule
                obj.is_active = True
                obj.webhook_enabled = webhook
                obj.save()
            verb = "Created" if was_created else "Updated"
            extra = f"  (webhook token: {obj.webhook_token})" if obj.webhook_enabled else ""
            self.stdout.write(self.style.SUCCESS(f"{verb} flow #{obj.id}: {obj.name}{extra}"))
