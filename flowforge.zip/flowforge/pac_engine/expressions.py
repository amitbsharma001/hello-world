"""
Expression resolution for step inputs and conditions.

Two entry points:

* :func:`resolve` walks a value (dict / list / str / scalar) and substitutes
  ``{{ expression }}`` interpolations against ``context``. If the entire
  string is a single expression, the native return type is preserved (so a
  resolved number stays a number, not a stringified one).
* :func:`evaluate_condition` evaluates a single boolean expression.

The expression grammar is a strict subset of Python operating on a
sandboxed AST: only attribute / subscript access, comparisons, boolean
logic, arithmetic, and a whitelist of built-in functions are permitted.
No imports, attribute writes, name binding, comprehensions, or
arbitrary calls.
"""
from __future__ import annotations

import ast
import re
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

_EXPR_RE = re.compile(r"\{\{\s*(.+?)\s*\}\}", re.DOTALL)
_FULL_EXPR_RE = re.compile(r"^\s*\{\{\s*(.+?)\s*\}\}\s*$", re.DOTALL)


# --- helpers exposed inside expressions -------------------------------------
def _now():
    return datetime.now(timezone.utc).isoformat()


def _uuid():
    return str(uuid4())


def _get(obj, key, default=None):
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(key, default)
    try:
        return obj[key]
    except (KeyError, IndexError, TypeError):
        return default


_FUNCTIONS: dict[str, Any] = {
    "len": len,
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "min": min,
    "max": max,
    "sum": sum,
    "abs": abs,
    "round": round,
    "now": _now,
    "uuid": _uuid,
    "lower": lambda s: str(s).lower(),
    "upper": lambda s: str(s).upper(),
    "trim": lambda s: str(s).strip(),
    "get": _get,
}


_ALLOWED_NODES = (
    ast.Expression,
    ast.Compare, ast.BoolOp, ast.UnaryOp, ast.BinOp,
    ast.Name, ast.Attribute, ast.Subscript, ast.Constant, ast.Load,
    ast.And, ast.Or, ast.Not,
    ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE,
    ast.In, ast.NotIn, ast.Is, ast.IsNot,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.FloorDiv, ast.Pow,
    ast.USub, ast.UAdd,
    ast.Call, ast.keyword,
    ast.List, ast.Dict, ast.Tuple, ast.Set,
    ast.IfExp,
)


def _eval(node: ast.AST, ctx: dict) -> Any:
    if isinstance(node, ast.Expression):
        return _eval(node.body, ctx)

    if isinstance(node, ast.Constant):
        return node.value

    if isinstance(node, ast.Name):
        if node.id in ctx:
            return ctx[node.id]
        if node.id in _FUNCTIONS:
            return _FUNCTIONS[node.id]
        if node.id in {"None", "True", "False"}:
            return {"None": None, "True": True, "False": False}[node.id]
        return None

    if isinstance(node, ast.Attribute):
        target = _eval(node.value, ctx)
        if target is None:
            return None
        if isinstance(target, dict):
            return target.get(node.attr)
        return getattr(target, node.attr, None)

    if isinstance(node, ast.Subscript):
        target = _eval(node.value, ctx)
        key = _eval(node.slice, ctx)
        if target is None:
            return None
        try:
            return target[key]
        except (KeyError, IndexError, TypeError):
            return None

    if isinstance(node, ast.UnaryOp):
        value = _eval(node.operand, ctx)
        if isinstance(node.op, ast.Not):
            return not value
        if isinstance(node.op, ast.USub):
            return -value
        if isinstance(node.op, ast.UAdd):
            return +value

    if isinstance(node, ast.BinOp):
        left = _eval(node.left, ctx)
        right = _eval(node.right, ctx)
        op = node.op
        if isinstance(op, ast.Add): return left + right
        if isinstance(op, ast.Sub): return left - right
        if isinstance(op, ast.Mult): return left * right
        if isinstance(op, ast.Div): return left / right
        if isinstance(op, ast.FloorDiv): return left // right
        if isinstance(op, ast.Mod): return left % right
        if isinstance(op, ast.Pow): return left ** right

    if isinstance(node, ast.BoolOp):
        values = [_eval(v, ctx) for v in node.values]
        if isinstance(node.op, ast.And):
            result = True
            for v in values:
                if not v:
                    return v
                result = v
            return result
        if isinstance(node.op, ast.Or):
            for v in values:
                if v:
                    return v
            return values[-1] if values else None

    if isinstance(node, ast.Compare):
        left = _eval(node.left, ctx)
        for op, comparator in zip(node.ops, node.comparators):
            right = _eval(comparator, ctx)
            if isinstance(op, ast.Eq):
                if not (left == right): return False
            elif isinstance(op, ast.NotEq):
                if not (left != right): return False
            elif isinstance(op, ast.Lt):
                if not (left < right): return False
            elif isinstance(op, ast.LtE):
                if not (left <= right): return False
            elif isinstance(op, ast.Gt):
                if not (left > right): return False
            elif isinstance(op, ast.GtE):
                if not (left >= right): return False
            elif isinstance(op, ast.In):
                if right is None or left not in right: return False
            elif isinstance(op, ast.NotIn):
                if right is not None and left in right: return False
            elif isinstance(op, ast.Is):
                if not (left is right): return False
            elif isinstance(op, ast.IsNot):
                if left is right: return False
            else:
                raise ValueError(f"Unsupported comparison: {op}")
            left = right
        return True

    if isinstance(node, ast.IfExp):
        return _eval(node.body, ctx) if _eval(node.test, ctx) else _eval(node.orelse, ctx)

    if isinstance(node, ast.Call):
        func = _eval(node.func, ctx)
        if not callable(func) or func not in _FUNCTIONS.values():
            raise ValueError("Only whitelisted functions may be called in expressions")
        args = [_eval(a, ctx) for a in node.args]
        kwargs = {kw.arg: _eval(kw.value, ctx) for kw in node.keywords}
        return func(*args, **kwargs)

    if isinstance(node, ast.List):
        return [_eval(e, ctx) for e in node.elts]
    if isinstance(node, ast.Tuple):
        return tuple(_eval(e, ctx) for e in node.elts)
    if isinstance(node, ast.Set):
        return {_eval(e, ctx) for e in node.elts}
    if isinstance(node, ast.Dict):
        return {_eval(k, ctx): _eval(v, ctx) for k, v in zip(node.keys, node.values)}

    raise ValueError(f"Unsupported expression node: {type(node).__name__}")


def _validate(tree: ast.AST) -> None:
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ValueError(
                f"Disallowed in expression: {type(node).__name__}"
            )


def evaluate(expr: str, context: dict) -> Any:
    """Parse and evaluate a single expression string (no braces)."""
    tree = ast.parse(expr, mode="eval")
    _validate(tree)
    return _eval(tree, context)


def evaluate_condition(expr: str, context: dict) -> bool:
    """Evaluate a condition. Accepts raw expression or ``{{ ... }}`` wrapped."""
    m = _FULL_EXPR_RE.match(expr)
    inner = m.group(1) if m else expr
    return bool(evaluate(inner, context))


def resolve(value: Any, context: dict) -> Any:
    """
    Recursively interpolate ``{{ ... }}`` expressions.

    If a string is *entirely* a single expression, the native value is
    returned (preserving numbers, dicts, booleans, etc.). Mixed text is
    substituted with ``str()`` of the resolved value.
    """
    if isinstance(value, str):
        m = _FULL_EXPR_RE.match(value)
        if m:
            return evaluate(m.group(1), context)

        def _sub(match):
            return str(evaluate(match.group(1), context))

        return _EXPR_RE.sub(_sub, value)
    if isinstance(value, dict):
        return {k: resolve(v, context) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve(v, context) for v in value]
    return value
