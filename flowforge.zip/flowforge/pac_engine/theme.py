"""
Config-driven UI theming.

All visual tokens (colours, radius, brand text) live here as defaults and
can be overridden from the host project's Django settings::

    # settings.py
    FLOWFORGE_THEME = {
        "primary":      "#e2001a",   # your brand colour
        "primary_700":  "#b30016",
        "brand_name":   "Acme Automate",
        "header_bg":    "#ffffff",
    }

Only the keys you set are overridden; everything else falls back to the
defaults below. The active theme is injected into every page as CSS
variables by :func:`theme_context` (a template context processor), so it
cascades across the whole UI including the visual builder.

You can also keep the palette in a standalone JSON/YAML file and load it
in settings, e.g.::

    import json, pathlib
    FLOWFORGE_THEME = json.loads(pathlib.Path("flowforge_theme.json").read_text())
"""
from __future__ import annotations

from django.conf import settings

# ---------------------------------------------------------------------------
# Default palette — a clean, neutral industrial/enterprise look.
# Swap `primary*` (and optionally `accent`) to rebrand the whole UI.
# ---------------------------------------------------------------------------
DEFAULT_THEME = {
    # Brand
    "brand_name":   "Flowforge",
    "brand_show":   True,          # show the brand name next to the logo

    # Primary / accent (drives buttons, links, active states, logo)
    "primary":      "#008ECF",
    "primary_600":  "#007ab4",
    "primary_700":  "#006391",
    "primary_ink":  "#ffffff",
    "primary_weak": "#e3f3fb",
    "accent":       "#00A8B0",     # secondary accent (turquoise)

    # Surfaces — white app background
    "bg":           "#ffffff",
    "surface":      "#ffffff",
    "surface_2":    "#f6f8fa",
    "surface_3":    "#eef2f5",

    # Header (its own knobs so you can do a dark or coloured top bar)
    "header_bg":    "#ffffff",
    "header_fg":    "#16202e",
    "header_border":"#e0e4e9",

    # Text
    "text":         "#16202e",
    "text_2":       "#3c4858",
    "muted":        "#5d6b7d",

    # Lines
    "border":       "#e0e4e9",
    "border_2":     "#cfd6dd",

    # Status (mapped to the palette: red + green)
    "ok":   "#5e9e16",  "ok_weak":   "#eef7e0",
    "warn": "#9a6700",  "warn_weak": "#fbf1d9",
    "err":  "#E20015",  "err_weak":  "#fde7e8",

    # Event-category palette (from the supplied colour configuration)
    "cat_1": "#ffffff",
    "cat_2": "#008ECF",
    "cat_3": "#E20015",
    "cat_4": "#B90276",
    "cat_5": "#78BE20",
    "cat_6": "#00A8B0",

    # Shape
    "radius":     "8px",
    "radius_sm":  "6px",
    "radius_lg":  "12px",

    # Typography (provide your own font stack; we do NOT bundle proprietary fonts)
    "font":  '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, '
             '"Helvetica Neue", Arial, sans-serif',
}

# Map theme keys -> CSS custom property names emitted into :root.
_CSS_VAR_MAP = {
    "primary": "--primary", "primary_600": "--primary-600", "primary_700": "--primary-700",
    "primary_ink": "--primary-ink", "primary_weak": "--primary-weak", "accent": "--cyan",
    "bg": "--bg", "surface": "--surface", "surface_2": "--surface-2", "surface_3": "--surface-3",
    "header_bg": "--header-bg", "header_fg": "--header-fg", "header_border": "--header-border",
    "text": "--text", "text_2": "--text-2", "muted": "--muted",
    "border": "--border", "border_2": "--border-2",
    "ok": "--ok", "ok_weak": "--ok-weak", "warn": "--warn", "warn_weak": "--warn-weak",
    "err": "--err", "err_weak": "--err-weak",
    "cat_1": "--cat-1", "cat_2": "--cat-2", "cat_3": "--cat-3",
    "cat_4": "--cat-4", "cat_5": "--cat-5", "cat_6": "--cat-6",
    "radius": "--radius", "radius_sm": "--radius-sm", "radius_lg": "--radius-lg",
    "font": "--font",
}


def get_theme() -> dict:
    """Return the effective theme (defaults merged with FLOWFORGE_THEME)."""
    overrides = getattr(settings, "FLOWFORGE_THEME", None) or {}
    merged = dict(DEFAULT_THEME)
    merged.update({k: v for k, v in overrides.items() if v is not None})
    return merged


def theme_css_vars(theme: dict | None = None) -> str:
    """Render the theme as a ``:root { --x: y; }`` CSS block."""
    theme = theme or get_theme()
    lines = []
    for key, css_var in _CSS_VAR_MAP.items():
        if key in theme and theme[key] != "":
            lines.append(f"  {css_var}: {theme[key]};")
    return ":root {\n" + "\n".join(lines) + "\n}"


def theme_context(request):
    """Template context processor: exposes ``theme`` and ``theme_css``."""
    theme = get_theme()
    return {"theme": theme, "theme_css": theme_css_vars(theme)}
