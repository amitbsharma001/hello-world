"""
Central configuration for Flowforge.

Reads ``FLOWFORGE_*`` keys from the host project's Django settings and
falls back to sane defaults, so a host application only has to set the
handful of values it actually wants to change.

Usage::

    from pac_engine.conf import conf
    if conf.ALLOW_PYTHON_EXEC:
        ...

Every attribute maps to a ``FLOWFORGE_<NAME>`` Django setting. Unknown
names raise ``AttributeError`` so typos surface quickly.
"""
from __future__ import annotations

from django.conf import settings

# name -> default value
_DEFAULTS = {
    # --- security toggles for powerful connectors -----------------------
    "ALLOW_PYTHON_EXEC": True,
    "ALLOW_DB_QUERY": True,
    "ALLOW_DB_EXECUTE": True,
    # --- redis.* connectors --------------------------------------------
    # Explicit Redis URL for the redis.* connectors. Intentionally NOT the
    # Celery broker URL — the broker may be RabbitMQ. Leave None to disable.
    "REDIS_URL": None,
    # --- credential encryption -----------------------------------------
    # Falls back to SECRET_KEY when None (see flows/fields.py).
    "ENCRYPTION_KEY": None,
    # --- logging --------------------------------------------------------
    "LOG_LEVEL": "INFO",
    # --- web layer ------------------------------------------------------
    # If you mount the UI at a non-root prefix, set this so generated
    # webhook URLs are shown correctly (informational only).
    "EXTERNAL_BASE_URL": None,
}


class _Conf:
    def __getattr__(self, name):
        django_key = f"FLOWFORGE_{name}"
        if hasattr(settings, django_key):
            return getattr(settings, django_key)
        if name in _DEFAULTS:
            return _DEFAULTS[name]
        raise AttributeError(
            f"Unknown Flowforge setting {name!r} "
            f"(set FLOWFORGE_{name} in Django settings, or check the spelling)"
        )

    def as_dict(self):
        """Return the effective config (defaults merged with overrides)."""
        return {k: getattr(self, k) for k in _DEFAULTS}


conf = _Conf()
