"""
Flowforge logging.

All Flowforge logging happens under the ``flowforge`` logger namespace:

    flowforge.executor   run lifecycle (start / finish / failure)
    flowforge.steps      per-step start / finish / retry
    flowforge.tasks      Celery task entry points
    flowforge.web        HTTP views + webhook receiver
    flowforge.flow       output from the log.* connectors (user messages)

Every record carries ``flow_id``, ``run_id`` and ``step_id`` attributes
(defaulting to ``-``) via :class:`RunContextFilter`, plus a compact
``ctx`` string the formatter can embed, e.g. ``[flow=3 run=42 step=fetch]``.

Host projects get this automatically in the standalone settings. To opt in
from your own settings, either copy ``LOGGING_CONFIG`` below or call
``configure_logging()`` from your settings module.
"""
from __future__ import annotations

import logging


class RunContextFilter(logging.Filter):
    """Ensure run-context attributes always exist and build a ``ctx`` string."""

    def filter(self, record: logging.LogRecord) -> bool:
        flow_id = getattr(record, "flow_id", None)
        run_id = getattr(record, "run_id", None)
        step_id = getattr(record, "step_id", None)
        record.flow_id = flow_id if flow_id is not None else "-"
        record.run_id = run_id if run_id is not None else "-"
        record.step_id = step_id if step_id is not None else "-"

        parts = []
        if flow_id is not None:
            parts.append(f"flow={flow_id}")
        if run_id is not None:
            parts.append(f"run={run_id}")
        if step_id is not None:
            parts.append(f"step={step_id}")
        record.ctx = f"[{' '.join(parts)}] " if parts else ""
        return True


def get_logger(name: str) -> logging.LoggerAdapter:
    """Return a logger under the ``flowforge`` namespace."""
    return logging.getLogger(f"flowforge.{name}")


def logging_config(level: str = "INFO") -> dict:
    """Return a ``dictConfig``-compatible LOGGING fragment for Flowforge.

    Merge this into your project's ``LOGGING`` (it only defines the
    ``flowforge`` logger plus its filter/formatter/handler, so it won't
    clobber your existing config)."""
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "filters": {
            "flowforge_ctx": {"()": "pac_engine.logging.RunContextFilter"},
        },
        "formatters": {
            "flowforge": {
                "format": "[{asctime}] {levelname:<7} {name} {ctx}{message}",
                "style": "{",
            },
        },
        "handlers": {
            "flowforge_console": {
                "class": "logging.StreamHandler",
                "formatter": "flowforge",
                "filters": ["flowforge_ctx"],
            },
        },
        "loggers": {
            "flowforge": {
                "handlers": ["flowforge_console"],
                "level": level,
                "propagate": False,
            },
        },
    }


def configure_logging(level: str = "INFO") -> None:
    """Apply the Flowforge logging config on top of whatever's configured.

    Safe to call from a host project's settings; uses ``incremental``-free
    ``dictConfig`` so it adds the ``flowforge`` logger without resetting
    the rest of the host's logging.
    """
    import logging.config
    logging.config.dictConfig(logging_config(level))
