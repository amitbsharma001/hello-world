"""GitHub connectors (REST API v3)."""
import requests

from ..connectors import register_connector, resolve_credentials

_API = "https://api.github.com"


def _headers(token):
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }


@register_connector("github.create_issue")
def github_create_issue(inputs, context):
    """
    Open an issue.

    Inputs (creds can come from a Connection):
      token:      GitHub PAT or app token (required)
      repo:       "owner/name" (required)
      title:      issue title (required)
      body:       issue body
      labels:     optional list of strings
      assignees:  optional list of usernames
    """
    creds = resolve_credentials(inputs)
    token = creds["token"]
    repo = creds["repo"]

    payload = {"title": creds["title"], "body": creds.get("body", "")}
    if creds.get("labels"):
        payload["labels"] = creds["labels"]
    if creds.get("assignees"):
        payload["assignees"] = creds["assignees"]

    resp = requests.post(f"{_API}/repos/{repo}/issues", json=payload,
                         headers=_headers(token), timeout=30)
    if not resp.ok:
        raise RuntimeError(f"github.create_issue failed: {resp.status_code} {resp.text[:300]}")
    out = resp.json()
    return {"number": out.get("number"), "url": out.get("html_url"), "id": out.get("id")}


@register_connector("github.dispatch_workflow")
def github_dispatch_workflow(inputs, context):
    """
    Trigger a workflow_dispatch event.

    Inputs:
      token:     GitHub token with 'actions:write' (required)
      repo:      "owner/name" (required)
      workflow:  workflow file name or id, e.g. "deploy.yml" (required)
      ref:       branch/tag to run on (default "main")
      inputs:    optional dict of workflow inputs
    """
    creds = resolve_credentials(inputs)
    token = creds["token"]
    repo = creds["repo"]
    workflow = creds["workflow"]

    payload = {"ref": creds.get("ref", "main")}
    if creds.get("inputs"):
        payload["inputs"] = creds["inputs"]

    resp = requests.post(
        f"{_API}/repos/{repo}/actions/workflows/{workflow}/dispatches",
        json=payload, headers=_headers(token), timeout=30,
    )
    if not resp.ok:
        raise RuntimeError(f"github.dispatch_workflow failed: {resp.status_code} {resp.text[:300]}")
    return {"dispatched": True, "workflow": workflow, "ref": payload["ref"]}
