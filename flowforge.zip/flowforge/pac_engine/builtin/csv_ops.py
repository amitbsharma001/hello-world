"""
CSV connectors. Uses Python's built-in ``csv`` module.

Connectors:
  csv.parse      Parse a CSV string into rows (with or without header).
  csv.stringify  Serialise a list of rows to a CSV string.
"""
from __future__ import annotations

import csv as _csv
import io

from ..connectors import register_connector


@register_connector("csv.parse")
def csv_parse(inputs, context):
    """
    Parse a CSV string.

    Inputs:
      text:       the CSV body (required)
      delimiter:  field separator (default ",")
      quotechar:  quote character (default '"')
      header:     bool — if true (default), use the first row as keys and
                  return rows as dicts. If false, return rows as lists.
      skip_rows:  number of leading rows to skip before reading
    """
    text = inputs.get("text", "")
    delimiter = inputs.get("delimiter", ",")
    quotechar = inputs.get("quotechar", '"')
    has_header = inputs.get("header", True)
    skip_rows = int(inputs.get("skip_rows", 0))

    if not isinstance(text, str):
        raise ValueError("csv.parse 'text' must be a string")

    reader = _csv.reader(io.StringIO(text), delimiter=delimiter, quotechar=quotechar)
    rows = list(reader)
    if skip_rows:
        rows = rows[skip_rows:]
    if not rows:
        return {"rows": [], "headers": [], "count": 0}

    if has_header:
        headers = rows[0]
        data = [dict(zip(headers, row)) for row in rows[1:]]
        return {"headers": headers, "rows": data, "count": len(data)}
    return {"rows": rows, "count": len(rows)}


@register_connector("csv.stringify")
def csv_stringify(inputs, context):
    """
    Serialise rows to a CSV string.

    Inputs:
      rows:       list of dicts (header row inferred from first item's keys)
                  OR list of lists (no header written).
      delimiter:  field separator (default ",")
      quotechar:  quote character (default '"')
      headers:    explicit header list. If provided with dict rows, controls
                  column order and which keys to emit.
      lineterminator: line ending (default "\\n")
    """
    rows = inputs.get("rows") or []
    delimiter = inputs.get("delimiter", ",")
    quotechar = inputs.get("quotechar", '"')
    lineterminator = inputs.get("lineterminator", "\n")

    output = io.StringIO()
    if not rows:
        return {"text": ""}

    first = rows[0]
    if isinstance(first, dict):
        fieldnames = inputs.get("headers") or list(first.keys())
        writer = _csv.DictWriter(
            output, fieldnames=fieldnames,
            delimiter=delimiter, quotechar=quotechar,
            lineterminator=lineterminator,
            extrasaction="ignore",
        )
        writer.writeheader()
        for r in rows:
            writer.writerow(r)
    else:
        writer = _csv.writer(
            output,
            delimiter=delimiter, quotechar=quotechar,
            lineterminator=lineterminator,
        )
        if inputs.get("headers"):
            writer.writerow(inputs["headers"])
        for r in rows:
            writer.writerow(r)

    return {"text": output.getvalue(), "rows": len(rows)}
