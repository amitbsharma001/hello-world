"""
Microsoft Teams connectors.

Two ways to post to Teams:

* ``teams.webhook`` — POST to a per-channel Incoming Webhook URL.
  Simplest, no OAuth needed. Uses the MessageCard format.

* ``teams.send_channel_message`` — POST via Graph API to a specific
  channel. Needs OAuth credentials (delegated or app-only with
  ``ChannelMessage.Send`` permission). Supports HTML content.
"""
from __future__ import annotations

import requests

from ..connectors import register_connector, resolve_credentials
from . import _graph


@register_connector("teams.webhook")
def teams_webhook(inputs, context):
    """
    Post a message to a Teams channel via Incoming Webhook URL.

    Inputs:
      url:      webhook URL (required)
      text:     plain message text
      title:    optional card title
      color:    theme colour as hex without ``#`` (default 0078D4 = Microsoft blue)
      sections: optional list of MessageCard sections for richer cards
    """
    url = inputs["url"]
    text = inputs.get("text", "")
    title = inputs.get("title")
    color = inputs.get("color", "0078D4")

    payload = {
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        "themeColor": color,
        "text": text,
    }
    if title:
        payload["title"] = title
    if "sections" in inputs:
        payload["sections"] = inputs["sections"]
    if "potential_actions" in inputs:
        payload["potentialAction"] = inputs["potential_actions"]

    resp = requests.post(url, json=payload, timeout=float(inputs.get("timeout", 15)))
    return {
        "status": resp.status_code,
        "ok": resp.ok,
        "body": resp.text,
    }


@register_connector("teams.send_channel_message")
def teams_send_channel_message(inputs, context):
    """
    Send a message to a Teams channel via Graph API.

    Inputs (plus Graph auth fields, see _graph.py):
      team_id:      team GUID (required)
      channel_id:   channel ID, e.g. "19:abc@thread.tacv2" (required)
      content:      message body
      content_type: "text" (default) or "html"
      subject:      optional subject
      importance:   "normal" (default), "high", or "urgent"
    """
    creds = resolve_credentials(inputs)
    team_id = creds.get("team_id")
    channel_id = creds.get("channel_id")
    if not (team_id and channel_id):
        raise ValueError("teams.send_channel_message requires 'team_id' and 'channel_id'")

    payload = {
        "body": {
            "contentType": creds.get("content_type", "text"),
            "content": creds.get("content", ""),
        },
    }
    if creds.get("subject"):
        payload["subject"] = creds["subject"]
    if creds.get("importance"):
        payload["importance"] = creds["importance"]

    resp = _graph.graph_request(
        "POST",
        f"teams/{team_id}/channels/{channel_id}/messages",
        creds,
        json_body=payload,
    )
    if not resp.ok:
        raise RuntimeError(f"send_channel_message failed: {resp.status_code} {resp.text[:300]}")
    return {"message": resp.json()}
