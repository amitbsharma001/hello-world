"""
HTTP request connector.

Inputs:
  method:        GET/POST/PUT/PATCH/DELETE/... (default GET)
  url:           full URL (required)
  headers:       dict
  params:        query-string dict
  body:          dict/list (sent as JSON) or string (raw)
  form:          dict (sent as application/x-www-form-urlencoded)
                 OR list of [name, value, [filename, content, content_type]]
                 tuples for multipart uploads (advanced)
  timeout:       seconds (default 30)
  follow_redirects: bool (default True)
  verify_ssl:    bool (default True)
  auth:          one of
                   {"type": "basic", "username": "...", "password": "..."}
                   {"type": "bearer", "token": "..."}
                   {"type": "header", "name": "X-Api-Key", "value": "..."}

Returns:
  {status, ok, headers, body (parsed JSON or text), url (final URL)}
"""
import requests
from requests.auth import HTTPBasicAuth

from ..connectors import register_connector, resolve_credentials


@register_connector("http.request")
def http_request(inputs, context):
    inputs = resolve_credentials(inputs)

    method = (inputs.get("method") or "GET").upper()
    url = inputs["url"]
    headers = dict(inputs.get("headers") or {})
    params = inputs.get("params") or {}
    body = inputs.get("body")
    form = inputs.get("form")
    timeout = float(inputs.get("timeout", 30))
    follow_redirects = bool(inputs.get("follow_redirects", True))
    verify_ssl = bool(inputs.get("verify_ssl", True))
    auth_cfg = inputs.get("auth") or {}

    # Auth handling
    requests_auth = None
    auth_type = (auth_cfg.get("type") or "").lower()
    if auth_type == "basic":
        requests_auth = HTTPBasicAuth(auth_cfg["username"], auth_cfg["password"])
    elif auth_type == "bearer":
        headers.setdefault("Authorization", f"Bearer {auth_cfg['token']}")
    elif auth_type == "header":
        headers[auth_cfg["name"]] = auth_cfg["value"]

    kwargs = {
        "headers": headers,
        "params": params,
        "timeout": timeout,
        "allow_redirects": follow_redirects,
        "verify": verify_ssl,
        "auth": requests_auth,
    }

    # Body handling: form > body
    if form is not None:
        if isinstance(form, dict):
            kwargs["data"] = form
        else:
            # Assume multipart tuples
            kwargs["files"] = form
    elif body is not None:
        if isinstance(body, (dict, list)):
            kwargs["json"] = body
        elif isinstance(body, (bytes, bytearray)):
            kwargs["data"] = body
        else:
            kwargs["data"] = str(body)

    resp = requests.request(method, url, **kwargs)

    try:
        parsed = resp.json()
    except ValueError:
        parsed = None

    return {
        "status": resp.status_code,
        "ok": resp.ok,
        "url": resp.url,
        "headers": dict(resp.headers),
        "body": parsed if parsed is not None else resp.text,
        "elapsed_ms": int(resp.elapsed.total_seconds() * 1000),
    }


# Convenience alias matching Power Automate's "HTTP" / "Send request" naming.
@register_connector("request.send")
def request_send(inputs, context):
    """Alias for ``http.request`` with a Power-Automate-style name."""
    return http_request(inputs, context)
