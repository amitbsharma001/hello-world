"""Discord webhook connector."""
import requests

from ..connectors import register_connector


@register_connector("discord.webhook")
def discord_webhook(inputs, context):
    """
    Post a message to a Discord channel via webhook URL.

    Inputs:
      url:       Discord webhook URL (required)
      content:   message text
      username:  optional display-name override
      embeds:    optional list of Discord embed objects
    """
    url = inputs["url"]
    payload = {}
    if inputs.get("content"):
        payload["content"] = inputs["content"]
    if inputs.get("username"):
        payload["username"] = inputs["username"]
    if inputs.get("embeds"):
        payload["embeds"] = inputs["embeds"]

    resp = requests.post(url, json=payload, timeout=float(inputs.get("timeout", 15)))
    return {"status": resp.status_code, "ok": resp.ok, "body": resp.text}
