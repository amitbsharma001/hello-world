"""Email connector. Uses Django's configured email backend."""
from django.conf import settings
from django.core.mail import send_mail

from ..connectors import register_connector


@register_connector("email.send")
def email_send(inputs, context):
    subject = inputs["subject"]
    body = inputs["body"]
    to = inputs["to"]
    if isinstance(to, str):
        to = [to]
    from_email = inputs.get("from") or settings.DEFAULT_FROM_EMAIL
    sent = send_mail(subject, body, from_email, to, fail_silently=False)
    return {"sent": sent, "to": to}
