"""
SharePoint / OneDrive connectors via Microsoft Graph.

Connectors:
  sharepoint.upload_file       Upload (create or replace) a file
  sharepoint.download_file     Read a file's contents
  sharepoint.list_items        List children of a folder

Auth: see ``_graph.py``. Use a Connection row for `tenant_id`/`client_id`/`client_secret`.

Drive targeting:
  Pass one of (in order of precedence):
    drive_id       — specific drive GUID
    site_id        — SharePoint site GUID (uses its default drive)
    user           — UPN to operate on that user's OneDrive
  Otherwise defaults to the signed-in user's OneDrive (``me``).
"""
from __future__ import annotations

import json
from urllib.parse import quote

from ..connectors import register_connector, resolve_credentials
from . import _graph


def _drive_root(creds: dict) -> str:
    """Build the URL prefix that resolves to a drive's root, e.g. ``drives/{id}/root``."""
    drive_id = creds.get("drive_id")
    site_id = creds.get("site_id")
    user = creds.get("user")
    if drive_id:
        return f"drives/{drive_id}/root"
    if site_id:
        return f"sites/{site_id}/drive/root"
    if user and user != "me":
        return f"users/{user}/drive/root"
    return "me/drive/root"


def _path_segment(path: str) -> str:
    """URL-escape a SharePoint path while preserving slashes."""
    return quote(path.lstrip("/"), safe="/")


@register_connector("sharepoint.upload_file")
def sharepoint_upload(inputs, context):
    """
    Upload (create or replace) a file in SharePoint / OneDrive.

    Inputs:
      path:         destination path within the drive (e.g. "reports/2025-Q4.xlsx") (required)
      content:      string, bytes, dict, or list (dicts/lists serialised as JSON)
      content_type: optional Content-Type override
      Plus drive targeting (see module docstring) and Graph auth fields.
    """
    creds = resolve_credentials(inputs)
    path = creds.get("path")
    if not path:
        raise ValueError("sharepoint.upload_file requires 'path'")

    content = creds.get("content", "")
    if isinstance(content, (dict, list)):
        content = json.dumps(content).encode()
    elif isinstance(content, str):
        content = content.encode()
    elif not isinstance(content, (bytes, bytearray)):
        content = str(content).encode()

    headers = {"Content-Type": creds.get("content_type", "application/octet-stream")}
    url_path = f"{_drive_root(creds)}:/{_path_segment(path)}:/content"

    resp = _graph.graph_request("PUT", url_path, creds, raw_body=content, headers=headers)
    if not resp.ok:
        raise RuntimeError(f"upload_file failed: {resp.status_code} {resp.text[:300]}")
    return {"item": resp.json(), "size": len(content)}


@register_connector("sharepoint.download_file")
def sharepoint_download(inputs, context):
    """
    Download a file's contents.

    Inputs:
      path:    path within the drive (required)
      as_text: if true (default), decode body as UTF-8 string. Otherwise
               returns base64-encoded bytes.

    Output: {path, content, content_type, size}
    """
    import base64

    creds = resolve_credentials(inputs)
    path = creds.get("path")
    if not path:
        raise ValueError("sharepoint.download_file requires 'path'")

    url_path = f"{_drive_root(creds)}:/{_path_segment(path)}:/content"
    resp = _graph.graph_request("GET", url_path, creds)
    if not resp.ok:
        raise RuntimeError(f"download_file failed: {resp.status_code} {resp.text[:300]}")

    as_text = creds.get("as_text", True)
    if as_text:
        try:
            content = resp.content.decode("utf-8")
        except UnicodeDecodeError:
            content = base64.b64encode(resp.content).decode("ascii")
    else:
        content = base64.b64encode(resp.content).decode("ascii")

    return {
        "path": path,
        "content": content,
        "content_type": resp.headers.get("Content-Type", ""),
        "size": len(resp.content),
    }


@register_connector("sharepoint.list_items")
def sharepoint_list(inputs, context):
    """
    List children of a folder.

    Inputs:
      path:  folder path within the drive (empty string = drive root)
      top:   max items (default 100)
    """
    creds = resolve_credentials(inputs)
    path = creds.get("path", "")
    top = int(creds.get("top", 100))

    if path:
        url_path = f"{_drive_root(creds)}:/{_path_segment(path)}:/children"
    else:
        url_path = f"{_drive_root(creds)}/children"

    resp = _graph.graph_request("GET", url_path, creds, params={"$top": top})
    if not resp.ok:
        raise RuntimeError(f"list_items failed: {resp.status_code} {resp.text[:300]}")
    data = resp.json()
    items = data.get("value", [])
    return {
        "count": len(items),
        "items": [
            {
                "id": it.get("id"),
                "name": it.get("name"),
                "size": it.get("size"),
                "is_folder": "folder" in it,
                "last_modified": it.get("lastModifiedDateTime"),
                "web_url": it.get("webUrl"),
            }
            for it in items
        ],
        "next_link": data.get("@odata.nextLink"),
    }
