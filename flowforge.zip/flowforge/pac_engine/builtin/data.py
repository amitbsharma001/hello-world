"""Data manipulation connectors."""
import json

from ..connectors import register_connector
from ..expressions import resolve


@register_connector("json.parse")
def json_parse(inputs, context):
    """Parse a JSON string into a Python object."""
    text = inputs.get("text", "")
    try:
        value = json.loads(text)
    except (ValueError, TypeError) as e:
        raise ValueError(f"Invalid JSON: {e}") from e
    return {"value": value}


@register_connector("json.stringify")
def json_stringify(inputs, context):
    """Serialise a value to a JSON string."""
    value = inputs.get("value")
    indent = inputs.get("indent")
    return {"text": json.dumps(value, indent=indent, default=str)}


@register_connector("text.template")
def text_template(inputs, context):
    """
    Render a template string with the current expression context.

    Useful for assembling a multi-line message from many pieces without
    cramming everything into one ``compose`` value::

        {"connector": "text.template",
         "inputs": {"template": "Hi {{ trigger.body.name }}, balance: {{ steps.fetch.output.body.amount }}"}}
    """
    tpl = inputs.get("template", "")
    rendered = resolve(tpl, context)
    return {"text": rendered}


@register_connector("data.pick")
def data_pick(inputs, context):
    """Pick a subset of keys from an input object."""
    source = inputs.get("source") or {}
    keys = inputs.get("keys") or []
    if not isinstance(source, dict):
        raise ValueError("'source' must be an object")
    return {"value": {k: source.get(k) for k in keys}}
