"""
Microsoft Outlook / Microsoft 365 connectors via the Graph API.

Auth: see ``_graph.py`` — supports both pre-acquired ``access_token`` and
client credentials (``tenant_id`` + ``client_id`` + ``client_secret``).
Credentials can come from a named ``Connection`` row.

Connectors:
  outlook.send_mail
  outlook.list_messages
  outlook.get_message
"""
from __future__ import annotations

from ..connectors import register_connector, resolve_credentials
from . import _graph


def _mailbox(creds: dict) -> str:
    """Return the mailbox URL segment: ``users/{user}`` or ``me``."""
    user = creds.get("user")
    if user and user != "me":
        return f"users/{user}"
    return "me"


@register_connector("outlook.send_mail")
def send_mail(inputs, context):
    """
    Send an email via Microsoft Graph.

    Inputs:
      to:         string or list (required)
      cc, bcc:    optional, same shape as ``to``
      subject:    string (required)
      body:       string
      body_type:  "Text" (default) or "HTML"
      user:       mailbox identity (UPN or "me"); defaults to "me" for
                  delegated tokens. With client_credentials you MUST set
                  this to a real UPN.
      save_to_sent_items: bool (default True)
    """
    creds = resolve_credentials(inputs)
    to = creds.get("to")
    subject = creds.get("subject")
    if not to or not subject:
        raise ValueError("outlook.send_mail requires 'to' and 'subject'")

    def _recipients(value):
        if value is None:
            return []
        if isinstance(value, str):
            value = [value]
        return [{"emailAddress": {"address": addr}} for addr in value]

    message = {
        "subject": subject,
        "body": {
            "contentType": creds.get("body_type", "Text"),
            "content": creds.get("body", ""),
        },
        "toRecipients": _recipients(to),
    }
    if creds.get("cc"):
        message["ccRecipients"] = _recipients(creds["cc"])
    if creds.get("bcc"):
        message["bccRecipients"] = _recipients(creds["bcc"])

    payload = {
        "message": message,
        "saveToSentItems": bool(creds.get("save_to_sent_items", True)),
    }

    resp = _graph.graph_request("POST", f"{_mailbox(creds)}/sendMail", creds, json_body=payload)
    if not resp.ok:
        raise RuntimeError(f"sendMail failed: {resp.status_code} {resp.text[:300]}")
    return {"sent": True, "status": resp.status_code, "to": to, "subject": subject}


@register_connector("outlook.list_messages")
def list_messages(inputs, context):
    """List messages in a mailbox / folder."""
    creds = resolve_credentials(inputs)
    folder = creds.get("folder", "inbox")
    params = {
        "$top": int(creds.get("top", 25)),
        "$orderby": creds.get("orderby", "receivedDateTime desc"),
    }
    if creds.get("filter"):
        params["$filter"] = creds["filter"]
    if creds.get("search"):
        params["$search"] = f'"{creds["search"]}"'

    resp = _graph.graph_request("GET", f"{_mailbox(creds)}/mailFolders/{folder}/messages",
                                creds, params=params)
    if not resp.ok:
        raise RuntimeError(f"list_messages failed: {resp.status_code} {resp.text[:300]}")
    data = resp.json()
    return {
        "count": len(data.get("value", [])),
        "messages": data.get("value", []),
        "next_link": data.get("@odata.nextLink"),
    }


@register_connector("outlook.get_message")
def get_message(inputs, context):
    """Fetch a single message by id. Inputs: ``message_id`` (required), ``user``."""
    creds = resolve_credentials(inputs)
    message_id = creds.get("message_id")
    if not message_id:
        raise ValueError("outlook.get_message requires 'message_id'")
    resp = _graph.graph_request("GET", f"{_mailbox(creds)}/messages/{message_id}", creds)
    if not resp.ok:
        raise RuntimeError(f"get_message failed: {resp.status_code} {resp.text[:300]}")
    return {"message": resp.json()}
