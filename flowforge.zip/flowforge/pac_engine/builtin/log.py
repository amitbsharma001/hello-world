"""Logging connectors."""
import logging

from ..connectors import register_connector

_log = logging.getLogger("flowforge.flow")


@register_connector("log.info")
def log_info(inputs, context):
    msg = inputs.get("message", "")
    _log.info("%s", msg)
    return {"level": "info", "message": msg}


@register_connector("log.error")
def log_error(inputs, context):
    msg = inputs.get("message", "")
    _log.error("%s", msg)
    return {"level": "error", "message": msg}


@register_connector("log.debug")
def log_debug(inputs, context):
    msg = inputs.get("message", "")
    _log.debug("%s", msg)
    return {"level": "debug", "message": msg}
