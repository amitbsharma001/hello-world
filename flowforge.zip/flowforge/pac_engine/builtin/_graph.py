"""
Shared Microsoft Graph helpers.

Used by ``outlook.py``, ``teams.py``, and ``sharepoint.py`` so all three
connectors share a single token cache. Tokens cached in-process per
``(tenant_id, client_id)`` until shortly before expiry.

Two auth modes:

1. **Pre-acquired token**: pass ``access_token`` directly. Useful when
   your Django app already runs an OIDC/PKCE flow (e.g. an Entra ID
   adapter) and has a valid delegated token.

2. **Client credentials**: pass ``tenant_id`` + ``client_id`` +
   ``client_secret``. Acquires a Graph token via the Microsoft identity
   platform.
"""
from __future__ import annotations

import threading
import time

import requests

GRAPH_BASE = "https://graph.microsoft.com/v1.0"
LOGIN_BASE = "https://login.microsoftonline.com"

_token_cache: dict[tuple, dict] = {}
_token_lock = threading.Lock()


def client_credentials_token(tenant_id: str, client_id: str, client_secret: str) -> str:
    """Acquire (or fetch from cache) an app-only access token."""
    cache_key = (tenant_id, client_id)
    now = time.time()
    with _token_lock:
        cached = _token_cache.get(cache_key)
        if cached and cached["expires_at"] - 60 > now:
            return cached["token"]

    url = f"{LOGIN_BASE}/{tenant_id}/oauth2/v2.0/token"
    resp = requests.post(
        url,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": "https://graph.microsoft.com/.default",
        },
        timeout=30,
    )
    if not resp.ok:
        raise RuntimeError(f"Graph token request failed: {resp.status_code} {resp.text}")
    data = resp.json()

    with _token_lock:
        _token_cache[cache_key] = {
            "token": data["access_token"],
            "expires_at": now + int(data.get("expires_in", 3600)),
        }
    return data["access_token"]


def get_token(creds: dict) -> str:
    """Resolve credentials dict to a bearer token (cached or freshly acquired)."""
    tok = creds.get("access_token")
    if tok:
        return tok
    tenant = creds.get("tenant_id")
    client = creds.get("client_id")
    secret = creds.get("client_secret")
    if not (tenant and client and secret):
        raise ValueError(
            "Microsoft Graph requires either 'access_token' or "
            "'tenant_id'+'client_id'+'client_secret' "
            "(directly or via a 'connection')"
        )
    return client_credentials_token(tenant, client, secret)


def graph_request(method, path, creds, *, json_body=None, params=None,
                  raw_body=None, headers=None, timeout=60):
    """Issue an authenticated Graph request and return the raw Response."""
    token = get_token(creds)
    final_headers = {"Authorization": f"Bearer {token}"}
    if json_body is not None:
        final_headers["Content-Type"] = "application/json"
    if headers:
        final_headers.update(headers)

    return requests.request(
        method,
        f"{GRAPH_BASE}/{path.lstrip('/')}",
        headers=final_headers,
        json=json_body,
        data=raw_body,
        params=params,
        timeout=timeout,
    )
