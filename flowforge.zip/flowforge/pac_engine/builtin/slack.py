"""Slack incoming-webhook connector."""
import requests

from ..connectors import register_connector


@register_connector("slack.webhook")
def slack_webhook(inputs, context):
    """
    Post a message to a Slack Incoming Webhook URL.

    Inputs:
      url:      the webhook URL (required)
      text:     plain-text message
      blocks:   optional Block Kit payload (overrides text formatting)
      channel:  optional channel override (only honoured by legacy webhooks)
      username: optional username override
    """
    url = inputs["url"]
    payload = {}
    if "text" in inputs:
        payload["text"] = inputs["text"]
    if "blocks" in inputs:
        payload["blocks"] = inputs["blocks"]
    if "channel" in inputs:
        payload["channel"] = inputs["channel"]
    if "username" in inputs:
        payload["username"] = inputs["username"]

    resp = requests.post(url, json=payload, timeout=float(inputs.get("timeout", 15)))
    return {
        "status": resp.status_code,
        "ok": resp.ok,
        "body": resp.text,
    }
