"""
Redis connectors — useful for sharing state between flow runs,
deduplication, rate-limit counters, and lightweight caching.

Connection URL resolution order:
  1. inputs["url"]
  2. settings.FLOWFORGE_REDIS_URL

NOTE: these connectors do NOT fall back to the Celery broker URL, because
the broker may be RabbitMQ (amqp://). If you want to use redis.* you must
point them at a real Redis instance via one of the two options above.
"""
import importlib

from ..conf import conf
from ..connectors import register_connector, resolve_credentials


def _client(creds):
    try:
        _redis = importlib.import_module("redis")
    except ImportError as e:  # pragma: no cover
        raise RuntimeError(
            "redis.* connectors require the 'redis' package. "
            "Install it with: pip install redis"
        ) from e
    url = creds.get("url") or conf.REDIS_URL
    if not url:
        raise ValueError(
            "redis.* needs a Redis URL — pass 'url' in the step inputs "
            "or set FLOWFORGE_REDIS_URL in Django settings"
        )
    return _redis.from_url(url, decode_responses=True)


@register_connector("redis.get")
def redis_get(inputs, context):
    """Get a value. Inputs: key (required), url. Output: {key, value, found}."""
    creds = resolve_credentials(inputs)
    key = creds["key"]
    value = _client(creds).get(key)
    return {"key": key, "value": value, "found": value is not None}


@register_connector("redis.set")
def redis_set(inputs, context):
    """
    Set a value. Inputs: key, value (required), ttl (seconds, optional),
    nx (only-if-absent, optional), url.
    """
    creds = resolve_credentials(inputs)
    key = creds["key"]
    value = creds["value"]
    if not isinstance(value, (str, int, float)):
        import json
        value = json.dumps(value)
    ttl = creds.get("ttl")
    nx = bool(creds.get("nx", False))
    ok = _client(creds).set(key, value, ex=int(ttl) if ttl else None, nx=nx)
    return {"key": key, "set": bool(ok)}


@register_connector("redis.delete")
def redis_delete(inputs, context):
    """Delete one or more keys. Inputs: key (string or list), url."""
    creds = resolve_credentials(inputs)
    key = creds["key"]
    keys = [key] if isinstance(key, str) else list(key)
    removed = _client(creds).delete(*keys)
    return {"deleted": removed}


@register_connector("redis.incr")
def redis_incr(inputs, context):
    """Atomically increment a counter. Inputs: key (required), amount (default 1), url."""
    creds = resolve_credentials(inputs)
    key = creds["key"]
    amount = int(creds.get("amount", 1))
    value = _client(creds).incrby(key, amount)
    return {"key": key, "value": value}
