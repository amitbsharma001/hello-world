"""
AI / LLM chat connector.

Provider-agnostic: works with any OpenAI-compatible chat completions
endpoint — OpenAI, Azure OpenAI, Groq, Together, Mistral, OpenRouter,
or a local Ollama/LM Studio server — by setting ``base_url``.
"""
import requests

from ..connectors import register_connector, resolve_credentials


@register_connector("ai.chat")
def ai_chat(inputs, context):
    """
    Call a chat-completions endpoint.

    Inputs (creds can come from a Connection):
      api_key:      bearer key (required for hosted providers)
      base_url:     API base (default "https://api.openai.com/v1")
      model:        model name (default "gpt-4o-mini")
      prompt:       a single user message (shortcut for messages)
      messages:     full chat array [{role, content}, ...] (overrides prompt)
      system:       optional system prompt prepended to messages
      temperature:  default 0.7
      max_tokens:   optional cap
      json_mode:    if true, request a JSON object response

    Output: {content, model, usage, finish_reason}
    """
    creds = resolve_credentials(inputs)
    api_key = creds.get("api_key")
    base_url = (creds.get("base_url") or "https://api.openai.com/v1").rstrip("/")
    model = creds.get("model", "gpt-4o-mini")

    messages = creds.get("messages")
    if not messages:
        prompt = creds.get("prompt")
        if not prompt:
            raise ValueError("ai.chat requires 'messages' or 'prompt'")
        messages = [{"role": "user", "content": prompt}]
    if creds.get("system"):
        messages = [{"role": "system", "content": creds["system"]}] + list(messages)

    payload = {
        "model": model,
        "messages": messages,
        "temperature": float(creds.get("temperature", 0.7)),
    }
    if creds.get("max_tokens"):
        payload["max_tokens"] = int(creds["max_tokens"])
    if creds.get("json_mode"):
        payload["response_format"] = {"type": "json_object"}

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    resp = requests.post(f"{base_url}/chat/completions", json=payload,
                         headers=headers, timeout=float(creds.get("timeout", 120)))
    if not resp.ok:
        raise RuntimeError(f"ai.chat failed: {resp.status_code} {resp.text[:300]}")
    data = resp.json()
    choice = (data.get("choices") or [{}])[0]
    return {
        "content": choice.get("message", {}).get("content", ""),
        "finish_reason": choice.get("finish_reason"),
        "model": data.get("model", model),
        "usage": data.get("usage"),
    }
