"""
S3 / object-storage connectors via boto3.

Works with any S3-compatible service: AWS, MinIO, Backblaze B2, Wasabi,
Cloudflare R2 — pass ``endpoint_url`` to point at non-AWS services.

Auth: pass credentials directly in ``inputs`` or via a ``Connection`` row:
  access_key_id, secret_access_key, region, endpoint_url (optional)

Or omit credentials entirely to use the boto3 default credential chain
(IAM role on EC2/ECS/Lambda, AWS_PROFILE, ~/.aws/credentials, etc).

Connectors:
  s3.upload     Upload a file
  s3.download   Download a file
  s3.list       List objects under a prefix
  s3.delete     Delete an object
"""
from __future__ import annotations

import base64
import json

from ..connectors import register_connector, resolve_credentials

try:
    import boto3
    from botocore.exceptions import ClientError, BotoCoreError
    _BOTO3_AVAILABLE = True
except ImportError:
    _BOTO3_AVAILABLE = False


def _require_boto3():
    if not _BOTO3_AVAILABLE:
        raise RuntimeError(
            "s3.* connectors require boto3. Install with: pip install boto3"
        )


def _make_client(creds: dict):
    _require_boto3()
    kwargs = {}
    if creds.get("access_key_id"):
        kwargs["aws_access_key_id"] = creds["access_key_id"]
    if creds.get("secret_access_key"):
        kwargs["aws_secret_access_key"] = creds["secret_access_key"]
    if creds.get("session_token"):
        kwargs["aws_session_token"] = creds["session_token"]
    if creds.get("region"):
        kwargs["region_name"] = creds["region"]
    if creds.get("endpoint_url"):
        kwargs["endpoint_url"] = creds["endpoint_url"]
    return boto3.client("s3", **kwargs)


@register_connector("s3.upload")
def s3_upload(inputs, context):
    """
    Upload an object.

    Inputs:
      bucket:        target bucket (required)
      key:           object key (required)
      body:          string, bytes, dict, or list (dicts/lists are JSON-encoded)
      content_type:  optional Content-Type
      metadata:      optional dict of x-amz-meta-* values
      acl:           optional ACL (e.g. "private", "public-read")
    """
    creds = resolve_credentials(inputs)
    client = _make_client(creds)

    bucket = creds.get("bucket")
    key = creds.get("key")
    if not (bucket and key):
        raise ValueError("s3.upload requires 'bucket' and 'key'")

    body = creds.get("body", "")
    if isinstance(body, (dict, list)):
        body = json.dumps(body).encode()
    elif isinstance(body, str):
        body = body.encode()
    elif not isinstance(body, (bytes, bytearray)):
        body = str(body).encode()

    extra = {}
    if creds.get("content_type"):
        extra["ContentType"] = creds["content_type"]
    if creds.get("metadata"):
        extra["Metadata"] = {str(k): str(v) for k, v in creds["metadata"].items()}
    if creds.get("acl"):
        extra["ACL"] = creds["acl"]

    try:
        client.put_object(Bucket=bucket, Key=key, Body=body, **extra)
    except (ClientError, BotoCoreError) as e:
        raise RuntimeError(f"s3.upload failed: {e}") from e

    return {"bucket": bucket, "key": key, "size": len(body)}


@register_connector("s3.download")
def s3_download(inputs, context):
    """
    Download an object.

    Inputs:
      bucket:  source bucket (required)
      key:     object key (required)
      as_text: if true (default), decode as UTF-8 string; else base64.
    """
    creds = resolve_credentials(inputs)
    client = _make_client(creds)

    bucket = creds.get("bucket")
    key = creds.get("key")
    if not (bucket and key):
        raise ValueError("s3.download requires 'bucket' and 'key'")

    try:
        resp = client.get_object(Bucket=bucket, Key=key)
    except (ClientError, BotoCoreError) as e:
        raise RuntimeError(f"s3.download failed: {e}") from e

    body = resp["Body"].read()
    as_text = creds.get("as_text", True)
    if as_text:
        try:
            content = body.decode("utf-8")
        except UnicodeDecodeError:
            content = base64.b64encode(body).decode("ascii")
    else:
        content = base64.b64encode(body).decode("ascii")

    return {
        "bucket": bucket,
        "key": key,
        "content": content,
        "content_type": resp.get("ContentType", ""),
        "size": len(body),
        "last_modified": resp["LastModified"].isoformat() if resp.get("LastModified") else None,
    }


@register_connector("s3.list")
def s3_list(inputs, context):
    """
    List objects under a prefix.

    Inputs:
      bucket:        bucket (required)
      prefix:        key prefix (default "")
      max_keys:      cap on items returned (default 1000)
      continuation:  optional pagination token from a previous call
    """
    creds = resolve_credentials(inputs)
    client = _make_client(creds)

    bucket = creds.get("bucket")
    if not bucket:
        raise ValueError("s3.list requires 'bucket'")

    kwargs = {
        "Bucket": bucket,
        "Prefix": creds.get("prefix", ""),
        "MaxKeys": int(creds.get("max_keys", 1000)),
    }
    if creds.get("continuation"):
        kwargs["ContinuationToken"] = creds["continuation"]

    try:
        resp = client.list_objects_v2(**kwargs)
    except (ClientError, BotoCoreError) as e:
        raise RuntimeError(f"s3.list failed: {e}") from e

    objects = [
        {
            "key": o["Key"],
            "size": o["Size"],
            "last_modified": o["LastModified"].isoformat(),
            "etag": o.get("ETag", "").strip('"'),
        }
        for o in resp.get("Contents", [])
    ]
    return {
        "bucket": bucket,
        "prefix": creds.get("prefix", ""),
        "count": len(objects),
        "objects": objects,
        "is_truncated": bool(resp.get("IsTruncated")),
        "next_continuation": resp.get("NextContinuationToken"),
    }


@register_connector("s3.delete")
def s3_delete(inputs, context):
    """Delete an object."""
    creds = resolve_credentials(inputs)
    client = _make_client(creds)
    bucket = creds.get("bucket")
    key = creds.get("key")
    if not (bucket and key):
        raise ValueError("s3.delete requires 'bucket' and 'key'")
    try:
        client.delete_object(Bucket=bucket, Key=key)
    except (ClientError, BotoCoreError) as e:
        raise RuntimeError(f"s3.delete failed: {e}") from e
    return {"deleted": True, "bucket": bucket, "key": key}
