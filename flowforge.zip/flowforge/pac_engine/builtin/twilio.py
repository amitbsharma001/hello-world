"""Twilio SMS connector (REST API, no SDK needed)."""
import requests

from ..connectors import register_connector, resolve_credentials


@register_connector("twilio.send_sms")
def twilio_send_sms(inputs, context):
    """
    Send an SMS via Twilio.

    Inputs (creds can come from a Connection):
      account_sid:  Twilio account SID (required)
      auth_token:   Twilio auth token (required)
      from:         sender number, e.g. "+14155552671" (required)
      to:           recipient number (required)
      body:         message text (required)
      messaging_service_sid: optional, use instead of 'from'
    """
    creds = resolve_credentials(inputs)
    account_sid = creds.get("account_sid")
    auth_token = creds.get("auth_token")
    to = creds.get("to")
    body = creds.get("body")
    if not (account_sid and auth_token and to and body):
        raise ValueError("twilio.send_sms requires account_sid, auth_token, to, body")

    data = {"To": to, "Body": body}
    if creds.get("messaging_service_sid"):
        data["MessagingServiceSid"] = creds["messaging_service_sid"]
    elif creds.get("from"):
        data["From"] = creds["from"]
    else:
        raise ValueError("twilio.send_sms requires 'from' or 'messaging_service_sid'")

    resp = requests.post(
        f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json",
        data=data,
        auth=(account_sid, auth_token),
        timeout=30,
    )
    if not resp.ok:
        raise RuntimeError(f"twilio.send_sms failed: {resp.status_code} {resp.text[:300]}")
    out = resp.json()
    return {"sid": out.get("sid"), "status": out.get("status"), "to": to}
