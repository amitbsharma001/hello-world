"""Jira Cloud connectors (REST API v3)."""
import requests

from ..connectors import register_connector, resolve_credentials


def _adf(text: str) -> dict:
    """Wrap plain text in Atlassian Document Format (required by API v3)."""
    return {
        "type": "doc",
        "version": 1,
        "content": [
            {"type": "paragraph", "content": [{"type": "text", "text": text or ""}]}
        ],
    }


@register_connector("jira.create_issue")
def jira_create_issue(inputs, context):
    """
    Create a Jira issue.

    Inputs (creds can come from a Connection):
      base_url:     e.g. "https://yourco.atlassian.net" (required)
      email:        Atlassian account email (required)
      api_token:    Atlassian API token (required)
      project_key:  e.g. "OPS" (required)
      summary:      issue title (required)
      description:  plain-text body
      issue_type:   default "Task"
      labels:       optional list of strings
    """
    creds = resolve_credentials(inputs)
    base_url = (creds.get("base_url") or "").rstrip("/")
    if not base_url:
        raise ValueError("jira.create_issue requires 'base_url'")
    auth = (creds.get("email"), creds.get("api_token"))

    fields = {
        "project": {"key": creds["project_key"]},
        "summary": creds["summary"],
        "description": _adf(creds.get("description", "")),
        "issuetype": {"name": creds.get("issue_type", "Task")},
    }
    if creds.get("labels"):
        fields["labels"] = creds["labels"]

    resp = requests.post(
        f"{base_url}/rest/api/3/issue",
        json={"fields": fields},
        auth=auth,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )
    if not resp.ok:
        raise RuntimeError(f"jira.create_issue failed: {resp.status_code} {resp.text[:300]}")
    out = resp.json()
    return {"key": out.get("key"), "id": out.get("id"), "url": f"{base_url}/browse/{out.get('key')}"}


@register_connector("jira.add_comment")
def jira_add_comment(inputs, context):
    """Add a comment to an issue. Inputs: base_url, email, api_token, issue_key, body."""
    creds = resolve_credentials(inputs)
    base_url = (creds.get("base_url") or "").rstrip("/")
    issue_key = creds["issue_key"]
    auth = (creds.get("email"), creds.get("api_token"))

    resp = requests.post(
        f"{base_url}/rest/api/3/issue/{issue_key}/comment",
        json={"body": _adf(creds.get("body", ""))},
        auth=auth,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )
    if not resp.ok:
        raise RuntimeError(f"jira.add_comment failed: {resp.status_code} {resp.text[:300]}")
    return {"id": resp.json().get("id"), "issue_key": issue_key}
