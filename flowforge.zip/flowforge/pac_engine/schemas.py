"""
Connector field schemas.

These drive the visual builder's structured inspector forms. Each entry
maps a connector name to display metadata plus a list of input ``fields``.

Field types understood by the builder:
  text       single-line input
  textarea   multi-line input
  code        monospace multi-line (for code / SQL / templates)
  number     numeric input
  boolean    checkbox
  select     dropdown (requires ``options``)
  keyvalue   key/value pair editor (renders to a JSON object)
  json       JSON editor (free-form object/array)
  list       comma-or-newline separated values (renders to a JSON array)

Field options:
  key         the inputs.* key it writes to (required)
  label       human label (required)
  type        one of the above (default "text")
  required    bool
  default     default value
  placeholder hint text
  help        small helper text shown under the field
  options     for select: list of allowed string values

Connectors without an entry here fall back to a raw JSON inputs editor in
the builder, so adding a schema is optional and additive.
"""

CONNECTOR_META = {
    # ---- HTTP & messaging --------------------------------------------------
    "http.request": {
        "category": "HTTP & messaging", "icon": "🌐", "label": "HTTP request",
        "fields": [
            {"key": "method", "label": "Method", "type": "select",
             "options": ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"], "default": "GET"},
            {"key": "url", "label": "URL", "type": "text", "required": True,
             "placeholder": "https://api.example.com/v1/resource"},
            {"key": "headers", "label": "Headers", "type": "keyvalue"},
            {"key": "params", "label": "Query params", "type": "keyvalue"},
            {"key": "body", "label": "Body (JSON)", "type": "json"},
            {"key": "timeout", "label": "Timeout (s)", "type": "number", "default": 30},
        ],
    },
    "slack.webhook": {
        "category": "HTTP & messaging", "icon": "💬", "label": "Slack webhook",
        "fields": [
            {"key": "url", "label": "Webhook URL", "type": "text", "required": True,
             "placeholder": "https://hooks.slack.com/services/..."},
            {"key": "text", "label": "Message", "type": "textarea", "required": True},
        ],
    },
    "discord.webhook": {
        "category": "HTTP & messaging", "icon": "🎮", "label": "Discord webhook",
        "fields": [
            {"key": "url", "label": "Webhook URL", "type": "text", "required": True},
            {"key": "content", "label": "Message", "type": "textarea", "required": True},
            {"key": "username", "label": "Username override", "type": "text"},
        ],
    },
    "email.send": {
        "category": "HTTP & messaging", "icon": "✉", "label": "Send email",
        "fields": [
            {"key": "to", "label": "To", "type": "text", "required": True,
             "placeholder": "someone@example.com"},
            {"key": "subject", "label": "Subject", "type": "text", "required": True},
            {"key": "body", "label": "Body", "type": "textarea", "required": True},
        ],
    },
    "twilio.send_sms": {
        "category": "HTTP & messaging", "icon": "📱", "label": "Twilio SMS",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text",
             "help": "Named Connection holding account_sid + auth_token"},
            {"key": "from", "label": "From number", "type": "text", "placeholder": "+14155552671"},
            {"key": "to", "label": "To number", "type": "text", "required": True},
            {"key": "body", "label": "Message", "type": "textarea", "required": True},
        ],
    },

    # ---- Microsoft 365 -----------------------------------------------------
    "outlook.send_mail": {
        "category": "Microsoft 365", "icon": "📧", "label": "Outlook send mail",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text",
             "help": "Named Connection with tenant_id/client_id/client_secret"},
            {"key": "user", "label": "Mailbox (UPN)", "type": "text", "placeholder": "alerts@contoso.com"},
            {"key": "to", "label": "To", "type": "text", "required": True},
            {"key": "cc", "label": "Cc", "type": "text"},
            {"key": "subject", "label": "Subject", "type": "text", "required": True},
            {"key": "body_type", "label": "Body type", "type": "select",
             "options": ["Text", "HTML"], "default": "Text"},
            {"key": "body", "label": "Body", "type": "textarea"},
        ],
    },
    "teams.webhook": {
        "category": "Microsoft 365", "icon": "💼", "label": "Teams webhook",
        "fields": [
            {"key": "url", "label": "Webhook URL", "type": "text", "required": True},
            {"key": "title", "label": "Title", "type": "text"},
            {"key": "text", "label": "Message", "type": "textarea", "required": True},
            {"key": "color", "label": "Theme colour (hex)", "type": "text", "default": "0078D4"},
        ],
    },
    "sharepoint.upload_file": {
        "category": "Microsoft 365", "icon": "📁", "label": "SharePoint upload",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text"},
            {"key": "site_id", "label": "Site ID", "type": "text"},
            {"key": "path", "label": "File path", "type": "text", "required": True,
             "placeholder": "Shared Documents/report.csv"},
            {"key": "content", "label": "Content", "type": "textarea"},
        ],
    },

    # ---- Database ----------------------------------------------------------
    "db.query": {
        "category": "Database", "icon": "🗄", "label": "DB query",
        "fields": [
            {"key": "sql", "label": "SQL (SELECT)", "type": "code", "required": True,
             "placeholder": "SELECT * FROM trades WHERE symbol = %s", "help": "Use %s placeholders"},
            {"key": "params", "label": "Params", "type": "json", "default": []},
            {"key": "using", "label": "DB alias", "type": "text", "default": "default"},
            {"key": "max_rows", "label": "Max rows", "type": "number", "default": 10000},
        ],
    },
    "db.execute": {
        "category": "Database", "icon": "🗄", "label": "DB execute",
        "fields": [
            {"key": "sql", "label": "SQL (write)", "type": "code", "required": True,
             "help": "INSERT / UPDATE / DELETE — use %s placeholders"},
            {"key": "params", "label": "Params", "type": "json", "default": []},
            {"key": "using", "label": "DB alias", "type": "text", "default": "default"},
        ],
    },

    # ---- Object storage ----------------------------------------------------
    "s3.upload": {
        "category": "Object storage", "icon": "☁", "label": "S3 upload",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text"},
            {"key": "bucket", "label": "Bucket", "type": "text", "required": True},
            {"key": "key", "label": "Key", "type": "text", "required": True,
             "placeholder": "reports/2025-q4.csv"},
            {"key": "body", "label": "Content", "type": "textarea"},
            {"key": "content_type", "label": "Content-Type", "type": "text",
             "placeholder": "text/csv"},
        ],
    },
    "s3.download": {
        "category": "Object storage", "icon": "☁", "label": "S3 download",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text"},
            {"key": "bucket", "label": "Bucket", "type": "text", "required": True},
            {"key": "key", "label": "Key", "type": "text", "required": True},
        ],
    },

    # ---- Code & data -------------------------------------------------------
    "python.exec": {
        "category": "Code & data", "icon": "🐍", "label": "Python code",
        "fields": [
            {"key": "code", "label": "Python", "type": "code", "required": True,
             "placeholder": "result = inputs['x'] * 2", "help": "Set `result` to return a value"},
        ],
    },
    "ai.chat": {
        "category": "Code & data", "icon": "🤖", "label": "AI / LLM chat",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text",
             "help": "Named Connection holding api_key (+ optional base_url)"},
            {"key": "model", "label": "Model", "type": "text", "default": "gpt-4o-mini"},
            {"key": "system", "label": "System prompt", "type": "textarea"},
            {"key": "prompt", "label": "User prompt", "type": "textarea", "required": True},
            {"key": "temperature", "label": "Temperature", "type": "number", "default": 0.7},
            {"key": "json_mode", "label": "JSON mode", "type": "boolean", "default": False},
        ],
    },
    "csv.parse": {
        "category": "Code & data", "icon": "📊", "label": "CSV parse",
        "fields": [
            {"key": "text", "label": "CSV text", "type": "textarea", "required": True},
            {"key": "delimiter", "label": "Delimiter", "type": "text", "default": ","},
            {"key": "header", "label": "First row is header", "type": "boolean", "default": True},
        ],
    },
    "text.template": {
        "category": "Code & data", "icon": "📄", "label": "Text template",
        "fields": [
            {"key": "template", "label": "Template", "type": "textarea", "required": True,
             "help": "Use {{ expressions }} for interpolation"},
        ],
    },
    "json.parse": {
        "category": "Code & data", "icon": "{}", "label": "JSON parse",
        "fields": [{"key": "text", "label": "JSON text", "type": "textarea", "required": True}],
    },

    # ---- Integrations ------------------------------------------------------
    "jira.create_issue": {
        "category": "Integrations", "icon": "🟦", "label": "Jira create issue",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text",
             "help": "Named Connection with base_url/email/api_token"},
            {"key": "project_key", "label": "Project key", "type": "text", "required": True,
             "placeholder": "OPS"},
            {"key": "summary", "label": "Summary", "type": "text", "required": True},
            {"key": "description", "label": "Description", "type": "textarea"},
            {"key": "issue_type", "label": "Issue type", "type": "select",
             "options": ["Task", "Bug", "Story", "Incident"], "default": "Task"},
        ],
    },
    "github.create_issue": {
        "category": "Integrations", "icon": "🐙", "label": "GitHub create issue",
        "fields": [
            {"key": "connection", "label": "Connection", "type": "text",
             "help": "Named Connection holding 'token'"},
            {"key": "repo", "label": "Repo", "type": "text", "required": True,
             "placeholder": "owner/name"},
            {"key": "title", "label": "Title", "type": "text", "required": True},
            {"key": "body", "label": "Body", "type": "textarea"},
            {"key": "labels", "label": "Labels", "type": "list"},
        ],
    },

    # ---- State / cache -----------------------------------------------------
    "redis.set": {
        "category": "State", "icon": "📮", "label": "Redis set",
        "fields": [
            {"key": "key", "label": "Key", "type": "text", "required": True},
            {"key": "value", "label": "Value", "type": "textarea", "required": True},
            {"key": "ttl", "label": "TTL (seconds)", "type": "number"},
        ],
    },
    "redis.get": {
        "category": "State", "icon": "📮", "label": "Redis get",
        "fields": [{"key": "key", "label": "Key", "type": "text", "required": True}],
    },

    # ---- Observability -----------------------------------------------------
    "log.info": {
        "category": "Observability", "icon": "📝", "label": "Log info",
        "fields": [{"key": "message", "label": "Message", "type": "textarea", "required": True}],
    },
    "log.error": {
        "category": "Observability", "icon": "📝", "label": "Log error",
        "fields": [{"key": "message", "label": "Message", "type": "textarea", "required": True}],
    },
}


def build_catalog(connector_names):
    """Merge the live connector registry with schema metadata."""
    out = []
    for name in connector_names:
        meta = CONNECTOR_META.get(name, {})
        out.append({
            "name": name,
            "label": meta.get("label", name),
            "category": meta.get("category", "Other"),
            "icon": meta.get("icon", "▸"),
            "fields": meta.get("fields", []),
        })
    return out
