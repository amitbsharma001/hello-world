class FlowError(Exception):
    """Generic engine error."""


class StepError(FlowError):
    """A single step failed."""

    def __init__(self, step_id: str, message: str):
        super().__init__(f"Step {step_id!r}: {message}")
        self.step_id = step_id


class FlowTerminate(FlowError):
    """Raised by a ``terminate`` step to stop execution with a status."""

    def __init__(self, status: str = "succeeded", message: str = ""):
        super().__init__(message or status)
        self.status = status
        self.message = message
