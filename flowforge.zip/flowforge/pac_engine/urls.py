"""
Drop-in URL configuration for host projects.

In your project's ``urls.py``::

    from django.urls import include, path

    urlpatterns = [
        ...
        path("automation/", include("pac_engine.urls")),
    ]

That single line mounts the whole Flowforge UI + REST API + webhook
receiver under ``/automation/``:

    /automation/                  flow list
    /automation/<id>/builder/     visual builder
    /automation/runs/             run history
    /automation/api/flows/        REST API
    /automation/api/connectors/   connector catalog
    /automation/webhooks/<token>/ inbound webhook receiver

If you prefer to wire pieces individually, include ``flows.urls``,
``runs.urls``, ``flows.urls_api`` and ``runs.urls_api`` yourself instead.
"""
from django.urls import include, path

from pac_flows.views import webhook_trigger


urlpatterns = [
    path("api/", include("pac_flows.urls_api")),
    path("api/", include("pac_runs.urls_api")),
    path("runs/", include("pac_runs.urls")),
    path("webhooks/<str:token>/", webhook_trigger, name="webhook-trigger"),
    path("", include("pac_flows.urls")),
]
