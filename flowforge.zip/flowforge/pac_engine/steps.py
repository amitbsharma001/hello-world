"""
Step handlers. Each handler takes (executor, step_definition) and is
responsible for creating the StepRun row, updating context, and either
returning normally or raising.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from django.db import close_old_connections
from django.utils import timezone

from pac_runs.models import Status, StepRun

from .connectors import get_connector
from .exceptions import FlowTerminate, StepError
from .expressions import evaluate_condition, resolve

logger = logging.getLogger("flowforge.steps")


_seq_lock = threading.Lock()


def _new_step_run(executor, step, step_type, connector=""):
    with _seq_lock:
        executor._seq += 1
        seq = executor._seq
    step_id = step.get("id") or f"_anon_{seq}"
    logger.info(
        "Step start: %s%s",
        step_type, f" ({connector})" if connector else "",
        extra={"flow_id": executor.flow_run.flow_id,
               "run_id": executor.flow_run.id, "step_id": step_id},
    )
    return StepRun.objects.create(
        run=executor.flow_run,
        step_id=step_id,
        step_type=step_type,
        connector=connector,
        status=Status.RUNNING,
        started_at=timezone.now(),
        sequence=seq,
    )


def _finalize(step_run, status, **fields):
    step_run.status = status
    step_run.completed_at = timezone.now()
    for k, v in fields.items():
        setattr(step_run, k, v)
    step_run.save()
    duration = None
    if step_run.started_at and step_run.completed_at:
        duration = (step_run.completed_at - step_run.started_at).total_seconds()
    log_fn = logger.info if status == Status.SUCCEEDED else logger.warning
    log_fn(
        "Step %s: %s%s",
        status,
        step_run.step_type,
        f" duration={duration:.3f}s" if duration is not None else "",
        extra={"flow_id": step_run.run.flow_id,
               "run_id": step_run.run_id, "step_id": step_run.step_id},
    )


# ---------- action ----------------------------------------------------------
def handle_action(executor, step):
    """
    Action step. Supports optional retry config::

        {
          "id": "fetch", "type": "action", "connector": "http.request",
          "inputs": {"url": "..."},
          "retry": {"max_attempts": 3, "delay_seconds": 1, "backoff": 2.0,
                    "on_failure": "fail"}   # or "continue" to swallow
        }

    If ``on_failure`` is ``"continue"``, the step is marked ``failed`` but the
    flow keeps executing (downstream conditions can read
    ``{{ steps.<id>.status }}``).
    """
    connector_name = step["connector"]
    step_run = _new_step_run(executor, step, "action", connector_name)

    retry_cfg = step.get("retry") or {}
    max_attempts = max(1, int(retry_cfg.get("max_attempts", 1)))
    delay_seconds = float(retry_cfg.get("delay_seconds", 0))
    backoff = float(retry_cfg.get("backoff", 1.0))
    on_failure = (retry_cfg.get("on_failure") or "fail").lower()

    attempts = []
    try:
        inputs = resolve(step.get("inputs", {}), executor.context)
        step_run.inputs = inputs
        connector_fn = get_connector(connector_name)

        last_error = None
        output = None
        for attempt in range(1, max_attempts + 1):
            try:
                output = connector_fn(inputs, executor.context)
                if not isinstance(output, dict):
                    output = {"value": output}
                attempts.append({"attempt": attempt, "status": "succeeded"})
                last_error = None
                break
            except Exception as e:  # noqa: BLE001
                last_error = e
                attempts.append({
                    "attempt": attempt,
                    "status": "failed",
                    "error": f"{type(e).__name__}: {e}",
                })
                if attempt < max_attempts:
                    sleep_for = delay_seconds * (backoff ** (attempt - 1))
                    logger.warning(
                        "Step attempt %d/%d failed (%s); retrying in %.1fs",
                        attempt, max_attempts, type(e).__name__, sleep_for,
                        extra={"flow_id": executor.flow_run.flow_id,
                               "run_id": executor.flow_run.id,
                               "step_id": step_run.step_id},
                    )
                    if sleep_for > 0:
                        time.sleep(sleep_for)

        if last_error is not None:
            # All attempts failed.
            executor.context["steps"][step_run.step_id] = {
                "status": "failed",
                "error": str(last_error),
                "attempts": attempts,
            }
            _finalize(
                step_run,
                Status.FAILED,
                error=f"{type(last_error).__name__}: {last_error}",
                output={"attempts": attempts},
            )
            if on_failure == "continue":
                return
            raise StepError(step_run.step_id, str(last_error)) from last_error

        executor.context["steps"][step_run.step_id] = {
            "status": "succeeded",
            "output": output,
            "attempts": attempts,
        }
        _finalize(step_run, Status.SUCCEEDED, output=output)
    except StepError:
        raise
    except FlowTerminate:
        _finalize(step_run, Status.SUCCEEDED)
        raise


# ---------- condition -------------------------------------------------------
def handle_condition(executor, step):
    step_run = _new_step_run(executor, step, "condition")
    try:
        result = evaluate_condition(step["condition"], executor.context)
        branch_key = "then" if result else "else"
        branch = step.get(branch_key, []) or []
        executor.context["steps"][step_run.step_id] = {
            "status": "succeeded",
            "output": {"result": result, "branch": branch_key},
        }
        _finalize(step_run, Status.SUCCEEDED, output={"result": result, "branch": branch_key})
        for child in branch:
            executor.execute(child)
    except FlowTerminate:
        raise
    except StepError:
        raise
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- foreach ---------------------------------------------------------
def handle_foreach(executor, step):
    step_run = _new_step_run(executor, step, "foreach")
    try:
        items = resolve(step.get("items"), executor.context)
        if items is None:
            items = []
        if not hasattr(items, "__iter__"):
            raise ValueError(f"'items' must be iterable, got {type(items).__name__}")
        item_var = step.get("item_var", "item")
        index_var = step.get("index_var", "index")

        prev_item = executor.context.get(item_var)
        prev_index = executor.context.get(index_var)
        try:
            for i, item in enumerate(items):
                executor.context[item_var] = item
                executor.context[index_var] = i
                for child in step.get("steps", []):
                    executor.execute(child)
        finally:
            if prev_item is None:
                executor.context.pop(item_var, None)
            else:
                executor.context[item_var] = prev_item
            if prev_index is None:
                executor.context.pop(index_var, None)
            else:
                executor.context[index_var] = prev_index

        _finalize(step_run, Status.SUCCEEDED, output={"iterations": len(list(items)) if hasattr(items, "__len__") else None})
    except FlowTerminate:
        raise
    except StepError:
        raise
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- delay -----------------------------------------------------------
def handle_delay(executor, step):
    step_run = _new_step_run(executor, step, "delay")
    try:
        seconds = float(resolve(step.get("seconds", 0), executor.context))
        # NOTE: blocks the worker. Fine for short waits; for long delays use
        # a dedicated Celery countdown task pattern (future work).
        time.sleep(max(0.0, seconds))
        _finalize(step_run, Status.SUCCEEDED, output={"slept": seconds})
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- set_variable ----------------------------------------------------
def handle_set_variable(executor, step):
    step_run = _new_step_run(executor, step, "set_variable")
    try:
        name = step["name"]
        value = resolve(step.get("value"), executor.context)
        executor.context["vars"][name] = value
        _finalize(step_run, Status.SUCCEEDED, inputs={"name": name, "value": value},
                  output={"vars": dict(executor.context["vars"])})
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- compose ---------------------------------------------------------
def handle_compose(executor, step):
    """Power-Automate-style ``Compose``: resolves a value into step output."""
    step_run = _new_step_run(executor, step, "compose")
    try:
        value = resolve(step.get("value"), executor.context)
        output = value if isinstance(value, dict) else {"value": value}
        executor.context["steps"][step_run.step_id] = {
            "status": "succeeded",
            "output": output,
        }
        _finalize(step_run, Status.SUCCEEDED, output=output)
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- terminate ------------------------------------------------------
def handle_terminate(executor, step):
    step_run = _new_step_run(executor, step, "terminate")
    status = (step.get("status") or "succeeded").lower()
    message = resolve(step.get("message", ""), executor.context)
    _finalize(step_run, Status.SUCCEEDED, output={"status": status, "message": message})
    raise FlowTerminate(status=status, message=message)


# ---------- parallel -------------------------------------------------------
def _run_branch(executor, branch_steps):
    """Run a branch in a worker thread, returning (steps_map, vars_delta, error)."""
    try:
        for child in branch_steps:
            executor.execute(child)
        return None
    except (FlowTerminate, StepError) as e:
        return e
    except Exception as e:  # noqa: BLE001
        return e
    finally:
        close_old_connections()


def handle_parallel(executor, step):
    """
    Run multiple branches concurrently::

        {
          "id": "fanout", "type": "parallel",
          "branches": [
            [ {step}, {step} ],
            [ {step} ]
          ],
          "fail_fast": false
        }

    Branches share the parent ``context`` dict — step outputs from any branch
    become visible to all subsequent steps once parallel completes.
    """
    step_run = _new_step_run(executor, step, "parallel")
    branches = step.get("branches") or []
    fail_fast = bool(step.get("fail_fast", False))

    if not branches:
        _finalize(step_run, Status.SUCCEEDED, output={"branches": 0})
        return

    errors = []
    try:
        with ThreadPoolExecutor(max_workers=min(len(branches), 8)) as pool:
            futures = {pool.submit(_run_branch, executor, b): i
                       for i, b in enumerate(branches)}
            for fut in as_completed(futures):
                err = fut.result()
                if err is not None:
                    errors.append({"branch": futures[fut], "error": str(err)})
                    if fail_fast:
                        # Cancel what we can; running threads still finish.
                        for f in futures:
                            f.cancel()
                        break

        if errors:
            executor.context["steps"][step_run.step_id] = {
                "status": "failed",
                "errors": errors,
            }
            _finalize(step_run, Status.FAILED,
                      error="; ".join(e["error"] for e in errors),
                      output={"errors": errors, "branches": len(branches)})
            raise StepError(step_run.step_id, f"{len(errors)} branch(es) failed")

        executor.context["steps"][step_run.step_id] = {
            "status": "succeeded",
            "output": {"branches": len(branches)},
        }
        _finalize(step_run, Status.SUCCEEDED, output={"branches": len(branches)})
    except StepError:
        raise
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- try / catch ----------------------------------------------------
def handle_try(executor, step):
    """
    Structured error handling::

        {
          "id": "safe_block", "type": "try",
          "steps": [ ... ],
          "catch": [ ... ],
          "finally": [ ... ]
        }

    Inside ``catch``, ``{{ error.type }}``, ``{{ error.message }}``, and
    ``{{ error.step_id }}`` are bound.
    """
    step_run = _new_step_run(executor, step, "try")
    caught = None
    try:
        try:
            for child in step.get("steps", []):
                executor.execute(child)
        except FlowTerminate:
            raise
        except StepError as e:
            caught = {
                "type": "StepError",
                "message": str(e),
                "step_id": getattr(e, "step_id", None),
            }
        except Exception as e:  # noqa: BLE001
            caught = {"type": type(e).__name__, "message": str(e), "step_id": None}

        if caught is not None:
            prev_error = executor.context.get("error")
            executor.context["error"] = caught
            try:
                for child in step.get("catch", []) or []:
                    executor.execute(child)
            finally:
                if prev_error is None:
                    executor.context.pop("error", None)
                else:
                    executor.context["error"] = prev_error

        for child in step.get("finally", []) or []:
            executor.execute(child)

        executor.context["steps"][step_run.step_id] = {
            "status": "succeeded",
            "output": {"caught": caught},
        }
        _finalize(step_run, Status.SUCCEEDED, output={"caught": caught})
    except FlowTerminate:
        raise
    except StepError:
        # An error inside catch/finally propagates
        _finalize(step_run, Status.FAILED, error="error in catch/finally block")
        raise
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


# ---------- call_flow (sub-flow) -------------------------------------------
def handle_call_flow(executor, step):
    """
    Synchronously execute another flow as a sub-step::

        {"id": "subcall", "type": "call_flow",
         "flow": "Helper Flow Name",  // or "flow_id": 7
         "input": {"x": "{{ vars.something }}"}}

    The sub-flow runs inline (in the same worker), producing its own
    FlowRun record so the hierarchy is visible in run history. The
    sub-flow's final ``output`` becomes this step's output.
    """
    from pac_flows.models import Flow
    from pac_runs.models import FlowRun
    from .executor import execute_run

    step_run = _new_step_run(executor, step, "call_flow")
    try:
        flow_id = step.get("flow_id")
        flow_name = step.get("flow")
        if flow_id:
            sub_flow = Flow.objects.get(pk=flow_id)
        elif flow_name:
            sub_flow = Flow.objects.get(name=flow_name)
        else:
            raise ValueError("call_flow requires 'flow' (name) or 'flow_id'")

        sub_input = resolve(step.get("input", {}), executor.context)
        sub_run = FlowRun.objects.create(
            flow=sub_flow,
            trigger_type="manual",
            trigger_data={
                "body": sub_input,
                "parent_run_id": executor.flow_run.id,
                "parent_step_id": step_run.step_id,
            },
        )
        sub_result = execute_run(sub_run.id)

        output = {
            "sub_run_id": sub_run.id,
            "status": sub_result.status,
            "output": sub_result.output,
            "error": sub_result.error or None,
        }
        executor.context["steps"][step_run.step_id] = {
            "status": "succeeded" if sub_result.status == "succeeded" else "failed",
            "output": output,
        }
        if sub_result.status == "succeeded":
            _finalize(step_run, Status.SUCCEEDED, output=output)
        else:
            _finalize(step_run, Status.FAILED,
                      error=f"Sub-flow failed: {sub_result.error[:200] if sub_result.error else 'unknown'}",
                      output=output)
            raise StepError(step_run.step_id, "sub-flow failed")
    except StepError:
        raise
    except Exception as e:
        _finalize(step_run, Status.FAILED, error=f"{type(e).__name__}: {e}")
        raise StepError(step_run.step_id, str(e)) from e


STEP_HANDLERS = {
    "action": handle_action,
    "condition": handle_condition,
    "foreach": handle_foreach,
    "delay": handle_delay,
    "set_variable": handle_set_variable,
    "compose": handle_compose,
    "terminate": handle_terminate,
    "parallel": handle_parallel,
    "try": handle_try,
    "call_flow": handle_call_flow,
}
