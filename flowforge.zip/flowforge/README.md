# Flowforge

A minimal Power Automate-style workflow engine built on Django + Celery.

- **Flow definitions** live as JSON: a list of typed steps (`action`, `condition`, `foreach`, `delay`, `set_variable`, `compose`, `terminate`).
- **Triggers**: manual (UI button or `POST /api/flows/<id>/trigger/`) and scheduled (cron via django-celery-beat).
- **Connectors** are pluggable Python callables registered with `@register_connector(...)`. HTTP, log, and email are built in.
- **Expressions**: `{{ ... }}` interpolation with a sandboxed AST evaluator. Supports attribute / subscript access, comparisons, boolean logic, arithmetic, conditional expressions, and a whitelist of helpers (`now()`, `uuid()`, `len()`, `upper()`, etc).
- **Run history**: every step persists inputs, outputs, errors, and timing. Browse runs in the UI or `GET /api/runs/<id>/`.

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env

# Start Redis (the only required dependency outside Python)
docker compose up -d redis

python manage.py migrate
python manage.py createsuperuser
python manage.py seed_flows        # optional: two example flows
```

Run the three processes in separate terminals:

```bash
# 1. Web
python manage.py runserver

# 2. Celery worker
celery -A flowforge worker -l info

# 3. Celery beat (only needed if you use scheduled flows)
celery -A flowforge beat -l info
```

Then open <http://localhost:8000/flows/>.

## Trigger from the API

```bash
curl -X POST http://localhost:8000/api/flows/1/trigger/ \
     -H 'Content-Type: application/json' \
     -d '{"foo": "bar"}'
```

The POST body becomes `{{ trigger.body }}` in the flow's expressions.

## Flow definition example

```json
{
  "trigger": {"type": "manual"},
  "variables": {"endpoint": "https://httpbin.org/get"},
  "steps": [
    {
      "id": "fetch",
      "type": "action",
      "connector": "http.request",
      "inputs": {
        "method": "GET",
        "url": "{{ vars.endpoint }}"
      }
    },
    {
      "id": "check",
      "type": "condition",
      "condition": "{{ steps.fetch.output.status == 200 }}",
      "then": [
        {"id": "ok",  "type": "action", "connector": "log.info",
         "inputs": {"message": "Got {{ steps.fetch.output.status }}"}}
      ],
      "else": [
        {"id": "bad", "type": "action", "connector": "log.error",
         "inputs": {"message": "Failed: {{ steps.fetch.output.status }}"}}
      ]
    },
    {
      "id": "report",
      "type": "compose",
      "value": {"endpoint": "{{ vars.endpoint }}", "status": "{{ steps.fetch.output.status }}"}
    }
  ]
}
```

## Adding a connector

```python
# myproject/my_connectors.py
from engine.connectors import register_connector

@register_connector("slack.post")
def slack_post(inputs, context):
    # ... call Slack ...
    return {"ts": "1234.5"}
```

Import the module from `engine/builtin/__init__.py` (or any app's `apps.ready()`) so it registers on startup.

## Step types

| Type           | Required keys                          | Notes                                                                              |
| -------------- | -------------------------------------- | ---------------------------------------------------------------------------------- |
| `action`       | `id`, `connector`, `inputs`            | Calls a registered connector. Supports `retry` config (see below).                 |
| `condition`    | `id`, `condition`, `then`/`else`       | Branches based on a boolean expression.                                            |
| `foreach`      | `id`, `items`, `steps`                 | Iterates over a resolved iterable. Exposes `{{ item }}` and `{{ index }}`.         |
| `parallel`     | `id`, `branches`                       | Runs branches concurrently in a thread pool. Optional `fail_fast: true`.           |
| `try`          | `id`, `steps`, `catch`, `finally`      | Structured error handling. Inside catch: `{{ error.type }}`, `.message`, `.step_id`. |
| `call_flow`    | `id`, `flow` (or `flow_id`), `input`   | Runs another flow inline as a sub-run. Output at `{{ steps.<id>.output.output }}`. |
| `delay`        | `seconds`                              | Sleeps the worker. OK for short waits; long waits should re-enqueue (future work). |
| `set_variable` | `name`, `value`                        | Writes to `{{ vars.* }}`.                                                          |
| `compose`      | `id`, `value`                          | Resolves a value and stores it under `{{ steps.<id>.output }}`.                    |
| `terminate`    | `status` (`succeeded`/`failed`)        | Stops the flow with the given outcome.                                             |

### Parallel example

```json
{
  "id": "fanout",
  "type": "parallel",
  "branches": [
    [ {"id": "fetch_a", "type": "action", "connector": "http.request",
       "inputs": {"url": "https://api.example.com/a"}} ],
    [ {"id": "fetch_b", "type": "action", "connector": "http.request",
       "inputs": {"url": "https://api.example.com/b"}} ]
  ]
}
```

Branches share the parent context. Once `parallel` returns, both `steps.fetch_a` and `steps.fetch_b` are visible to downstream steps.

### Try / catch / finally

```json
{
  "id": "safe_block",
  "type": "try",
  "steps": [
    {"id": "risky", "type": "action", "connector": "http.request",
     "inputs": {"url": "https://flaky.example.com"}}
  ],
  "catch": [
    {"id": "notify", "type": "action", "connector": "slack.webhook",
     "inputs": {"url": "https://hooks.slack.com/...",
                "text": "Flow hit error: {{ error.message }} in {{ error.step_id }}"}}
  ],
  "finally": [
    {"id": "cleanup", "type": "set_variable", "name": "done", "value": true}
  ]
}
```

### Sub-flow

```json
{
  "id": "use_helper",
  "type": "call_flow",
  "flow": "Compute Indicators",
  "input": {"symbol": "{{ vars.symbol }}"}
}
```

The sub-flow gets its own `FlowRun` row (visible in run history), receives `input` as `{{ trigger.body }}`, and its full output is exposed at `{{ steps.use_helper.output.output }}`.

### Retries

Any `action` step may carry a `retry` block:

```json
{
  "id": "fetch",
  "type": "action",
  "connector": "http.request",
  "inputs": {"url": "https://flaky.example.com"},
  "retry": {
    "max_attempts": 3,
    "delay_seconds": 1,
    "backoff": 2.0,
    "on_failure": "fail"
  }
}
```

- `max_attempts` (default `1`) — total attempts including the first.
- `delay_seconds` (default `0`) — wait between attempts.
- `backoff` (default `1.0`) — multiplier applied to the delay each round.
- `on_failure` — `"fail"` (default; stops the flow) or `"continue"` (marks the step failed but lets downstream steps run; check `{{ steps.<id>.status }}`).

The per-attempt history is preserved on `StepRun.output.attempts`.

## Built-in connectors

28 connectors across six categories. All credential-using connectors auto-resolve from named `Connection` rows via a `connection` input.

### HTTP & messaging

| Name             | Purpose                                                        |
| ---------------- | -------------------------------------------------------------- |
| `http.request`   | Generic HTTP, basic/bearer/header auth, form bodies, multipart |
| `request.send`   | Alias of `http.request`                                        |
| `slack.webhook`  | POST to a Slack Incoming Webhook                               |
| `email.send`     | Send via Django's email backend                                |

### Microsoft 365 (Graph API)

A single in-process token cache backs all three Microsoft modules. Tokens are keyed by `(tenant_id, client_id)` and refreshed shortly before expiry.

| Name                            | Purpose                                                  |
| ------------------------------- | -------------------------------------------------------- |
| `outlook.send_mail`             | Send mail via Graph                                      |
| `outlook.list_messages`         | List inbox / folder messages with `$filter` / `$search`  |
| `outlook.get_message`           | Fetch a message by id                                    |
| `teams.webhook`                 | Post a MessageCard to a Teams Incoming Webhook URL       |
| `teams.send_channel_message`    | Post to a Teams channel via Graph                        |
| `sharepoint.upload_file`        | Upload to SharePoint / OneDrive                          |
| `sharepoint.download_file`      | Read a file's contents                                   |
| `sharepoint.list_items`         | List a folder's children                                 |

### Database

Uses Django's connection pool with parameterised queries — never interpolate user input into the SQL string yourself. Both connectors honour `using` to target a non-default DB alias and can be disabled via `FLOWFORGE_ALLOW_DB_QUERY` / `FLOWFORGE_ALLOW_DB_EXECUTE`.

| Name         | Purpose                                            |
| ------------ | -------------------------------------------------- |
| `db.query`   | SELECT — returns rows as list of dicts             |
| `db.execute` | INSERT / UPDATE / DELETE / DDL inside a transaction |

### Object storage (S3-compatible)

Requires `boto3`. Works with AWS, MinIO, R2, B2, Wasabi — pass `endpoint_url` for non-AWS providers. Omit credentials entirely to use boto3's default chain (IAM role, `AWS_PROFILE`, `~/.aws/credentials`).

| Name          | Purpose                              |
| ------------- | ------------------------------------ |
| `s3.upload`   | Upload an object                     |
| `s3.download` | Download an object (text or base64)  |
| `s3.list`     | List objects under a prefix          |
| `s3.delete`   | Delete an object                     |

### Code & data

| Name             | Purpose                                          |
| ---------------- | ------------------------------------------------ |
| `python.exec`    | Restricted Python sandbox                        |
| `json.parse`     | Parse a JSON string into a value                 |
| `json.stringify` | Serialise a value to a JSON string               |
| `text.template`  | Render an expression template into a string      |
| `data.pick`      | Pick a subset of keys from an object             |
| `csv.parse`      | Parse CSV text into rows (header-aware)          |
| `csv.stringify`  | Serialise rows to CSV (handles dict & list rows) |

### Observability

| Name        | Purpose       |
| ----------- | ------------- |
| `log.info`  | INFO log line |
| `log.error` | ERROR log line |
| `log.debug` | DEBUG log line |

Add your own with `@register_connector("name")` — see `engine/builtin/http.py` for a minimal example, `engine/builtin/outlook.py` for credential resolution + shared token caching, or `engine/builtin/database.py` for a Django-backed example.

### `http.request` / `request.send` — full input shape

```json
{
  "method": "POST",
  "url": "https://api.example.com/v1/widgets",
  "headers": {"X-Trace-Id": "{{ run_id }}"},
  "params": {"version": "2"},
  "body": {"name": "thing", "qty": 3},
  "form": null,
  "auth": {"type": "bearer", "token": "{{ vars.api_token }}"},
  "timeout": 30,
  "follow_redirects": true,
  "verify_ssl": true
}
```

Auth options:
- `{"type": "basic", "username": "...", "password": "..."}`
- `{"type": "bearer", "token": "..."}`
- `{"type": "header", "name": "X-Api-Key", "value": "..."}`

Use `form` (dict) for `application/x-www-form-urlencoded`; use `body` (dict/list) for JSON; use `body` (string/bytes) for a raw payload. Reference a `Connection` row by name with `"connection": "my-creds"` to merge encrypted credentials into the inputs at runtime.

### `python.exec` — embedded Python

For one-off transforms that would be awkward as a chain of `compose` steps:

```json
{
  "id": "compute_rsi",
  "type": "action",
  "connector": "python.exec",
  "inputs": {
    "closes": "{{ steps.fetch.output.body.closes }}",
    "period": 14,
    "code": "import math\ngains = [max(0, b - a) for a, b in zip(inputs['closes'], inputs['closes'][1:])]\nlosses = [max(0, a - b) for a, b in zip(inputs['closes'], inputs['closes'][1:])]\nperiod = inputs['period']\navg_gain = statistics.mean(gains[-period:])\navg_loss = statistics.mean(losses[-period:]) or 1e-9\nrs = avg_gain / avg_loss\nresult = {'rsi': 100 - (100 / (1 + rs)), 'gain': avg_gain, 'loss': avg_loss}"
  }
}
```

The code runs in a restricted namespace with `inputs` (other keys from the step's `inputs`), `context` (a copy of the flow context), and pre-imported modules (`json`, `re`, `math`, `statistics`, `datetime`, `base64`, `hashlib`). Set `result` to whatever you want returned; if you don't, all non-private locals become the output.

> **Security**: the sandbox restricts builtins and blocks `import`, but a sufficiently determined Python script can still break out (bytecode tricks via subclass walks). Treat it like `eval` in a shell script — fine when only trusted operators author flows, not safe for multi-tenant or end-user-defined flows. Set `FLOWFORGE_ALLOW_PYTHON_EXEC = False` in `settings.py` to disable it entirely.

### Outlook — Microsoft 365 mail

`outlook.send_mail`, `outlook.list_messages`, and `outlook.get_message` all talk to Microsoft Graph. Two auth modes:

**Pre-acquired token** (slot in here if your Django app already runs an OIDC/PKCE flow — e.g. an Entra ID adapter):
```json
{
  "type": "action",
  "connector": "outlook.send_mail",
  "inputs": {
    "access_token": "{{ trigger.body.user_token }}",
    "to": "x@example.com",
    "subject": "Hello",
    "body": "From a PKCE-acquired delegated token"
  }
}
```

**Client credentials** (app-only, needs the `Mail.Send` application permission and admin consent):
```json
{
  "type": "action",
  "connector": "outlook.send_mail",
  "inputs": {
    "connection": "m365-prod",
    "user": "alerts@contoso.com",
    "to": ["amit@contoso.com", "team@contoso.com"],
    "cc": "manager@contoso.com",
    "subject": "NIFTY breakout — {{ now() }}",
    "body_type": "HTML",
    "body": "<b>BUY</b> signal at {{ steps.fetch.output.body.price }}"
  }
}
```

where the connection holds `tenant_id`, `client_id`, `client_secret`. Tokens are cached in-process per `(tenant, client_id)` until just before expiry, so a burst of mails only authenticates once.

## Authoring flows

Two editors are available:

1. **Visual builder** at `/flows/<id>/builder/` — drag-and-drop UI matching the Power Automate model.
2. **JSON editor** at `/flows/<id>/edit/` — raw definition textarea (the form-based editor used for flow metadata).

### Visual builder

The builder is a vanilla-JS single-page editor served from `/static/builder.js`. It has three columns:

- **Palette** (left): groups of draggable step templates (Connectors, Logic, Data).
- **Canvas** (centre): the flow rendered as a vertical list of step cards. Container steps (`condition`, `foreach`, `parallel`, `try`) expand inline to show their nested step lists with colour-coded branch labels (THEN/ELSE, BRANCH N, TRY/CATCH/FINALLY).
- **Inspector** (right): per-step configuration. Action steps get a connector picker plus an inputs JSON editor and an optional retry block. Conditions get the expression field. Foreach gets `items` + `item_var`. Parallel gets an "Add branch" button. Compose/Set variable/Delay/Call flow each get their relevant fields.

What works:

- Drag a palette item onto any drop-zone (between steps, at the top, inside any branch) to add it.
- Drag a card by its handle (`⋮⋮`) to reorder among siblings or move into another container.
- Click a card to select it; the inspector populates with editable fields.
- All inspector inputs commit on blur. JSON fields show inline error messages on invalid JSON.
- "Show JSON" opens a dialog with the raw definition; you can edit and re-apply it.
- "Validate" checks for missing required fields and duplicate step IDs without saving.
- Cmd/Ctrl-S saves. So does the Save button. Status pill in the header tracks dirty/saved/error.

What's pending:

- No undo/redo stack yet — Cmd-Z reverts the current text input but not structural changes.
- The trigger configuration (manual/schedule/webhook) still lives on the regular Edit form.

## Triggers

### Manual
Click **Run now** on the flow detail page, or `POST /api/flows/<id>/trigger/` with a JSON body. The body lands at `{{ trigger.body }}`.

### Scheduled
Set `Flow.schedule` to a 5-field cron string (e.g. `*/5 * * * *`). A signal converts it to a `django_celery_beat.PeriodicTask` that fires `engine.trigger_scheduled_flow`. Beat (`celery -A flowforge beat`) must be running.

### Webhook
Tick the **Webhook** checkbox when editing a flow. A unique token is generated and the URL appears on the detail page:

```
https://your-host/webhooks/<token>/
```

POST any JSON to that URL — no auth required beyond knowing the token. Headers, query params, and body are all exposed to expressions:

```
{{ trigger.body.user_id }}
{{ trigger.headers["X-GitHub-Event"] }}
{{ trigger.query.foo }}
```

Click **Rotate** on the flow detail page to regenerate the token (the old one stops working immediately).

> **Expression gotcha**: dot notation requires valid Python identifiers, so use bracket syntax for keys with hyphens or other special characters: `{{ trigger.headers["X-Custom"] }}`. Or use the safe-access helper: `{{ get(trigger.headers, "X-Custom", "default") }}`.

## Connections (encrypted credentials)

`Connection` rows store reusable credentials for use across flows. The `config` field is transparently encrypted at rest via Fernet, with the key derived from `settings.FLOWFORGE_ENCRYPTION_KEY` (or `SECRET_KEY` as a fallback).

```python
from flows.models import Connection
Connection.objects.create(
    name="prod-api",
    connector_type="http",
    config={"api_key": "sk-..."},   # plaintext in Python, ciphertext on disk
)
```

> **Heads up**: connectors don't yet read from `Connection` automatically — that's the next wiring step. For now, reference them yourself from custom connectors.

## Limitations / next steps

- `delay` blocks the worker — fine for seconds, not for hours. Convert to `apply_async(countdown=...)` when needed.
- `python.exec` is restricted but not hardened. For multi-tenant flow authoring, run code in a subprocess with OS-level isolation, or use `RestrictedPython`.
- `DEFAULT_PERMISSION_CLASSES` is `AllowAny`. Add proper auth before exposing the API externally. Webhook endpoints are token-protected but currently unrate-limited.
- The visual builder has no undo/redo. Add a command-pattern wrapper around the structural mutations.
- No approval/wait step (resumable workflows). Would require persisting suspended runs and a resume endpoint.
- Parallel branches share context — if two branches write the same `vars.x` the last-writer-wins. Document or scope per-branch as needed.
- Outlook token cache is in-process. For a multi-worker deployment, move to Redis (`django-redis` cache) so all workers share acquired tokens.
