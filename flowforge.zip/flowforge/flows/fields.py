"""
Transparent JSON-over-Fernet field.

The key is derived from ``settings.FLOWFORGE_ENCRYPTION_KEY`` if set, else
from ``settings.SECRET_KEY`` (SHA-256, base64-encoded for Fernet).

In production, set ``FLOWFORGE_ENCRYPTION_KEY`` explicitly so rotating
``SECRET_KEY`` doesn't render existing rows unreadable.
"""
from __future__ import annotations

import base64
import hashlib
import json
from functools import lru_cache

from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings
from django.db import models


@lru_cache(maxsize=1)
def _fernet() -> Fernet:
    raw = getattr(settings, "FLOWFORGE_ENCRYPTION_KEY", None) or settings.SECRET_KEY
    if isinstance(raw, str):
        raw = raw.encode()
    key = base64.urlsafe_b64encode(hashlib.sha256(raw).digest())
    return Fernet(key)


class EncryptedJSONField(models.TextField):
    """A JSON field whose ciphertext sits on disk and decrypts on access."""

    description = "Encrypted JSON (Fernet)"

    def from_db_value(self, value, expression, connection):
        if value in (None, ""):
            return {}
        try:
            return json.loads(_fernet().decrypt(value.encode()).decode())
        except (InvalidToken, ValueError):
            return {}

    def to_python(self, value):
        if value in (None, ""):
            return {}
        if isinstance(value, (dict, list)):
            return value
        # Coming from a form: assume already JSON-decoded by the form widget.
        if isinstance(value, str):
            try:
                return json.loads(value)
            except ValueError:
                # Maybe already a ciphertext string fetched from DB
                try:
                    return json.loads(_fernet().decrypt(value.encode()).decode())
                except (InvalidToken, ValueError):
                    return {}
        return value

    def get_prep_value(self, value):
        if value is None:
            return ""
        if not isinstance(value, str):
            value = json.dumps(value)
        return _fernet().encrypt(value.encode()).decode()
