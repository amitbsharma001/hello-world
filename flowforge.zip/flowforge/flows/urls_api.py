from rest_framework.routers import DefaultRouter

from .views import ConnectionViewSet, FlowViewSet

router = DefaultRouter()
router.register("flows", FlowViewSet, basename="api-flow")
router.register("connections", ConnectionViewSet, basename="api-connection")

urlpatterns = router.urls
