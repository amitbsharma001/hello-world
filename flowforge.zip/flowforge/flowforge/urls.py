from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

from pac_flows.views import webhook_trigger

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("pac_flows.urls_api")),
    path("api/", include("pac_runs.urls_api")),
    path("flows/", include("pac_flows.urls")),
    path("runs/", include("pac_runs.urls")),
    path("webhooks/<str:token>/", webhook_trigger, name="webhook-trigger"),
    path("", RedirectView.as_view(url="/flows/", permanent=False)),
]
