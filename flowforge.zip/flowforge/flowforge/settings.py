"""
Django settings for flowforge.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-insecure-change-me")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "*").split(",")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    # 3rd-party
    "rest_framework",
    "django_celery_beat",

    # local
    "pac_flows.apps.FlowsConfig",
    "pac_runs.apps.RunsConfig",
    "pac_engine.apps.EngineConfig",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "flowforge.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        # Templates ship inside each app (flows/templates, runs/templates),
        # so APP_DIRS finds them with no project-level config. This empty
        # DIRS list is why Flowforge drops cleanly into a host project.
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "pac_engine.theme.theme_context",
            ],
        },
    },
]

WSGI_APPLICATION = "flowforge.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

AUTH_PASSWORD_VALIDATORS = []

LANGUAGE_CODE = "en-us"
TIME_ZONE = os.environ.get("DJANGO_TIME_ZONE", "UTC")
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
# Static assets ship inside the flows app (flows/static/flowforge/), found
# by the app-directories finder — no STATICFILES_DIRS needed.
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Celery
# Broker defaults to RabbitMQ (amqp). Override with CELERY_BROKER_URL env var.
CELERY_BROKER_URL = os.environ.get(
    "CELERY_BROKER_URL", "amqp://guest:guest@localhost:5672//"
)
# Flowforge stores all run state in its own FlowRun/StepRun models, so a
# Celery result backend is optional. Leave empty to disable; set to e.g.
# "rpc://" or a django-celery-results backend if you want task-level results.
CELERY_RESULT_BACKEND = os.environ.get("CELERY_RESULT_BACKEND", "") or None
CELERY_TASK_SERIALIZER = "json"
CELERY_RESULT_SERIALIZER = "json"
CELERY_ACCEPT_CONTENT = ["json"]
CELERY_TIMEZONE = TIME_ZONE
CELERY_BEAT_SCHEDULER = "django_celery_beat.schedulers:DatabaseScheduler"

# Redis is only needed if you use the redis.* connectors. It is NOT the
# broker. Point them at a Redis instance here (or per-step via 'url').
FLOWFORGE_REDIS_URL = os.environ.get("FLOWFORGE_REDIS_URL") or None

# DRF
REST_FRAMEWORK = {
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_PERMISSION_CLASSES": [
        "rest_framework.permissions.AllowAny",  # tighten in production
    ],
}

# Email -- console backend for dev. Override in production.
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
DEFAULT_FROM_EMAIL = "flowforge@example.com"

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "filters": {
        "flowforge_ctx": {"()": "pac_engine.logging.RunContextFilter"},
    },
    "formatters": {
        "flowforge": {
            "format": "[{asctime}] {levelname:<7} {name} {ctx}{message}",
            "style": "{",
        },
    },
    "handlers": {
        "flowforge_console": {
            "class": "logging.StreamHandler",
            "formatter": "flowforge",
            "filters": ["flowforge_ctx"],
        },
    },
    "loggers": {
        # One entry covers executor, steps, tasks, web, and log.* output.
        "flowforge": {
            "handlers": ["flowforge_console"],
            "level": os.environ.get("FLOWFORGE_LOG_LEVEL", "INFO"),
            "propagate": False,
        },
    },
}

# Make the configured level available to the app layer too.
FLOWFORGE_LOG_LEVEL = os.environ.get("FLOWFORGE_LOG_LEVEL", "INFO")


# When running the test suite, execute Celery tasks synchronously so flows
# triggered via views/webhooks run inline.
import sys as _sys
if "test" in _sys.argv:
    CELERY_TASK_ALWAYS_EAGER = True
    CELERY_TASK_EAGER_PROPAGATES = True
    import logging as _logging
    _logging.getLogger("flowforge").setLevel(_logging.CRITICAL)
    # Parallel steps run in real threads; in-memory SQLite isn't shared
    # across connections/threads, so use a file-based test DB.
    DATABASES["default"]["TEST"] = {"NAME": str(BASE_DIR / "test_db.sqlite3")}
