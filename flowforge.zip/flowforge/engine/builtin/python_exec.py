"""
Python code execution connector.

Inputs:
  code:    string of Python source. The code runs in a restricted namespace
           with ``inputs`` (the dict of all other input keys), ``context``
           (the flow context, mostly read-only), and a curated set of
           builtins and modules.

           The code should assign the output to a local variable named
           ``result``. If ``result`` is not set, all non-private locals are
           returned as a dict.

  *:       any other input key becomes available as ``inputs["<key>"]``
           inside the code.

Available in the sandbox:
  Builtins: abs, all, any, bool, dict, divmod, enumerate, filter, float,
            frozenset, int, isinstance, len, list, map, max, min, range,
            reversed, round, set, sorted, str, sum, tuple, type, zip,
            True, False, None, print
  Modules:  json, re, math, statistics, datetime, base64, hashlib

Disabled by default if ``settings.FLOWFORGE_ALLOW_PYTHON_EXEC`` is False.

SECURITY NOTE
-------------
The restriction here mitigates accidental damage but is NOT a hardened
sandbox. Treat ``python.exec`` like ``eval`` in a shell script — only
permit it for flows authored by trusted operators. For multi-tenant
scenarios, run code in a subprocess with OS-level isolation
(seccomp/firejail/gVisor) or use the ``RestrictedPython`` package.
"""
from __future__ import annotations

import base64
import datetime
import hashlib
import json
import math
import re
import statistics

from django.conf import settings

from ..connectors import register_connector


_SAFE_BUILTINS = {
    "abs": abs, "all": all, "any": any, "bool": bool,
    "dict": dict, "divmod": divmod, "enumerate": enumerate,
    "filter": filter, "float": float, "frozenset": frozenset,
    "int": int, "isinstance": isinstance, "len": len, "list": list,
    "map": map, "max": max, "min": min, "print": print,
    "range": range, "repr": repr, "reversed": reversed, "round": round,
    "set": set, "sorted": sorted, "str": str, "sum": sum,
    "tuple": tuple, "type": type, "zip": zip,
    "True": True, "False": False, "None": None,
}

_SAFE_MODULES = {
    "json": json,
    "re": re,
    "math": math,
    "statistics": statistics,
    "datetime": datetime,
    "base64": base64,
    "hashlib": hashlib,
}


def _json_safe(value):
    """Coerce common non-JSON types into JSON-serialisable form."""
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_json_safe(v) for v in value]
    if isinstance(value, (datetime.datetime, datetime.date)):
        return value.isoformat()
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return base64.b64encode(value).decode("ascii")
    return repr(value)


@register_connector("python.exec")
def python_exec(inputs, context):
    if not getattr(settings, "FLOWFORGE_ALLOW_PYTHON_EXEC", True):
        raise RuntimeError("python.exec is disabled by FLOWFORGE_ALLOW_PYTHON_EXEC")

    code = inputs.get("code")
    if not code or not isinstance(code, str):
        raise ValueError("python.exec requires 'code' (string)")

    user_inputs = {k: v for k, v in inputs.items() if k != "code"}

    sandbox_globals = {
        "__builtins__": _SAFE_BUILTINS,
        "inputs": user_inputs,
        "context": dict(context),  # shallow copy: writes don't leak back
        **_SAFE_MODULES,
    }
    sandbox_locals: dict = {}

    try:
        compiled = compile(code, "<python.exec>", "exec")
    except SyntaxError as e:
        raise ValueError(f"Syntax error in code: {e}") from e

    exec(compiled, sandbox_globals, sandbox_locals)  # noqa: S102

    if "result" in sandbox_locals:
        result = sandbox_locals["result"]
    else:
        # Return all non-private locals as a dict if no explicit result
        result = {k: v for k, v in sandbox_locals.items()
                  if not k.startswith("_") and k != "inputs"}

    return {"result": _json_safe(result)}
