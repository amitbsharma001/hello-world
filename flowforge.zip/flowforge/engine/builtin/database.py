"""
Database connectors using Django's connection pool.

Connectors:
  db.query    Run a SELECT-style statement; returns rows as list of dicts.
  db.execute  Run an INSERT / UPDATE / DELETE / DDL statement inside a transaction.

Both connectors use parameterised queries — never interpolate user input
into the SQL string yourself. Always pass values via the ``params`` list:

    {
      "sql": "SELECT * FROM trades WHERE symbol = %s AND qty > %s",
      "params": ["NIFTY", 100]
    }

Database aliases (``using``) come from Django's ``DATABASES`` setting and
default to ``"default"``.

Safety
------
SQL execution is gated by two settings:

  FLOWFORGE_ALLOW_DB_QUERY   = True   (default; turn off in untrusted envs)
  FLOWFORGE_ALLOW_DB_EXECUTE = True   (default; turn off if read-only access wanted)

The ``max_rows`` input caps the number of rows returned from ``db.query``
(default 10,000) so a runaway query doesn't blow up memory.
"""
from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal

from django.conf import settings
from django.db import connections, transaction

from ..connectors import register_connector


def _coerce(value):
    """Convert DB-native types to JSON-safe equivalents."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (bytes, bytearray)):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            import base64
            return base64.b64encode(value).decode("ascii")
    return str(value)


@register_connector("db.query")
def db_query(inputs, context):
    """
    Run a read query.

    Inputs:
      sql:      SQL string (required). Use ``%s`` placeholders.
      params:   list of values to substitute (default [])
      using:    DB alias (default "default")
      max_rows: cap on rows returned (default 10000)

    Output: {rows, count, columns}
    """
    if not getattr(settings, "FLOWFORGE_ALLOW_DB_QUERY", True):
        raise RuntimeError("db.query is disabled by FLOWFORGE_ALLOW_DB_QUERY")

    sql = inputs.get("sql")
    if not sql:
        raise ValueError("db.query requires 'sql'")
    params = inputs.get("params") or []
    alias = inputs.get("using", "default")
    max_rows = int(inputs.get("max_rows", 10000))

    if alias not in connections.databases:
        raise ValueError(f"Unknown database alias: {alias!r}")

    conn = connections[alias]
    with conn.cursor() as cur:
        cur.execute(sql, params)
        if cur.description is None:
            # No result set (e.g. someone passed an UPDATE here)
            return {"rows": [], "count": 0, "columns": [], "rowcount": cur.rowcount}

        columns = [col[0] for col in cur.description]
        rows = []
        for i, row in enumerate(cur.fetchall()):
            if i >= max_rows:
                break
            rows.append({columns[j]: _coerce(v) for j, v in enumerate(row)})

    return {"rows": rows, "count": len(rows), "columns": columns}


@register_connector("db.execute")
def db_execute(inputs, context):
    """
    Run a write statement inside a transaction.

    Inputs:
      sql:    SQL string (required). Use ``%s`` placeholders.
      params: list of values (default [])
      using:  DB alias (default "default")

    Output: {rowcount}
    """
    if not getattr(settings, "FLOWFORGE_ALLOW_DB_EXECUTE", True):
        raise RuntimeError("db.execute is disabled by FLOWFORGE_ALLOW_DB_EXECUTE")

    sql = inputs.get("sql")
    if not sql:
        raise ValueError("db.execute requires 'sql'")
    params = inputs.get("params") or []
    alias = inputs.get("using", "default")

    if alias not in connections.databases:
        raise ValueError(f"Unknown database alias: {alias!r}")

    conn = connections[alias]
    with transaction.atomic(using=alias):
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return {"rowcount": cur.rowcount}
