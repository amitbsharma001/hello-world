from django.apps import AppConfig


class EngineConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "engine"

    def ready(self):
        # Trigger connector registration as a side-effect of import.
        from . import builtin  # noqa: F401
