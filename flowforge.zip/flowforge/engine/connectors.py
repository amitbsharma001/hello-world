"""
Connector registry.

Connectors are plain callables registered by string name. They receive
resolved ``inputs`` and the current execution ``context``, and return a
JSON-serialisable dict (or any value, which will be wrapped under
``{"value": ...}`` automatically).

Add a new connector::

    from engine.connectors import register_connector

    @register_connector("slack.post")
    def slack_post(inputs, context):
        ...
        return {"ts": "1234.5678"}
"""
from __future__ import annotations

from typing import Callable

_REGISTRY: dict[str, Callable] = {}


def register_connector(name: str):
    def decorator(fn: Callable) -> Callable:
        if name in _REGISTRY:
            raise ValueError(f"Connector already registered: {name!r}")
        _REGISTRY[name] = fn
        return fn
    return decorator


def get_connector(name: str) -> Callable:
    try:
        return _REGISTRY[name]
    except KeyError:
        raise ValueError(f"Unknown connector: {name!r}") from None


def list_connectors() -> list[str]:
    return sorted(_REGISTRY.keys())


def resolve_credentials(inputs: dict) -> dict:
    """
    If ``inputs`` contains a ``connection`` key, merge that ``Connection``
    row's decrypted ``config`` into the inputs. Existing input keys win
    over connection values, so the flow can override on a per-call basis.

    Returns a new dict; the original ``inputs`` is not mutated.
    """
    conn_name = inputs.get("connection")
    if not conn_name:
        return inputs
    # Local import to keep this module free of Django at import time.
    from flows.models import Connection
    try:
        conn = Connection.objects.get(name=conn_name)
    except Connection.DoesNotExist:
        raise ValueError(f"Connection not found: {conn_name!r}")
    merged = dict(conn.config or {})
    for k, v in inputs.items():
        if k == "connection":
            continue
        merged[k] = v
    return merged
