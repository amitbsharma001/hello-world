"""
The flow executor.

``execute_run(flow_run_id)`` is the single entry point used by the Celery
worker. It loads the flow, builds a fresh execution context, dispatches
each top-level step to the corresponding handler in ``engine.steps``,
and persists the final FlowRun state.
"""
from __future__ import annotations

import logging
import traceback

from django.utils import timezone

from runs.models import FlowRun, Status

from .exceptions import FlowTerminate
from .steps import STEP_HANDLERS

logger = logging.getLogger("engine.executor")


class _Executor:
    def __init__(self, flow_run: FlowRun, context: dict):
        self.flow_run = flow_run
        self.context = context
        self._seq = 0

    def execute(self, step: dict) -> None:
        step_type = step.get("type")
        handler = STEP_HANDLERS.get(step_type)
        if handler is None:
            raise ValueError(f"Unknown step type: {step_type!r}")
        handler(self, step)


def execute_run(flow_run_id: int) -> FlowRun:
    flow_run = FlowRun.objects.select_related("flow").get(pk=flow_run_id)
    flow_run.status = Status.RUNNING
    flow_run.started_at = timezone.now()
    flow_run.save(update_fields=["status", "started_at"])

    definition = flow_run.flow.definition or {}
    steps = definition.get("steps", []) or []

    context = {
        "trigger": flow_run.trigger_data or {},
        "steps": {},
        "vars": dict(definition.get("variables", {}) or {}),
        "flow_id": flow_run.flow_id,
        "run_id": flow_run.id,
    }

    executor = _Executor(flow_run, context)

    final_status = Status.SUCCEEDED
    error_text = ""
    terminated_message = ""

    try:
        for step in steps:
            executor.execute(step)
    except FlowTerminate as t:
        # Map terminate status to a FlowRun status
        mapping = {
            "succeeded": Status.SUCCEEDED,
            "failed": Status.FAILED,
            "cancelled": Status.CANCELLED,
        }
        final_status = mapping.get(t.status, Status.SUCCEEDED)
        terminated_message = t.message
    except Exception as e:  # noqa: BLE001 - we want any error to mark the run failed
        final_status = Status.FAILED
        error_text = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        logger.exception("Flow run %s failed", flow_run.id)

    flow_run.status = final_status
    flow_run.output = {
        "steps": context["steps"],
        "vars": context["vars"],
        **({"terminated": terminated_message} if terminated_message else {}),
    }
    if error_text:
        flow_run.error = error_text
    flow_run.completed_at = timezone.now()
    flow_run.save(update_fields=["status", "output", "error", "completed_at"])

    return flow_run
