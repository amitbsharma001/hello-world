curl -X POST http://localhost:8000/api/v1/external/approvals/1/substitute/ \
  -H "Content-Type: application/json" \
  -d '{"from_email": "stage2@acme.com", "to_email": "newstage2@acme.com", "reason": "will be OOO"}'
# works even before stage 1 is decided -> {"status": "reassigned_upcoming", ...}