"""Inbound callback: a decision made in Microsoft Teams (or the Power Automate
flow driving it) calls this endpoint, which maps it to ApprovalService.act so the
in-app task reaches the same state. Secured by a shared secret header."""
from django.conf import settings
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.approvals.models import ApprovalTask
from apps.approvals.services import ApprovalService
from apps.approvals.states import TaskStatus


class TeamsApprovalCallback(APIView):
    """POST {taskId|external_ref, decision: approve|reject, comment, actor_email}
    with header X-Approval-Secret. Idempotent."""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        conf = getattr(settings, "TEAMS_APPROVAL", {}) or {}
        secret = conf.get("CALLBACK_SECRET", "")
        if not secret or request.headers.get("X-Approval-Secret") != secret:
            return Response({"detail": "Invalid callback secret."},
                            status=status.HTTP_403_FORBIDDEN)

        data = request.data or {}
        decision = (data.get("decision") or "").lower()
        if decision not in ("approve", "reject"):
            return Response({"detail": "decision must be 'approve' or 'reject'."}, status=400)

        task = None
        if data.get("taskId"):
            task = ApprovalTask.objects.filter(pk=data["taskId"]).first()
        if task is None and data.get("external_ref"):
            task = ApprovalTask.objects.filter(external_ref=str(data["external_ref"])).first()
        if task is None:
            return Response({"detail": "No matching task."}, status=404)

        if task.status != TaskStatus.PENDING:
            # already decided (perhaps in-app) — accept idempotently
            return Response({"status": task.status, "note": "already actioned"}, status=200)

        # The approver already authenticated in Teams; act as the task's assignee.
        req = ApprovalService.act(
            task_id=task.pk, actor=task.assignee, action=decision,
            comment=data.get("comment", "") or "Decided in Microsoft Teams",
        )
        return Response({"status": req.state, "task": task.pk}, status=200)


class ExternalApprovalCreate(APIView):
    """Inbound REST: create an approval from an external system's payload
    (approvers + viewable metadata + Result_Callback_URL). Secret-protected."""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        ext_conf = getattr(settings, "EXTERNAL_APPROVAL", {}) or {}
        teams_conf = getattr(settings, "TEAMS_APPROVAL", {}) or {}
        secret = ext_conf.get("INBOUND_SECRET") or teams_conf.get("CALLBACK_SECRET", "")
        if not secret or request.headers.get("X-Approval-Secret") != secret:
            return Response({"detail": "Invalid secret."}, status=status.HTTP_403_FORBIDDEN)
        from apps.approvals.integrations.external import create_from_payload
        base = request.build_absolute_uri("/").rstrip("/")
        import logging
        logging.getLogger("approvals.external").info(
            "Inbound external approval received from %s",
            request.META.get("REMOTE_ADDR", "?"),
        )
        try:
            ext, appr = create_from_payload(request.data or {}, base_url=base)
        except (KeyError, ValueError) as exc:
            logging.getLogger("approvals.external").warning(
                "Inbound external approval rejected: %s", exc)
            return Response({"detail": str(exc) or "Invalid payload."}, status=400)
        return Response(
            {"external_id": ext.pk, "request_id": appr.pk, "status": appr.state},
            status=status.HTTP_201_CREATED,
        )


class ExternalApprovalSubstitute(APIView):
    """Swap the pending approver on an external approval, by EMAIL — the incoming
    approver need not already exist as a user. No authentication required."""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request, external_id):

        from apps.approvals.integrations.external import substitute_approver
        from apps.approvals.models import ExternalApproval

        ext = ExternalApproval.objects.filter(pk=external_id).first()
        if ext is None:
            return Response({"detail": "External approval not found."}, status=404)

        from_email = request.data.get("from_email", "")
        to_email = request.data.get("to_email", "")
        reason = request.data.get("reason", "")   # optional
        if not from_email or not to_email:
            return Response({"detail": "from_email and to_email are required."}, status=400)

        try:
            new_task = substitute_approver(ext, from_email, to_email, reason)
        except ValueError as exc:
            return Response({"detail": str(exc)}, status=400)
        if new_task is not None:
            return Response(
                {"status": "substituted", "new_task_id": new_task.pk, "new_approver": to_email},
                status=200,
            )
        return Response(
            {"status": "reassigned_upcoming",
             "detail": "That approver's stage hasn't started yet; the new approver "
                       "is now assigned and will be notified when it activates.",
             "new_approver": to_email},
            status=200,
        )
