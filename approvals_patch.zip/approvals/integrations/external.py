"""Adapter for an external REST approval flow (e.g. iFlow transports).

Inbound: `create_from_payload` takes the request body (a list of approvers, each
with a title, plus the metadata fields to display) and creates an approval whose
steps mirror the approver titles — so each "… Approval" is its own stage and the
metadata is viewable on the console and in the approver email.

Outbound: when the approval is fully decided, `on_external_decided` builds the
response document (responders, summary, outcome, dates, priority) and POSTs it to
the caller's `Result_Callback_URL`.
"""
import json
import logging
import urllib.error
import urllib.request

logger = logging.getLogger("approvals.external")


def _post_json(url, payload):
    """POST JSON to the result callback. Returns the HTTP status code. Mockable."""
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        status = getattr(resp, "status", None) or resp.getcode()
        resp.read()
        return status


def _send_result(ext, doc, *, phase):
    """POST the result document to the caller and log clearly what happened."""
    url = ext.result_callback_url
    outcome = doc.get("outcome")
    if not url:
        logger.info("External #%s [%s]: no Result_Callback_URL — callback skipped (outcome=%s)",
                    ext.pk, phase, outcome)
        return False
    logger.info("External #%s [%s]: POST callback -> %s (outcome=%s, %d responders)",
                ext.pk, phase, url, outcome, len(doc.get("responses", [])))
    try:
        status = _post_json(url, doc)
        logger.info("External #%s [%s]: callback OK (HTTP %s)", ext.pk, phase, status)
        return True
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:500]
        except Exception:
            pass
        logger.warning("External #%s [%s]: callback HTTP %s -> %s", ext.pk, phase, exc.code, body)
    except Exception as exc:
        logger.warning("External #%s [%s]: callback FAILED -> %s", ext.pk, phase, exc)
    return False


def create_from_payload(payload, *, base_url=""):
    """Create an approval from the inbound body. Returns (ExternalApproval, ApprovalRequest)."""
    from django.core import signing

    from apps.approvals.flow import Flow
    from apps.approvals.models import ExternalApproval
    from apps.approvals.registry import ApprovalEngine
    from apps.dynamic_forms.services import _resolve_approver  # email -> user (provisioned)

    body = payload.get("body", payload)          # accept {"body": {...}} or the body itself
    approvers = body.get("approvers") or []
    if not approvers:
        raise ValueError("At least one approver is required.")

    ext = ExternalApproval.objects.create(
        payload=body,
        result_callback_url=body.get("Result_Callback_URL", "") or payload.get("Result_Callback_URL", ""),
        name=body.get("name") or body.get("Workflow_Name", ""),
        title=body.get("title") or (approvers[0].get("title", "") if approvers else ""),
        priority=body.get("priority", "Normal"),
        require_callback_ack=bool(
            body.get("require_callback_ack",
                     body.get("Require_Callback_Ack",
                              body.get("require_callback_success", False)))
        ),
        login_required=bool(body.get("login_required", body.get("Login_Required", False))),
    )

    # One step per approver, in order, named by the approver's title (e.g.
    # "Validation Approval", then "Customer Approval").
    steps = []
    for i, ap in enumerate(approvers, start=1):
        user = _resolve_approver(ap["email"])
        steps.append(Flow.step(ap.get("title") or f"Approval {i}", approvers=[user]))

    slug = f"ext_{ext.pk}"
    Flow.define(slug, name=ext.title or ext.name or slug, steps=steps,
                notify_approvers=True, notify_initiator=False)

    from django.conf import settings as _s
    base_url = getattr(_s, "APP_BASE_URL", "") or base_url
    action_url = ""
    if base_url:
        token = signing.dumps(ext.pk, salt="ext-approval")
        action_url = f"{base_url}/forms/approve/{token}/"  # reusable token approve page
    req = ApprovalEngine.start(
        instance=ext, initiated_by=None, workflow=slug,
        context={
            "description": body.get("Details", "") or "External approval request.",
            "details": ext.as_dict(),
            "action_url": action_url,
            "base_url": base_url,
        },
    )
    if ext.login_required:
        _ce = (ext.creator_email or "").strip().lower()
        _clash = [a.get("email") for a in approvers
                  if (a.get("email") or "").strip().lower() == _ce]
        if _ce and _clash:
            logger.warning(
                "External #%s: login_required is set and creator %s is also an approver — "
                "they will NOT be able to act, so that stage will stall unless another "
                "approver can act on it.", ext.pk, _ce)
    logger.info(
        "External #%s created: request_id=%s, %d approver(s) %s, callback=%s",
        ext.pk, req.pk, len(approvers),
        [a.get("email") for a in approvers],
        ext.result_callback_url or "(none)",
    )
    if ext.login_required:
        _ce = (ext.creator_email or "").strip().lower()
        if _ce and any((a.get("email") or "").strip().lower() == _ce for a in approvers):
            logger.warning(
                "External #%s: login_required is set and creator %s is ALSO an approver — "
                "they cannot act on their own request, so that stage will stall unless "
                "someone else can act on it.", ext.pk, _ce)
    return ext, req


def build_response_document(ext, request):
    """Build the result payload (the shape the caller's API expects)."""
    from apps.approvals.states import TaskStatus

    responses = []
    for task in request.tasks.select_related("assignee", "step").order_by("step__order"):
        decided = task.status in (TaskStatus.APPROVED, TaskStatus.REJECTED)
        user = task.assignee
        responses.append({
            "responder": {
                "id": str(user.pk),
                "displayName": (user.get_full_name() or user.get_username()),
                "email": user.email or "",
                "userPrincipalName": user.email or user.get_username(),
            },
            "stage": task.step.name,
            "requestDate": task.created_at.isoformat() if task.created_at else None,
            "responseDate": (task.updated_at.isoformat() if decided and task.updated_at else None),
            "approverResponse": {"approved": "Approve", "rejected": "Reject"}.get(task.status, "Pending"),
            "comment": task.comment or "",
        })

    approved = request.state == "approved"
    rejected = request.state == "rejected"
    responded = sum(1 for r in responses if r["approverResponse"] in ("Approve", "Reject"))
    total = len(responses)
    if approved:
        outcome, summary = "Approved", "All approvers approved the request."
    elif rejected:
        outcome, summary = "Rejected", "The request was rejected."
    else:
        outcome = "Pending"
        summary = f"{responded} of {total} approvers have responded."
    doc = {
        "responses": responses,
        "responseSummary": summary,
        "completionDate": request.decided_at.isoformat() if request.decided_at else None,
        "outcome": outcome,
        "name": ext.name,
        "title": ext.title,
        "requestDate": request.submitted_at.isoformat() if request.submitted_at else None,
        "expirationDate": request.expires_at.isoformat() if request.expires_at else None,
        "priority": ext.priority,
        "confirmationRequired": ext.require_callback_ack,
    }
    # Echo back every metadata field the caller sent (with their original keys),
    # without overwriting the response structure above.
    for k, v in ext.echo_fields().items():
        doc.setdefault(k, v)
    return doc


def _completion_emails(ext, req, approved):
    """Email the result to the approvers and an optional requester
    (payload 'Requester_Email' / 'notify_email')."""
    from django.conf import settings
    from django.core.mail import EmailMultiAlternatives

    from apps.approvals.notifications.email_html import build_email
    from apps.approvals.services import ApprovalService

    verb = "request_approved" if approved else "request_rejected"
    description, details = ApprovalService._detail_payload(req)
    payload = {"summary": ext.title or ext.name, "description": description, "details": details}

    recipients = []
    for task in req.tasks.select_related("assignee"):
        email = getattr(task.assignee, "email", "")
        if email and email not in recipients:
            recipients.append(email)
    requester = ext.payload.get("Requester_Email") or ext.payload.get("notify_email")
    if requester and requester not in recipients:
        recipients.append(requester)

    if not recipients:
        logger.info("External #%s: no recipients for completion email", ext.pk)
        return
    subject, text_body, html_body = build_email(verb, payload)
    from_email = getattr(settings, "DEFAULT_FROM_EMAIL", "noreply@example.com")
    sent = []
    for email in recipients:
        try:
            msg = EmailMultiAlternatives(subject, text_body, from_email, [email])
            msg.attach_alternative(html_body, "text/html")
            msg.send(fail_silently=True)
            sent.append(email)
        except Exception as exc:
            logger.warning("External #%s: completion email to %s failed -> %s", ext.pk, email, exc)
    logger.info("External #%s: completion email (%s) sent to %s", ext.pk, verb, sent)


def on_external_decided(ext):
    """Engine callback (approved or rejected) -> email the result and POST it."""
    from apps.approvals.models import ApprovalRequest

    req = ApprovalRequest.objects.filter(
        content_type__app_label="approvals", content_type__model="externalapproval",
        object_id=ext.pk,
    ).order_by("-created_at").first()
    if req is None:
        logger.warning("External #%s decided but no ApprovalRequest found", ext.pk)
        return
    approved = req.state == "approved"
    ext.outcome = "Approved" if approved else "Rejected"
    logger.info("External #%s DECIDED: %s (request_id=%s)", ext.pk, ext.outcome, req.pk)

    _completion_emails(ext, req, approved)

    doc = build_response_document(ext, req)
    acked = _send_result(ext, doc, phase="final")
    ext.result_posted = acked
    ext.callback_acked = acked
    if ext.require_callback_ack and not acked:
        logger.warning(
            "External #%s: decision '%s' NOT CONFIRMED — callback did not return 2xx; "
            "treat as unconfirmed until the callback succeeds.", ext.pk, ext.outcome)
    elif ext.require_callback_ack and acked:
        logger.info("External #%s: decision '%s' CONFIRMED by callback (HTTP 2xx).",
                    ext.pk, ext.outcome)
    ext.save(update_fields=["outcome", "result_posted", "callback_acked", "updated_at"])
    return doc


from django.dispatch import receiver  # noqa: E402

from apps.approvals.signals import task_acted  # noqa: E402


@receiver(task_acted)
def _external_progress(sender, request, task, action, **kwargs):
    """POST a progress update to the caller on each approver decision. The final
    decision is handled by on_external_decided, so here we only fire for the
    intermediate (non-terminal) ones to avoid double-posting.

    This posts inline (same as the final callback) rather than on transaction
    commit, so it fires reliably for every intermediate approver — including when
    two stages share the same approver email."""
    from apps.approvals.models import ExternalApproval

    if request.is_terminal:
        return
    subject = request.subject
    if not isinstance(subject, ExternalApproval) or not subject.result_callback_url:
        return
    doc = build_response_document(subject, request)
    logger.info("External #%s: approver decision (%s) on '%s' — sending progress",
                subject.pk, action, getattr(task.step, "name", ""))
    _send_result(subject, doc, phase="progress")


def substitute_approver(ext, from_email, to_email, reason=""):
    """Swap the approver on ext's request by EMAIL — works ANY TIME, not just
    while their stage is active:
      1. If they have a PENDING task right now, delegate it (full audit trail +
         the same rich, detailed email a normal assignment gets).
      2. Otherwise, if they're listed as the approver on a step that HASN'T
         activated yet (e.g. stage 2 while stage 1 is still pending), swap the
         step's assignment now. No task/email exists yet for that stage, so
         nothing to notify — the NEW approver simply gets the normal
         task-assigned email (with their own approve link) once that stage
         activates, exactly like any other assignment.
    `to_email` need not already exist as a user (auto-provisioned). `reason` is
    optional."""
    from apps.approvals.models import ApprovalRequest
    from apps.approvals.models.workflow import ApproverKind, StepApprover
    from apps.approvals.services import ApprovalService
    from apps.approvals.states import ApprovalAction, TaskStatus
    from apps.dynamic_forms.services import _resolve_approver

    req = ApprovalRequest.objects.filter(
        content_type__app_label="approvals", content_type__model="externalapproval",
        object_id=ext.pk,
    ).order_by("-created_at").first()
    if req is None:
        raise ValueError("No approval request found for this external approval.")

    from_email = (from_email or "").strip().lower()
    to_user = _resolve_approver(to_email)
    owner = _resolve_approver(ext.creator_email) if ext.creator_email else None

    # Case 1: an active task right now -> delegate it (existing behaviour).
    task = req.tasks.filter(status=TaskStatus.PENDING, assignee__email__iexact=from_email).first()
    if task is not None:
        actor = owner or task.assignee
        return ApprovalService.delegate(
            task_id=task.pk, actor=actor, to_user=to_user,
            comment=reason or "Substituted via external API",
        )

    # Case 2: no task yet -> they're the approver on a step that hasn't
    # activated. Reassign the step itself so the NEW person gets it when it does.
    current_order = req.current_step.order if req.current_step_id else -1
    slots = list(StepApprover.objects.filter(
        step__workflow_id=req.workflow_id, step__order__gte=current_order,
        kind=ApproverKind.USER, user__email__iexact=from_email,
    ).select_related("step"))
    if not slots:
        raise ValueError(
            f"No pending or upcoming task found for approver '{from_email}'."
        )
    step_names = []
    for slot in slots:
        slot.user = to_user
        slot.save(update_fields=["user"])
        step_names.append(slot.step.name)
    ApprovalService._log(
        req, actor=owner or to_user, action=ApprovalAction.DELEGATE, task=None,
        comment=(f"Pre-emptively reassigned {from_email} -> {to_email} on upcoming "
                f"step(s): {', '.join(step_names)}. {reason}").strip(),
    )
    return None


