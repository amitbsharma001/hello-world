# django-notifications-framework

A production-grade, plug-and-play notification framework for Django. Install
it like `django.contrib.auth`, call one function from anywhere, and get
multi-channel delivery, live WebSocket updates, user preferences, scheduling,
a REST API, an admin dashboard, and a drop-in frontend widget.

```python
from django_notifications import notify

notify.success(user=request.user, title="Profile updated",
               message="Your changes were saved.")
```

```django
{% load django_notifications %}
{% notification_bell %}   {# bell + badge + live dropdown, one line #}
```

- **Universal API** — works in views, DRF, Celery tasks, signals, middleware,
  management commands, consumers, cron scripts. No request required.
- **Any recipient shape** — `user=`, `user_id=`, `users=` (queryset or list),
  `user_ids=`, `group=`/`groups=`, `permission=`, `everyone=True`, or a
  callable/dotted-path `recipients=`.
- **25+ built-in types, unlimited custom** — `notify.order(...)`,
  `notify.shipment_delayed(...)` just work.
- **Channels** — in-app, WebSocket, email, SMS, push, webhook (HMAC-signed),
  Slack, Teams, Discord, console — plus your own in ~10 lines.
- **Realtime** — Django Channels consumer with auto-reconnect and
  missed-notification sync; polling fallback when Channels isn't installed.
- **Async or sync** — uses Celery automatically when a broker is configured,
  falls back to synchronous delivery otherwise. `USE_CELERY = "auto"|True|False`.
- **User preferences** — per-channel opt-outs, muted types/categories, quiet
  hours (deliveries defer, not drop), digest fields, per-user timezone.
- **Scheduling** — `delay=`, `at=`, recurring `every=`/`until=`, TTL expiry.
- **Rich content** — sanitized HTML bodies, action buttons, attachments,
  icons, images, arbitrary `data`, actor/target generic relations, threading.
- **REST API** — list/unread/count/read/archive/delete/detail/preferences,
  session or token auth, pagination, filtering, search.
- **Admin dashboard** — level badges, per-channel delivery status, retry
  failed deliveries, template test-send, 14-day stats page.
- **Scale** — chunked `bulk_create` fan-out, composite indexes, optional
  Celery fan-out for very large audiences (`enqueue=True`), retention
  cleanup command.

Requires Python 3.12+ and Django 5.x. `djangorestframework` is the only hard
dependency; everything else is optional extras.

---

## Installation

```bash
pip install django-notifications-framework          # core
pip install "django-notifications-framework[all]"   # + channels, celery, nh3, markdown
```

```python
# settings.py
INSTALLED_APPS = [
    # ...
    "rest_framework",
    "django_notifications",
]
```

```bash
python manage.py migrate
```

```python
# urls.py
from django.urls import include, path

urlpatterns = [
    # ...
    path("notifications/", include("django_notifications.urls")),
]
```

That's a working install. Seed some data and look around:

```bash
python manage.py notifications_demo --user <your-username>
```

## The frontend, in one line

The widget is dependency-free vanilla JS + scoped CSS. It works inside
Bootstrap, Tailwind, HTMX, or plain Django templates without collisions, and
it injects its own assets, so this is genuinely all you need:

```django
{% load django_notifications %}
<nav>
  ...
  {% notification_bell %}
</nav>
```

You get: bell + unread badge, dropdown panel, All/Unread/Archived tabs,
search, infinite scroll, mark-read/pin/archive/delete with optimistic UI,
mark-all-read, toasts for live pushes, optional browser notifications,
relative timestamps, dark mode, mobile bottom-sheet layout, keyboard and
screen-reader support. Live updates use WebSockets when Channels is wired
(see below) and fall back to polling otherwise — no configuration needed.

Also available:

```django
{% notification_center %}            {# full inbox, embeddable on any page #}
{% notification_bell theme="dark" %} {# theme: auto | light | dark #}
{% unread_count user %}              {# server-side integer, no JS #}
```

A ready-made full page ships at `/notifications/page/`; override
`django_notifications/center_page.html` to wrap it in your base template.
An HTMX-friendly HTML fragment lives at `/notifications/partial/`.

Theming is pure CSS variables (defaults shown):

```css
.djn-widget {
  --djn-accent: #008ECF;
  --djn-radius: 2px;
  --djn-font: inherit;   /* inherits your app's font */
}
```

React/Vue? Use the headless ESM client
(`static/django_notifications/notifications.esm.js`) — same REST + WebSocket
protocol, no DOM. A complete example component is in
`django_notifications/frontend/react/NotificationBell.jsx`.

## Sending

```python
from django_notifications import notify

# Typed helpers (level, icon, category preset per type)
notify.success(user=user, title="Report ready", url="/reports/7/")
notify.error(user=user, title="Build failed", message="Pipeline #482")
notify.security(user=user, title="New sign-in")     # cannot be muted in-app
notify.system(title="Backups completed")            # -> staff by default
notify.announcement(title="Maintenance at 22:00")   # -> everyone

# Custom types are just attributes
notify.invoice_overdue(user=user, title="Invoice #9 overdue",
                       category="billing", channels=["in_app", "email"])

# Bulk
notify.bulk(group="engineers", title="Deploy finished")
notify.bulk(users=User.objects.filter(is_staff=True), title="Heads up")
notify.bulk(everyone=True, title="New feature", enqueue=True)  # Celery fan-out

# Scheduling
notify.schedule(user=user, title="Stand-up in 15 min", delay=900)
notify.schedule(user=user, title="Weekly digest",
                at=next_monday_9am, every=timedelta(weeks=1))

# Rich content
notify.info(
    user=user,
    title="PR #42 approved",
    body_html="<p><b>LGTM!</b> Two approvals.</p>",     # sanitized
    actions=[{"label": "Merge", "url": "/pr/42/merge", "style": "primary"},
             {"label": "View", "url": "/pr/42/"}],
    actor=reviewer, target=pull_request,
    data={"pr": 42},
)
```

Every kwarg is documented in [docs/usage.md](docs/usage.md).

## Event templates

Register once, trigger everywhere — and let non-developers override copy in
the admin (DB templates win over code):

```python
# any app's notifications.py — autodiscovered at startup
from django_notifications import notify

notify.register_event(
    "order.shipped",
    title="Order #{{ order.id }} shipped",
    message="Arriving {{ order.eta|date:'D, j M' }}",
    url="/orders/{{ order.id }}/",
    type="order",
)
```

```python
notify.event("order.shipped", user=order.user, context={"order": order})
```

## Realtime (optional)

```bash
pip install "django-notifications-framework[channels]"
```

```python
# asgi.py
from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter, URLRouter
from django_notifications.routing import websocket_urlpatterns

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AuthMiddlewareStack(URLRouter(websocket_urlpatterns)),
})
```

The widget detects the socket automatically. Reconnects use exponential
backoff and replay anything missed via `{"action": "sync"}`.

## Celery (optional)

```bash
pip install "django-notifications-framework[celery]"
```

With a broker configured, delivery is queued automatically (`USE_CELery =
"auto"`). Add the beat entries for scheduling and retention:

```python
app.conf.beat_schedule = {
    "djn-scheduler": {"task": "django_notifications.dispatch_due", "schedule": 60.0},
    "djn-cleanup":   {"task": "django_notifications.cleanup", "schedule": 86400.0},
}
```

No Celery? `python manage.py notifications_send_scheduled` from cron does the
same job, and delivery happens synchronously in-request.

## Configuration

One dict, sensible defaults, every key optional:

```python
DJANGO_NOTIFICATIONS = {
    "DEFAULT_CHANNELS": ["in_app", "websocket"],
    "TYPE_CHANNELS": {"security": ["in_app", "websocket", "email"]},
    "USE_CELERY": "auto",
    "EMAIL": {"FROM": None, "SUBJECT_PREFIX": ""},
    "WEBHOOK": {"URL": None, "SECRET": None},          # HMAC-SHA256 signed
    "SLACK": {"WEBHOOK_URL": None},
    "RATE_LIMIT": None,                                 # e.g. "100/m"
    "PREFERENCES": {"ENFORCE": True,
                    "QUIET_HOURS_CHANNELS": ["email", "sms", "push"]},
    "SYSTEM_RECIPIENTS": "staff",
    "CLEANUP": {"READ_AFTER_DAYS": 90, "ARCHIVED_AFTER_DAYS": 30},
}
```

Full reference: [docs/configuration.md](docs/configuration.md).

## REST API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/notifications/` | List (filters: `unread`, `archived`, `pinned`, `type`, `level`, `category`, `q`, `since_id`, `ordering`) |
| POST | `/notifications/` | Create (self; others per `API.CREATE_FOR_OTHERS`) |
| DELETE | `/notifications/` | Bulk delete `{"ids": [...]}` or `{"all": true}` |
| GET | `/notifications/unread/` | Unread only |
| GET | `/notifications/count/` | `{"unread": n, "total": m}` |
| PATCH | `/notifications/read/` | Mark read/unread |
| PATCH | `/notifications/archive/` | Archive/unarchive |
| GET/PATCH/DELETE | `/notifications/<id>/` | Detail, `{"read"/"pinned"/"archived"}` |
| GET/PATCH | `/notifications/preferences/` | User preferences |
| POST | `/notifications/broadcast/send/` | Broadcast to whole groups (per `API.BROADCAST`) |

## Custom channels

```python
from django_notifications.backends.base import BaseChannel

class PagerDutyChannel(BaseChannel):
    key = "pagerduty"
    def send(self, notification) -> bool:
        trigger_incident(notification.title, notification.message)
        return True   # False = skipped; raise DeliveryError/Retryable... to fail
```

```python
DJANGO_NOTIFICATIONS = {"CHANNELS": {"pagerduty": "myapp.channels.PagerDutyChannel"}}
notify.critical(user=oncall, title="DB down", channels=["pagerduty"])
```

## Project layout

```
django_notifications/   the installable app (models, services, API, widget)
docs/                   installation, configuration, usage, frontend, ops
example/                minimal runnable project wired end-to-end
deploy/k8s/             Deployment/Service manifests (web, worker, beat)
Dockerfile, docker-compose.yml, .github/workflows/ci.yml
```

## Development

```bash
pip install -e ".[all,dev]"
DJANGO_SETTINGS_MODULE=django_notifications.tests.settings python -m django test django_notifications
coverage run -m django test django_notifications && coverage report
```

114 tests, 93% line coverage (uncovered lines are mostly import-error guards
for optional dependencies).

## License

MIT — see [LICENSE](LICENSE).
