# Load the Celery app when celery is installed (docker-compose profile).
try:
    from .celery import app as celery_app  # noqa: F401
except ImportError:  # pragma: no cover
    pass
