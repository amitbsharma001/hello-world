import os

from celery import Celery

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "example.settings")

app = Celery("example")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    "djn-scheduler": {"task": "django_notifications.dispatch_due", "schedule": 60.0},
    "djn-cleanup": {"task": "django_notifications.cleanup", "schedule": 86400.0},
}
