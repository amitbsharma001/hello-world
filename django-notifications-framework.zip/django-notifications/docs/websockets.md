# WebSockets (Django Channels)

```bash
pip install "django-notifications-framework[channels]"
```

```python
# asgi.py
import os
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "project.settings")
django_asgi = get_asgi_application()

from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter, URLRouter
from django_notifications.routing import websocket_urlpatterns

application = ProtocolTypeRouter({
    "http": django_asgi,
    "websocket": AuthMiddlewareStack(URLRouter(websocket_urlpatterns)),
})
```

```python
CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels_redis.core.RedisChannelLayer",
        "CONFIG": {"hosts": [os.environ.get("REDIS_URL", "redis://localhost:6379/0")]},
    }
}
```

Serve with Daphne/Uvicorn. The endpoint path is
`DJANGO_NOTIFICATIONS["WEBSOCKET"]["PATH"]` (default `/ws/notifications/`).

## Wire protocol

Server → client:
`{"kind":"init","unread_count":n}` on connect;
`{"kind":"notification","notification":{...},"unread_count":n}` on push;
`{"kind":"counts","unread_count":n}` after state changes;
`{"kind":"sync","notifications":[...],"unread_count":n}` replaying missed items.

Client → server:
`{"action":"sync","since_id":123}`, `{"action":"mark_read","ids":[...]}`,
`{"action":"mark_all_read"}`, `{"action":"ping"}` → `{"kind":"pong"}`.

The bundled widget reconnects with exponential backoff + jitter and sends
`sync` with the highest id it has seen, so brief disconnects lose nothing.
Server-side pushes come from the `websocket` channel backend and from
`django_notifications.websocket.push_counts(user)` after read/archive/delete
via API. Without a channel layer, everything degrades gracefully (deliveries
recorded as skipped; widget polls).
