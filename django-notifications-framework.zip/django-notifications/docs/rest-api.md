# REST API

Mounted wherever you `include("django_notifications.urls")` — `/notifications/`
below. Auth defaults to DRF `SessionAuthentication` + `IsAuthenticated`;
swap in tokens/JWT without code:

```python
DJANGO_NOTIFICATIONS = {"API": {"AUTHENTICATION_CLASSES": [
    "rest_framework.authentication.TokenAuthentication",
]}}
```

Users only ever see their own notifications (object-level `IsRecipient`).

## Endpoints

### `GET /notifications/`
Query params: `page`, `page_size` (capped by `MAX_PAGE_SIZE`), `unread=1`,
`archived=1` (archived are excluded by default), `pinned=1`, `type`, `level`,
`category`, `thread_key`, `event`, `q` (title/message search), `since_id`
(incremental fetch), `ordering` (`created_at`, `-created_at`, `priority`,
`-priority`, `id`, `-id`; pinned always sort first).

```json
{"count": 42, "next": "...", "previous": null, "unread_count": 7,
 "results": [{"id": 1, "type": "success", "level": "success",
   "title": "Report ready", "message": "...", "url": "/reports/7/",
   "actions": [], "pinned": false, "is_read": false, "is_archived": false,
   "created_at": "2026-07-16T09:00:00Z", ...}]}
```

### `POST /notifications/`
`{"title", "message"?, "type"?, "recipient"?, "url"?, "body_html"?, "data"?,
"actions"?, "channels"?}` → `201` with the serialized notification.
`recipient` other than yourself is governed by `API.CREATE_FOR_OTHERS`
(`staff` default, `superusers`, `perm:app.codename`, `nobody`).

### `DELETE /notifications/`
Body `{"ids": [...]}` or `{"all": true}` → `{"deleted": n}`.

### `GET /notifications/unread/` — list, pre-filtered.
### `GET /notifications/count/` → `{"unread": n, "total": m}`.

### `PATCH /notifications/read/`
`{"ids": [...]}` or `{"all": true}`; add `"read": false` to mark unread.
→ `{"updated": n, "unread_count": m}`.

### `PATCH /notifications/archive/`
Same body shape; `"archived": false` un-archives ids.

### `/notifications/<id>/`
`GET` detail · `PATCH` `{"read"|"pinned"|"archived": bool}` · `DELETE` → 204.

### `/notifications/preferences/`
`GET` (created on first access) / `PATCH` any of: `enabled`,
`channel_settings` (`{"email": false}`), `muted_categories`, `muted_types`,
`quiet_hours_start/end` (`"HH:MM"`), `timezone`, `language`, `digest`
(`off|daily|weekly`), `digest_hour`.

## cURL

```bash
curl -H "Authorization: Token $T" https://app/notifications/?unread=1
curl -X PATCH -H "Authorization: Token $T" -H "Content-Type: application/json" \
     -d '{"all": true}' https://app/notifications/read/
```
