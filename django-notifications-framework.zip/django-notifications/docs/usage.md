# Sending notifications — full API

`from django_notifications import notify` and call it from anywhere. Every
helper accepts the same kwargs as `notify.send()`.

## Recipients (pick one style)

| Kwarg | Accepts |
|---|---|
| `user=` | a user instance |
| `user_id=` | an int |
| `users=` | queryset **or** list of users |
| `user_ids=` | iterable of ints |
| `group=` / `groups=` | Group instance(s) or name(s) |
| `permission=` | `"app_label.codename"` (direct, group, or superuser) |
| `everyone=True` | all active users |
| `recipients=` | user, iterable, queryset, callable, or dotted path returning any of those |

Duplicates across shapes are removed. Resolution is chunked
(`FANOUT_CHUNK`), so `everyone=True` on a million-user table won't load them
into memory.

## Classification

`type` (any string; presets exist for success/error/warning/info/critical/
system/security/audit/reminder/announcement/order/payment/shipping/message/
mention/comment/reaction/follow/invite/task/deadline/approval/alert/report/
maintenance/promotion/achievement...), `level` (debug/info/success/warning/
error/critical), `category`, `priority` (int, default 20), `thread_key`
(group related items), `source`, `event`.

## Content

`title` (required, ≤255), `message` (plain text), `body_html` (sanitized),
`content_format` ("plain"|"html"|"markdown"), `icon`, `image`, `url`,
`actions=[{"label", "url", "style"?}]`, `attachments=[{"url", "name"?, ...}]`,
`data={}` (arbitrary JSON), `actor=`, `target=` (any model instances).

## Routing & lifecycle

`channels=[...]` (defaults: `TYPE_CHANNELS[type]` or `DEFAULT_CHANNELS`),
`scheduled_for=`/`delay=`, `expires_at=`/`ttl=`, `repeat_interval=`+
`repeat_until=` (recurring; requires a schedule), `sync=True` (force
synchronous), `enqueue=True` (offload creation itself to Celery — for very
large audiences), `request=` (enables `RATE_LIMIT` accounting).

Scheduled notifications are invisible to users until dispatched; run the
scheduler (Celery beat task or `manage.py notifications_send_scheduled`).

## Return values

Single direct recipient (`user=`/`user_id=`) → the `Notification`.
Anything else → `BulkResult(created, ids[:1000], truncated, queued)`.

## Reading & state (server side)

```python
from django_notifications.models import Notification

Notification.objects.for_user(user).unread()        # queryset helpers:
# .unarchived() .archived() .pinned() .visible() .search(q) .since(id)
Notification.objects.unread_count(user)

from django_notifications.services import service
service.mark_read(user, ids=[...])      # or everything=True
service.archive(user, ids=[...])
service.delete(user, everything=True)
```

Instances: `n.mark_read()`, `n.mark_unread()`, `n.is_read`, `n.is_archived`,
`n.is_expired`.

## Signals

`django_notifications.signals` — `notification_created`,
`notification_read`, `delivery_sent`, `delivery_failed`.
