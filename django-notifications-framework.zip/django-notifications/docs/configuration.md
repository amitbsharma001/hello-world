# Configuration reference

Everything lives in one optional dict. Dict-valued keys are shallow-merged
with the defaults, so override only what you need.

```python
DJANGO_NOTIFICATIONS = {
    # ----------------------------------------------------------- delivery
    "DEFAULT_CHANNELS": ["in_app", "websocket"],
    "TYPE_CHANNELS": {},                # {"security": ["in_app", "email"]}
    "CHANNELS": {                        # registry; add your own here
        "in_app":    "django_notifications.backends.in_app.InAppChannel",
        "websocket": "django_notifications.backends.websocket.WebSocketChannel",
        "email":     "django_notifications.backends.email.EmailChannel",
        "console":   "django_notifications.backends.console.ConsoleChannel",
        "webhook":   "django_notifications.backends.webhook.WebhookChannel",
        "slack":     "django_notifications.backends.slack.SlackChannel",
        "teams":     "django_notifications.backends.teams.TeamsChannel",
        "discord":   "django_notifications.backends.discord.DiscordChannel",
        "sms":       "django_notifications.backends.sms.SMSChannel",
        "push":      "django_notifications.backends.push.PushChannel",
    },
    "MANDATORY_TYPES": ["security", "system", "critical"],  # bypass mutes (in-app/ws)

    # ------------------------------------------------------------- async
    "USE_CELERY": "auto",       # "auto" | True | False
    "CELERY_QUEUE": None,       # route package tasks to a dedicated queue
    "MAX_DELIVERY_ATTEMPTS": 3,
    "RETRY_BACKOFF_SECONDS": 30,  # doubled per retry, capped at 1h

    # ------------------------------------------------------------- scale
    "FANOUT_CHUNK": 500,        # recipients resolved per chunk
    "BATCH_SIZE": 1000,         # bulk_create batch size

    # ----------------------------------------------------------- content
    "SANITIZER": "django_notifications.validators.sanitize_html",
    "ALLOWED_TAGS": [...],      # see validators.py for the default list
    "ALLOWED_ATTRIBUTES": {...},
    "DEFAULT_TTL": None,        # seconds/timedelta applied when no expires_at

    # ------------------------------------------------------- preferences
    "PREFERENCES": {
        "ENFORCE": True,
        "QUIET_HOURS_CHANNELS": ["email", "sms", "push"],
    },

    # ---------------------------------------------------------- channels
    "EMAIL": {"FROM": None, "SUBJECT_PREFIX": "", "TEMPLATE_DIR": "django_notifications/email"},
    "WEBHOOK": {"URL": None, "SECRET": None, "TIMEOUT": 5, "HEADERS": {}},
    "SLACK":   {"WEBHOOK_URL": None, "TIMEOUT": 5},
    "TEAMS":   {"WEBHOOK_URL": None, "TIMEOUT": 5},
    "DISCORD": {"WEBHOOK_URL": None, "TIMEOUT": 5},
    "SMS":     {"GATEWAY_URL": None, "TIMEOUT": 5, "HEADERS": {}},
    "PUSH":    {"GATEWAY_URL": None, "TIMEOUT": 5, "HEADERS": {}},
    "USER_PHONE_GETTER": None,       # dotted path: fn(user) -> str | None
    "USER_WEBHOOK_GETTER": None,     # fn(user) -> url | None (overrides WEBHOOK.URL)
    "USER_PUSH_TOKEN_GETTER": None,  # fn(user) -> token | None
    "WEBSOCKET": {"GROUP_PREFIX": "djn.user.", "PATH": "/ws/notifications/"},

    # --------------------------------------------------------------- api
    "API": {
        "PAGE_SIZE": 20,
        "MAX_PAGE_SIZE": 100,
        "AUTHENTICATION_CLASSES": [],   # [] -> SessionAuthentication
        "PERMISSION_CLASSES": [],       # [] -> IsAuthenticated
        "CREATE_FOR_OTHERS": "staff",   # staff|superusers|perm:<app.codename>|nobody
    },

    # ---------------------------------------------------------- frontend
    "FRONTEND": {
        "USE_WEBSOCKET": True,      # widget attempts WS, falls back to polling
        "POLL_INTERVAL": 30,        # seconds; 0 disables polling
        "PAGE_SIZE": 15,
        "TOASTS": True,
        "BROWSER_NOTIFICATIONS": False,
        "THEME": "auto",            # auto | light | dark
    },

    # -------------------------------------------------------------- misc
    "SYSTEM_RECIPIENTS": "staff",   # staff|superusers|group:<name>|dotted-callable
    "RATE_LIMIT": None,             # "100/m" — per request-user, cache-backed
    "SITE_URL": None,               # falls back to settings.SITE_URL; absolutizes links
    "CLEANUP": {"READ_AFTER_DAYS": 90, "ARCHIVED_AFTER_DAYS": 30},
    "LOGGER": "django_notifications",
}
```

Settings are read live (safe with `override_settings`) and dotted paths are
resolved lazily, so you can point any hook at your own code.
