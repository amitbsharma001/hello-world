# Celery integration

`USE_CELERY = "auto"` (default): async when a broker is configured
(`CELERY_BROKER_URL` or app config), synchronous otherwise. Force with
`True`/`False`; per-call `sync=True` overrides. Broker down at enqueue time?
The service logs a warning and delivers synchronously — sends never silently
vanish.

Tasks (registered via `shared_task`, so your existing app picks them up):

| Task | Purpose |
|---|---|
| `django_notifications.deliver_chunk` | Execute deliveries for created notifications; retries with exponential backoff up to `MAX_DELIVERY_ATTEMPTS`. |
| `django_notifications.fanout` / `.fanout_chunk` | Create+deliver for serialized recipient specs (used by `enqueue=True`). |
| `django_notifications.dispatch_due` | Beat: send due scheduled notifications and quiet-hours-deferred deliveries. |
| `django_notifications.cleanup` | Beat: TTL + retention pruning. |

```python
app.conf.beat_schedule = {
    "djn-scheduler": {"task": "django_notifications.dispatch_due", "schedule": 60.0},
    "djn-cleanup":   {"task": "django_notifications.cleanup", "schedule": 86400.0},
}
```

Route to a dedicated queue with `DJANGO_NOTIFICATIONS["CELERY_QUEUE"]`.

## Without Celery

Cron the management commands:

```
* * * * *  python manage.py notifications_send_scheduled
0 3 * * *  python manage.py notifications_cleanup
```

`notifications_send_scheduled --forever --interval 30` also works as a tiny
long-running worker.
