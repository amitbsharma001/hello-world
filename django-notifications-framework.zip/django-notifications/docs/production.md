# Production notes

## Performance

- Fan-out is chunked (`FANOUT_CHUNK`) and inserted with `bulk_create`
  (`BATCH_SIZE`); a million-recipient announcement streams primary keys, it
  never materializes users in memory.
- Composite indexes cover the hot paths: `(recipient, -created_at)`,
  `(recipient, read_at)`, `(recipient, archived_at)`, plus type/category and
  scheduler indexes on `scheduled_for`/`deliver_after`.
- For huge broadcasts pass `enqueue=True` so creation itself runs in Celery
  chunks (`fanout_chunk` tasks) instead of the request.
- The unread badge is one indexed `COUNT`; the middleware count is lazy.
- `dispatch_due` uses `SELECT ... FOR UPDATE SKIP LOCKED` (PostgreSQL) so you
  can run multiple beat workers safely.
- Keep tables lean: schedule `django_notifications.cleanup` (or the
  management command) — TTL rows plus `CLEANUP.READ_AFTER_DAYS` /
  `ARCHIVED_AFTER_DAYS` retention.

## Security

- `body_html` is sanitized (nh3 when installed, strict stdlib allowlist
  otherwise): scripts, handlers, and `javascript:` URLs are stripped; links
  gain `rel="noopener noreferrer"`.
- Action/attachment payloads are schema-validated.
- API is recipient-scoped; creating for other users is policy-gated
  (`API.CREATE_FOR_OTHERS`); WebSocket consumer rejects anonymous sockets
  (4401).
- Outgoing webhooks can be HMAC-SHA256 signed (`WEBHOOK.SECRET` →
  `X-DJN-Signature: sha256=<hex>`); verify server-side with a constant-time
  compare of the raw body digest.
- `RATE_LIMIT = "100/m"` throttles request-attributed sends via the cache.
- Set `SITE_URL` so emails/webhooks contain absolute links.

## Deployment

`Dockerfile` + `docker-compose.yml` at the repo root run the example project
end-to-end: PostgreSQL, Redis, ASGI web (uvicorn), Celery worker, Celery
beat. `deploy/k8s/` contains equivalent Deployment/Service manifests to adapt
— web (ASGI), worker, beat, plus readiness probes hitting `/admin/login/`.

Checklist: run ASGI (daphne/uvicorn) when using WebSockets; put Redis behind
`CHANNEL_LAYERS` and the Celery broker; run exactly one beat; ship
`collectstatic` (the widget is plain static files, CDN-friendly);
monitor the `django_notifications` logger (`delivery.failed`,
`scheduler.run`) and the admin stats page for channel success rates.
