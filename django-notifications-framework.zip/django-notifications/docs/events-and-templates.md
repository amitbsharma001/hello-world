# Events & templates

Decouple "what happened" from "what the user sees". Trigger events in code;
define copy in code templates that product/ops can override in the admin.

## Register in code

Create `notifications.py` in any installed app — autodiscovered at startup:

```python
from django_notifications import notify

notify.register_event(
    "order.shipped",
    title="Order #{{ order.id }} shipped",
    message="Arriving {{ order.eta|date:'D, j M' }}",
    url="/orders/{{ order.id }}/",
    type="order",
    channels=["in_app", "email"],   # optional per-event routing
)
```

Templates are Django template strings; the context is what you pass to
`notify.event(...)` (plus `user` when a single `user=` is given).

## Trigger

```python
notify.event("order.shipped", user=order.user, context={"order": order})
notify.event("order.shipped", users=team, context={"order": order},
             strict=False)   # lenient: unknown event -> use kwargs as-is
```

Explicit kwargs win over template output, so callers can override anything.

## Admin overrides

`NotificationTemplate` rows with the same `event` take precedence over code —
edit copy, level, icon, or channels without a deploy. The admin's *"Send a
test notification to me"* action renders any template against your own user.

## Programmatic registry

```python
from django_notifications import events
events.register("x.y", title="...")
events.resolve("x.y", context, strict=True)
events.unregister("x.y"); events.registered()
```
