# Installation

## Requirements

- Python 3.12+
- Django 5.x
- djangorestframework 3.15+ (installed automatically)

## Steps

```bash
pip install django-notifications-framework
```

Optional extras:

| Extra | Adds | Enables |
|---|---|---|
| `[channels]` | channels, channels-redis | Live WebSocket updates |
| `[celery]` | celery, redis | Async delivery, beat scheduling |
| `[sanitize]` | nh3 | Faster/stronger HTML sanitizing (stdlib fallback built in) |
| `[markdown]` | markdown | `content_format="markdown"` rendering in emails |
| `[postgres]` | psycopg | Production database driver |
| `[all]` | all of the above | |

```python
INSTALLED_APPS = [
    ...,
    "rest_framework",
    "django_notifications",
]
```

```bash
python manage.py migrate
```

```python
# project urls.py
path("notifications/", include("django_notifications.urls")),
```

Optionally add the middleware for `request.unread_notifications_count`
(lazy — costs nothing unless a template reads it):

```python
MIDDLEWARE = [..., "django_notifications.middleware.NotificationsMiddleware"]
```

## Verify

```bash
python manage.py notifications_demo --user <username>
```

Sign in and open `/notifications/page/`, or drop `{% notification_bell %}`
into any template. Done.

## Upgrading

Standard Django app lifecycle: `pip install -U`, then `python manage.py
migrate django_notifications`.
