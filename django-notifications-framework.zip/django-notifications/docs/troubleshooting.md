# Troubleshooting

**`{% notification_bell %}` raises `TemplateSyntaxError` about URLs** —
include the urlconf: `path("notifications/", include("django_notifications.urls"))`.

**Widget renders but the list 403s** — the viewer isn't authenticated, or
you swapped `API.AUTHENTICATION_CLASSES` to token-auth while the widget uses
session cookies. Keep `SessionAuthentication` in the list for same-site pages.

**No live updates** — Channels isn't installed/wired (widget then polls every
`FRONTEND.POLL_INTERVAL`s — that's the designed fallback), the ASGI router
doesn't mount `django_notifications.routing.websocket_urlpatterns`, or
`CHANNEL_LAYERS` is missing. Check the browser console for the `/ws/…` frame.

**Emails not sending** — user has no email (delivery recorded as `skipped`),
Django `EMAIL_BACKEND` unconfigured, or the recipient's preferences opt out
of email/quiet hours deferred it (see the Delivery rows in admin —
`deferred` + `deliver_after` means quiet hours).

**Scheduled notifications never arrive** — nothing runs the scheduler. Add
the `dispatch_due` beat task or cron `manage.py notifications_send_scheduled`.

**Celery installed but delivery is synchronous** — `USE_CELERY="auto"`
requires a configured broker; set `CELERY_BROKER_URL` or `USE_CELERY=True`.
Broker unreachable at runtime logs *"Celery enqueue failed … falling back"*.

**Deliveries stuck `pending`** — they were queued for Celery but no worker
consumes the queue (check `CELERY_QUEUE` routing). Admin → Deliveries →
*Retry selected* executes them inline.

**`notify.x()` raised `UnknownChannelError`** — a `channels=[...]` key isn't
in the `CHANNELS` registry; typos fail fast by design.

**Duplicate widget assets** — you emitted `{% notifications_assets %}` and
left `assets=True` on the tag. Harmless (the JS is idempotent) but pass
`assets=False` to keep the HTML tidy.

**Counts look wrong across tabs** — state pushes flow through the WebSocket;
with polling-only there's up to `POLL_INTERVAL` seconds of lag by design.

Still stuck? Enable logging:

```python
LOGGING = {"loggers": {"django_notifications": {"level": "DEBUG",
                                                "handlers": ["console"]}}}
```
