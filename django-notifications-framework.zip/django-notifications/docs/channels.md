# Delivery channels

A channel is a class with a `send(notification) -> bool` method. Returning
`False` records the delivery as **skipped** (e.g. user has no phone number);
raising `RetryableDeliveryError` triggers Celery retries with backoff (or a
single failure in sync mode); any other exception (ideally `DeliveryError`)
is a permanent failure. All outcomes are stored per `(notification, channel)`
on the `Delivery` model and visible in the admin, which can bulk-retry.

## Built-ins

| Key | Notes |
|---|---|
| `in_app` | The DB row itself; always cheap. |
| `websocket` | Pushes through Channels; silently skipped without a channel layer. |
| `email` | `EmailMultiAlternatives`; templates in `django_notifications/email/` (`subject.txt`, `body.txt`, `body.html`) — override per project. Skips users without an address. |
| `console` | Prints; handy in development. |
| `webhook` | POSTs the full serialized notification. Global `WEBHOOK.URL` or per-user via `USER_WEBHOOK_GETTER`. `WEBHOOK.SECRET` adds an HMAC-SHA256 `X-DJN-Signature` header. |
| `slack` / `teams` / `discord` | Incoming-webhook payloads (Block Kit / Adaptive Card / embeds). Set `<NAME>.WEBHOOK_URL`. |
| `sms` / `push` | Provider-agnostic JSON POST to `GATEWAY_URL`; per-user address via `USER_PHONE_GETTER` / `USER_PUSH_TOKEN_GETTER`. Subclass and override `build_payload()` for Twilio/FCM/APNs shapes. |

## Writing your own

```python
# myapp/channels.py
from django_notifications.backends.base import BaseChannel
from django_notifications.exceptions import RetryableDeliveryError

class PagerDutyChannel(BaseChannel):
    key = "pagerduty"

    def send(self, notification) -> bool:
        if notification.level not in ("error", "critical"):
            return False                      # skipped
        ok = pagerduty.trigger(
            summary=notification.title,
            details=self.plain_text(notification),
            link=self.absolute_url(notification),
        )
        if not ok:
            raise RetryableDeliveryError("PagerDuty 5xx")
        return True
```

```python
DJANGO_NOTIFICATIONS = {
    "CHANNELS": {"pagerduty": "myapp.channels.PagerDutyChannel"},
    "TYPE_CHANNELS": {"critical": ["in_app", "websocket", "pagerduty"]},
}
```

`BaseChannel` helpers: `self.plain_text(n)` (title+message),
`self.absolute_url(n)` (uses `SITE_URL`).

## Routing recap

Per-call `channels=[...]` → else `TYPE_CHANNELS[type]` → else
`DEFAULT_CHANNELS`. User preferences filter that list at dispatch time;
`MANDATORY_TYPES` always keep `in_app` + `websocket`.
