# Frontend integration

## Drop-in (any Django template)

```django
{% load django_notifications %}
{% notification_bell %}
```

That single line renders the bell, badge, and dropdown, loads the CSS/JS
(idempotently), points itself at your mounted URLs, connects the WebSocket if
available, and otherwise polls. It has **zero** JS dependencies and every
class is prefixed `djn-`, so Bootstrap/Tailwind/anything coexist happily.

Tag options: `theme="auto|light|dark"`, `assets=False` (if you emit
`{% notifications_assets %}` once in `<head>` yourself).

`{% notification_center %}` renders the full inbox inline on any page —
tabs, search, archive view, infinite scroll. A standalone page using it is
already routed at `/notifications/page/`; override
`templates/django_notifications/center_page.html` to `{% extends %}` your
base instead.

`{% unread_count user %}` gives a plain server-rendered integer for
custom badges (no JS at all).

## Theming

CSS custom properties, override anywhere:

```css
.djn-widget {
  --djn-accent: #008ECF;   /* brand color */
  --djn-radius: 2px;       /* corner rounding */
  --djn-width: 384px;      /* dropdown width */
  --djn-font: inherit;     /* inherits your app font by default */
  /* --djn-bg, --djn-fg, --djn-border, --djn-hover, --djn-unread, ... */
}
```

Dark mode: `theme="dark"` forces it; the default `auto` follows
`prefers-color-scheme`. Mobile (<520px) turns the dropdown into a bottom
sheet. `prefers-reduced-motion` disables animation. Badge updates announce
via `aria-live`; Esc/outside-click close; everything is keyboard reachable.

## HTMX / server-rendered

`GET /notifications/partial/?filter=all|unread|archived&q=&page=` returns an
HTML fragment (`_items.html`) with an hx-get "Load more" hook:

```html
<div hx-get="/notifications/partial/" hx-trigger="load"></div>
```

## React / Vue / SPA

Use the headless ESM client — same REST+WS protocol, no DOM:

```js
import { NotificationsClient } from "/static/django_notifications/notifications.esm.js";

const client = new NotificationsClient({ apiBase: "/notifications/" });
client.on("counts", n => setUnread(n));
client.on("notification", n => prepend(n));
client.connect();                         // WS + auto-reconnect + sync
const { results, next } = await client.list({ page: 1 });
await client.markRead({ ids: [7] });      // archive/remove/patchOne/deleteOne/preferences...
```

A complete component lives at
`django_notifications/frontend/react/NotificationBell.jsx`.

For dynamically injected markup (HTMX swaps, SPAs), re-init with
`window.DjangoNotifications.initAll(container)`.

## Widget config

The tags serialize config into `data-djn-config`; you can hand-write the
markup and tweak: `apiBase`, `wsPath`, `useWebSocket`, `pollInterval`,
`pageSize`, `toasts`, `browserNotifications`, `theme`, `pageUrl`,
`csrfCookie`. Defaults come from the `FRONTEND` settings block.
