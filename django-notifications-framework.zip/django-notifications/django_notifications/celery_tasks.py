"""Celery tasks.

Import-guarded: when Celery is not installed every task name is ``None`` and
the service layer transparently delivers synchronously. When Celery *is*
installed the tasks register with ``@shared_task`` and bind to whatever app
your project configures — no extra wiring.

Recommended beat schedule (add to your celery config)::

    app.conf.beat_schedule = {
        "django-notifications-scheduler": {
            "task": "django_notifications.dispatch_due",
            "schedule": 60.0,
        },
        "django-notifications-cleanup": {
            "task": "django_notifications.cleanup",
            "schedule": 3600.0 * 24,
        },
    }
"""

from __future__ import annotations

import logging
from typing import Any

from .settings import app_settings

logger = logging.getLogger(app_settings.LOGGER)

try:
    from celery import shared_task

    HAS_CELERY = True
except ImportError:  # pragma: no cover - exercised in celery-less installs
    HAS_CELERY = False
    shared_task = None  # type: ignore[assignment]


if HAS_CELERY:

    @shared_task(
        name="django_notifications.deliver_chunk",
        bind=True,
        max_retries=None,  # per-delivery attempts capped by the service
        acks_late=True,
    )
    def deliver_chunk_task(self, notification_ids: list[int]) -> dict[str, int]:
        """Create + execute deliveries for a chunk of notifications.

        Idempotent: already-sent deliveries are never re-run; a retry only
        re-attempts deliveries still in ``pending``.
        """
        from .models import Notification
        from .repository import preferences_by_user
        from .services import service

        notifications = list(
            Notification.objects.filter(pk__in=notification_ids).select_related(
                "recipient"
            )
        )
        preferences = preferences_by_user(
            [n.recipient_id for n in notifications if n.recipient_id]
        )
        total_sent = total_retryable = 0
        for notification in notifications:
            if not notification.deliveries.exists():
                deliveries = service.dispatch(
                    notification,
                    preferences.get(notification.recipient_id),
                    execute=False,
                )
                pending = [d for d in deliveries if d.status == "pending"]
            else:
                pending = list(notification.deliveries.pending())
            sent, retryable = service.execute_deliveries(
                notification, pending, allow_retry=True
            )
            total_sent += sent
            total_retryable += retryable

        if total_retryable:
            backoff = app_settings.RETRY_BACKOFF_SECONDS * (2 ** self.request.retries)
            raise self.retry(countdown=min(backoff, 3600))
        return {"sent": total_sent}

    @shared_task(name="django_notifications.fanout", acks_late=True)
    def fanout_task(recipient_spec: dict[str, Any], payload: dict[str, Any]) -> int:
        """Create + deliver notifications for a serialized recipient spec."""
        from .services import deserialize_payload, service

        data = deserialize_payload(payload)
        result = service.send(**recipient_spec, **_as_send_kwargs(data), sync=None)
        return getattr(result, "created", 1)

    @shared_task(name="django_notifications.fanout_chunk", acks_late=True)
    def fanout_chunk_task(user_ids: list[int], payload: dict[str, Any]) -> int:
        """Create + deliver notifications for an explicit id chunk."""
        from .services import deserialize_payload, service

        data = deserialize_payload(payload)
        result = service.send(user_ids=user_ids, **_as_send_kwargs(data))
        return getattr(result, "created", 1)

    @shared_task(name="django_notifications.dispatch_due")
    def dispatch_due_task(limit: int = 500) -> dict[str, int]:
        """Beat task: send due scheduled notifications + deferred deliveries."""
        from .services import service

        return service.dispatch_due(limit=limit)

    @shared_task(name="django_notifications.cleanup")
    def cleanup_task() -> dict[str, int]:
        """Beat task: prune expired and aged-out notifications."""
        from .management.commands.notifications_cleanup import run_cleanup

        return run_cleanup()

    def _as_send_kwargs(data: dict[str, Any]) -> dict[str, Any]:
        """Map persisted-model payload keys back to ``send()`` kwargs."""
        mapped = dict(data)
        mapped.pop("sent_at", None)
        # Rebuild generic relations as the objects send() expects.
        for prefix in ("actor", "target"):
            content_type = mapped.pop(f"{prefix}_content_type", None)
            object_id = mapped.pop(f"{prefix}_object_id", None)
            if content_type is not None and object_id is not None:
                mapped[prefix] = content_type.get_object_for_this_type(pk=object_id)
        return mapped

else:  # pragma: no cover
    deliver_chunk_task = None
    fanout_task = None
    fanout_chunk_task = None
    dispatch_due_task = None
    cleanup_task = None
