"""WebSocket URL routing.

Add to your project's ASGI application::

    # asgi.py
    from channels.auth import AuthMiddlewareStack
    from channels.routing import ProtocolTypeRouter, URLRouter
    from django_notifications.routing import websocket_urlpatterns

    application = ProtocolTypeRouter({
        "http": django_asgi_app,
        "websocket": AuthMiddlewareStack(URLRouter(websocket_urlpatterns)),
    })
"""

from __future__ import annotations

from .settings import app_settings

try:
    from django.urls import re_path

    from .consumers import HAS_CHANNELS, NotificationConsumer

    if HAS_CHANNELS:
        websocket_urlpatterns = [
            re_path(
                app_settings.WEBSOCKET["URL_PATTERN"],
                NotificationConsumer.as_asgi(),
                name="django_notifications_ws",
            )
        ]
    else:  # pragma: no cover
        websocket_urlpatterns = []
except ImportError:  # pragma: no cover
    websocket_urlpatterns = []
