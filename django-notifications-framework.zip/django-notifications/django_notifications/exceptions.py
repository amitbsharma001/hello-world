"""Exception hierarchy for django_notifications.

All exceptions inherit from :class:`NotificationError` so callers can catch
one base class. Delivery backends raise :class:`RetryableDeliveryError` to
signal that a retry (via Celery) is worthwhile.
"""

from __future__ import annotations


class NotificationError(Exception):
    """Base class for all django_notifications errors."""


class ConfigurationError(NotificationError):
    """Raised when DJANGO_NOTIFICATIONS settings are invalid."""


class NoRecipientsError(NotificationError):
    """Raised when a send call resolves to zero recipients."""


class UnknownChannelError(NotificationError):
    """Raised when a channel key is not present in the channel registry."""


class EventNotRegisteredError(NotificationError):
    """Raised by ``notify.event`` for an unknown event with strict=True."""


class RateLimitedError(NotificationError):
    """Raised when the service-level creation rate limit is exceeded."""


class DeliveryError(NotificationError):
    """A delivery attempt failed permanently (no retry)."""


class RetryableDeliveryError(DeliveryError):
    """A delivery attempt failed but may succeed on retry (network, 5xx...)."""


class ValidationError(NotificationError):
    """Raised when notification payload validation fails."""
