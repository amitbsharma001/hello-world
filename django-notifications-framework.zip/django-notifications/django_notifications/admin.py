"""Django admin: operations dashboard for notifications.

Highlights: colored level badges, per-channel delivery inline with error
details, bulk retry of failed deliveries, template test-send, and a
statistics page (last 14 days volume, per-type counts, channel success
rates) at ``…/notification/stats/``.
"""

from __future__ import annotations

from django.contrib import admin, messages
from django.db.models import Count, Q
from django.db.models.functions import TruncDate
from django.template.response import TemplateResponse
from django.urls import path
from django.utils import timezone
from django.utils.html import format_html

from .models import Delivery, Notification, NotificationPreference, NotificationTemplate

_LEVEL_COLORS = {
    "debug": "#6b7280",
    "info": "#008ECF",
    "success": "#2e7d32",
    "warning": "#b26a00",
    "error": "#c62828",
    "critical": "#7f1d1d",
}
_STATUS_COLORS = {
    "pending": "#6b7280",
    "queued": "#0369a1",
    "sent": "#2e7d32",
    "failed": "#c62828",
    "skipped": "#9ca3af",
    "deferred": "#b26a00",
}


def _badge(text: str, color: str) -> str:
    return format_html(
        '<span style="background:{}1a;color:{};border:1px solid {};'
        'padding:1px 8px;border-radius:2px;font-size:11px;'
        'font-weight:600;text-transform:uppercase;">{}</span>',
        color, color, color, text,
    )


class DeliveryInline(admin.TabularInline):
    model = Delivery
    extra = 0
    can_delete = False
    readonly_fields = (
        "channel", "status", "attempts", "last_error", "deliver_after", "sent_at",
    )

    def has_add_permission(self, request, obj=None) -> bool:
        return False


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = (
        "id", "title", "recipient", "type", "level_badge", "category",
        "read_flag", "pinned", "delivery_summary", "created_at",
    )
    list_filter = ("level", "type", "category", "pinned", "created_at")
    search_fields = ("title", "message", "recipient__username", "recipient__email")
    date_hierarchy = "created_at"
    raw_id_fields = ("recipient",)
    readonly_fields = ("created_at", "updated_at", "sent_at")
    actions = ("mark_read", "mark_unread", "archive", "retry_failed_deliveries")
    list_select_related = ("recipient",)
    list_per_page = 50

    # -- display helpers -----------------------------------------------------

    @admin.display(description="Level", ordering="level")
    def level_badge(self, obj: Notification) -> str:
        return _badge(obj.level, _LEVEL_COLORS.get(obj.level, "#6b7280"))

    @admin.display(description="Read", boolean=True, ordering="read_at")
    def read_flag(self, obj: Notification) -> bool:
        return obj.is_read

    @admin.display(description="Deliveries")
    def delivery_summary(self, obj: Notification) -> str:
        parts = [
            _badge(f"{d.channel}:{d.status}", _STATUS_COLORS.get(d.status, "#6b7280"))
            for d in obj.deliveries.all()
        ]
        return format_html(" ".join("{}" for _ in parts), *parts) if parts else "—"

    def get_queryset(self, request):
        return super().get_queryset(request).prefetch_related("deliveries")

    inlines = [DeliveryInline]

    # -- actions -----------------------------------------------------------------

    @admin.action(description="Mark selected as read")
    def mark_read(self, request, queryset) -> None:
        self.message_user(request, f"Marked {queryset.mark_read()} as read.")

    @admin.action(description="Mark selected as unread")
    def mark_unread(self, request, queryset) -> None:
        self.message_user(request, f"Marked {queryset.mark_unread()} as unread.")

    @admin.action(description="Archive selected")
    def archive(self, request, queryset) -> None:
        self.message_user(request, f"Archived {queryset.archive()}.")

    @admin.action(description="Retry failed deliveries")
    def retry_failed_deliveries(self, request, queryset) -> None:
        from .services import service

        requeued = Delivery.objects.filter(notification__in=queryset).requeue()
        executed = 0
        for notification in queryset.prefetch_related("deliveries"):
            pending = list(notification.deliveries.pending())
            if pending:
                sent, _ = service.execute_deliveries(
                    notification, pending, allow_retry=False
                )
                executed += sent
        self.message_user(
            request,
            f"Requeued {requeued} failed deliveries; {executed} sent.",
            level=messages.SUCCESS,
        )

    # -- stats page ----------------------------------------------------------------

    def get_urls(self):
        return [
            path(
                "stats/",
                self.admin_site.admin_view(self.stats_view),
                name="django_notifications_notification_stats",
            )
        ] + super().get_urls()

    def stats_view(self, request):
        since = timezone.now() - timezone.timedelta(days=14)
        daily = list(
            Notification.objects.filter(created_at__gte=since)
            .annotate(day=TruncDate("created_at"))
            .values("day")
            .annotate(count=Count("id"))
            .order_by("day")
        )
        peak = max((row["count"] for row in daily), default=1)
        for row in daily:
            row["pct"] = int(row["count"] / peak * 100)
        by_type = list(
            Notification.objects.values("type")
            .annotate(count=Count("id"), unread=Count("id", filter=Q(read_at=None)))
            .order_by("-count")[:15]
        )
        by_channel = list(
            Delivery.objects.values("channel")
            .annotate(
                total=Count("id"),
                sent=Count("id", filter=Q(status="sent")),
                failed=Count("id", filter=Q(status="failed")),
                pending=Count("id", filter=Q(status__in=["pending", "queued"])),
            )
            .order_by("-total")
        )
        context = {
            **self.admin_site.each_context(request),
            "title": "Notification statistics",
            "daily": daily,
            "by_type": by_type,
            "by_channel": by_channel,
            "totals": {
                "all": Notification.objects.count(),
                "unread": Notification.objects.filter(read_at=None).count(),
                "failed_deliveries": Delivery.objects.failed().count(),
                "scheduled": Notification.objects.filter(
                    scheduled_for__isnull=False, sent_at__isnull=True
                ).count(),
            },
        }
        return TemplateResponse(
            request, "django_notifications/admin/stats.html", context
        )


@admin.register(Delivery)
class DeliveryAdmin(admin.ModelAdmin):
    list_display = (
        "id", "notification", "channel", "status_badge", "attempts",
        "deliver_after", "sent_at", "updated_at",
    )
    list_filter = ("channel", "status")
    search_fields = ("notification__title", "last_error")
    raw_id_fields = ("notification",)
    actions = ("retry",)
    list_per_page = 50

    @admin.display(description="Status", ordering="status")
    def status_badge(self, obj: Delivery) -> str:
        return _badge(obj.status, _STATUS_COLORS.get(obj.status, "#6b7280"))

    @admin.action(description="Retry selected (failed → pending, execute now)")
    def retry(self, request, queryset) -> None:
        from .services import service

        requeued = queryset.requeue()
        executed = 0
        for delivery in queryset.filter(status="pending").select_related("notification"):
            sent, _ = service.execute_deliveries(
                delivery.notification, [delivery], allow_retry=False
            )
            executed += sent
        self.message_user(request, f"Requeued {requeued}; {executed} sent.")


@admin.register(NotificationTemplate)
class NotificationTemplateAdmin(admin.ModelAdmin):
    list_display = ("event", "name", "type", "level", "is_active", "updated_at")
    list_filter = ("is_active", "type", "level")
    search_fields = ("event", "name", "title_template")
    actions = ("send_test",)

    @admin.action(description="Send a test notification to me")
    def send_test(self, request, queryset) -> None:
        from .services import service

        for template in queryset:
            service.send_event(
                template.event,
                context={"user": request.user},
                strict=False,
                user=request.user,
            )
        self.message_user(request, f"Sent {queryset.count()} test notification(s) to you.")


@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    list_display = (
        "user", "enabled", "digest", "quiet_hours_start", "quiet_hours_end", "updated_at",
    )
    list_filter = ("enabled", "digest")
    search_fields = ("user__username", "user__email")
    raw_id_fields = ("user",)
