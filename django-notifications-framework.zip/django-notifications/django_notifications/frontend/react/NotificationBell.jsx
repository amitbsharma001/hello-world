/* Example: React notification bell built on the headless client.
 *
 * Copy into your React app (or adapt for Vue — the client is framework-
 * agnostic). Serve the ESM client from Django's static files:
 *
 *   import { NotificationsClient } from
 *     "/static/django_notifications/notifications.esm.js";
 *
 * Requires the API to be mounted at /notifications/ and (optionally) the
 * Channels consumer at /ws/notifications/ for realtime.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { NotificationsClient } from "/static/django_notifications/notifications.esm.js";

export default function NotificationBell({ apiBase = "/notifications/" }) {
  const clientRef = useRef(null);
  const [unread, setUnread] = useState(0);
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const [nextPage, setNextPage] = useState(null);

  useEffect(() => {
    const client = new NotificationsClient({ apiBase });
    clientRef.current = client;
    const offCounts = client.on("counts", setUnread);
    const offPush = client.on("notification", (n) =>
      setItems((prev) => (prev.some((i) => i.id === n.id) ? prev : [n, ...prev]))
    );
    client.connect();
    client.count().then(({ unread }) => setUnread(unread)).catch(() => {});
    return () => { offCounts(); offPush(); client.disconnect(); };
  }, [apiBase]);

  const load = useCallback(async (page = 1) => {
    const data = await clientRef.current.list({ page });
    setItems((prev) => (page === 1 ? data.results : [...prev, ...data.results]));
    setNextPage(data.next ? page + 1 : null);
    clientRef.current.track(data.results);
  }, []);

  const toggle = () => {
    setOpen((wasOpen) => {
      if (!wasOpen && items.length === 0) load(1).catch(() => {});
      return !wasOpen;
    });
  };

  const markAllRead = async () => {
    setItems((prev) => prev.map((n) => ({ ...n, is_read: true })));
    const { unread_count } = await clientRef.current.markRead({ all: true });
    setUnread(unread_count);
  };

  return (
    <div style={{ position: "relative", display: "inline-block" }}>
      <button onClick={toggle} aria-expanded={open} aria-label="Notifications">
        🔔{unread > 0 && <sup>{unread > 99 ? "99+" : unread}</sup>}
      </button>
      {open && (
        <div role="dialog" aria-label="Notifications"
             style={{ position: "absolute", right: 0, width: 360, maxHeight: 420,
                      overflow: "auto", background: "#fff",
                      border: "1px solid #e4e7ec", borderTop: "2px solid #008ECF" }}>
          <header style={{ display: "flex", justifyContent: "space-between", padding: 12 }}>
            <strong>Notifications</strong>
            <button onClick={markAllRead}>Mark all read</button>
          </header>
          <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
            {items.map((n) => (
              <li key={n.id}
                  style={{ padding: 12, borderTop: "1px solid #f0f0f0",
                           background: n.is_read ? "transparent" : "#f0f8fc" }}>
                <a href={n.url || "#"}
                   onClick={() => clientRef.current.markRead({ ids: [n.id] })}>
                  <strong>{n.title}</strong>
                </a>
                {n.message && <p style={{ margin: "4px 0 0" }}>{n.message}</p>}
              </li>
            ))}
            {items.length === 0 && <li style={{ padding: 24 }}>You're all caught up.</li>}
          </ul>
          {nextPage && <button onClick={() => load(nextPage)}>Load more</button>}
        </div>
      )}
    </div>
  );
}
