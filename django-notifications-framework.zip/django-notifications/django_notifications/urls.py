"""URL configuration.

Include once in the project urlconf::

    path("notifications/", include("django_notifications.urls")),

This exposes:

* ``GET|POST|DELETE /notifications/`` — list / create / bulk delete
* ``GET  /notifications/unread/``
* ``GET  /notifications/count/``
* ``PATCH /notifications/read/`` — ``{"ids": [...]}`` or ``{"all": true}``
* ``PATCH /notifications/archive/``
* ``GET|PATCH|DELETE /notifications/<id>/``
* ``GET|PATCH /notifications/preferences/``
* ``GET /notifications/page/`` — full notification-center page
* ``GET /notifications/partial/`` — HTML fragment (HTMX-friendly)
* ``GET /notifications/broadcast/`` — broadcast composer page
* ``POST /notifications/broadcast/send/`` — send to whole groups
* ``GET /notifications/groups/`` — selectable groups for the broadcast picker
"""

from __future__ import annotations

from django.urls import path

from . import views

app_name = "django_notifications"

urlpatterns = [
    path("", views.NotificationListView.as_view(), name="list"),
    path("unread/", views.UnreadListView.as_view(), name="unread"),
    path("count/", views.CountView.as_view(), name="count"),
    path("read/", views.MarkReadView.as_view(), name="read"),
    path("archive/", views.ArchiveView.as_view(), name="archive"),
    path("preferences/", views.PreferencesView.as_view(), name="preferences"),
    path("page/", views.NotificationCenterView.as_view(), name="center"),
    path("partial/", views.NotificationPartialView.as_view(), name="partial"),
    path("broadcast/", views.BroadcastPageView.as_view(), name="broadcast_page"),
    path("broadcast/send/", views.BroadcastView.as_view(), name="broadcast"),
    path("groups/", views.GroupListView.as_view(), name="groups"),
    path("<int:pk>/", views.NotificationDetailView.as_view(), name="detail"),
]
