"""Settings for django_notifications.

All configuration lives under a single ``DJANGO_NOTIFICATIONS`` dict in the
project's settings module. Every key has a production-safe default, so a bare

    INSTALLED_APPS = [..., "django_notifications"]

works with zero configuration. Access settings through the module-level
``app_settings`` object::

    from django_notifications.settings import app_settings
    app_settings.DEFAULT_CHANNELS

Dotted-path values are resolved lazily and cached. ``override_settings`` in
tests is honoured via Django's ``setting_changed`` signal.
"""

from __future__ import annotations

import copy
from typing import Any

from django.conf import settings as django_settings
from django.core.signals import setting_changed
from django.utils.module_loading import import_string

from .exceptions import ConfigurationError

SETTINGS_KEY = "DJANGO_NOTIFICATIONS"

DEFAULTS: dict[str, Any] = {
    # ------------------------------------------------------------------ core
    # Registry of channel key -> backend class (dotted path). Extend or
    # replace entries to plug in custom delivery channels.
    "CHANNELS": {
        "in_app": "django_notifications.backends.in_app.InAppChannel",
        "websocket": "django_notifications.backends.websocket.WebSocketChannel",
        "email": "django_notifications.backends.email.EmailChannel",
        "sms": "django_notifications.backends.sms.SMSChannel",
        "push": "django_notifications.backends.push.PushChannel",
        "webhook": "django_notifications.backends.webhook.WebhookChannel",
        "slack": "django_notifications.backends.slack.SlackChannel",
        "teams": "django_notifications.backends.teams.TeamsChannel",
        "discord": "django_notifications.backends.discord.DiscordChannel",
        "console": "django_notifications.backends.console.ConsoleChannel",
    },
    # Channels used when a send call does not specify any.
    "DEFAULT_CHANNELS": ["in_app", "websocket"],
    # Optional per-type channel routing, e.g. {"security": ["in_app", "email"]}.
    "TYPE_CHANNELS": {},
    # Types that bypass user mutes for in-app delivery (never silenceable).
    "MANDATORY_TYPES": ["security", "system", "critical"],
    # --------------------------------------------------------------- async
    # "auto": use Celery if importable and a default app is configured;
    # True: require Celery; False: always deliver synchronously.
    "USE_CELERY": "auto",
    "CELERY_QUEUE": None,  # e.g. "notifications"
    "MAX_DELIVERY_ATTEMPTS": 3,
    "RETRY_BACKOFF_SECONDS": 30,  # base for exponential backoff
    # ---------------------------------------------------------------- scale
    "BATCH_SIZE": 1000,  # bulk_create batch size
    "FANOUT_CHUNK": 500,  # recipients per fan-out chunk/task
    # ------------------------------------------------------------ recipients
    # Who receives ``notify.system(...)`` when no recipient is given:
    # "staff" | "superusers" | "group:<name>" | dotted path to a callable
    # returning a queryset/iterable of users.
    "SYSTEM_RECIPIENTS": "staff",
    # ------------------------------------------------------------- content
    "SANITIZER": "django_notifications.validators.sanitize_html",
    "ALLOWED_TAGS": None,  # None -> validators.DEFAULT_ALLOWED_TAGS
    "ALLOWED_ATTRIBUTES": None,
    # -------------------------------------------------------------- expiry
    "DEFAULT_TTL": None,  # timedelta or seconds; None = never expires
    # ---------------------------------------------------------- preferences
    "PREFERENCES": {
        "ENFORCE": True,
        # Channels that respect quiet hours (deferred until quiet end).
        "QUIET_HOURS_CHANNELS": ["email", "sms", "push"],
    },
    # ---------------------------------------------------------------- email
    "EMAIL": {
        "FROM": None,  # None -> settings.DEFAULT_FROM_EMAIL
        "SUBJECT_PREFIX": "",
        "SUBJECT_TEMPLATE": "django_notifications/email/subject.txt",
        "BODY_TXT_TEMPLATE": "django_notifications/email/body.txt",
        "BODY_HTML_TEMPLATE": "django_notifications/email/body.html",
        "REPLY_TO": None,
    },
    # ----------------------------------------------------- outbound webhooks
    "WEBHOOK": {
        "URL": None,  # global default; per-user override via USER_WEBHOOK_GETTER
        "SECRET": None,  # HMAC-SHA256 signature in X-DJN-Signature when set
        "TIMEOUT": 5,
        "HEADERS": {},
    },
    "SLACK": {"WEBHOOK_URL": None, "TIMEOUT": 5},
    "TEAMS": {"WEBHOOK_URL": None, "TIMEOUT": 5},
    "DISCORD": {"WEBHOOK_URL": None, "TIMEOUT": 5},
    # Dotted callables resolving per-user delivery addresses. Each receives
    # the user instance and returns a string or None (None -> skip).
    "USER_PHONE_GETTER": None,
    "USER_WEBHOOK_GETTER": None,
    "USER_PUSH_TOKEN_GETTER": None,
    # SMS/Push are generic HTTP gateway backends; point them at your gateway.
    "SMS": {"GATEWAY_URL": None, "TIMEOUT": 5, "HEADERS": {}},
    "PUSH": {"GATEWAY_URL": None, "TIMEOUT": 5, "HEADERS": {}},
    # ------------------------------------------------------------ websocket
    "WEBSOCKET": {
        "GROUP_PREFIX": "djn.user",
        "URL_PATTERN": r"^ws/notifications/$",  # used by routing.py
        "PATH": "/ws/notifications/",  # advertised to the frontend widget
    },
    # ------------------------------------------------------------- REST API
    "API": {
        "PAGE_SIZE": 20,
        "MAX_PAGE_SIZE": 100,
        # Dotted paths; None -> [SessionAuthentication]. Permissions default
        # to IsAuthenticated.
        "AUTHENTICATION_CLASSES": None,
        "PERMISSION_CLASSES": None,
        # Who may POST notifications through the API to *other* users:
        # "staff" (default), "superusers", "perm:<app.codename>", or "nobody".
        "CREATE_FOR_OTHERS": "staff",
        # Who may broadcast to whole groups (bell-popup "Broadcast" page and
        # POST /broadcast/). Same vocabulary as CREATE_FOR_OTHERS.
        "BROADCAST": "staff",
    },
    # ------------------------------------------------------------- security
    # Service-level creation rate limit per (source user or "anonymous"),
    # e.g. "100/m", "1000/h". None disables. Requires a configured cache.
    "RATE_LIMIT": None,
    # ------------------------------------------------------------- frontend
    "FRONTEND": {
        "POLL_INTERVAL": 30,  # seconds; 0 disables polling fallback
        "USE_WEBSOCKET": True,
        "BROWSER_NOTIFICATIONS": False,  # Notification API toasts on push
        "THEME": "auto",  # auto | light | dark
        "PAGE_SIZE": 15,
        "TOASTS": True,
    },
    # -------------------------------------------------------------- cleanup
    "CLEANUP": {"READ_AFTER_DAYS": None, "ARCHIVED_AFTER_DAYS": None},
    # ------------------------------------------------------------- logging
    "LOGGER": "django_notifications",
}

#: Keys whose values are dicts and should be shallow-merged with defaults
#: instead of replaced wholesale.
_MERGE_KEYS = (
    "CHANNELS",
    "PREFERENCES",
    "EMAIL",
    "WEBHOOK",
    "SLACK",
    "TEAMS",
    "DISCORD",
    "SMS",
    "PUSH",
    "WEBSOCKET",
    "API",
    "FRONTEND",
    "CLEANUP",
)

#: Keys (or dotted sub-keys) that hold import strings resolved on access.
_IMPORT_KEYS = (
    "SANITIZER",
    "SYSTEM_RECIPIENTS",  # only when it looks like a dotted path
    "USER_PHONE_GETTER",
    "USER_WEBHOOK_GETTER",
    "USER_PUSH_TOKEN_GETTER",
)


class AppSettings:
    """Lazy accessor over ``settings.DJANGO_NOTIFICATIONS`` with defaults."""

    def __init__(self) -> None:
        self._cache: dict[str, Any] = {}

    # -- public API --------------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        if name in self._cache:
            return self._cache[name]
        if name not in DEFAULTS:
            raise ConfigurationError(f"Unknown DJANGO_NOTIFICATIONS setting: {name!r}")
        value = self._user_settings().get(name, DEFAULTS[name])
        if name in _MERGE_KEYS and isinstance(value, dict):
            merged = copy.deepcopy(DEFAULTS[name])
            merged.update(value)
            value = merged
        self._cache[name] = value
        return value

    def resolve(self, name: str) -> Any:
        """Return the setting with any dotted import string resolved."""
        value = getattr(self, name)
        if isinstance(value, str) and name in _IMPORT_KEYS and "." in value:
            resolved = import_string(value)
            self._cache[name] = resolved
            return resolved
        return value

    def channel_backend(self, key: str) -> type:
        """Return the backend class registered for ``key`` (cached)."""
        registry: dict[str, Any] = self.CHANNELS
        try:
            entry = registry[key]
        except KeyError as exc:
            from .exceptions import UnknownChannelError

            raise UnknownChannelError(
                f"Channel {key!r} is not registered. Known channels: "
                f"{sorted(registry)}"
            ) from exc
        if isinstance(entry, str):
            entry = import_string(entry)
            registry[key] = entry  # cache resolved class in merged dict
        return entry

    def reload(self) -> None:
        """Drop all cached values (used on ``setting_changed``)."""
        self._cache.clear()

    # -- internals ---------------------------------------------------------

    @staticmethod
    def _user_settings() -> dict[str, Any]:
        value = getattr(django_settings, SETTINGS_KEY, {}) or {}
        if not isinstance(value, dict):
            raise ConfigurationError(f"settings.{SETTINGS_KEY} must be a dict.")
        return value


app_settings = AppSettings()


def _reload_on_change(*, setting: str, **kwargs: Any) -> None:
    if setting == SETTINGS_KEY:
        app_settings.reload()


setting_changed.connect(_reload_on_change)
