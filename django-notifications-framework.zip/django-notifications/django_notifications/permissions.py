"""DRF permission classes for the notification API."""

from __future__ import annotations

from rest_framework.permissions import BasePermission

from .settings import app_settings


class IsRecipient(BasePermission):
    """Object-level guard: users only ever touch their own notifications."""

    def has_object_permission(self, request, view, obj) -> bool:
        return obj.recipient_id == request.user.pk


class CanCreateForOthers(BasePermission):
    """Governs POST /notifications/ targeting other users.

    Controlled by ``API.CREATE_FOR_OTHERS``: "staff" (default),
    "superusers", "perm:<app_label.codename>", or "nobody". Sending to
    yourself is always allowed.
    """

    message = "You are not allowed to send notifications to other users."

    def has_permission(self, request, view) -> bool:
        if request.method != "POST":
            return True
        target = request.data.get("recipient") or request.data.get("user_id")
        if target in (None, "", request.user.pk, str(request.user.pk)):
            return True
        policy = app_settings.API["CREATE_FOR_OTHERS"]
        if policy == "nobody":
            return False
        if policy == "staff":
            return bool(request.user.is_staff)
        if policy == "superusers":
            return bool(request.user.is_superuser)
        if isinstance(policy, str) and policy.startswith("perm:"):
            return request.user.has_perm(policy.split(":", 1)[1])
        return False
