"""DRF permission classes for the notification API."""

from __future__ import annotations

from typing import Any

from rest_framework.permissions import BasePermission

from .settings import app_settings


def policy_grants(user: Any, policy: str) -> bool:
    """Evaluate a ``"staff"|"superusers"|"perm:<app.codename>"|"nobody"`` policy.

    Shared by the create-for-others and broadcast permissions and by the
    template tag that decides whether to show the Broadcast control.
    """
    if user is None or not getattr(user, "is_authenticated", False):
        return False
    if policy == "nobody":
        return False
    if policy == "staff":
        return bool(user.is_staff)
    if policy == "superusers":
        return bool(user.is_superuser)
    if isinstance(policy, str) and policy.startswith("perm:"):
        return user.has_perm(policy.split(":", 1)[1])
    return False


def user_can_broadcast(user: Any) -> bool:
    """Whether ``user`` may broadcast to groups (per ``API.BROADCAST``)."""
    return policy_grants(user, app_settings.API["BROADCAST"])


class IsRecipient(BasePermission):
    """Object-level guard: users only ever touch their own notifications."""

    def has_object_permission(self, request, view, obj) -> bool:
        return obj.recipient_id == request.user.pk


class CanCreateForOthers(BasePermission):
    """Governs POST /notifications/ targeting other users.

    Controlled by ``API.CREATE_FOR_OTHERS``: "staff" (default),
    "superusers", "perm:<app_label.codename>", or "nobody". Sending to
    yourself is always allowed.
    """

    message = "You are not allowed to send notifications to other users."

    def has_permission(self, request, view) -> bool:
        if request.method != "POST":
            return True
        target = request.data.get("recipient") or request.data.get("user_id")
        if target in (None, "", request.user.pk, str(request.user.pk)):
            return True
        return policy_grants(request.user, app_settings.API["CREATE_FOR_OTHERS"])


class CanBroadcast(BasePermission):
    """Governs broadcasting to whole groups (bell-popup Broadcast page + API).

    Controlled by ``API.BROADCAST`` with the same vocabulary as
    ``CREATE_FOR_OTHERS``.
    """

    message = "You are not allowed to broadcast notifications."

    def has_permission(self, request, view) -> bool:
        return user_can_broadcast(request.user)
