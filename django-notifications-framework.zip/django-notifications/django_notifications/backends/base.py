"""Base class every delivery channel implements."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from ..models import Notification


class BaseChannel(ABC):
    """Contract for a delivery channel.

    Implementations should be stateless (a fresh instance is created per
    delivery) and raise:

    * :class:`~django_notifications.exceptions.RetryableDeliveryError` for
      transient failures (timeouts, 5xx) — the dispatcher retries with
      exponential backoff when Celery is available.
    * :class:`~django_notifications.exceptions.DeliveryError` for permanent
      failures (bad config, 4xx) — marked failed immediately.

    Returning ``False`` from :meth:`send` marks the delivery ``skipped``
    (e.g. user has no phone number); returning ``True``/``None`` marks it
    ``sent``.
    """

    #: Registry key; informational (the registry in settings is the source
    #: of truth for routing).
    key: str = ""

    @abstractmethod
    def send(self, notification: Notification) -> bool | None:
        """Deliver ``notification`` to its recipient over this channel."""

    # -- shared helpers -----------------------------------------------------

    @staticmethod
    def plain_text(notification: Notification) -> str:
        """Title + message as a single plain-text block."""
        parts = [notification.title]
        if notification.message:
            parts.append(notification.message)
        return "\n".join(parts)

    @staticmethod
    def absolute_url(notification: Notification) -> str:
        """Best-effort absolute URL for the notification's click target."""
        url = notification.url or ""
        if url.startswith(("http://", "https://")) or not url:
            return url
        from django.conf import settings

        base = getattr(settings, "SITE_URL", "") or ""
        return f"{base.rstrip('/')}{url}" if base else url
