"""Microsoft Teams channel via incoming webhook (Adaptive Card)."""

from __future__ import annotations

from ..settings import app_settings
from .base import BaseChannel
from .http import post_json


class TeamsChannel(BaseChannel):
    key = "teams"

    def send(self, notification) -> bool:
        conf = app_settings.TEAMS
        url = conf.get("WEBHOOK_URL")
        if not url:
            return False
        body: list[dict] = [
            {"type": "TextBlock", "text": notification.title, "weight": "Bolder", "size": "Medium"},
        ]
        if notification.message:
            body.append({"type": "TextBlock", "text": notification.message, "wrap": True})
        card: dict = {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "type": "AdaptiveCard",
                        "version": "1.4",
                        "body": body,
                    },
                }
            ],
        }
        link = self.absolute_url(notification)
        if link:
            card["attachments"][0]["content"]["actions"] = [
                {"type": "Action.OpenUrl", "title": "Open", "url": link}
            ]
        post_json(url, card, timeout=conf.get("TIMEOUT", 5))
        return True
