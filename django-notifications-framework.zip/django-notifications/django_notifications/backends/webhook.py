"""Generic outbound webhook channel.

Resolution order for the target URL:

1. Per-user URL via ``USER_WEBHOOK_GETTER`` (dotted callable in settings).
2. Global ``WEBHOOK.URL``.

Payloads are signed with HMAC-SHA256 (``X-DJN-Signature``) when
``WEBHOOK.SECRET`` is set.
"""

from __future__ import annotations

from ..settings import app_settings
from .base import BaseChannel
from .http import post_json


def build_payload(notification) -> dict:
    return {
        "id": notification.pk,
        "type": notification.type,
        "level": notification.level,
        "category": notification.category,
        "title": notification.title,
        "message": notification.message,
        "url": notification.url,
        "data": notification.data,
        "recipient_id": notification.recipient_id,
        "created_at": notification.created_at.isoformat(),
    }


class WebhookChannel(BaseChannel):
    key = "webhook"

    def get_url(self, notification) -> str | None:
        getter = app_settings.resolve("USER_WEBHOOK_GETTER")
        if callable(getter) and notification.recipient is not None:
            url = getter(notification.recipient)
            if url:
                return url
        return app_settings.WEBHOOK.get("URL")

    def send(self, notification) -> bool:
        url = self.get_url(notification)
        if not url:
            return False  # skipped: nowhere to deliver
        conf = app_settings.WEBHOOK
        post_json(
            url,
            {"event": "notification.created", "notification": build_payload(notification)},
            timeout=conf.get("TIMEOUT", 5),
            headers=conf.get("HEADERS") or {},
            secret=conf.get("SECRET"),
        )
        return True
