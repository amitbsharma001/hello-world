"""Email channel using Django's mail framework and overridable templates."""

from __future__ import annotations

from django.conf import settings as django_settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string

from ..exceptions import RetryableDeliveryError
from ..settings import app_settings
from .base import BaseChannel


class EmailChannel(BaseChannel):
    key = "email"

    def send(self, notification) -> bool:
        user = notification.recipient
        email = getattr(user, "email", "") if user else ""
        if not email:
            return False  # skipped: recipient has no address

        conf = app_settings.EMAIL
        context = {
            "notification": notification,
            "user": user,
            "url": self.absolute_url(notification),
        }
        subject = render_to_string(conf["SUBJECT_TEMPLATE"], context).strip()
        subject = f"{conf['SUBJECT_PREFIX']}{subject}".splitlines()[0][:250]
        text_body = render_to_string(conf["BODY_TXT_TEMPLATE"], context)
        html_body = render_to_string(conf["BODY_HTML_TEMPLATE"], context)

        from_email = conf["FROM"] or getattr(
            django_settings, "DEFAULT_FROM_EMAIL", "webmaster@localhost"
        )
        message = EmailMultiAlternatives(
            subject=subject,
            body=text_body,
            from_email=from_email,
            to=[email],
            reply_to=[conf["REPLY_TO"]] if conf.get("REPLY_TO") else None,
        )
        message.attach_alternative(html_body, "text/html")
        try:
            message.send(fail_silently=False)
        except Exception as exc:  # SMTP errors are typically transient
            raise RetryableDeliveryError(f"Email send failed: {exc}") from exc
        return True
