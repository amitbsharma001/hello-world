"""Slack channel via incoming webhook (Block Kit payload)."""

from __future__ import annotations

from ..settings import app_settings
from .base import BaseChannel
from .http import post_json

_LEVEL_EMOJI = {
    "success": ":white_check_mark:",
    "warning": ":warning:",
    "error": ":x:",
    "critical": ":rotating_light:",
}


class SlackChannel(BaseChannel):
    key = "slack"

    def send(self, notification) -> bool:
        conf = app_settings.SLACK
        url = conf.get("WEBHOOK_URL")
        if not url:
            return False
        emoji = _LEVEL_EMOJI.get(notification.level, ":bell:")
        blocks: list[dict] = [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"{emoji} *{notification.title}*\n{notification.message}",
                },
            }
        ]
        link = self.absolute_url(notification)
        if link:
            blocks.append(
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {"type": "plain_text", "text": "Open"},
                            "url": link,
                        }
                    ],
                }
            )
        post_json(
            url,
            {"text": self.plain_text(notification), "blocks": blocks},
            timeout=conf.get("TIMEOUT", 5),
        )
        return True
