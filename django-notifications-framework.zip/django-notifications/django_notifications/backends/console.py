"""Console channel: prints notifications; useful in development/tests."""

from __future__ import annotations

import sys

from .base import BaseChannel


class ConsoleChannel(BaseChannel):
    key = "console"

    def send(self, notification) -> bool:
        recipient = getattr(notification.recipient, "pk", None)
        sys.stdout.write(
            f"[django_notifications] to=user:{recipient} "
            f"type={notification.type} title={notification.title!r} "
            f"message={notification.message!r}\n"
        )
        return True
