"""Push channel via a generic HTTP gateway (FCM proxy, ntfy, Gotify...).

Sends ``{"token", "title", "body", "url", "data"}`` to ``PUSH.GATEWAY_URL``;
the device token is resolved with ``USER_PUSH_TOKEN_GETTER``. Subclass and
override :meth:`build_payload` for provider-specific shapes. Browser
notifications for the bundled widget are handled client-side over the
WebSocket channel and need no server config.
"""

from __future__ import annotations

from ..settings import app_settings
from .base import BaseChannel
from .http import post_json


class PushChannel(BaseChannel):
    key = "push"

    def get_token(self, user) -> str | None:
        getter = app_settings.resolve("USER_PUSH_TOKEN_GETTER")
        if callable(getter) and user is not None:
            return getter(user)
        return None

    def build_payload(self, notification, token: str) -> dict:
        return {
            "token": token,
            "title": notification.title,
            "body": notification.message,
            "url": self.absolute_url(notification),
            "data": notification.data,
        }

    def send(self, notification) -> bool:
        conf = app_settings.PUSH
        gateway = conf.get("GATEWAY_URL")
        token = self.get_token(notification.recipient)
        if not gateway or not token:
            return False  # skipped
        post_json(
            gateway,
            self.build_payload(notification, token),
            timeout=conf.get("TIMEOUT", 5),
            headers=conf.get("HEADERS") or {},
        )
        return True
