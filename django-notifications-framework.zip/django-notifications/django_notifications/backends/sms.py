"""SMS channel via a generic HTTP gateway.

Provider-agnostic: point ``SMS.GATEWAY_URL`` at any HTTP endpoint (Twilio
proxy, Kannel, an internal gateway...). The payload is ``{"to", "message"}``;
subclass and override :meth:`build_payload` for provider-specific shapes.
The recipient's number is resolved with ``USER_PHONE_GETTER``.
"""

from __future__ import annotations

from ..settings import app_settings
from .base import BaseChannel
from .http import post_json


class SMSChannel(BaseChannel):
    key = "sms"

    def get_phone(self, user) -> str | None:
        getter = app_settings.resolve("USER_PHONE_GETTER")
        if callable(getter) and user is not None:
            return getter(user)
        return getattr(user, "phone_number", None) if user else None

    def build_payload(self, notification, phone: str) -> dict:
        return {"to": phone, "message": self.plain_text(notification)[:640]}

    def send(self, notification) -> bool:
        conf = app_settings.SMS
        gateway = conf.get("GATEWAY_URL")
        phone = self.get_phone(notification.recipient)
        if not gateway or not phone:
            return False  # skipped
        post_json(
            gateway,
            self.build_payload(notification, phone),
            timeout=conf.get("TIMEOUT", 5),
            headers=conf.get("HEADERS") or {},
        )
        return True
