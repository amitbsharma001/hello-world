"""In-app channel: the persisted Notification row *is* the delivery."""

from __future__ import annotations

from .base import BaseChannel


class InAppChannel(BaseChannel):
    """No external side effect; marks the DB record as delivered in-app.

    Kept as an explicit channel so preference toggles, delivery logs and
    per-type routing treat in-app like any other channel.
    """

    key = "in_app"

    def send(self, notification) -> bool:
        return True
