"""Tiny stdlib HTTP client for webhook-style channels (no `requests` dep)."""

from __future__ import annotations

import hashlib
import hmac
import json
import urllib.error
import urllib.request

from ..exceptions import DeliveryError, RetryableDeliveryError


def post_json(
    url: str,
    payload: dict,
    *,
    timeout: int = 5,
    headers: dict[str, str] | None = None,
    secret: str | None = None,
) -> int:
    """POST ``payload`` as JSON. Returns the HTTP status on 2xx.

    Raises :class:`RetryableDeliveryError` on network errors / 5xx / 429 and
    :class:`DeliveryError` on other 4xx.
    """
    body = json.dumps(payload, default=str).encode("utf-8")
    request_headers = {"Content-Type": "application/json", **(headers or {})}
    if secret:
        signature = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        request_headers["X-DJN-Signature"] = f"sha256={signature}"
    request = urllib.request.Request(url, data=body, headers=request_headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:  # noqa: S310
            return int(response.status)
    except urllib.error.HTTPError as exc:
        if exc.code >= 500 or exc.code == 429:
            raise RetryableDeliveryError(f"HTTP {exc.code} from {url}") from exc
        raise DeliveryError(f"HTTP {exc.code} from {url}") from exc
    except urllib.error.URLError as exc:
        raise RetryableDeliveryError(f"Network error posting to {url}: {exc.reason}") from exc
    except TimeoutError as exc:
        raise RetryableDeliveryError(f"Timeout posting to {url}") from exc
