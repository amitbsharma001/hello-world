"""Pluggable delivery channel backends.

A channel is any class implementing :class:`~.base.BaseChannel`. Register
custom channels in settings::

    DJANGO_NOTIFICATIONS = {
        "CHANNELS": {"pagerduty": "myapp.channels.PagerDutyChannel"},
        "DEFAULT_CHANNELS": ["in_app", "websocket", "pagerduty"],
    }
"""

from .base import BaseChannel

__all__ = ["BaseChannel"]
