"""Discord channel via incoming webhook (embed payload)."""

from __future__ import annotations

from ..settings import app_settings
from .base import BaseChannel
from .http import post_json

_LEVEL_COLOR = {
    "success": 0x2E7D32,
    "info": 0x008ECF,
    "warning": 0xF9A825,
    "error": 0xC62828,
    "critical": 0xB71C1C,
}


class DiscordChannel(BaseChannel):
    key = "discord"

    def send(self, notification) -> bool:
        conf = app_settings.DISCORD
        url = conf.get("WEBHOOK_URL")
        if not url:
            return False
        embed = {
            "title": notification.title[:256],
            "description": (notification.message or "")[:4000],
            "color": _LEVEL_COLOR.get(notification.level, 0x008ECF),
        }
        link = self.absolute_url(notification)
        if link:
            embed["url"] = link
        post_json(url, {"embeds": [embed]}, timeout=conf.get("TIMEOUT", 5))
        return True
