"""WebSocket channel: pushes the serialized notification over Channels.

Silently skips (status ``skipped``) when Django Channels or a channel layer
is not configured, so the default channel set works on any project.
"""

from __future__ import annotations

from ..websocket import push_notification
from .base import BaseChannel


class WebSocketChannel(BaseChannel):
    key = "websocket"

    def send(self, notification) -> bool:
        if notification.recipient_id is None:
            return False
        return push_notification(notification)
