"""Template tags — the one-line frontend integration.

Anywhere in any Django template::

    {% load django_notifications %}
    <html>
      <head>{% notifications_assets %}</head>
      <body>
        ... navbar ... {% notification_bell %} ...
        {% notification_center %}   {# optional full inbox on any page #}
      </body>
    </html>

``notification_bell``/``notification_center`` inject their own assets by
default (deduplicated client-side), so the single tag alone is enough. Works
with Bootstrap, Tailwind, plain Django templates, HTMX pages — the widget is
dependency-free vanilla JS scoped under ``.djn-*`` with CSS variables for
theming.
"""

from __future__ import annotations

import json

from django import template
from django.template.loader import render_to_string
from django.urls import NoReverseMatch, reverse
from django.utils.safestring import mark_safe

from ..settings import app_settings

register = template.Library()

_URLS_HINT = (
    "django_notifications URLs are not included. Add "
    "path('notifications/', include('django_notifications.urls')) to your "
    "project urlconf."
)


def _build_config(overrides: dict | None = None) -> dict:
    frontend = app_settings.FRONTEND
    try:
        api_base = reverse("django_notifications:list")
        page_url = reverse("django_notifications:center")
        partial_url = reverse("django_notifications:partial")
        prefs_url = reverse("django_notifications:preferences")
    except NoReverseMatch as exc:  # pragma: no cover - config error path
        raise template.TemplateSyntaxError(_URLS_HINT) from exc
    config = {
        "apiBase": api_base,
        "pageUrl": page_url,
        "partialUrl": partial_url,
        "prefsUrl": prefs_url,
        "wsPath": app_settings.WEBSOCKET["PATH"],
        "useWebSocket": frontend["USE_WEBSOCKET"],
        "pollInterval": frontend["POLL_INTERVAL"],
        "pageSize": frontend["PAGE_SIZE"],
        "toasts": frontend["TOASTS"],
        "browserNotifications": frontend["BROWSER_NOTIFICATIONS"],
        "theme": frontend["THEME"],
        "csrfCookie": "csrftoken",
    }
    config.update(overrides or {})
    return config


@register.simple_tag
def notifications_assets() -> str:
    """<link> + <script> tags for the widget (idempotent client-side)."""
    return mark_safe(
        render_to_string("django_notifications/assets.html")
    )


@register.simple_tag(takes_context=True)
def notification_bell(context, theme: str | None = None, assets: bool = True) -> str:
    """Drop-in bell + badge + dropdown panel. ``theme``: auto|light|dark."""
    config = _build_config({"mode": "bell"})
    if theme:
        config["theme"] = theme
    return mark_safe(
        render_to_string(
            "django_notifications/bell.html",
            {
                "config_json": json.dumps(config),
                "theme": config["theme"],
                "include_assets": assets,
            },
            request=context.get("request"),
        )
    )


@register.simple_tag(takes_context=True)
def notification_center(context, theme: str | None = None, assets: bool = True) -> str:
    """Full inline notification center (inbox) for any page."""
    config = _build_config({"mode": "center"})
    if theme:
        config["theme"] = theme
    return mark_safe(
        render_to_string(
            "django_notifications/center.html",
            {
                "config_json": json.dumps(config),
                "theme": config["theme"],
                "include_assets": assets,
            },
            request=context.get("request"),
        )
    )


@register.simple_tag
def unread_count(user) -> int:
    """Server-side unread count for a user (no JS)."""
    if user is None or not getattr(user, "is_authenticated", False):
        return 0
    from ..models import Notification

    return Notification.objects.unread_count(user)
