"""The universal ``notify`` API.

Import it anywhere — views, DRF, Celery tasks, signals, middleware, models,
forms, management commands, cron jobs, consumers, GraphQL resolvers, plain
scripts — with zero setup::

    from django_notifications import notify

    notify.success(user=request.user, title="Profile updated",
                   message="Changes saved successfully.")
    notify.event("order.created", user=order.user, context={"order": order})
    notify.bulk(users=User.objects.filter(is_staff=True),
                title="Deployment complete")
    notify.schedule(user=user, title="Stand-up", delay=3600,
                    every=86400)  # daily reminder

Any attribute becomes a typed sender, so ``notify.shipment_delayed(...)``
just works and sets ``type="shipment_delayed"``. All heavy imports happen at
call time, which keeps this module importable before Django's app registry
is ready.
"""

from __future__ import annotations

import datetime as dt
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover
    from .models import Notification
    from .services import BulkResult

__all__ = ["notify", "Notify"]

_DOC_TEMPLATE = "Send a '{type}' notification. Accepts every notify.send() kwarg."


class Notify:
    """Facade over :class:`~django_notifications.services.NotificationService`."""

    # -- core ---------------------------------------------------------------

    def send(self, **kwargs: Any) -> Notification | BulkResult:
        """Create + deliver a notification. The one method behind them all."""
        from .services import service

        return service.send(**kwargs)

    def event(
        self,
        event: str,
        context: dict | None = None,
        strict: bool = True,
        **kwargs: Any,
    ) -> Notification | BulkResult:
        """Send using a registered event template (DB template wins)."""
        from .services import service

        return service.send_event(event, context=context, strict=strict, **kwargs)

    def bulk(self, **kwargs: Any) -> BulkResult:
        """Send to many recipients (queryset/list/group/everyone/...).

        Pass ``enqueue=True`` to offload creation itself to Celery for very
        large audiences.
        """
        from .services import service

        result = service.send(**kwargs)
        from .services import BulkResult

        if isinstance(result, BulkResult):
            return result
        return BulkResult(created=1, ids=[result.pk])

    def schedule(
        self,
        *,
        at: dt.datetime | None = None,
        delay: int | dt.timedelta | None = None,
        every: int | dt.timedelta | None = None,
        until: dt.datetime | None = None,
        **kwargs: Any,
    ) -> Notification | BulkResult:
        """Schedule for later; ``every``/``until`` make it recurring."""
        from .services import service

        return service.schedule(at=at, delay=delay, every=every, until=until, **kwargs)

    # -- typed helpers (explicit for IDE completion & docs) --------------------

    def success(self, **kwargs: Any):
        return self.send(type="success", **kwargs)

    def error(self, **kwargs: Any):
        return self.send(type="error", **kwargs)

    def warning(self, **kwargs: Any):
        return self.send(type="warning", **kwargs)

    def info(self, **kwargs: Any):
        return self.send(type="info", **kwargs)

    def critical(self, **kwargs: Any):
        return self.send(type="critical", **kwargs)

    def system(self, **kwargs: Any):
        """System notice; defaults to SYSTEM_RECIPIENTS when no recipient given."""
        return self.send(type="system", **kwargs)

    def security(self, **kwargs: Any):
        """Security notice; in-app delivery cannot be muted by preferences."""
        return self.send(type="security", **kwargs)

    def audit(self, **kwargs: Any):
        return self.send(type="audit", **kwargs)

    def reminder(self, **kwargs: Any):
        return self.send(type="reminder", **kwargs)

    def announcement(self, **kwargs: Any):
        """Broadcast; defaults to ``everyone=True`` when no recipient given."""
        return self.send(type="announcement", **kwargs)

    # -- extension points ----------------------------------------------------------

    def register_event(self, event: str, **template: Any) -> None:
        """Register a code-level event template (see events module docs)."""
        from . import events

        events.register(event, **template)

    def register_channel(self, key: str, backend: str | type) -> None:
        """Register a delivery channel at runtime (settings-based preferred)."""
        from .settings import app_settings

        app_settings.CHANNELS[key] = backend

    # -- dynamic custom types -----------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)

        def sender(**kwargs: Any):
            return self.send(type=name, **kwargs)

        sender.__name__ = name
        sender.__qualname__ = f"Notify.{name}"
        sender.__doc__ = _DOC_TEMPLATE.format(type=name)
        return sender

    def __repr__(self) -> str:  # pragma: no cover
        return "<django_notifications.notify>"


#: The importable singleton: ``from django_notifications import notify``.
notify = Notify()
