"""String-template rendering used by event templates and rich content."""

from __future__ import annotations

from django.template import Context, Template


def render_string(template_string: str, context: dict | None = None) -> str:
    """Render a Django template string with ``context``.

    Uses the default engine (autoescape on), so values interpolated into
    ``body_html_template`` are escaped and the final HTML is additionally
    sanitized by the service layer.
    """
    if not template_string:
        return ""
    return Template(template_string).render(Context(context or {})).strip()
