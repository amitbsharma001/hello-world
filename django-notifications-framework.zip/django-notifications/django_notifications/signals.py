"""Signals emitted by django_notifications.

These are the primary integration points for observability (Sentry, OTel,
Prometheus) and custom side effects. All signals are best-effort: receivers
must not raise for delivery to proceed (exceptions are logged).

    from django_notifications.signals import notification_created

    @receiver(notification_created)
    def on_created(sender, notification, **kwargs):
        statsd.incr("notifications.created")
"""

from __future__ import annotations

import django.dispatch

#: Fired once per persisted notification (after bulk_create per chunk).
notification_created = django.dispatch.Signal()  # kwargs: notification

#: Fired when a notification is marked read via model/queryset/API helpers.
notification_read = django.dispatch.Signal()  # kwargs: notification_ids, user

#: Fired after a channel backend succeeds. kwargs: delivery
delivery_sent = django.dispatch.Signal()

#: Fired after a channel backend fails permanently. kwargs: delivery, error
delivery_failed = django.dispatch.Signal()
