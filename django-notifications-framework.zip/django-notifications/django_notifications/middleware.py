"""Optional middleware exposing a lazy unread count on every request.

Add after ``AuthenticationMiddleware``::

    MIDDLEWARE = [..., "django_notifications.middleware.NotificationsMiddleware"]

Then in any template: ``{{ request.unread_notifications_count }}``. The count
is a ``SimpleLazyObject`` — no query runs unless it is actually accessed.
"""

from __future__ import annotations

from django.utils.functional import SimpleLazyObject


class NotificationsMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        request.unread_notifications_count = SimpleLazyObject(
            lambda: self._count(request)
        )
        return self.get_response(request)

    @staticmethod
    def _count(request) -> int:
        user = getattr(request, "user", None)
        if user is None or not getattr(user, "is_authenticated", False):
            return 0
        from .models import Notification

        return Notification.objects.unread_count(user)
