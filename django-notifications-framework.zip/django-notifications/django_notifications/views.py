"""Views: DRF API + server-rendered center page + HTMX partial.

Authentication/permission classes are resolved from settings at request
time, so projects can swap in TokenAuthentication, JWT, etc. without
subclassing::

    DJANGO_NOTIFICATIONS = {
        "API": {"AUTHENTICATION_CLASSES": [
            "rest_framework.authentication.TokenAuthentication",
        ]},
    }
"""

from __future__ import annotations

from typing import Any

from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.utils.module_loading import import_string
from django.views.generic import TemplateView
from rest_framework import status
from rest_framework.authentication import SessionAuthentication
from rest_framework.generics import GenericAPIView
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import Notification, NotificationPreference
from .permissions import (
    CanBroadcast,
    CanCreateForOthers,
    IsRecipient,
    user_can_broadcast,
)
from .serializers import (
    BroadcastSerializer,
    NotificationCreateSerializer,
    NotificationSerializer,
    PreferenceSerializer,
)
from .services import service
from .settings import app_settings


class NotificationPagination(PageNumberPagination):
    page_size_query_param = "page_size"

    @property
    def page_size(self) -> int:  # type: ignore[override]
        return app_settings.API["PAGE_SIZE"]

    @property
    def max_page_size(self) -> int:  # type: ignore[override]
        return app_settings.API["MAX_PAGE_SIZE"]

    def get_paginated_response(self, data: Any) -> Response:
        response = super().get_paginated_response(data)
        request = self.request
        response.data["unread_count"] = Notification.objects.unread_count(request.user)
        return response


class BaseNotificationAPIView(GenericAPIView):
    """Runtime-configurable auth/permissions + per-user queryset."""

    serializer_class = NotificationSerializer
    pagination_class = NotificationPagination

    def get_authenticators(self):
        paths = app_settings.API["AUTHENTICATION_CLASSES"]
        classes = (
            [import_string(p) for p in paths] if paths else [SessionAuthentication]
        )
        return [cls() for cls in classes]

    def get_permissions(self):
        paths = app_settings.API["PERMISSION_CLASSES"]
        classes = [import_string(p) for p in paths] if paths else [IsAuthenticated]
        return [cls() for cls in classes] + [IsRecipient()]

    def get_queryset(self):
        return (
            Notification.objects.for_user(self.request.user)
            .unexpired()
            .filter(sent_at__isnull=False)
            .select_related("actor_content_type", "target_content_type")
        )

    # -- shared body parsing -------------------------------------------------

    @staticmethod
    def ids_or_all(request) -> tuple[list[int], bool]:
        body = request.data or {}
        everything = bool(body.get("all"))
        ids = [int(i) for i in body.get("ids", []) if str(i).lstrip("-").isdigit()]
        return ids, everything


ORDERABLE = {"created_at", "-created_at", "priority", "-priority", "id", "-id"}


class NotificationListView(BaseNotificationAPIView):
    """GET list / POST create / DELETE bulk."""

    def filter_queryset(self, queryset):
        params = self.request.query_params
        if params.get("archived") in ("1", "true", "True"):
            queryset = queryset.archived()
        else:
            queryset = queryset.unarchived()
        if params.get("unread") in ("1", "true", "True"):
            queryset = queryset.unread()
        if params.get("pinned") in ("1", "true", "True"):
            queryset = queryset.pinned()
        for exact in ("type", "level", "category", "thread_key", "event"):
            if params.get(exact):
                queryset = queryset.filter(**{exact: params[exact]})
        if params.get("q"):
            queryset = queryset.search(params["q"])
        if params.get("since_id"):
            queryset = queryset.since(int(params["since_id"]))
        ordering = params.get("ordering", "")
        if ordering in ORDERABLE:
            queryset = queryset.order_by("-pinned", ordering, "-id")
        else:
            queryset = queryset.order_by("-pinned", "-created_at", "-id")
        return queryset

    def get(self, request, *args: Any, **kwargs: Any) -> Response:
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        serializer = self.get_serializer(page, many=True)
        return self.get_paginated_response(serializer.data)

    def post(self, request, *args: Any, **kwargs: Any) -> Response:
        self.check_permissions(request)
        gate = CanCreateForOthers()
        if not gate.has_permission(request, self):
            return Response({"detail": gate.message}, status=status.HTTP_403_FORBIDDEN)
        serializer = NotificationCreateSerializer(
            data=request.data, context={"request": request}
        )
        serializer.is_valid(raise_exception=True)
        notification = serializer.save()
        return Response(
            NotificationSerializer(notification).data, status=status.HTTP_201_CREATED
        )

    def delete(self, request, *args: Any, **kwargs: Any) -> Response:
        ids, everything = self.ids_or_all(request)
        if not ids and not everything:
            return Response(
                {"detail": "Provide 'ids' or 'all': true."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        deleted = service.delete(request.user, ids=ids, everything=everything)
        return Response({"deleted": deleted})


class UnreadListView(NotificationListView):
    """GET /unread/ — convenience alias for ?unread=1."""

    def filter_queryset(self, queryset):
        return super().filter_queryset(queryset).unread()

    post = None  # type: ignore[assignment]
    delete = None  # type: ignore[assignment]

    http_method_names = ["get", "head", "options"]


class CountView(BaseNotificationAPIView):
    def get(self, request, *args: Any, **kwargs: Any) -> Response:
        base = self.get_queryset().unarchived()
        return Response(
            {"unread": base.unread().count(), "total": base.count()}
        )


class MarkReadView(BaseNotificationAPIView):
    def patch(self, request, *args: Any, **kwargs: Any) -> Response:
        ids, everything = self.ids_or_all(request)
        mark_unread = request.data.get("read") is False
        if not ids and not everything:
            return Response(
                {"detail": "Provide 'ids' or 'all': true."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if mark_unread:
            updated = service.mark_unread(request.user, ids)
        else:
            updated = service.mark_read(request.user, ids=ids, everything=everything)
        return Response(
            {
                "updated": updated,
                "unread_count": Notification.objects.unread_count(request.user),
            }
        )


class ArchiveView(BaseNotificationAPIView):
    def patch(self, request, *args: Any, **kwargs: Any) -> Response:
        ids, everything = self.ids_or_all(request)
        if not ids and not everything:
            return Response(
                {"detail": "Provide 'ids' or 'all': true."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        if request.data.get("archived") is False:
            queryset = Notification.objects.for_user(request.user).filter(pk__in=ids)
            updated = queryset.unarchive()
        else:
            updated = service.archive(request.user, ids=ids, everything=everything)
        return Response(
            {
                "updated": updated,
                "unread_count": Notification.objects.unread_count(request.user),
            }
        )


class NotificationDetailView(BaseNotificationAPIView):
    lookup_field = "pk"

    def get(self, request, *args: Any, **kwargs: Any) -> Response:
        return Response(self.get_serializer(self.get_object()).data)

    def patch(self, request, *args: Any, **kwargs: Any) -> Response:
        from django.utils import timezone

        notification = self.get_object()
        body = request.data or {}
        fields: list[str] = []
        if "read" in body:
            notification.read_at = (
                None if body["read"] is False else notification.read_at or timezone.now()
            )
            fields.append("read_at")
        if "pinned" in body:
            notification.pinned = bool(body["pinned"])
            fields.append("pinned")
        if "archived" in body:
            notification.archived_at = timezone.now() if body["archived"] else None
            fields.append("archived_at")
        if fields:
            notification.save(update_fields=fields + ["updated_at"])
            from .websocket import push_counts

            push_counts(request.user)
        return Response(self.get_serializer(notification).data)

    def delete(self, request, *args: Any, **kwargs: Any) -> Response:
        self.get_object().delete()
        from .websocket import push_counts

        push_counts(request.user)
        return Response(status=status.HTTP_204_NO_CONTENT)


class PreferencesView(BaseNotificationAPIView):
    serializer_class = PreferenceSerializer

    def get_permissions(self):  # no IsRecipient (not a Notification object)
        paths = app_settings.API["PERMISSION_CLASSES"]
        classes = [import_string(p) for p in paths] if paths else [IsAuthenticated]
        return [cls() for cls in classes]

    def get_object(self) -> NotificationPreference:
        obj, _ = NotificationPreference.objects.get_or_create(user=self.request.user)
        return obj

    def get(self, request, *args: Any, **kwargs: Any) -> Response:
        return Response(self.get_serializer(self.get_object()).data)

    def patch(self, request, *args: Any, **kwargs: Any) -> Response:
        serializer = self.get_serializer(
            self.get_object(), data=request.data, partial=True
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


# --------------------------------------------------------------------------
# Broadcast (send to whole groups)
# --------------------------------------------------------------------------

class BroadcastBaseView(BaseNotificationAPIView):
    """Auth from settings + CanBroadcast (no IsRecipient — not object-scoped)."""

    def get_permissions(self):
        paths = app_settings.API["PERMISSION_CLASSES"]
        classes = [import_string(p) for p in paths] if paths else [IsAuthenticated]
        return [cls() for cls in classes] + [CanBroadcast()]


class GroupListView(BroadcastBaseView):
    """GET /groups/ — selectable groups with member counts (for the picker)."""

    def get(self, request, *args: Any, **kwargs: Any) -> Response:
        from django.contrib.auth.models import Group
        from django.db.models import Count

        groups = (
            Group.objects.annotate(user_count=Count("user", distinct=True))
            .order_by("name")
            .values("id", "name", "user_count")
        )
        return Response(list(groups))


class BroadcastView(BroadcastBaseView):
    """POST /broadcast/ — send a notification to every member of the groups."""

    serializer_class = BroadcastSerializer

    def post(self, request, *args: Any, **kwargs: Any) -> Response:
        serializer = BroadcastSerializer(
            data=request.data, context={"request": request}
        )
        serializer.is_valid(raise_exception=True)
        summary = serializer.save()
        return Response(summary, status=status.HTTP_201_CREATED)


# --------------------------------------------------------------------------
# Server-rendered views (notification center page + HTMX partial)
# --------------------------------------------------------------------------

class BroadcastPageView(LoginRequiredMixin, UserPassesTestMixin, TemplateView):
    """Broadcast composer page opened from the bell-popup Broadcast link.

    Gated by ``API.BROADCAST``; unprivileged users get 403.
    """

    template_name = "django_notifications/broadcast_page.html"

    # Anonymous → redirect to login (LoginRequiredMixin); authenticated but
    # unprivileged → 403 (UserPassesTestMixin raises for logged-in users).
    def test_func(self) -> bool:
        return user_can_broadcast(self.request.user)


class NotificationCenterView(LoginRequiredMixin, TemplateView):
    """Full-page notification center hosting the bundled widget."""

    template_name = "django_notifications/center_page.html"


class NotificationPartialView(LoginRequiredMixin, TemplateView):
    """HTML fragment of notification items — HTMX/hx-get friendly.

    Query params: ``page``, ``q``, ``filter`` (all|unread|archived).
    """

    template_name = "django_notifications/_items.html"

    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        from django.core.paginator import Paginator

        context = super().get_context_data(**kwargs)
        queryset = (
            Notification.objects.for_user(self.request.user)
            .unexpired()
            .filter(sent_at__isnull=False)
        )
        selected = self.request.GET.get("filter", "all")
        if selected == "unread":
            queryset = queryset.unarchived().unread()
        elif selected == "archived":
            queryset = queryset.archived()
        else:
            queryset = queryset.unarchived()
        if self.request.GET.get("q"):
            queryset = queryset.search(self.request.GET["q"])
        paginator = Paginator(
            queryset.order_by("-pinned", "-created_at"),
            app_settings.FRONTEND["PAGE_SIZE"],
        )
        page = paginator.get_page(self.request.GET.get("page", 1))
        context.update({"page": page, "filter": selected, "q": self.request.GET.get("q", "")})
        return context
