"""Django Channels consumer for live notifications.

Import-guarded so the package works without ``channels`` installed. Wire it
in your ASGI application via :mod:`django_notifications.routing`.

Client protocol (JSON):

* server → ``{"kind": "init", "unread_count": n}`` on connect
* server → ``{"kind": "notification", "notification": {...}, "unread_count": n}``
* server → ``{"kind": "counts", "unread_count": n}``
* client → ``{"action": "sync", "since_id": 123}`` → server replays missed
  notifications created after ``since_id`` (reconnect catch-up)
* client → ``{"action": "mark_read", "ids": [...]}`` or ``{"action":
  "mark_all_read"}``
* client → ``{"action": "ping"}`` → ``{"kind": "pong"}``
"""

from __future__ import annotations

try:
    from channels.db import database_sync_to_async
    from channels.generic.websocket import AsyncJsonWebsocketConsumer

    HAS_CHANNELS = True
except ImportError:  # pragma: no cover - exercised in channel-less installs
    HAS_CHANNELS = False

from .settings import app_settings
from .websocket import user_group

if HAS_CHANNELS:

    class NotificationConsumer(AsyncJsonWebsocketConsumer):
        """Per-user live notification stream."""

        SYNC_LIMIT = 50

        async def connect(self) -> None:
            user = self.scope.get("user")
            if user is None or user.is_anonymous:
                await self.close(code=4401)
                return
            self.user = user
            self.group_name = user_group(user.pk)
            await self.channel_layer.group_add(self.group_name, self.channel_name)
            await self.accept()
            await self.send_json(
                {"kind": "init", "unread_count": await self._unread_count()}
            )

        async def disconnect(self, code: int) -> None:
            if hasattr(self, "group_name"):
                await self.channel_layer.group_discard(self.group_name, self.channel_name)

        # -- messages from the channel layer --------------------------------

        async def djn_message(self, event: dict) -> None:
            await self.send_json(event["payload"])

        # -- messages from the client ----------------------------------------

        async def receive_json(self, content: dict, **kwargs) -> None:
            action = content.get("action")
            if action == "ping":
                await self.send_json({"kind": "pong"})
            elif action == "sync":
                await self._replay_missed(content.get("since_id") or 0)
            elif action == "mark_read":
                ids = [int(i) for i in content.get("ids", []) if str(i).isdigit()]
                if ids:
                    await self._mark_read(ids)
                    await self.send_json(
                        {"kind": "counts", "unread_count": await self._unread_count()}
                    )
            elif action == "mark_all_read":
                await self._mark_all_read()
                await self.send_json({"kind": "counts", "unread_count": 0})

        # -- database helpers --------------------------------------------------

        @database_sync_to_async
        def _unread_count(self) -> int:
            from .models import Notification

            return Notification.objects.unread_count(self.user)

        @database_sync_to_async
        def _mark_read(self, ids: list[int]) -> int:
            from .models import Notification

            return Notification.objects.for_user(self.user).filter(pk__in=ids).mark_read()

        @database_sync_to_async
        def _mark_all_read(self) -> int:
            from .models import Notification

            return Notification.objects.for_user(self.user).visible().mark_read()

        @database_sync_to_async
        def _missed(self, since_id: int) -> list[dict]:
            from .models import Notification
            from .serializers import NotificationSerializer

            queryset = (
                Notification.objects.for_user(self.user)
                .visible()
                .since(since_id)
                .order_by("id")[: self.SYNC_LIMIT]
            )
            return NotificationSerializer(queryset, many=True).data

        async def _replay_missed(self, since_id: int) -> None:
            items = await self._missed(int(since_id))
            await self.send_json(
                {
                    "kind": "sync",
                    "notifications": items,
                    "unread_count": await self._unread_count(),
                }
            )

else:  # pragma: no cover

    class NotificationConsumer:  # type: ignore[no-redef]
        """Placeholder raising a clear error when Channels is missing."""

        def __init__(self, *args, **kwargs):
            raise ImportError(
                "django_notifications.consumers.NotificationConsumer requires "
                "'channels'. Install with: pip install django-notifications[channels]"
            )


__all__ = ["NotificationConsumer", "HAS_CHANNELS"]
_ = app_settings  # keep import (settings reload hooks) explicit
