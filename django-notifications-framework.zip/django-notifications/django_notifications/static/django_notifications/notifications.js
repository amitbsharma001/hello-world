/* django_notifications widget — dependency-free vanilla JS.
 *
 * Auto-initializes every element carrying [data-djn-widget] (rendered by the
 * {% notification_bell %} / {% notification_center %} template tags). Also
 * exposes window.DjangoNotifications = { init, initAll, Client } so SPAs and
 * HTMX swaps can (re)initialize manually, and React/Vue apps can reuse the
 * headless Client (see also notifications.esm.js).
 */
(function () {
  'use strict';
  if (window.DjangoNotifications) { return; } // idempotent across duplicate tags

  /* ------------------------------------------------------------ utilities */

  function getCookie(name) {
    var m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    if (m) { return decodeURIComponent(m.pop()); }
    var input = document.querySelector('input[name=csrfmiddlewaretoken]');
    return input ? input.value : '';
  }

  function esc(text) {
    return String(text == null ? '' : text)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function timeAgo(iso) {
    var then = new Date(iso).getTime();
    if (isNaN(then)) { return ''; }
    var s = Math.max(0, Math.floor((Date.now() - then) / 1000));
    if (s < 45) { return 'just now'; }
    var m = Math.floor(s / 60);
    if (m < 60) { return m + 'm ago'; }
    var h = Math.floor(m / 60);
    if (h < 24) { return h + 'h ago'; }
    var d = Math.floor(h / 24);
    if (d < 7) { return d + 'd ago'; }
    return new Date(iso).toLocaleDateString();
  }

  function debounce(fn, wait) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, wait);
    };
  }

  var ICONS = {
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    success: '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/>',
    warning: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    error: '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/>',
    critical: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
    pin: '<path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1Z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    archive: '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>'
  };

  function svg(name, size) {
    size = size || 15;
    return '<svg viewBox="0 0 24 24" width="' + size + '" height="' + size +
      '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"' +
      ' stroke-linejoin="round" aria-hidden="true">' +
      (ICONS[name] || ICONS.bell) + '</svg>';
  }

  /* ------------------------------------------------------- headless client */

  function Client(config) {
    this.cfg = config || {};
    this._handlers = {};
    this._ws = null;
    this._wsAttempts = 0;
    this._pollTimer = null;
    this._closed = false;
    this.maxSeenId = 0;
    this.unread = 0;
  }

  Client.prototype.on = function (event, handler) {
    (this._handlers[event] = this._handlers[event] || []).push(handler);
    return this;
  };

  Client.prototype._emit = function (event, payload) {
    (this._handlers[event] || []).forEach(function (handler) {
      try { handler(payload); } catch (err) { console.error('[djn]', err); }
    });
  };

  Client.prototype._headers = function (unsafe) {
    var headers = { 'Accept': 'application/json' };
    if (unsafe) {
      headers['Content-Type'] = 'application/json';
      headers['X-CSRFToken'] = getCookie(this.cfg.csrfCookie || 'csrftoken');
    }
    return headers;
  };

  Client.prototype.api = function (path, options) {
    options = options || {};
    var unsafe = options.method && options.method !== 'GET';
    return fetch(this.cfg.apiBase + path, {
      method: options.method || 'GET',
      credentials: 'same-origin',
      headers: this._headers(unsafe),
      body: options.body ? JSON.stringify(options.body) : undefined
    }).then(function (response) {
      if (response.status === 204) { return null; }
      if (!response.ok) {
        var error = new Error('HTTP ' + response.status);
        error.status = response.status;
        throw error;
      }
      return response.json();
    });
  };

  Client.prototype.list = function (params) {
    var query = new URLSearchParams(params || {}).toString();
    return this.api(query ? '?' + query : '');
  };
  Client.prototype.count = function () { return this.api('count/'); };
  Client.prototype.markRead = function (body) {
    return this.api('read/', { method: 'PATCH', body: body });
  };
  Client.prototype.archive = function (body) {
    return this.api('archive/', { method: 'PATCH', body: body });
  };
  Client.prototype.remove = function (body) {
    return this.api('', { method: 'DELETE', body: body });
  };
  Client.prototype.patchOne = function (id, body) {
    return this.api(id + '/', { method: 'PATCH', body: body });
  };
  Client.prototype.deleteOne = function (id) {
    return this.api(id + '/', { method: 'DELETE' });
  };

  Client.prototype.track = function (items) {
    var self = this;
    (items || []).forEach(function (n) {
      if (n && n.id > self.maxSeenId) { self.maxSeenId = n.id; }
    });
  };

  Client.prototype.setUnread = function (n) {
    if (typeof n === 'number' && n >= 0) {
      this.unread = n;
      this._emit('counts', n);
    }
  };

  /* -- realtime: websocket with reconnect + missed-notification sync ------- */

  Client.prototype.connect = function () {
    this._closed = false;
    if (this.cfg.useWebSocket !== false && 'WebSocket' in window) {
      this._openSocket();
    } else {
      this._startPolling();
    }
  };

  Client.prototype.disconnect = function () {
    this._closed = true;
    if (this._ws) { try { this._ws.close(); } catch (e) { /* noop */ } }
    this._stopPolling();
  };

  Client.prototype._openSocket = function () {
    var self = this;
    var scheme = location.protocol === 'https:' ? 'wss://' : 'ws://';
    var url = scheme + location.host + (this.cfg.wsPath || '/ws/notifications/');
    var ws;
    try { ws = new WebSocket(url); } catch (e) { this._startPolling(); return; }
    this._ws = ws;

    ws.onopen = function () {
      self._wsAttempts = 0;
      self._stopPolling();
      if (self.maxSeenId) {
        ws.send(JSON.stringify({ action: 'sync', since_id: self.maxSeenId }));
      }
    };
    ws.onmessage = function (frame) {
      var data;
      try { data = JSON.parse(frame.data); } catch (e) { return; }
      if (data.kind === 'init' || data.kind === 'counts') {
        self.setUnread(data.unread_count);
      } else if (data.kind === 'notification') {
        self.track([data.notification]);
        self.setUnread(data.unread_count);
        self._emit('notification', data.notification);
      } else if (data.kind === 'sync') {
        self.track(data.notifications);
        self.setUnread(data.unread_count);
        self._emit('sync', data.notifications || []);
      }
    };
    ws.onclose = function () {
      self._ws = null;
      if (self._closed) { return; }
      self._startPolling();
      var backoff = Math.min(30000, 1000 * Math.pow(2, self._wsAttempts++));
      backoff += Math.random() * 400; // jitter
      setTimeout(function () {
        if (!self._closed) { self._openSocket(); }
      }, backoff);
    };
    ws.onerror = function () { try { ws.close(); } catch (e) { /* noop */ } };
  };

  Client.prototype._startPolling = function () {
    var self = this;
    var interval = (this.cfg.pollInterval || 0) * 1000;
    if (!interval || this._pollTimer) { return; }
    this._pollTimer = setInterval(function () {
      if (document.hidden) { return; }
      self.count().then(function (data) {
        var previous = self.unread;
        self.setUnread(data.unread);
        if (data.unread > previous) { self._emit('poll-new'); }
      }).catch(function () { /* transient */ });
    }, interval);
  };

  Client.prototype._stopPolling = function () {
    if (this._pollTimer) { clearInterval(this._pollTimer); this._pollTimer = null; }
  };

  /* --------------------------------------------------------------- toasts */

  var toastRoot = null;
  function toast(title, message, url) {
    if (!toastRoot) {
      toastRoot = document.createElement('div');
      toastRoot.className = 'djn-toasts';
      toastRoot.setAttribute('role', 'status');
      document.body.appendChild(toastRoot);
    }
    var el = document.createElement('div');
    el.className = 'djn-toast';
    el.innerHTML =
      '<div>' + svg('bell', 16) + '</div>' +
      '<div><div class="djn-toast-title">' + esc(title) + '</div>' +
      (message ? '<p class="djn-toast-msg">' + esc(message) + '</p>' : '') + '</div>' +
      '<button type="button" class="djn-toast-close" aria-label="Dismiss">&times;</button>';
    el.querySelector('.djn-toast-close').addEventListener('click', function (e) {
      e.stopPropagation(); el.remove();
    });
    if (url) {
      el.style.cursor = 'pointer';
      el.addEventListener('click', function () { window.location.href = url; });
    }
    toastRoot.appendChild(el);
    setTimeout(function () { el.remove(); }, 6000);
  }

  /* --------------------------------------------------------------- widget */

  function Widget(root) {
    var raw = root.getAttribute('data-djn-config') || '{}';
    this.cfg = JSON.parse(raw);
    this.root = root;
    this.mode = this.cfg.mode || 'bell';
    this.client = new Client(this.cfg);

    this.bell = root.querySelector('.djn-bell');
    this.badge = root.querySelector('.djn-badge');
    this.live = root.querySelector('[data-djn-live]');
    this.panel = root.querySelector('.djn-panel');
    this.list = root.querySelector('[data-djn-list]');
    this.scroll = root.querySelector('[data-djn-scroll]');
    this.sentinel = root.querySelector('[data-djn-sentinel]');
    this.empty = root.querySelector('[data-djn-empty]');
    this.statusEl = root.querySelector('[data-djn-status]');
    this.search = root.querySelector('[data-djn-search]');

    this.state = { filter: 'all', q: '', page: 1, hasNext: false, loading: false, loaded: false };
    this.items = {}; // id -> data

    this._bind();
    this._connectClient();

    if (this.mode === 'center') {
      this.panel.hidden = false;
      this.refresh();
    } else {
      this.client.count().then(function (data) {
        this.client.setUnread(data.unread);
      }.bind(this)).catch(function () { /* unauthenticated or offline */ });
    }
  }

  Widget.prototype._connectClient = function () {
    var self = this;
    this.client.on('counts', function (n) { self.updateBadge(n); });
    this.client.on('notification', function (n) { self.onPush(n); });
    this.client.on('sync', function (items) {
      items.slice().reverse().forEach(function (n) { self.prepend(n, true); });
    });
    this.client.on('poll-new', function () {
      if (self.isOpen()) { self.refresh(); }
    });
    this.client.connect();
    window.addEventListener('beforeunload', function () { self.client.disconnect(); });
  };

  /* -- events ------------------------------------------------------------- */

  Widget.prototype._bind = function () {
    var self = this;

    if (this.mode === 'bell' && this.bell) {
      this.bell.addEventListener('click', function () { self.toggle(); });
      document.addEventListener('click', function (event) {
        if (self.isOpen() && !self.root.contains(event.target)) { self.close(); }
      });
      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && self.isOpen()) { self.close(); self.bell.focus(); }
      });
    }

    this.root.querySelectorAll('[data-djn-filter]').forEach(function (tab) {
      tab.addEventListener('click', function () {
        self.root.querySelectorAll('[data-djn-filter]').forEach(function (t) {
          t.classList.toggle('djn-tab-active', t === tab);
          t.setAttribute('aria-selected', t === tab ? 'true' : 'false');
        });
        self.state.filter = tab.getAttribute('data-djn-filter');
        self.refresh();
      });
    });

    if (this.search) {
      this.search.addEventListener('input', debounce(function () {
        self.state.q = self.search.value.trim();
        self.refresh();
      }, 300));
    }

    var markAll = this.root.querySelector('[data-djn-action="mark-all"]');
    if (markAll) {
      markAll.addEventListener('click', function () { self.markAllRead(); });
    }

    var pageLink = this.root.querySelector('[data-djn-page-link]');
    if (pageLink && this.cfg.pageUrl) { pageLink.href = this.cfg.pageUrl; }

    // Delegated item interactions.
    this.list.addEventListener('click', function (event) {
      var tool = event.target.closest('[data-djn-tool]');
      var item = event.target.closest('.djn-item');
      if (!item) { return; }
      var id = parseInt(item.getAttribute('data-id'), 10);
      if (tool) {
        event.preventDefault();
        self.runTool(tool.getAttribute('data-djn-tool'), id, item);
      } else if (event.target.closest('.djn-item-title')) {
        self.markItemsRead([id]); // fire-and-forget; link navigates naturally
      }
    });

    // Infinite scroll.
    if ('IntersectionObserver' in window && this.sentinel) {
      new IntersectionObserver(function (entries) {
        if (entries[0].isIntersecting) { self.loadMore(); }
      }, { root: this.scroll, rootMargin: '80px' }).observe(this.sentinel);
    } else if (this.scroll) {
      this.scroll.addEventListener('scroll', function () {
        var node = self.scroll;
        if (node.scrollTop + node.clientHeight >= node.scrollHeight - 60) {
          self.loadMore();
        }
      });
    }

    // Relative timestamps refresh.
    setInterval(function () {
      self.list.querySelectorAll('time[datetime]').forEach(function (node) {
        node.textContent = timeAgo(node.getAttribute('datetime'));
      });
    }, 60000);
  };

  /* -- panel open/close ---------------------------------------------------- */

  Widget.prototype.isOpen = function () { return this.panel && !this.panel.hidden; };

  Widget.prototype.toggle = function () {
    if (this.isOpen()) { this.close(); } else { this.open(); }
  };

  Widget.prototype.open = function () {
    this.panel.hidden = false;
    if (this.bell) { this.bell.setAttribute('aria-expanded', 'true'); }
    this._maybeAskBrowserPermission();
    if (!this.state.loaded) { this.refresh(); }
  };

  Widget.prototype.close = function () {
    this.panel.hidden = true;
    if (this.bell) { this.bell.setAttribute('aria-expanded', 'false'); }
  };

  /* -- data loading ---------------------------------------------------------- */

  Widget.prototype._params = function () {
    var params = { page: this.state.page, page_size: this.cfg.pageSize || 15 };
    if (this.state.filter === 'unread') { params.unread = 1; }
    if (this.state.filter === 'archived') { params.archived = 1; }
    if (this.state.q) { params.q = this.state.q; }
    return params;
  };

  Widget.prototype.refresh = function () {
    this.state.page = 1;
    this.state.hasNext = false;
    this.items = {};
    this.list.innerHTML = '';
    this.showSkeletons();
    this.state.loaded = true;
    this._fetchPage(true);
  };

  Widget.prototype.loadMore = function () {
    if (this.state.loading || !this.state.hasNext) { return; }
    this.state.page += 1;
    this._fetchPage(false);
  };

  Widget.prototype._fetchPage = function (replace) {
    var self = this;
    this.state.loading = true;
    this.client.list(this._params()).then(function (data) {
      self.state.loading = false;
      self.state.hasNext = Boolean(data.next);
      if (replace) { self.list.innerHTML = ''; }
      (data.results || []).forEach(function (n) { self.append(n); });
      self.client.track(data.results);
      if (typeof data.unread_count === 'number') { self.client.setUnread(data.unread_count); }
      self.updateEmpty();
      self.setStatus('');
    }).catch(function (error) {
      self.state.loading = false;
      if (replace) { self.list.innerHTML = ''; }
      self.setStatus(
        error.status === 403 || error.status === 401
          ? 'Sign in to see your notifications.'
          : 'Could not load notifications. Retrying may help.',
        true
      );
    });
  };

  Widget.prototype.showSkeletons = function () {
    for (var i = 0; i < 4; i++) {
      var li = document.createElement('li');
      li.className = 'djn-skel';
      this.list.appendChild(li);
    }
    if (this.empty) { this.empty.hidden = true; }
  };

  Widget.prototype.setStatus = function (text, isError) {
    if (!this.statusEl) { return; }
    this.statusEl.hidden = !text;
    this.statusEl.textContent = text || '';
    this.statusEl.classList.toggle('djn-status-error', Boolean(isError));
  };

  Widget.prototype.updateEmpty = function () {
    if (this.empty) {
      this.empty.hidden = this.list.querySelector('.djn-item') !== null;
    }
  };

  /* -- rendering --------------------------------------------------------------- */

  Widget.prototype.renderItem = function (n) {
    var li = document.createElement('li');
    li.className = 'djn-item djn-level-' + esc(n.level || 'info') +
      (n.is_read ? '' : ' djn-item-unread');
    li.setAttribute('data-id', n.id);

    var iconHtml = n.image
      ? '<img class="djn-item-img" src="' + esc(n.image) + '" alt="">'
      : svg(ICONS[n.level] ? n.level : 'bell');

    var titleHtml = n.url
      ? '<a class="djn-item-title" href="' + esc(n.url) + '">' + esc(n.title) +
        (n.pinned ? '<span class="djn-item-pin">' + svg('pin', 10) + '</span>' : '') + '</a>'
      : '<span class="djn-item-title">' + esc(n.title) +
        (n.pinned ? '<span class="djn-item-pin">' + svg('pin', 10) + '</span>' : '') + '</span>';

    var ctaHtml = '';
    if (n.actions && n.actions.length) {
      ctaHtml = '<div class="djn-cta">' + n.actions.map(function (action) {
        var cls = action.style === 'primary' ? ' class="djn-cta-primary"' : '';
        return '<a' + cls + ' href="' + esc(action.url) + '">' + esc(action.label) + '</a>';
      }).join('') + '</div>';
    }

    li.innerHTML =
      '<span class="djn-dot" aria-hidden="true"></span>' +
      '<div class="djn-item-icon">' + iconHtml + '</div>' +
      '<div class="djn-item-body">' + titleHtml +
      (n.message ? '<p class="djn-item-msg">' + esc(n.message) + '</p>' : '') +
      ctaHtml +
      '<time class="djn-item-time" datetime="' + esc(n.created_at) + '">' +
      timeAgo(n.created_at) + '</time></div>' +
      '<div class="djn-item-tools">' +
      '<button type="button" class="djn-tool" data-djn-tool="read" title="' +
      (n.is_read ? 'Mark unread' : 'Mark read') + '" aria-label="' +
      (n.is_read ? 'Mark unread' : 'Mark read') + '">' + svg('check', 13) + '</button>' +
      '<button type="button" class="djn-tool" data-djn-tool="pin" data-active="' +
      Boolean(n.pinned) + '" title="Pin" aria-label="Pin">' + svg('pin', 13) + '</button>' +
      '<button type="button" class="djn-tool" data-djn-tool="archive" title="' +
      (n.is_archived ? 'Unarchive' : 'Archive') + '" aria-label="' +
      (n.is_archived ? 'Unarchive' : 'Archive') + '">' + svg('archive', 13) + '</button>' +
      '<button type="button" class="djn-tool" data-djn-tool="delete" title="Delete" ' +
      'aria-label="Delete">' + svg('trash', 13) + '</button>' +
      '</div>';
    return li;
  };

  Widget.prototype.append = function (n) {
    if (this.items[n.id]) { return; }
    this.items[n.id] = n;
    this.list.appendChild(this.renderItem(n));
    this.updateEmpty();
  };

  Widget.prototype.prepend = function (n, quiet) {
    if (this.items[n.id]) { return; }
    if (this.state.filter === 'archived') { return; }
    if (this.state.filter === 'unread' && n.is_read) { return; }
    if (!this.state.loaded && this.mode === 'bell') { return; } // list not built yet
    this.items[n.id] = n;
    this.list.insertBefore(this.renderItem(n), this.list.firstChild);
    this.updateEmpty();
    if (!quiet && this.bell) {
      this.bell.classList.add('djn-ringing');
      var bell = this.bell;
      setTimeout(function () { bell.classList.remove('djn-ringing'); }, 600);
    }
  };

  /* -- realtime handlers ------------------------------------------------------- */

  Widget.prototype.onPush = function (n) {
    this.prepend(n, false);
    if (this.cfg.toasts !== false && !this.isOpen()) {
      toast(n.title, n.message, n.url);
    }
    if (this.cfg.browserNotifications && document.hidden &&
        'Notification' in window && Notification.permission === 'granted') {
      try {
        var browserNote = new Notification(n.title, { body: n.message || '' });
        if (n.url) {
          browserNote.onclick = function () { window.focus(); location.href = n.url; };
        }
      } catch (e) { /* some platforms restrict constructor */ }
    }
  };

  Widget.prototype.updateBadge = function (count) {
    if (this.badge) {
      this.badge.hidden = !count;
      this.badge.textContent = count > 99 ? '99+' : String(count);
    }
    if (this.live) {
      this.live.textContent = count ? count + ' unread notifications' : 'No unread notifications';
    }
  };

  Widget.prototype._maybeAskBrowserPermission = function () {
    if (this.cfg.browserNotifications && 'Notification' in window &&
        Notification.permission === 'default') {
      Notification.requestPermission();
    }
  };

  /* -- item + bulk actions ------------------------------------------------------ */

  Widget.prototype.markItemsRead = function (ids) {
    var self = this;
    var pending = ids.filter(function (id) {
      return self.items[id] && !self.items[id].is_read;
    });
    if (!pending.length) { return; }
    pending.forEach(function (id) { self._applyRead(id, true); });
    this.client.markRead({ ids: pending }).then(function (data) {
      self.client.setUnread(data.unread_count);
    }).catch(function () { /* transient */ });
  };

  Widget.prototype._applyRead = function (id, read) {
    var item = this.items[id];
    if (item) { item.is_read = read; item.read_at = read ? new Date().toISOString() : null; }
    var node = this.list.querySelector('.djn-item[data-id="' + id + '"]');
    if (node) {
      node.classList.toggle('djn-item-unread', !read);
      var button = node.querySelector('[data-djn-tool="read"]');
      if (button) {
        button.title = read ? 'Mark unread' : 'Mark read';
        button.setAttribute('aria-label', button.title);
      }
    }
  };

  Widget.prototype.markAllRead = function () {
    var self = this;
    Object.keys(this.items).forEach(function (id) { self._applyRead(parseInt(id, 10), true); });
    this.client.markRead({ all: true }).then(function (data) {
      self.client.setUnread(data.unread_count);
    }).catch(function () { /* transient */ });
  };

  Widget.prototype.runTool = function (tool, id, node) {
    var self = this;
    var item = this.items[id] || {};
    if (tool === 'read') {
      var makeRead = !item.is_read;
      this._applyRead(id, makeRead);
      this.client.markRead(makeRead ? { ids: [id] } : { ids: [id], read: false })
        .then(function (data) { self.client.setUnread(data.unread_count); })
        .catch(function () { self._applyRead(id, !makeRead); });
    } else if (tool === 'pin') {
      var pinned = !item.pinned;
      item.pinned = pinned;
      var pinButton = node.querySelector('[data-djn-tool="pin"]');
      if (pinButton) { pinButton.setAttribute('data-active', String(pinned)); }
      this.client.patchOne(id, { pinned: pinned }).catch(function () {
        item.pinned = !pinned;
        if (pinButton) { pinButton.setAttribute('data-active', String(!pinned)); }
      });
    } else if (tool === 'archive') {
      var makeArchived = !item.is_archived;
      node.remove();
      delete this.items[id];
      this.updateEmpty();
      this.client.archive({ ids: [id], archived: makeArchived })
        .then(function (data) { self.client.setUnread(data.unread_count); })
        .catch(function () { self.refresh(); });
    } else if (tool === 'delete') {
      node.remove();
      delete this.items[id];
      this.updateEmpty();
      this.client.deleteOne(id).catch(function () { self.refresh(); });
    }
  };

  /* ------------------------------------------------------------ bootstrap */

  function init(root) {
    if (root.getAttribute('data-djn-ready')) { return null; }
    root.setAttribute('data-djn-ready', '1');
    try {
      return new Widget(root);
    } catch (error) {
      console.error('[django_notifications] widget init failed:', error);
      return null;
    }
  }

  function initAll(scope) {
    var widgets = [];
    (scope || document).querySelectorAll('[data-djn-widget]:not([data-djn-ready])')
      .forEach(function (root) {
        var widget = init(root);
        if (widget) { widgets.push(widget); }
      });
    return widgets;
  }

  window.DjangoNotifications = { init: init, initAll: initAll, Client: Client, toast: toast };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initAll(document); });
  } else {
    initAll(document);
  }
})();
