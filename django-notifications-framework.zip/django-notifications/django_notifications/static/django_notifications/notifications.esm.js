/* django_notifications — headless ESM client for SPAs (React, Vue, Svelte).
 *
 *   import { NotificationsClient } from "django_notifications/notifications.esm.js";
 *
 *   const client = new NotificationsClient({ apiBase: "/notifications/" });
 *   client.on("counts", n => setUnread(n));
 *   client.on("notification", n => setItems(prev => [n, ...prev]));
 *   client.connect();
 *   const page = await client.list({ page: 1 });
 *
 * Same wire protocol as the bundled widget: REST for state, WebSocket (with
 * exponential-backoff reconnect and missed-notification sync) for realtime,
 * automatic polling fallback. See frontend/react/NotificationBell.jsx for a
 * complete component example.
 */

function getCookie(name) {
  const match = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
  return match ? decodeURIComponent(match.pop()) : '';
}

export class NotificationsClient {
  constructor(config = {}) {
    this.cfg = { csrfCookie: 'csrftoken', wsPath: '/ws/notifications/', ...config };
    if (!this.cfg.apiBase) throw new Error('apiBase is required');
    this._handlers = new Map();
    this._ws = null;
    this._attempts = 0;
    this._pollTimer = null;
    this._closed = false;
    this.maxSeenId = 0;
    this.unread = 0;
  }

  on(event, handler) {
    if (!this._handlers.has(event)) this._handlers.set(event, new Set());
    this._handlers.get(event).add(handler);
    return () => this._handlers.get(event).delete(handler); // unsubscribe
  }

  _emit(event, payload) {
    for (const handler of this._handlers.get(event) ?? []) {
      try { handler(payload); } catch (err) { console.error('[djn]', err); }
    }
  }

  async api(path, { method = 'GET', body } = {}) {
    const unsafe = method !== 'GET';
    const response = await fetch(this.cfg.apiBase + path, {
      method,
      credentials: 'same-origin',
      headers: {
        Accept: 'application/json',
        ...(unsafe && {
          'Content-Type': 'application/json',
          'X-CSRFToken': getCookie(this.cfg.csrfCookie),
        }),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (response.status === 204) return null;
    if (!response.ok) throw Object.assign(new Error(`HTTP ${response.status}`), { status: response.status });
    return response.json();
  }

  list(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.api(query ? `?${query}` : '');
  }
  count() { return this.api('count/'); }
  markRead(body) { return this.api('read/', { method: 'PATCH', body }); }
  archive(body) { return this.api('archive/', { method: 'PATCH', body }); }
  remove(body) { return this.api('', { method: 'DELETE', body }); }
  patchOne(id, body) { return this.api(`${id}/`, { method: 'PATCH', body }); }
  deleteOne(id) { return this.api(`${id}/`, { method: 'DELETE' }); }
  preferences() { return this.api('preferences/'); }
  savePreferences(body) { return this.api('preferences/', { method: 'PATCH', body }); }

  track(items = []) {
    for (const item of items) if (item?.id > this.maxSeenId) this.maxSeenId = item.id;
  }

  _setUnread(n) {
    if (typeof n === 'number' && n >= 0) { this.unread = n; this._emit('counts', n); }
  }

  connect() {
    this._closed = false;
    if (this.cfg.useWebSocket !== false && 'WebSocket' in globalThis) this._open();
    else this._poll();
  }

  disconnect() {
    this._closed = true;
    this._ws?.close();
    clearInterval(this._pollTimer);
    this._pollTimer = null;
  }

  _open() {
    const scheme = location.protocol === 'https:' ? 'wss://' : 'ws://';
    let ws;
    try { ws = new WebSocket(scheme + location.host + this.cfg.wsPath); }
    catch { this._poll(); return; }
    this._ws = ws;

    ws.onopen = () => {
      this._attempts = 0;
      clearInterval(this._pollTimer);
      this._pollTimer = null;
      if (this.maxSeenId) ws.send(JSON.stringify({ action: 'sync', since_id: this.maxSeenId }));
    };
    ws.onmessage = ({ data }) => {
      let message;
      try { message = JSON.parse(data); } catch { return; }
      switch (message.kind) {
        case 'init':
        case 'counts':
          this._setUnread(message.unread_count); break;
        case 'notification':
          this.track([message.notification]);
          this._setUnread(message.unread_count);
          this._emit('notification', message.notification);
          break;
        case 'sync':
          this.track(message.notifications);
          this._setUnread(message.unread_count);
          this._emit('sync', message.notifications ?? []);
          break;
      }
    };
    ws.onclose = () => {
      this._ws = null;
      if (this._closed) return;
      this._poll();
      const backoff = Math.min(30000, 1000 * 2 ** this._attempts++) + Math.random() * 400;
      setTimeout(() => { if (!this._closed) this._open(); }, backoff);
    };
    ws.onerror = () => ws.close();
  }

  _poll() {
    const interval = (this.cfg.pollInterval ?? 30) * 1000;
    if (!interval || this._pollTimer) return;
    this._pollTimer = setInterval(async () => {
      if (document.hidden) return;
      try {
        const { unread } = await this.count();
        const previous = this.unread;
        this._setUnread(unread);
        if (unread > previous) this._emit('poll-new');
      } catch { /* transient */ }
    }, interval);
  }
}

export default NotificationsClient;
