"""App configuration: event autodiscovery on startup."""

from __future__ import annotations

from django.apps import AppConfig


class DjangoNotificationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_notifications"
    verbose_name = "Notifications"

    def ready(self) -> None:
        # Import <app>.notifications from every installed app so event
        # templates register themselves (mirrors admin autodiscovery).
        from . import events

        events.autodiscover()
