"""Event registry.

``notify.event("order.created", user=..., context={...})`` resolves its
template in two steps:

1. Active :class:`~django_notifications.models.NotificationTemplate` row for
   the event (admin-editable, wins).
2. Code-registered template from this registry.

Register from any app — typically in a ``notifications.py`` module that is
autodiscovered on startup::

    from django_notifications import notify

    notify.register_event(
        "order.created",
        title="Order #{{ order.id }} placed",
        message="Thanks {{ user.first_name }}! Total: {{ order.total }}",
        url="/orders/{{ order.id }}/",
        type="order",
        channels=["in_app", "websocket", "email"],
    )
"""

from __future__ import annotations

import threading
from typing import Any

from .exceptions import EventNotRegisteredError

_lock = threading.Lock()
_registry: dict[str, dict[str, Any]] = {}

_ALLOWED_KEYS = frozenset(
    {
        "title",
        "message",
        "body_html",
        "url",
        "type",
        "level",
        "category",
        "icon",
        "channels",
        "priority",
    }
)
_TEMPLATE_KEYS = ("title", "message", "body_html", "url")


def register(event: str, **template: Any) -> None:
    """Register (or replace) a code-level template for ``event``."""
    unknown = set(template) - _ALLOWED_KEYS
    if unknown:
        raise ValueError(f"Unknown event-template keys: {sorted(unknown)}")
    if "title" not in template:
        raise ValueError("Event templates require at least a 'title'.")
    with _lock:
        _registry[event] = dict(template)


def unregister(event: str) -> None:
    with _lock:
        _registry.pop(event, None)


def registered_events() -> list[str]:
    return sorted(_registry)


def resolve(event: str, context: dict, strict: bool = True) -> dict[str, Any] | None:
    """Return rendered notification kwargs for ``event`` or None/raise."""
    from .models import NotificationTemplate
    from .templates import render_string

    db_template = (
        NotificationTemplate.objects.filter(event=event, is_active=True).first()
    )
    if db_template is not None:
        return db_template.render(context)

    template = _registry.get(event)
    if template is None:
        if strict:
            raise EventNotRegisteredError(
                f"No template registered for event {event!r}. Register one in "
                f"code via notify.register_event(...) or create a "
                f"NotificationTemplate in the admin."
            )
        return None

    rendered: dict[str, Any] = {}
    for key, value in template.items():
        if key in _TEMPLATE_KEYS:
            rendered[key] = render_string(value, context)
        else:
            rendered[key] = value
    return rendered


def autodiscover() -> None:
    """Import ``<app>.notifications`` from every installed app.

    Mirrors Django's admin autodiscovery so apps can declare their event
    templates in a conventional place with zero wiring.
    """
    from django.utils.module_loading import autodiscover_modules

    autodiscover_modules("notifications")
