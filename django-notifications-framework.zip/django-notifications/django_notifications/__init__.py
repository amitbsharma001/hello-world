"""django_notifications — a production-grade, plug-and-play notification
framework for any Django project.

Quickstart::

    INSTALLED_APPS = [..., "django_notifications"]
    # python manage.py migrate

    from django_notifications import notify
    notify.success(user=request.user, title="Profile updated")

Full documentation lives in the package's ``docs/`` directory and README.
"""

from .api import Notify, notify

__version__ = "1.0.0"
__all__ = ["notify", "Notify", "__version__"]
