"""Repository layer: all direct data access used by the service layer.

Keeping raw ORM plumbing here keeps :mod:`services` readable and makes the
persistence strategy (chunked ``bulk_create``) swappable and testable.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from typing import Any

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.db import models
from django.utils.module_loading import import_string

from .exceptions import ConfigurationError, NoRecipientsError
from .models import Delivery, Notification
from .settings import app_settings


def _chunks(iterable: Iterable[int], size: int) -> Iterator[list[int]]:
    chunk: list[int] = []
    for item in iterable:
        chunk.append(item)
        if len(chunk) >= size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk


def _permission_users(perm: str) -> models.QuerySet:
    """Active users holding ``app_label.codename`` directly or via group."""
    try:
        app_label, codename = perm.split(".", 1)
    except ValueError as exc:
        raise ConfigurationError(
            f"Permission must be 'app_label.codename', got {perm!r}."
        ) from exc
    permission = Permission.objects.get(
        content_type__app_label=app_label, codename=codename
    )
    User = get_user_model()
    return User.objects.filter(
        models.Q(is_superuser=True)
        | models.Q(user_permissions=permission)
        | models.Q(groups__permissions=permission),
        is_active=True,
    ).distinct()


def system_recipients() -> models.QuerySet:
    """Resolve the SYSTEM_RECIPIENTS setting to a user queryset."""
    User = get_user_model()
    setting = app_settings.SYSTEM_RECIPIENTS
    if callable(setting):
        return setting()
    if setting == "staff":
        return User.objects.filter(is_staff=True, is_active=True)
    if setting == "superusers":
        return User.objects.filter(is_superuser=True, is_active=True)
    if isinstance(setting, str) and setting.startswith("group:"):
        return User.objects.filter(
            groups__name=setting.split(":", 1)[1], is_active=True
        )
    if isinstance(setting, str) and "." in setting:
        return import_string(setting)()
    raise ConfigurationError(f"Invalid SYSTEM_RECIPIENTS value: {setting!r}")


def resolve_recipient_id_chunks(
    *,
    user: Any = None,
    user_id: int | None = None,
    users: Any = None,
    user_ids: Iterable[int] | None = None,
    group: Any = None,
    groups: Iterable[Any] | None = None,
    permission: str | None = None,
    everyone: bool = False,
    recipients: Any = None,
    chunk_size: int | None = None,
) -> Iterator[list[int]]:
    """Yield recipient primary keys in fan-out sized chunks.

    Accepts every recipient shape the ``notify`` API supports; multiple
    shapes may be combined and are de-duplicated per call (via a queryset
    union where possible, otherwise a seen-set).
    """
    chunk_size = chunk_size or app_settings.FANOUT_CHUNK
    User = get_user_model()
    querysets: list[models.QuerySet] = []
    direct_ids: list[int] = []

    if user is not None:
        direct_ids.append(user.pk)
    if user_id is not None:
        direct_ids.append(int(user_id))
    if user_ids:
        direct_ids.extend(int(pk) for pk in user_ids)

    if users is not None:
        if isinstance(users, models.QuerySet):
            querysets.append(users)
        else:  # list/tuple/generator of user instances
            direct_ids.extend(u.pk for u in users)

    if group is not None:
        groups = list(groups or []) + [group]
    if groups:
        names = [g.name if isinstance(g, Group) else str(g) for g in groups]
        querysets.append(User.objects.filter(groups__name__in=names, is_active=True))

    if permission:
        querysets.append(_permission_users(permission))

    if everyone:
        querysets.append(User.objects.filter(is_active=True))

    if recipients is not None:
        if callable(recipients):
            recipients = recipients()
        if isinstance(recipients, str):
            recipients = import_string(recipients)()
        if isinstance(recipients, models.QuerySet):
            querysets.append(recipients)
        elif isinstance(recipients, User):
            direct_ids.append(recipients.pk)
        else:
            for entry in recipients:
                direct_ids.append(entry if isinstance(entry, int) else entry.pk)

    if not querysets and not direct_ids:
        raise NoRecipientsError(
            "No recipients: pass user/users/user_id(s)/group(s)/permission/"
            "everyone/recipients."
        )

    seen: set[int] = set()

    def _emit(ids: Iterable[int]) -> Iterator[int]:
        for pk in ids:
            if pk not in seen:
                seen.add(pk)
                yield pk

    def _all_ids() -> Iterator[int]:
        yield from _emit(direct_ids)
        for queryset in querysets:
            yield from _emit(
                queryset.values_list("pk", flat=True).iterator(chunk_size=chunk_size)
            )

    yield from _chunks(_all_ids(), chunk_size)


def bulk_create_notifications(instances: list[Notification]) -> list[Notification]:
    """Persist a chunk of notifications with the configured batch size."""
    return Notification.objects.bulk_create(
        instances, batch_size=app_settings.BATCH_SIZE
    )


def bulk_create_deliveries(instances: list[Delivery]) -> list[Delivery]:
    return Delivery.objects.bulk_create(instances, batch_size=app_settings.BATCH_SIZE)


def preferences_by_user(user_ids: list[int]) -> dict[int, Any]:
    """Fetch preferences for a chunk of users in one query."""
    from .models import NotificationPreference

    return {
        pref.user_id: pref
        for pref in NotificationPreference.objects.filter(user_id__in=user_ids)
    }
