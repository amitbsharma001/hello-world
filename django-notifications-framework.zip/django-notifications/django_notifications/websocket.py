"""WebSocket push helpers.

Degrades gracefully: if Django Channels is not installed or no channel layer
is configured, pushes are no-ops (callers see ``False`` → delivery marked
skipped) and everything else keeps working.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from .settings import app_settings

if TYPE_CHECKING:  # pragma: no cover
    from .models import Notification

logger = logging.getLogger(app_settings.LOGGER)


def user_group(user_id: int | str) -> str:
    """Channel-layer group name for a user, e.g. ``djn.user.42``."""
    prefix = app_settings.WEBSOCKET["GROUP_PREFIX"]
    return f"{prefix}.{user_id}"


def _get_channel_layer():
    try:
        from channels.layers import get_channel_layer
    except ImportError:
        return None
    return get_channel_layer()


def group_send(user_id: int | str, payload: dict[str, Any]) -> bool:
    """Send ``payload`` to a user's group. Returns False when unavailable."""
    layer = _get_channel_layer()
    if layer is None:
        logger.debug("Channel layer unavailable; websocket push skipped.")
        return False
    from asgiref.sync import async_to_sync

    message = {"type": "djn.message", "payload": payload}
    async_to_sync(layer.group_send)(user_group(user_id), message)
    return True


def push_notification(notification: Notification) -> bool:
    """Push a freshly created notification + updated unread count."""
    if notification.recipient_id is None:
        return False
    from .models import Notification
    from .serializers import NotificationSerializer

    payload = {
        "kind": "notification",
        "notification": NotificationSerializer(notification).data,
        "unread_count": Notification.objects.unread_count(notification.recipient),
    }
    return group_send(notification.recipient_id, payload)


def push_counts(user) -> bool:
    """Push only the unread count (after mark-read/archive/delete ops)."""
    from .models import Notification

    return group_send(
        user.pk,
        {"kind": "counts", "unread_count": Notification.objects.unread_count(user)},
    )
