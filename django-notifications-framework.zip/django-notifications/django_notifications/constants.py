"""Constants and enumerations for django_notifications.

Everything here is data, not behaviour. ``TYPE_PRESETS`` powers the dynamic
``notify.<type>()`` facade: any key listed here gets sensible defaults for
level, icon and category, and arbitrary custom types are still allowed.
"""

from __future__ import annotations

from django.db import models
from django.utils.translation import gettext_lazy as _


class Level(models.TextChoices):
    """Visual/semantic severity of a notification."""

    DEBUG = "debug", _("Debug")
    INFO = "info", _("Info")
    SUCCESS = "success", _("Success")
    WARNING = "warning", _("Warning")
    ERROR = "error", _("Error")
    CRITICAL = "critical", _("Critical")


class Priority(models.IntegerChoices):
    """Delivery priority. Higher values may be routed to faster queues."""

    LOW = 10, _("Low")
    NORMAL = 20, _("Normal")
    HIGH = 30, _("High")
    URGENT = 40, _("Urgent")


class ContentFormat(models.TextChoices):
    """How ``Notification.message`` should be interpreted by renderers."""

    PLAIN = "plain", _("Plain text")
    MARKDOWN = "markdown", _("Markdown")
    HTML = "html", _("HTML")


class DeliveryStatus(models.TextChoices):
    """Lifecycle of a single (notification, channel) delivery attempt."""

    PENDING = "pending", _("Pending")
    QUEUED = "queued", _("Queued")
    SENT = "sent", _("Sent")
    FAILED = "failed", _("Failed")
    SKIPPED = "skipped", _("Skipped")
    DEFERRED = "deferred", _("Deferred")


class Digest(models.TextChoices):
    """User digest preference."""

    OFF = "off", _("Off")
    DAILY = "daily", _("Daily")
    WEEKLY = "weekly", _("Weekly")


#: Built-in channel keys shipped with the package. The registry in settings
#: maps these to backend classes and may be extended/overridden freely.
CHANNEL_IN_APP = "in_app"
CHANNEL_WEBSOCKET = "websocket"
CHANNEL_EMAIL = "email"
CHANNEL_SMS = "sms"
CHANNEL_PUSH = "push"
CHANNEL_WEBHOOK = "webhook"
CHANNEL_SLACK = "slack"
CHANNEL_TEAMS = "teams"
CHANNEL_DISCORD = "discord"
CHANNEL_CONSOLE = "console"

#: Presets applied when ``notify.<type>()`` is used. ``type`` is an open
#: vocabulary — anything not listed here simply defaults to level=info.
TYPE_PRESETS: dict[str, dict[str, str]] = {
    # Core levels double as types.
    "success": {"level": Level.SUCCESS, "icon": "check-circle"},
    "error": {"level": Level.ERROR, "icon": "x-circle"},
    "warning": {"level": Level.WARNING, "icon": "alert-triangle"},
    "info": {"level": Level.INFO, "icon": "info"},
    "critical": {"level": Level.CRITICAL, "icon": "alert-octagon"},
    # Operational / platform types.
    "system": {"level": Level.INFO, "icon": "server", "category": "system"},
    "security": {"level": Level.WARNING, "icon": "shield", "category": "security"},
    "audit": {"level": Level.INFO, "icon": "clipboard", "category": "audit"},
    "maintenance": {"level": Level.WARNING, "icon": "tool", "category": "system"},
    "celery": {"level": Level.INFO, "icon": "cpu", "category": "jobs"},
    "background_job": {"level": Level.INFO, "icon": "cpu", "category": "jobs"},
    "scheduled_job": {"level": Level.INFO, "icon": "clock", "category": "jobs"},
    # Product / workflow types.
    "reminder": {"level": Level.INFO, "icon": "bell", "category": "reminders"},
    "announcement": {"level": Level.INFO, "icon": "megaphone", "category": "announcements"},
    "approval": {"level": Level.INFO, "icon": "check-square", "category": "workflow"},
    "workflow": {"level": Level.INFO, "icon": "git-branch", "category": "workflow"},
    "chat": {"level": Level.INFO, "icon": "message-circle", "category": "social"},
    "mention": {"level": Level.INFO, "icon": "at-sign", "category": "social"},
    "comment": {"level": Level.INFO, "icon": "message-square", "category": "social"},
    "login": {"level": Level.INFO, "icon": "log-in", "category": "security"},
    "logout": {"level": Level.INFO, "icon": "log-out", "category": "security"},
    "payment": {"level": Level.SUCCESS, "icon": "credit-card", "category": "billing"},
    "order": {"level": Level.INFO, "icon": "shopping-cart", "category": "orders"},
    "file_upload": {"level": Level.SUCCESS, "icon": "upload", "category": "files"},
    "import": {"level": Level.INFO, "icon": "download", "category": "data"},
    "export": {"level": Level.INFO, "icon": "upload", "category": "data"},
}

#: Types delivered in-app even when the user disabled the category/channel.
#: Users should never be able to mute security-relevant information.
MANDATORY_TYPES: tuple[str, ...] = ("security", "system", "critical")

#: Reserved kwargs on ``notify.send`` that are not notification fields.
RECIPIENT_KWARGS: tuple[str, ...] = (
    "user",
    "user_id",
    "users",
    "user_ids",
    "group",
    "groups",
    "permission",
    "everyone",
    "recipients",
)
