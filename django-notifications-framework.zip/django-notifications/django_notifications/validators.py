"""Validation and sanitization utilities.

``sanitize_html`` prefers `bleach`/`nh3` when installed and otherwise falls
back to a conservative stdlib ``HTMLParser`` allowlist that drops every tag,
attribute and URL scheme not explicitly permitted. The fallback favours
safety over fidelity: unknown markup is removed, never passed through.
"""

from __future__ import annotations

from collections.abc import Iterable
from html import escape
from html.parser import HTMLParser

from .exceptions import ValidationError

DEFAULT_ALLOWED_TAGS: frozenset[str] = frozenset(
    {
        "a", "abbr", "b", "blockquote", "br", "code", "del", "em", "hr", "i",
        "li", "ol", "p", "pre", "s", "small", "span", "strong", "sub", "sup",
        "u", "ul",
    }
)
DEFAULT_ALLOWED_ATTRIBUTES: dict[str, frozenset[str]] = {
    "a": frozenset({"href", "title", "rel", "target"}),
    "abbr": frozenset({"title"}),
    "span": frozenset({"class"}),
    "code": frozenset({"class"}),
}
_ALLOWED_URL_SCHEMES = ("http:", "https:", "mailto:", "tel:", "/", "#")
_VOID_TAGS = frozenset({"br", "hr"})


class _AllowlistSanitizer(HTMLParser):
    """Minimal, strict allowlist sanitizer built on the stdlib parser."""

    def __init__(self, tags: frozenset[str], attrs: dict[str, frozenset[str]]):
        super().__init__(convert_charrefs=True)
        self._tags = tags
        self._attrs = attrs
        self._out: list[str] = []
        self._suppress_depth = 0  # inside <script>/<style> etc.

    # -- handlers ----------------------------------------------------------

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]):
        if tag in ("script", "style", "iframe", "object", "embed"):
            self._suppress_depth += 1
            return
        if self._suppress_depth or tag not in self._tags:
            return
        cleaned = self._clean_attrs(tag, attrs)
        self._out.append(f"<{tag}{cleaned}>")

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style", "iframe", "object", "embed"):
            self._suppress_depth = max(0, self._suppress_depth - 1)
            return
        if self._suppress_depth or tag not in self._tags or tag in _VOID_TAGS:
            return
        self._out.append(f"</{tag}>")

    def handle_startendtag(self, tag: str, attrs) -> None:  # <br/>
        self.handle_starttag(tag, attrs)

    def handle_data(self, data: str) -> None:
        if not self._suppress_depth:
            self._out.append(escape(data, quote=False))

    # -- helpers -----------------------------------------------------------

    def _clean_attrs(self, tag: str, attrs: list[tuple[str, str | None]]) -> str:
        allowed = self._attrs.get(tag, frozenset())
        parts: list[str] = []
        for name, value in attrs:
            name = name.lower()
            if name.startswith("on") or name not in allowed or value is None:
                continue
            if name in ("href", "src"):
                candidate = value.strip().lower()
                if not candidate.startswith(_ALLOWED_URL_SCHEMES):
                    continue
            parts.append(f' {name}="{escape(value)}"')
        if tag == "a" and any(p.startswith(" href=") for p in parts):
            if not any(p.startswith(" rel=") for p in parts):
                parts.append(' rel="noopener noreferrer"')
        return "".join(parts)

    def result(self) -> str:
        return "".join(self._out)


def sanitize_html(
    html: str,
    allowed_tags: Iterable[str] | None = None,
    allowed_attributes: dict[str, Iterable[str]] | None = None,
) -> str:
    """Return ``html`` reduced to a safe allowlisted subset.

    Uses ``nh3`` or ``bleach`` when available (recommended in production),
    otherwise the strict stdlib fallback above.
    """
    if not html:
        return ""
    tags = frozenset(allowed_tags) if allowed_tags else DEFAULT_ALLOWED_TAGS
    attrs = (
        {k: frozenset(v) for k, v in allowed_attributes.items()}
        if allowed_attributes
        else DEFAULT_ALLOWED_ATTRIBUTES
    )
    try:  # pragma: no cover - exercised only when nh3 is installed
        import nh3

        return nh3.clean(html, tags=set(tags), attributes={k: set(v) for k, v in attrs.items()})
    except ImportError:
        pass
    try:  # pragma: no cover - exercised only when bleach is installed
        import bleach

        return bleach.clean(
            html,
            tags=set(tags),
            attributes={k: list(v) for k, v in attrs.items()},
            strip=True,
        )
    except ImportError:
        pass
    parser = _AllowlistSanitizer(tags, attrs)
    parser.feed(html)
    parser.close()
    return parser.result()


def validate_actions(actions: object) -> list[dict[str, str]]:
    """Validate the CTA ``actions`` payload: a list of {label, url, [style]}."""
    if actions in (None, ""):
        return []
    if not isinstance(actions, (list, tuple)):
        raise ValidationError("'actions' must be a list of {label, url} dicts.")
    cleaned: list[dict[str, str]] = []
    for item in actions:
        if not isinstance(item, dict) or "label" not in item or "url" not in item:
            raise ValidationError("Each action needs at least 'label' and 'url'.")
        entry = {"label": str(item["label"])[:80], "url": str(item["url"])[:500]}
        if item.get("style"):
            entry["style"] = str(item["style"])[:20]
        if item.get("method"):
            entry["method"] = str(item["method"]).upper()[:10]
        cleaned.append(entry)
    return cleaned


def validate_attachments(attachments: object) -> list[dict[str, str]]:
    """Validate ``attachments``: a list of {name, url, [size], [content_type]}."""
    if attachments in (None, ""):
        return []
    if not isinstance(attachments, (list, tuple)):
        raise ValidationError("'attachments' must be a list of {name, url} dicts.")
    cleaned: list[dict[str, str]] = []
    for item in attachments:
        if not isinstance(item, dict) or "url" not in item:
            raise ValidationError("Each attachment needs at least a 'url'.")
        entry = {"name": str(item.get("name", ""))[:255], "url": str(item["url"])[:500]}
        for extra in ("size", "content_type"):
            if item.get(extra) is not None:
                entry[extra] = str(item[extra])[:100]
        cleaned.append(entry)
    return cleaned
