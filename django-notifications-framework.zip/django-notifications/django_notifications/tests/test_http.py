"""HTTP layer tests: REST API, server-rendered views, tags, middleware."""

from __future__ import annotations

import json

from django.contrib.auth import get_user_model
from django.template import Context, Template
from django.test import TestCase, override_settings

from django_notifications import notify
from django_notifications.models import Notification, NotificationPreference

User = get_user_model()


def post_json(client, url, payload, method="post"):
    return getattr(client, method)(
        url, data=json.dumps(payload), content_type="application/json"
    )


class ApiTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "amit@example.com", "x")
        cls.other = User.objects.create_user("other", "other@example.com", "x")

    def setUp(self):
        self.client.force_login(self.user)


class ListEndpointTests(ApiTestCase):
    def test_requires_authentication(self):
        self.client.logout()
        response = self.client.get("/notifications/")
        self.assertEqual(response.status_code, 403)  # SessionAuth → 403

    def test_list_scoped_paginated_with_unread_count(self):
        for i in range(3):
            notify.info(user=self.user, title=f"Mine {i}")
        notify.info(user=self.other, title="Not mine")
        response = self.client.get("/notifications/")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["count"], 3)
        self.assertEqual(data["unread_count"], 3)
        titles = {item["title"] for item in data["results"]}
        self.assertNotIn("Not mine", titles)

    def test_filters_and_search(self):
        read_one = notify.success(user=self.user, title="Deploy finished")
        notify.error(user=self.user, title="Build broke", category="ci")
        read_one.mark_read()
        self.assertEqual(
            self.client.get("/notifications/?unread=1").json()["count"], 1
        )
        self.assertEqual(
            self.client.get("/notifications/?type=error").json()["count"], 1
        )
        self.assertEqual(
            self.client.get("/notifications/?q=deploy").json()["count"], 1
        )
        self.assertEqual(
            self.client.get("/notifications/?category=ci").json()["count"], 1
        )

    def test_pagination_and_page_size_cap(self):
        for i in range(7):
            notify.info(user=self.user, title=f"N{i}")
        with override_settings(
            DJANGO_NOTIFICATIONS={"USE_CELERY": False,
                                  "API": {"PAGE_SIZE": 3, "MAX_PAGE_SIZE": 5}}
        ):
            data = self.client.get("/notifications/").json()
            self.assertEqual(len(data["results"]), 3)
            self.assertIsNotNone(data["next"])
            capped = self.client.get("/notifications/?page_size=50").json()
            self.assertEqual(len(capped["results"]), 5)

    def test_since_id_incremental(self):
        first = notify.info(user=self.user, title="Old")
        notify.info(user=self.user, title="New")
        data = self.client.get(f"/notifications/?since_id={first.pk}").json()
        self.assertEqual(data["count"], 1)
        self.assertEqual(data["results"][0]["title"], "New")

    def test_pinned_sort_first(self):
        notify.info(user=self.user, title="Plain")
        pinned = notify.info(user=self.user, title="Pinned early")
        Notification.objects.filter(pk=pinned.pk).update(pinned=True)
        data = self.client.get("/notifications/").json()
        self.assertEqual(data["results"][0]["title"], "Pinned early")

    def test_unread_alias_endpoint(self):
        notification = notify.info(user=self.user, title="A")
        notify.info(user=self.user, title="B")
        notification.mark_read()
        data = self.client.get("/notifications/unread/").json()
        self.assertEqual(data["count"], 1)

    def test_archived_excluded_by_default(self):
        notification = notify.info(user=self.user, title="Bye")
        Notification.objects.filter(pk=notification.pk).archive()
        self.assertEqual(self.client.get("/notifications/").json()["count"], 0)
        self.assertEqual(
            self.client.get("/notifications/?archived=1").json()["count"], 1
        )


class CountAndMutationTests(ApiTestCase):
    def test_count(self):
        notify.info(user=self.user, title="A")
        read_one = notify.info(user=self.user, title="B")
        read_one.mark_read()
        data = self.client.get("/notifications/count/").json()
        self.assertEqual(data, {"unread": 1, "total": 2})

    def test_mark_read_ids_and_all(self):
        a = notify.info(user=self.user, title="A")
        notify.info(user=self.user, title="B")
        response = post_json(
            self.client, "/notifications/read/", {"ids": [a.pk]}, method="patch"
        )
        self.assertEqual(response.json(), {"updated": 1, "unread_count": 1})
        response = post_json(
            self.client, "/notifications/read/", {"all": True}, method="patch"
        )
        self.assertEqual(response.json()["unread_count"], 0)

    def test_mark_unread(self):
        a = notify.info(user=self.user, title="A")
        a.mark_read()
        response = post_json(
            self.client, "/notifications/read/",
            {"ids": [a.pk], "read": False}, method="patch",
        )
        self.assertEqual(response.json()["unread_count"], 1)

    def test_mark_read_requires_ids_or_all(self):
        response = post_json(self.client, "/notifications/read/", {}, method="patch")
        self.assertEqual(response.status_code, 400)

    def test_archive_and_unarchive(self):
        a = notify.info(user=self.user, title="A")
        response = post_json(
            self.client, "/notifications/archive/", {"ids": [a.pk]}, method="patch"
        )
        self.assertEqual(response.json()["updated"], 1)
        a.refresh_from_db()
        self.assertTrue(a.is_archived)
        post_json(
            self.client, "/notifications/archive/",
            {"ids": [a.pk], "archived": False}, method="patch",
        )
        a.refresh_from_db()
        self.assertFalse(a.is_archived)

    def test_bulk_delete(self):
        notify.info(user=self.user, title="A")
        notify.info(user=self.user, title="B")
        notify.info(user=self.other, title="Other keeps this")
        response = post_json(
            self.client, "/notifications/", {"all": True}, method="delete"
        )
        self.assertEqual(response.json()["deleted"], 2)
        self.assertEqual(Notification.objects.count(), 1)

    def test_cannot_touch_others_notification(self):
        theirs = notify.info(user=self.other, title="Theirs")
        response = self.client.get(f"/notifications/{theirs.pk}/")
        self.assertEqual(response.status_code, 404)
        count = post_json(
            self.client, "/notifications/read/", {"ids": [theirs.pk]}, method="patch"
        ).json()["updated"]
        self.assertEqual(count, 0)


class DetailEndpointTests(ApiTestCase):
    def test_get_patch_delete(self):
        notification = notify.info(user=self.user, title="Detail", url="/x/")
        url = f"/notifications/{notification.pk}/"
        data = self.client.get(url).json()
        self.assertEqual(data["title"], "Detail")
        data = post_json(
            self.client, url, {"read": True, "pinned": True}, method="patch"
        ).json()
        self.assertTrue(data["is_read"])
        self.assertTrue(data["pinned"])
        data = post_json(self.client, url, {"archived": True}, method="patch").json()
        self.assertTrue(data["is_archived"])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, 204)
        self.assertFalse(Notification.objects.filter(pk=notification.pk).exists())


class CreateEndpointTests(ApiTestCase):
    def test_create_for_self(self):
        response = post_json(
            self.client, "/notifications/",
            {"title": "Self note", "type": "reminder"},
        )
        self.assertEqual(response.status_code, 201)
        notification = Notification.objects.get()
        self.assertEqual(notification.recipient, self.user)
        self.assertEqual(notification.type, "reminder")

    def test_create_for_others_denied_for_plain_users(self):
        response = post_json(
            self.client, "/notifications/",
            {"title": "Spam", "recipient": self.other.pk},
        )
        self.assertEqual(response.status_code, 403)
        self.assertEqual(Notification.objects.count(), 0)

    def test_create_for_others_allowed_for_staff(self):
        staff = User.objects.create_user("boss", "b@e.com", "x", is_staff=True)
        self.client.force_login(staff)
        response = post_json(
            self.client, "/notifications/",
            {"title": "Heads up", "recipient": self.other.pk},
        )
        self.assertEqual(response.status_code, 201)
        self.assertEqual(Notification.objects.get().recipient, self.other)


class PreferencesEndpointTests(ApiTestCase):
    def test_get_creates_defaults_and_patch_updates(self):
        data = self.client.get("/notifications/preferences/").json()
        self.assertTrue(data["enabled"])
        response = post_json(
            self.client, "/notifications/preferences/",
            {"channel_settings": {"email": False}, "digest": "daily"},
            method="patch",
        )
        self.assertEqual(response.status_code, 200)
        preference = NotificationPreference.objects.get(user=self.user)
        self.assertEqual(preference.channel_settings, {"email": False})
        self.assertEqual(preference.digest, "daily")


class PageAndPartialTests(ApiTestCase):
    def test_center_page_renders_widget(self):
        response = self.client.get("/notifications/page/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "data-djn-widget")
        self.assertContains(response, "djn-mode-center")

    def test_partial_lists_items(self):
        notify.info(user=self.user, title="Fragment me")
        response = self.client.get("/notifications/partial/?filter=all")
        self.assertContains(response, "Fragment me")
        self.assertContains(response, "djn-item")

    def test_partial_requires_login(self):
        self.client.logout()
        response = self.client.get("/notifications/partial/")
        self.assertEqual(response.status_code, 302)


class TemplateTagTests(ApiTestCase):
    def render(self, source: str) -> str:
        return Template("{% load django_notifications %}" + source).render(Context())

    def test_bell_tag_renders_config(self):
        html = self.render("{% notification_bell %}")
        self.assertIn("data-djn-widget", html)
        self.assertIn("djn-mode-bell", html)
        self.assertIn("notifications.js", html)
        self.assertIn("&quot;apiBase&quot;: &quot;/notifications/&quot;", html)

    def test_center_tag_and_theme_override(self):
        html = self.render('{% notification_center theme="dark" %}')
        self.assertIn('data-djn-theme="dark"', html)
        self.assertIn("djn-mode-center", html)

    def test_assets_tag_skippable(self):
        html = self.render("{% notification_bell assets=False %}")
        self.assertNotIn("notifications.css", html)

    def test_unread_count_tag(self):
        notify.info(user=self.user, title="One")
        html = Template(
            "{% load django_notifications %}{% unread_count user %}"
        ).render(Context({"user": self.user}))
        self.assertEqual(html.strip(), "1")


class MiddlewareTests(ApiTestCase):
    def test_lazy_unread_count_on_request(self):
        notify.info(user=self.user, title="One")
        # The partial view runs through full middleware; grab via template.
        response = self.client.get("/notifications/page/")
        self.assertEqual(response.wsgi_request.unread_notifications_count, 1)

    def test_anonymous_gets_zero(self):
        self.client.logout()
        response = self.client.get("/notifications/partial/")
        self.assertEqual(response.wsgi_request.unread_notifications_count, 0)


class BroadcastTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        from django.contrib.auth.models import Group

        cls.staff = User.objects.create_user("boss", "b@e.com", "x", is_staff=True)
        cls.plain = User.objects.create_user("plain", "p@e.com", "x")
        cls.eng = Group.objects.create(name="engineers")
        cls.ops = Group.objects.create(name="ops")
        cls.m1 = User.objects.create_user("m1", "m1@e.com", "x")
        cls.m2 = User.objects.create_user("m2", "m2@e.com", "x")
        cls.m3 = User.objects.create_user("m3", "m3@e.com", "x")
        cls.eng.user_set.add(cls.m1, cls.m2)
        cls.ops.user_set.add(cls.m2, cls.m3)  # m2 in both -> dedup check

    # -- groups picker -------------------------------------------------------

    def test_groups_endpoint_lists_counts_for_staff(self):
        self.client.force_login(self.staff)
        data = self.client.get("/notifications/groups/").json()
        by_name = {g["name"]: g["user_count"] for g in data}
        self.assertEqual(by_name["engineers"], 2)
        self.assertEqual(by_name["ops"], 2)

    def test_groups_endpoint_forbidden_for_plain_user(self):
        self.client.force_login(self.plain)
        self.assertEqual(self.client.get("/notifications/groups/").status_code, 403)

    # -- sending -------------------------------------------------------------

    def test_broadcast_to_multiple_groups_dedupes_members(self):
        self.client.force_login(self.staff)
        response = post_json(
            self.client,
            "/notifications/broadcast/send/",
            {"title": "Maintenance tonight", "message": "22:00 UTC",
             "level": "warning", "groups": [self.eng.pk, self.ops.pk]},
        )
        self.assertEqual(response.status_code, 201)
        body = response.json()
        self.assertEqual(body["created"], 3)  # m1, m2, m3 — m2 not doubled
        self.assertEqual({g["name"] for g in body["groups"]}, {"engineers", "ops"})
        recipients = set(
            Notification.objects.values_list("recipient__username", flat=True)
        )
        self.assertEqual(recipients, {"m1", "m2", "m3"})
        note = Notification.objects.filter(recipient=self.m1).get()
        self.assertEqual(note.title, "Maintenance tonight")
        self.assertEqual(note.level, "warning")
        self.assertEqual(note.actor, self.staff)

    def test_broadcast_forbidden_for_plain_user(self):
        self.client.force_login(self.plain)
        response = post_json(
            self.client, "/notifications/broadcast/send/",
            {"title": "Nope", "groups": [self.eng.pk]},
        )
        self.assertEqual(response.status_code, 403)
        self.assertEqual(Notification.objects.count(), 0)

    def test_broadcast_requires_group_and_title(self):
        self.client.force_login(self.staff)
        self.assertEqual(
            post_json(self.client, "/notifications/broadcast/send/",
                      {"title": "No groups", "groups": []}).status_code,
            400,
        )
        self.assertEqual(
            post_json(self.client, "/notifications/broadcast/send/",
                      {"title": "", "groups": [self.eng.pk]}).status_code,
            400,
        )

    def test_broadcast_unknown_group_rejected(self):
        self.client.force_login(self.staff)
        response = post_json(
            self.client, "/notifications/broadcast/send/",
            {"title": "Ghost", "groups": [999999]},
        )
        self.assertEqual(response.status_code, 400)

    def test_broadcast_policy_superusers(self):
        superuser = User.objects.create_superuser("root", "r@e.com", "x")
        with override_settings(
            DJANGO_NOTIFICATIONS={"USE_CELERY": False,
                                  "API": {"BROADCAST": "superusers"}}
        ):
            self.client.force_login(self.staff)  # staff no longer allowed
            self.assertEqual(
                post_json(self.client, "/notifications/broadcast/send/",
                          {"title": "x", "groups": [self.eng.pk]}).status_code,
                403,
            )
            self.client.force_login(superuser)
            self.assertEqual(
                post_json(self.client, "/notifications/broadcast/send/",
                          {"title": "x", "groups": [self.eng.pk]}).status_code,
                201,
            )

    # -- page ----------------------------------------------------------------

    def test_broadcast_page_renders_for_staff(self):
        self.client.force_login(self.staff)
        response = self.client.get("/notifications/broadcast/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Broadcast a notification")
        self.assertContains(response, "bc-groups")

    def test_broadcast_page_forbidden_for_plain_user(self):
        self.client.force_login(self.plain)
        self.assertEqual(self.client.get("/notifications/broadcast/").status_code, 403)

    def test_broadcast_page_redirects_anonymous(self):
        self.assertEqual(self.client.get("/notifications/broadcast/").status_code, 302)

    # -- widget link visibility ---------------------------------------------

    def test_bell_shows_broadcast_link_for_staff_only(self):
        staff_html = self._render_bell(self.staff)
        self.assertIn("djn-broadcast-link", staff_html)
        self.assertIn("/notifications/broadcast/", staff_html)
        self.assertIn('&quot;canBroadcast&quot;: true', staff_html)

        plain_html = self._render_bell(self.plain)
        self.assertNotIn("djn-broadcast-link", plain_html)
        self.assertIn('&quot;canBroadcast&quot;: false', plain_html)

    def _render_bell(self, user) -> str:
        from django.test import RequestFactory

        request = RequestFactory().get("/")
        request.user = user
        return Template(
            "{% load django_notifications %}{% notification_bell %}"
        ).render(Context({"request": request}))
