"""Optional-dependency and edge-path tests: Celery, Channels, HTTP backends.

These run because the test environment installs ``celery`` and ``channels``;
the package itself keeps both optional at runtime.
"""

from __future__ import annotations

import datetime as dt
import json
from unittest import mock

from celery import Celery
from django.contrib.auth import get_user_model
from django.test import RequestFactory, TestCase, TransactionTestCase, override_settings

from django_notifications import notify
from django_notifications.backends import discord, push, slack, sms, teams, webhook
from django_notifications.backends.http import post_json
from django_notifications.exceptions import (
    ConfigurationError,
    DeliveryError,
    RetryableDeliveryError,
    ValidationError,
)
from django_notifications.models import Notification
from django_notifications.permissions import CanCreateForOthers
from django_notifications.services import (
    _serialize_payload,
    celery_available,
    deserialize_payload,
    service,
)
from django_notifications.tests.channels import SENT
from django_notifications.tests.test_core import RECORDER, dj_settings

User = get_user_model()

# Eager Celery app: .delay()/apply_async() execute inline in-process.
celery_app = Celery("djn-tests")
celery_app.conf.update(
    task_always_eager=True, task_eager_propagates=True, broker_url="memory://"
)


# ---------------------------------------------------------------- celery

@dj_settings(USE_CELERY=True, CHANNELS={"recorder": RECORDER},
             DEFAULT_CHANNELS=["recorder"])
class CeleryPipelineTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "a@e.com", "x")
        cls.other = User.objects.create_user("uma", "u@e.com", "x")

    def setUp(self):
        SENT.clear()

    def test_delivery_flows_through_deliver_chunk_task(self):
        notification = notify.success(user=self.user, title="Via celery")
        self.assertEqual(SENT, [(notification.pk, "Via celery")])
        self.assertEqual(notification.deliveries.get().status, "sent")

    def test_enqueue_fanout_ids(self):
        result = notify.bulk(
            user_ids=[self.user.pk, self.other.pk],
            title="Broadcast",
            enqueue=True,
        )
        self.assertTrue(result.queued)
        self.assertEqual(Notification.objects.count(), 2)
        self.assertEqual(len(SENT), 2)

    def test_enqueue_fanout_queryset_chunks(self):
        with dj_settings(USE_CELERY=True, FANOUT_CHUNK=1,
                         CHANNELS={"recorder": RECORDER},
                         DEFAULT_CHANNELS=["recorder"]):
            result = notify.bulk(
                users=User.objects.all(), title="QS broadcast", enqueue=True
            )
        self.assertTrue(result.queued)
        self.assertEqual(Notification.objects.count(), 2)

    def test_fanout_preserves_actor(self):
        notify.bulk(
            user_ids=[self.user.pk], title="With actor",
            actor=self.other, enqueue=True,
        )
        self.assertEqual(Notification.objects.get().actor, self.other)

    def test_scheduled_dispatch_via_beat_task(self):
        from django_notifications.celery_tasks import cleanup_task, dispatch_due_task

        notify.schedule(user=self.user, title="Due soon",
                        at=dt.datetime.now(dt.UTC) - dt.timedelta(minutes=1))
        stats = dispatch_due_task.delay().get()
        self.assertEqual(stats["scheduled_sent"], 1)
        self.assertEqual(cleanup_task.delay().get()["expired"], 0)


class CeleryDetectionTests(TestCase):
    @dj_settings(USE_CELERY=False)
    def test_disabled(self):
        self.assertFalse(celery_available())

    @dj_settings(USE_CELERY=True)
    def test_forced_on(self):
        self.assertTrue(celery_available())

    @dj_settings(USE_CELERY="auto")
    def test_auto_uses_configured_broker(self):
        # Eager test app sets broker_url, so auto-detection sees a broker.
        self.assertTrue(celery_available())

    def test_payload_roundtrip(self):
        when = dt.datetime(2026, 7, 16, 9, 0, tzinfo=dt.UTC)
        payload = {
            "title": "X",
            "scheduled_for": when,
            "repeat_interval": dt.timedelta(hours=2),
            "data": {"a": 1},
        }
        restored = deserialize_payload(_serialize_payload(payload))
        self.assertEqual(restored["scheduled_for"], when)
        self.assertEqual(restored["repeat_interval"], dt.timedelta(hours=2))
        self.assertEqual(restored["data"], {"a": 1})


# --------------------------------------------------------------- channels

class ConsumerTests(TransactionTestCase):
    """WebSocket consumer against the in-memory channel layer."""

    layer_settings = override_settings(
        CHANNEL_LAYERS={"default": {"BACKEND": "channels.layers.InMemoryChannelLayer"}}
    )

    def setUp(self):
        self.layer_settings.enable()
        self.addCleanup(self.layer_settings.disable)
        self.user = User.objects.create_user("amit", "a@e.com", "x")

    async def _connect(self):
        from channels.db import database_sync_to_async
        from channels.testing import WebsocketCommunicator

        from django_notifications.consumers import NotificationConsumer

        communicator = WebsocketCommunicator(
            NotificationConsumer.as_asgi(), "/ws/notifications/"
        )
        communicator.scope["user"] = self.user
        connected, _ = await communicator.connect()
        assert connected
        init = await communicator.receive_json_from()
        return communicator, init, database_sync_to_async

    async def test_init_push_sync_and_mark_read(self):
        from channels.db import database_sync_to_async

        seed = await database_sync_to_async(notify.info)(
            user=self.user, title="Seed", sync=True
        )
        communicator, init, db_async = await self._connect()
        self.assertEqual(init, {"kind": "init", "unread_count": 1})

        # Live push through the websocket channel backend.
        pushed = await db_async(notify.success)(
            user=self.user, title="Live one", sync=True
        )
        frame = await communicator.receive_json_from()
        self.assertEqual(frame["kind"], "notification")
        self.assertEqual(frame["notification"]["title"], "Live one")
        self.assertEqual(frame["unread_count"], 2)

        # Reconnect catch-up: ask for everything after the seed id.
        await communicator.send_json_to({"action": "sync", "since_id": seed.pk})
        frame = await communicator.receive_json_from()
        self.assertEqual(frame["kind"], "sync")
        self.assertEqual(
            [n["id"] for n in frame["notifications"]], [pushed.pk]
        )

        # Mark read over the socket.
        await communicator.send_json_to(
            {"action": "mark_read", "ids": [seed.pk, pushed.pk]}
        )
        frame = await communicator.receive_json_from()
        self.assertEqual(frame, {"kind": "counts", "unread_count": 0})

        await communicator.send_json_to({"action": "ping"})
        self.assertEqual(await communicator.receive_json_from(), {"kind": "pong"})
        await communicator.disconnect()

    async def test_anonymous_rejected(self):
        from channels.testing import WebsocketCommunicator
        from django.contrib.auth.models import AnonymousUser

        from django_notifications.consumers import NotificationConsumer

        communicator = WebsocketCommunicator(
            NotificationConsumer.as_asgi(), "/ws/notifications/"
        )
        communicator.scope["user"] = AnonymousUser()
        connected, code = await communicator.connect()
        self.assertFalse(connected)
        self.assertEqual(code, 4401)


# ------------------------------------------------------------ http backends

class PostJsonTests(TestCase):
    def _response(self, status=200):
        response = mock.MagicMock()
        response.status = status
        response.__enter__ = lambda s: s
        response.__exit__ = lambda s, *a: False
        return response

    def test_success_and_signature(self):
        with mock.patch("urllib.request.urlopen", return_value=self._response()) as opened:
            status = post_json("https://hooks.example/x", {"a": 1}, secret="s3cr3t")
        self.assertEqual(status, 200)
        request = opened.call_args[0][0]
        self.assertTrue(request.headers["X-djn-signature"].startswith("sha256="))
        self.assertEqual(json.loads(request.data), {"a": 1})

    def test_http_error_mapping(self):
        import urllib.error

        def raise_code(code):
            return urllib.error.HTTPError("u", code, "err", {}, None)

        with mock.patch("urllib.request.urlopen", side_effect=raise_code(503)):
            with self.assertRaises(RetryableDeliveryError):
                post_json("https://x", {})
        with mock.patch("urllib.request.urlopen", side_effect=raise_code(400)):
            with self.assertRaises(DeliveryError):
                post_json("https://x", {})
        with mock.patch(
            "urllib.request.urlopen",
            side_effect=urllib.error.URLError("down"),
        ):
            with self.assertRaises(RetryableDeliveryError):
                post_json("https://x", {})


class WebhookFamilyTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "a@e.com", "x")

    def _notification(self, **kwargs):
        kwargs.setdefault("title", "Deploy done")
        kwargs.setdefault("message", "v2 shipped")
        kwargs.setdefault("url", "/deploys/2/")
        return notify.success(user=self.user, channels=["in_app"], **kwargs)

    def test_webhook_uses_global_url_and_secret(self):
        notification = self._notification()
        with dj_settings(WEBHOOK={"URL": "https://hooks.example/djn",
                                  "SECRET": "s", "TIMEOUT": 5, "HEADERS": {}}):
            with mock.patch.object(webhook, "post_json", return_value=200) as posted:
                self.assertTrue(webhook.WebhookChannel().send(notification))
        _, kwargs = posted.call_args
        self.assertEqual(posted.call_args[0][0], "https://hooks.example/djn")
        self.assertEqual(kwargs["secret"], "s")
        self.assertEqual(posted.call_args[0][1]["notification"]["title"], "Deploy done")

    def test_webhook_per_user_getter_wins(self):
        notification = self._notification()
        getter = "django_notifications.tests.test_optional._user_webhook"
        with dj_settings(USER_WEBHOOK_GETTER=getter,
                         WEBHOOK={"URL": None, "SECRET": None,
                                  "TIMEOUT": 5, "HEADERS": {}}):
            with mock.patch.object(webhook, "post_json", return_value=200) as posted:
                self.assertTrue(webhook.WebhookChannel().send(notification))
        self.assertEqual(posted.call_args[0][0], "https://user.example/hook")

    def test_webhook_skips_without_url(self):
        notification = self._notification()
        self.assertFalse(webhook.WebhookChannel().send(notification))

    def test_slack_teams_discord_payload_shapes(self):
        notification = self._notification()
        cases = [
            (slack, "SLACK", "blocks"),
            (teams, "TEAMS", "attachments"),
            (discord, "DISCORD", "embeds"),
        ]
        for module, setting_key, payload_key in cases:
            with self.subTest(channel=setting_key):
                with dj_settings(**{setting_key: {"WEBHOOK_URL": "https://h.example/w",
                                                  "TIMEOUT": 5}}):
                    with mock.patch.object(module, "post_json", return_value=200) as posted:
                        channel_cls = getattr(
                            module, f"{setting_key.title()}Channel"
                        )
                        self.assertTrue(channel_cls().send(notification))
                payload = posted.call_args[0][1]
                self.assertIn(payload_key, payload)
                self.assertIn("Deploy done", json.dumps(payload))

    def test_sms_and_push_gateways(self):
        notification = self._notification()
        with dj_settings(
            USER_PHONE_GETTER="django_notifications.tests.test_optional._phone",
            USER_PUSH_TOKEN_GETTER="django_notifications.tests.test_optional._token",
            SMS={"GATEWAY_URL": "https://sms.example/send", "TIMEOUT": 5, "HEADERS": {}},
            PUSH={"GATEWAY_URL": "https://push.example/send", "TIMEOUT": 5, "HEADERS": {}},
        ):
            with mock.patch.object(sms, "post_json", return_value=200) as sms_post:
                self.assertTrue(sms.SMSChannel().send(notification))
            with mock.patch.object(push, "post_json", return_value=200) as push_post:
                self.assertTrue(push.PushChannel().send(notification))
        self.assertEqual(sms_post.call_args[0][1]["to"], "+91-99999")
        self.assertEqual(push_post.call_args[0][1]["token"], "tok-1")

    def test_sms_skips_without_phone(self):
        notification = self._notification()
        with dj_settings(SMS={"GATEWAY_URL": "https://sms.example", "TIMEOUT": 5,
                              "HEADERS": {}}):
            self.assertFalse(sms.SMSChannel().send(notification))


def _user_webhook(user):
    return "https://user.example/hook"


def _phone(user):
    return "+91-99999"


def _token(user):
    return "tok-1"


# --------------------------------------------------------- permission policy

class CreateForOthersPolicyTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.factory = RequestFactory()
        cls.plain = User.objects.create_user("p", "p@e.com", "x")
        cls.staff = User.objects.create_user("s", "s@e.com", "x", is_staff=True)
        cls.superuser = User.objects.create_superuser("su", "su@e.com", "x")

    def _request(self, user, recipient):
        request = self.factory.post("/notifications/")
        request.user = user
        request.data = {"recipient": recipient}
        return request

    def test_policies(self):
        gate = CanCreateForOthers()
        target = self.plain.pk + 1000
        self.assertTrue(gate.has_permission(self._request(self.plain, self.plain.pk), None))
        with dj_settings(API={"CREATE_FOR_OTHERS": "nobody"}):
            self.assertFalse(gate.has_permission(self._request(self.staff, target), None))
        with dj_settings(API={"CREATE_FOR_OTHERS": "superusers"}):
            self.assertFalse(gate.has_permission(self._request(self.staff, target), None))
            self.assertTrue(
                gate.has_permission(self._request(self.superuser, target), None)
            )
        with dj_settings(API={"CREATE_FOR_OTHERS": "perm:django_notifications.add_notification"}):
            self.assertFalse(gate.has_permission(self._request(self.plain, target), None))
            self.assertTrue(
                gate.has_permission(self._request(self.superuser, target), None)
            )


# ------------------------------------------------------- misc engine edges

class EngineEdgeTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.users = [
            User.objects.create_user(f"e{i}", f"e{i}@e.com", "x") for i in range(3)
        ]
        User.objects.create_user("inactive", "i@e.com", "x", is_active=False)

    def test_everyone_excludes_inactive(self):
        result = notify.info(everyone=True, title="Actives only")
        self.assertEqual(result.created, 3)

    def test_users_as_plain_list_and_dotted_recipients(self):
        result = notify.info(users=[self.users[0], self.users[1]], title="List")
        self.assertEqual(result.created, 2)
        result = notify.info(
            recipients="django_notifications.tests.test_optional._pick_first",
            title="Dotted",
        )
        self.assertEqual(result.created, 1)

    def test_schedule_requires_time(self):
        with self.assertRaises(ValidationError):
            notify.schedule(user=self.users[0], title="No time")

    @dj_settings(RATE_LIMIT="not-a-spec")
    def test_bad_rate_limit_spec(self):
        with self.assertRaises(ConfigurationError):
            service._check_rate_limit(mock.Mock(user=self.users[0]))

    def test_register_channel_runtime(self):
        notify.register_channel("runtime_recorder", RECORDER)
        try:
            notification = notify.info(
                user=self.users[0], title="RT", channels=["runtime_recorder"]
            )
            self.assertEqual(notification.deliveries.get().status, "sent")
        finally:
            from django_notifications.settings import app_settings

            app_settings.CHANNELS.pop("runtime_recorder", None)


def _pick_first():
    return User.objects.filter(username="e2")


class RoutingAndSystemRecipientTests(TestCase):
    def test_routing_exports_url_pattern(self):
        from django_notifications import routing

        self.assertEqual(len(routing.websocket_urlpatterns), 1)
        self.assertTrue(hasattr(routing.websocket_urlpatterns[0], "callback"))

    def test_system_recipients_variants(self):
        from django.contrib.auth.models import Group

        from django_notifications.repository import system_recipients

        superuser = User.objects.create_superuser("root2", "r2@e.com", "x")
        group = Group.objects.create(name="oncall")
        member = User.objects.create_user("member", "m@e.com", "x")
        member.groups.add(group)
        with dj_settings(SYSTEM_RECIPIENTS="superusers"):
            self.assertEqual(list(system_recipients()), [superuser])
        with dj_settings(SYSTEM_RECIPIENTS="group:oncall"):
            self.assertEqual(list(system_recipients()), [member])
        with dj_settings(SYSTEM_RECIPIENTS=lambda: User.objects.filter(pk=member.pk)):
            self.assertEqual(list(system_recipients()), [member])
        with dj_settings(SYSTEM_RECIPIENTS="nonsense"):
            with self.assertRaises(ConfigurationError):
                system_recipients()

    def test_bad_permission_spec(self):
        from django_notifications.repository import _permission_users

        with self.assertRaises(ConfigurationError):
            _permission_users("no-dot")

    def test_recipients_single_user_object(self):
        user = User.objects.create_user("solo", "s2@e.com", "x")
        result = notify.info(recipients=user, title="Solo")
        self.assertEqual(result.created, 1)
