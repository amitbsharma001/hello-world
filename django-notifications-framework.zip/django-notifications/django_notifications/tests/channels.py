"""Test channel backends for exercising delivery outcomes."""

from django_notifications.backends.base import BaseChannel
from django_notifications.exceptions import DeliveryError, RetryableDeliveryError

SENT: list[tuple[int, str]] = []


class RecorderChannel(BaseChannel):
    key = "recorder"

    def send(self, notification):
        SENT.append((notification.pk, notification.title))
        return True


class SkippingChannel(BaseChannel):
    key = "skipper"

    def send(self, notification):
        return False


class FlakyChannel(BaseChannel):
    key = "flaky"

    def send(self, notification):
        raise RetryableDeliveryError("temporary outage")


class BrokenChannel(BaseChannel):
    key = "broken"

    def send(self, notification):
        raise DeliveryError("bad configuration")
