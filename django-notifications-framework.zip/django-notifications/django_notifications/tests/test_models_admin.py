"""Model, validator, admin and management-command tests."""

from __future__ import annotations

import datetime as dt
from io import StringIO

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.test import TestCase
from django.utils import timezone

from django_notifications import notify
from django_notifications.exceptions import ValidationError
from django_notifications.models import (
    Notification,
    NotificationPreference,
    NotificationTemplate,
)
from django_notifications.validators import (
    sanitize_html,
    validate_actions,
    validate_attachments,
)

User = get_user_model()


class ModelTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "a@e.com", "x")

    def test_str_representations(self):
        notification = notify.success(user=self.user, title="Done")
        self.assertEqual(str(notification), "[success] Done")
        template = NotificationTemplate.objects.create(
            event="x.y", title_template="T"
        )
        self.assertEqual(str(template), "x.y")
        preference = NotificationPreference.objects.create(user=self.user)
        self.assertIn("amit", str(preference))
        self.assertIn("in_app", str(notification.deliveries.first()))

    def test_mark_read_unread_instance(self):
        notification = notify.info(user=self.user, title="X")
        notification.mark_read()
        self.assertTrue(Notification.objects.get(pk=notification.pk).is_read)
        notification.mark_unread()
        self.assertFalse(Notification.objects.get(pk=notification.pk).is_read)

    def test_quiet_hours_midnight_crossing(self):
        preference = NotificationPreference(
            user=self.user,
            quiet_hours_start=dt.time(22, 0),
            quiet_hours_end=dt.time(7, 0),
            timezone="UTC",
        )
        inside = dt.datetime(2026, 7, 15, 23, 30, tzinfo=dt.UTC)
        outside = dt.datetime(2026, 7, 15, 12, 0, tzinfo=dt.UTC)
        self.assertTrue(preference.in_quiet_hours(inside))
        self.assertFalse(preference.in_quiet_hours(outside))
        end = preference.quiet_hours_end_datetime(inside)
        self.assertEqual(end.astimezone(dt.UTC).hour, 7)
        self.assertGreater(end, inside)

    def test_template_render_channels_and_defaults(self):
        template = NotificationTemplate.objects.create(
            event="deploy.done",
            title_template="Deployed {{ version }}",
            channels=["in_app"],
            level="success",
            icon="rocket",
        )
        rendered = template.render({"version": "v2"})
        self.assertEqual(rendered["title"], "Deployed v2")
        self.assertEqual(rendered["channels"], ["in_app"])
        self.assertEqual(rendered["level"], "success")
        self.assertEqual(rendered["icon"], "rocket")


class SanitizerTests(TestCase):
    def test_strips_scripts_and_handlers(self):
        dirty = (
            '<p onclick="steal()">Hi <script>alert(1)</script>'
            '<a href="javascript:evil()">x</a>'
            '<a href="https://ok.example">ok</a></p>'
        )
        clean = sanitize_html(dirty)
        self.assertNotIn("script", clean)
        self.assertNotIn("alert", clean)
        self.assertNotIn("onclick", clean)
        self.assertNotIn("javascript:", clean)
        self.assertIn('<a href="https://ok.example"', clean)
        self.assertIn("rel=", clean)

    def test_unknown_tags_removed_text_kept(self):
        clean = sanitize_html("<marquee><b>bold</b> plain</marquee>")
        self.assertEqual(clean, "<b>bold</b> plain")

    def test_service_sanitizes_body_html(self):
        user = User.objects.create_user("amit", "a@e.com", "x")
        notification = notify.info(
            user=user, title="X", body_html='<img src=x onerror=alert(1)><i>ok</i>'
        )
        self.assertNotIn("onerror", notification.body_html)
        self.assertIn("<i>ok</i>", notification.body_html)

    def test_action_validation(self):
        with self.assertRaises(ValidationError):
            validate_actions([{"label": "no url"}])
        cleaned = validate_actions(
            [{"label": "Open", "url": "/x/", "style": "primary", "extra": "drop"}]
        )
        self.assertEqual(
            cleaned, [{"label": "Open", "url": "/x/", "style": "primary"}]
        )

    def test_attachment_validation(self):
        with self.assertRaises(ValidationError):
            validate_attachments("nope")
        cleaned = validate_attachments([{"url": "/f.pdf", "name": "f.pdf"}])
        self.assertEqual(cleaned[0]["url"], "/f.pdf")


class AdminSmokeTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.admin = User.objects.create_superuser("root", "r@e.com", "x")

    def setUp(self):
        self.client.force_login(self.admin)

    def test_changelist_and_stats(self):
        notify.success(user=self.admin, title="Seed")
        response = self.client.get(
            "/admin/django_notifications/notification/"
        )
        self.assertEqual(response.status_code, 200)
        response = self.client.get(
            "/admin/django_notifications/notification/stats/"
        )
        self.assertContains(response, "Notification statistics")
        self.assertContains(response, "Delivery success by channel")

    def test_template_test_send_action(self):
        template = NotificationTemplate.objects.create(
            event="ping", title_template="Ping {{ user.username }}"
        )
        response = self.client.post(
            "/admin/django_notifications/notificationtemplate/",
            {"action": "send_test", "_selected_action": [template.pk]},
            follow=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(
            Notification.objects.filter(title="Ping root").exists()
        )


class CommandTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser("root", "r@e.com", "x")

    def test_demo_seeds_notifications(self):
        out = StringIO()
        call_command("notifications_demo", "--count", "5", stdout=out)
        self.assertEqual(Notification.objects.count(), 5)
        self.assertIn("Created 5", out.getvalue())

    def test_send_scheduled_command(self):
        notify.schedule(
            user=self.user, title="Due", at=timezone.now() - dt.timedelta(minutes=1)
        )
        out = StringIO()
        call_command("notifications_send_scheduled", stdout=out)
        self.assertIn("scheduled=1", out.getvalue())
        self.assertIsNotNone(Notification.objects.get().sent_at)

    def test_cleanup_command(self):
        stale = notify.info(user=self.user, title="Old read")
        Notification.objects.filter(pk=stale.pk).update(
            read_at=timezone.now() - dt.timedelta(days=40)
        )
        expired = notify.info(user=self.user, title="Expired", ttl=1)
        Notification.objects.filter(pk=expired.pk).update(
            expires_at=timezone.now() - dt.timedelta(seconds=5)
        )
        out = StringIO()
        call_command("notifications_cleanup", "--read-after-days", "30", stdout=out)
        self.assertEqual(Notification.objects.count(), 0)
        self.assertIn("'expired': 1", out.getvalue())
