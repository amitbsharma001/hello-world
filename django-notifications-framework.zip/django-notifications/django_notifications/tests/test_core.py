"""Core engine tests: facade, recipients, dispatch, preferences, scheduling."""

from __future__ import annotations

import datetime as dt

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.core import mail
from django.test import TestCase, override_settings
from django.utils import timezone

from django_notifications import notify
from django_notifications.exceptions import (
    EventNotRegisteredError,
    NoRecipientsError,
    RateLimitedError,
    UnknownChannelError,
    ValidationError,
)
from django_notifications.models import (
    Delivery,
    Notification,
    NotificationPreference,
    NotificationTemplate,
)
from django_notifications.services import BulkResult, service
from django_notifications.tests.channels import SENT

User = get_user_model()

RECORDER = "django_notifications.tests.channels.RecorderChannel"
SKIPPER = "django_notifications.tests.channels.SkippingChannel"
FLAKY = "django_notifications.tests.channels.FlakyChannel"
BROKEN = "django_notifications.tests.channels.BrokenChannel"


def dj_settings(**overrides):
    base = {"USE_CELERY": False}
    base.update(overrides)
    return override_settings(DJANGO_NOTIFICATIONS=base)


class FacadeTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "amit@example.com", "x")

    def test_success_creates_notification_with_preset(self):
        notification = notify.success(
            user=self.user, title="Profile updated", message="Saved."
        )
        self.assertIsInstance(notification, Notification)
        self.assertEqual(notification.type, "success")
        self.assertEqual(notification.level, "success")
        self.assertEqual(notification.icon, "check-circle")
        self.assertIsNotNone(notification.sent_at)
        self.assertEqual(notification.recipient, self.user)

    def test_dynamic_custom_type(self):
        notification = notify.shipment_delayed(user=self.user, title="Delayed")
        self.assertEqual(notification.type, "shipment_delayed")
        self.assertEqual(notification.level, "info")

    def test_title_required(self):
        with self.assertRaises(ValidationError):
            notify.info(user=self.user)

    def test_no_recipients_raises(self):
        with self.assertRaises(NoRecipientsError):
            notify.info(title="Orphan")

    def test_unknown_channel_fails_fast(self):
        with self.assertRaises(UnknownChannelError):
            notify.info(user=self.user, title="X", channels=["carrier_pigeon"])

    def test_system_defaults_to_staff(self):
        staff = User.objects.create_user("ops", "ops@example.com", "x", is_staff=True)
        User.objects.create_user("plain", "p@example.com", "x")
        result = notify.system(title="Nightly backup", message="Backup completed.")
        self.assertIsInstance(result, BulkResult)
        self.assertEqual(result.created, 1)
        self.assertEqual(Notification.objects.get().recipient, staff)

    def test_announcement_defaults_to_everyone(self):
        User.objects.create_user("second", "s@example.com", "x")
        result = notify.announcement(title="Maintenance window tonight")
        self.assertEqual(result.created, User.objects.filter(is_active=True).count())

    def test_security_ignores_user_mute_for_in_app(self):
        NotificationPreference.objects.create(user=self.user, enabled=False)
        notify.security(user=self.user, title="New login detected")
        deliveries = Delivery.objects.filter(notification__recipient=self.user)
        self.assertEqual(
            set(deliveries.values_list("channel", flat=True)), {"in_app", "websocket"}
        )

    def test_bulk_returns_bulkresult_with_ids(self):
        users = [
            User.objects.create_user(f"u{i}", f"u{i}@example.com", "x")
            for i in range(3)
        ]
        result = notify.bulk(users=User.objects.filter(pk__in=[u.pk for u in users]),
                             title="Deployment complete")
        self.assertEqual(result.created, 3)
        self.assertEqual(len(result.ids), 3)
        self.assertTrue(result)

    def test_actor_and_target_stored(self):
        actor = User.objects.create_user("actor", "a@e.com", "x")
        notification = notify.mention(
            user=self.user, title="You were mentioned", actor=actor, target=self.user
        )
        self.assertEqual(notification.actor, actor)
        self.assertEqual(notification.target, self.user)


class RecipientResolutionTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.users = [
            User.objects.create_user(f"user{i}", f"user{i}@example.com", "x")
            for i in range(5)
        ]
        cls.group = Group.objects.create(name="engineers")
        cls.group.user_set.add(cls.users[0], cls.users[1])

    def test_user_ids_and_dedup(self):
        result = notify.info(
            user=self.users[0],
            user_ids=[self.users[0].pk, self.users[1].pk],
            title="Hi",
        )
        self.assertEqual(result.created, 2)

    def test_group_by_name(self):
        result = notify.info(group="engineers", title="Group message")
        self.assertEqual(result.created, 2)

    def test_permission_recipients(self):
        permission = Permission.objects.get(codename="view_notification")
        self.users[2].user_permissions.add(permission)
        result = notify.info(permission="django_notifications.view_notification",
                             title="For viewers")
        recipients = set(
            Notification.objects.values_list("recipient__username", flat=True)
        )
        self.assertIn("user2", recipients)
        self.assertGreaterEqual(result.created, 1)

    def test_everyone(self):
        result = notify.info(everyone=True, title="All hands")
        self.assertEqual(result.created, User.objects.filter(is_active=True).count())

    @dj_settings(FANOUT_CHUNK=2)
    def test_chunking_preserves_total(self):
        result = notify.info(
            users=User.objects.all().order_by("pk"), title="Chunked"
        )
        self.assertEqual(result.created, 5)

    def test_callable_recipients(self):
        result = notify.info(
            recipients=lambda: User.objects.filter(username="user3"), title="Call me"
        )
        self.assertEqual(result.created, 1)


@dj_settings(CHANNELS={"recorder": RECORDER, "skipper": SKIPPER,
                       "flaky": FLAKY, "broken": BROKEN},
             DEFAULT_CHANNELS=["in_app", "recorder"])
class DeliveryTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "amit@example.com", "x")

    def setUp(self):
        SENT.clear()

    def test_sync_delivery_records_sent(self):
        notification = notify.success(user=self.user, title="Done")
        self.assertEqual(SENT, [(notification.pk, "Done")])
        statuses = dict(
            notification.deliveries.values_list("channel", "status")
        )
        self.assertEqual(statuses, {"in_app": "sent", "recorder": "sent"})

    def test_skipped_status(self):
        notification = notify.info(
            user=self.user, title="X", channels=["skipper"]
        )
        self.assertEqual(notification.deliveries.get().status, "skipped")

    def test_retryable_failure_marks_failed_in_sync_mode(self):
        notification = notify.info(user=self.user, title="X", channels=["flaky"])
        delivery = notification.deliveries.get()
        self.assertEqual(delivery.status, "failed")
        self.assertIn("temporary outage", delivery.last_error)
        self.assertEqual(delivery.attempts, 1)

    def test_permanent_failure(self):
        notification = notify.info(user=self.user, title="X", channels=["broken"])
        self.assertEqual(notification.deliveries.get().status, "failed")

    def test_requeue_and_retry_succeeds_when_fixed(self):
        notification = notify.info(user=self.user, title="X", channels=["flaky"])
        Delivery.objects.requeue()
        with dj_settings(CHANNELS={"flaky": RECORDER}):  # "fix" the channel
            sent, _ = service.execute_deliveries(
                notification, list(notification.deliveries.pending()),
                allow_retry=False,
            )
        self.assertEqual(sent, 1)
        self.assertEqual(notification.deliveries.get().status, "sent")

    def test_type_channel_routing(self):
        with dj_settings(CHANNELS={"recorder": RECORDER, "skipper": SKIPPER},
                         DEFAULT_CHANNELS=["recorder"],
                         TYPE_CHANNELS={"order": ["skipper"]}):
            notification = notify.order(user=self.user, title="Order placed")
        self.assertEqual(
            list(notification.deliveries.values_list("channel", flat=True)),
            ["skipper"],
        )


class PreferenceTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "amit@example.com", "x")

    @dj_settings(CHANNELS={"recorder": RECORDER}, DEFAULT_CHANNELS=["in_app", "recorder"])
    def test_channel_opt_out_skips_channel(self):
        NotificationPreference.objects.create(
            user=self.user, channel_settings={"recorder": False}
        )
        SENT.clear()
        notification = notify.info(user=self.user, title="Quiet")
        self.assertEqual(SENT, [])
        self.assertEqual(
            list(notification.deliveries.values_list("channel", flat=True)), ["in_app"]
        )

    def test_muted_category_drops_all_non_mandatory(self):
        NotificationPreference.objects.create(
            user=self.user, muted_categories=["orders"]
        )
        notification = notify.order(user=self.user, title="Order shipped")
        self.assertEqual(notification.deliveries.count(), 0)

    @dj_settings(DEFAULT_CHANNELS=["in_app", "email"])
    def test_quiet_hours_defer_email(self):
        now_local = timezone.localtime()
        NotificationPreference.objects.create(
            user=self.user,
            quiet_hours_start=(now_local - dt.timedelta(hours=1)).time(),
            quiet_hours_end=(now_local + dt.timedelta(hours=1)).time(),
        )
        notification = notify.info(user=self.user, title="Later please")
        email_delivery = notification.deliveries.get(channel="email")
        self.assertEqual(email_delivery.status, "deferred")
        self.assertIsNotNone(email_delivery.deliver_after)
        self.assertEqual(len(mail.outbox), 0)
        in_app = notification.deliveries.get(channel="in_app")
        self.assertEqual(in_app.status, "sent")

    @dj_settings(DEFAULT_CHANNELS=["in_app", "email"])
    def test_deferred_delivery_sent_after_quiet_hours(self):
        now_local = timezone.localtime()
        pref = NotificationPreference.objects.create(
            user=self.user,
            quiet_hours_start=(now_local - dt.timedelta(hours=1)).time(),
            quiet_hours_end=(now_local + dt.timedelta(hours=1)).time(),
        )
        notification = notify.info(user=self.user, title="Deferred email")
        deferred = notification.deliveries.get(channel="email")
        self.assertEqual(deferred.status, "deferred")
        # Quiet hours "end": make the deferral due and run the scheduler.
        deferred.deliver_after = timezone.now() - dt.timedelta(minutes=1)
        deferred.save(update_fields=["deliver_after"])
        pref.delete()
        stats = service.dispatch_due()
        self.assertEqual(stats["deferred_sent"], 1)
        deferred.refresh_from_db()
        self.assertEqual(deferred.status, "sent")
        self.assertEqual(len(mail.outbox), 1)

    def test_master_switch_off_blocks_normal_types(self):
        NotificationPreference.objects.create(user=self.user, enabled=False)
        notification = notify.info(user=self.user, title="Blocked")
        self.assertEqual(notification.deliveries.count(), 0)


@dj_settings(DEFAULT_CHANNELS=["in_app", "email"])
class EmailChannelTests(TestCase):
    def test_email_rendered_and_sent(self):
        user = User.objects.create_user("amit", "amit@example.com", "x")
        notify.success(
            user=user, title="Report ready", message="Your report is ready.",
            url="/reports/7/",
        )
        self.assertEqual(len(mail.outbox), 1)
        email = mail.outbox[0]
        self.assertEqual(email.subject, "Report ready")
        self.assertIn("Your report is ready.", email.body)
        self.assertIn("https://example.com/reports/7/", email.body)
        self.assertEqual(email.alternatives[0][1], "text/html")

    def test_missing_address_skips(self):
        user = User.objects.create_user("noemail", "", "x")
        notification = notify.info(user=user, title="Hi")
        self.assertEqual(notification.deliveries.get(channel="email").status, "skipped")
        self.assertEqual(len(mail.outbox), 0)


class SchedulingTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "amit@example.com", "x")

    def test_future_notification_not_dispatched(self):
        notification = notify.schedule(
            user=self.user, title="Stand-up", delay=3600
        )
        self.assertIsNone(notification.sent_at)
        self.assertEqual(notification.deliveries.count(), 0)
        self.assertEqual(Notification.objects.for_user(self.user).visible().count(), 0)

    def test_dispatch_due_sends_and_recurs(self):
        notification = notify.schedule(
            user=self.user,
            title="Daily digest",
            at=timezone.now() - dt.timedelta(minutes=1),
            every=dt.timedelta(days=1),
        )
        stats = service.dispatch_due()
        self.assertEqual(stats["scheduled_sent"], 1)
        self.assertEqual(stats["recurred"], 1)
        notification.refresh_from_db()
        self.assertIsNotNone(notification.sent_at)
        clone = Notification.objects.exclude(pk=notification.pk).get()
        self.assertIsNone(clone.sent_at)
        self.assertEqual(
            clone.scheduled_for, notification.scheduled_for + dt.timedelta(days=1)
        )

    def test_repeat_until_respected(self):
        notify.schedule(
            user=self.user,
            title="Short series",
            at=timezone.now() - dt.timedelta(minutes=1),
            every=dt.timedelta(days=1),
            until=timezone.now(),  # next occurrence would exceed this
        )
        service.dispatch_due()
        self.assertEqual(Notification.objects.count(), 1)

    def test_recurring_requires_schedule(self):
        with self.assertRaises(ValidationError):
            notify.send(user=self.user, title="X", repeat_interval=60)

    def test_ttl_sets_expiry_and_hides(self):
        notification = notify.info(user=self.user, title="Ephemeral", ttl=1)
        self.assertIsNotNone(notification.expires_at)
        Notification.objects.filter(pk=notification.pk).update(
            expires_at=timezone.now() - dt.timedelta(seconds=1)
        )
        self.assertEqual(Notification.objects.for_user(self.user).visible().count(), 0)
        self.assertEqual(Notification.objects.prune_expired(), 1)


class EventTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(
            "amit", "amit@example.com", "x", first_name="Amit"
        )

    def test_code_registered_event(self):
        notify.register_event(
            "order.created",
            title="Order #{{ order.id }} placed",
            message="Thanks {{ user.first_name }}!",
            url="/orders/{{ order.id }}/",
            type="order",
        )
        try:
            notification = notify.event(
                "order.created",
                user=self.user,
                context={"order": {"id": 42}},
            )
        finally:
            from django_notifications import events

            events.unregister("order.created")
        self.assertEqual(notification.title, "Order #42 placed")
        self.assertEqual(notification.message, "Thanks Amit!")
        self.assertEqual(notification.url, "/orders/42/")
        self.assertEqual(notification.type, "order")
        self.assertEqual(notification.event, "order.created")

    def test_db_template_overrides_code(self):
        notify.register_event("invoice.paid", title="from code")
        NotificationTemplate.objects.create(
            event="invoice.paid",
            title_template="Invoice {{ invoice }} paid",
            type="payment",
        )
        try:
            notification = notify.event(
                "invoice.paid", user=self.user, context={"invoice": "INV-9"}
            )
        finally:
            from django_notifications import events

            events.unregister("invoice.paid")
        self.assertEqual(notification.title, "Invoice INV-9 paid")
        self.assertEqual(notification.type, "payment")

    def test_unregistered_event_strict(self):
        with self.assertRaises(EventNotRegisteredError):
            notify.event("nope.never", user=self.user)

    def test_unregistered_event_lenient_uses_kwargs(self):
        notification = notify.event(
            "nope.never", user=self.user, strict=False, title="Fallback title"
        )
        self.assertEqual(notification.title, "Fallback title")


class RateLimitTests(TestCase):
    @dj_settings(RATE_LIMIT="2/m")
    def test_rate_limit_enforced_per_request_user(self):
        user = User.objects.create_user("amit", "a@e.com", "x")

        class FakeRequest:
            pass

        request = FakeRequest()
        request.user = user
        notify.info(user=user, title="1", request=request)
        notify.info(user=user, title="2", request=request)
        with self.assertRaises(RateLimitedError):
            notify.info(user=user, title="3", request=request)


class StateHelperTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user("amit", "a@e.com", "x")
        cls.other = User.objects.create_user("other", "o@e.com", "x")

    def test_mark_read_scoped_to_user(self):
        mine = notify.info(user=self.user, title="Mine")
        theirs = notify.info(user=self.other, title="Theirs")
        count = service.mark_read(self.user, ids=[mine.pk, theirs.pk])
        self.assertEqual(count, 1)
        theirs.refresh_from_db()
        self.assertFalse(theirs.is_read)

    def test_mark_all_read_and_unread_count(self):
        for i in range(3):
            notify.info(user=self.user, title=f"N{i}")
        self.assertEqual(Notification.objects.unread_count(self.user), 3)
        service.mark_read(self.user, everything=True)
        self.assertEqual(Notification.objects.unread_count(self.user), 0)

    def test_archive_and_delete(self):
        first = notify.info(user=self.user, title="A")
        notify.info(user=self.user, title="B")
        self.assertEqual(service.archive(self.user, ids=[first.pk]), 1)
        self.assertEqual(
            Notification.objects.for_user(self.user).visible().count(), 1
        )
        self.assertEqual(service.delete(self.user, everything=True), 2)
        self.assertEqual(Notification.objects.count(), 0)
