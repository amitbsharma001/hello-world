"""Prune expired and aged-out notifications.

Retention for read/archived rows comes from ``CLEANUP`` settings; ``--expired``
alone removes only TTL-expired rows. Safe to run from cron or Celery beat.
"""

from __future__ import annotations

from django.core.management.base import BaseCommand
from django.utils import timezone


def run_cleanup(
    expired: bool = True,
    read_after_days: int | None = None,
    archived_after_days: int | None = None,
) -> dict[str, int]:
    from django_notifications.models import Notification
    from django_notifications.settings import app_settings

    read_after_days = read_after_days or app_settings.CLEANUP["READ_AFTER_DAYS"]
    archived_after_days = (
        archived_after_days or app_settings.CLEANUP["ARCHIVED_AFTER_DAYS"]
    )
    stats = {"expired": 0, "read": 0, "archived": 0}
    if expired:
        stats["expired"] = Notification.objects.prune_expired()
    now = timezone.now()
    if read_after_days:
        cutoff = now - timezone.timedelta(days=read_after_days)
        _, per_model = Notification.objects.filter(read_at__lt=cutoff).delete()
        stats["read"] = per_model.get("django_notifications.Notification", 0)
    if archived_after_days:
        cutoff = now - timezone.timedelta(days=archived_after_days)
        _, per_model = Notification.objects.filter(
            archived_at__lt=cutoff
        ).delete()
        stats["archived"] = per_model.get("django_notifications.Notification", 0)
    return stats


class Command(BaseCommand):
    help = "Delete expired notifications and apply retention policies."

    def add_arguments(self, parser) -> None:
        parser.add_argument("--read-after-days", type=int, default=None)
        parser.add_argument("--archived-after-days", type=int, default=None)
        parser.add_argument("--no-expired", action="store_true")

    def handle(self, *args, **options) -> None:
        stats = run_cleanup(
            expired=not options["no_expired"],
            read_after_days=options["read_after_days"],
            archived_after_days=options["archived_after_days"],
        )
        self.stdout.write(self.style.SUCCESS(f"Cleanup done: {stats}"))
