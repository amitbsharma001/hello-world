"""Seed demo notifications — handy right after installing the package."""

from __future__ import annotations

import random

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError

SAMPLES = [
    ("success", "Report ready", "Your quarterly report finished rendering."),
    ("info", "New comment", "Priya commented on your integration runbook."),
    ("warning", "Certificate expiring", "TLS cert for api.internal expires in 12 days."),
    ("error", "Build failed", "Pipeline #482 failed at the test stage."),
    ("security", "New sign-in", "New sign-in to your account from Chrome on Windows."),
    ("order", "Order shipped", "Order #10233 left the warehouse."),
    ("mention", "You were mentioned", "Rahul mentioned you in 'Broker migration'."),
    ("reminder", "Stand-up in 15 minutes", "Daily sync starts at 09:30."),
]


class Command(BaseCommand):
    help = "Create sample notifications for a user (default: first superuser)."

    def add_arguments(self, parser) -> None:
        parser.add_argument("--user", type=str, default=None, help="Username.")
        parser.add_argument("--count", type=int, default=12)

    def handle(self, *args, **options) -> None:
        from django_notifications import notify

        User = get_user_model()
        if options["user"]:
            user = User.objects.filter(**{User.USERNAME_FIELD: options["user"]}).first()
        else:
            user = User.objects.filter(is_superuser=True).first()
        if user is None:
            raise CommandError("No matching user found. Pass --user <username>.")
        for _ in range(options["count"]):
            type_, title, message = random.choice(SAMPLES)
            notify.send(
                user=user,
                type=type_,
                title=title,
                message=message,
                url="#",
                source="notifications_demo",
                sync=True,
            )
        self.stdout.write(
            self.style.SUCCESS(f"Created {options['count']} notifications for {user}.")
        )
