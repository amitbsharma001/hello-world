"""Send due scheduled notifications and deferred deliveries.

Run from cron every minute, or use ``--forever`` as a lightweight daemon
when you don't run Celery beat::

    * * * * * manage.py notifications_send_scheduled
    manage.py notifications_send_scheduled --forever --interval 30
"""

from __future__ import annotations

import time

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Dispatch due scheduled notifications and deferred deliveries."

    def add_arguments(self, parser) -> None:
        parser.add_argument("--limit", type=int, default=500)
        parser.add_argument("--forever", action="store_true")
        parser.add_argument("--interval", type=int, default=60, help="Seconds between runs.")

    def handle(self, *args, **options) -> None:
        from django_notifications.services import service

        while True:
            stats = service.dispatch_due(limit=options["limit"])
            self.stdout.write(
                f"scheduled={stats['scheduled_sent']} "
                f"deferred={stats['deferred_sent']} recurred={stats['recurred']}"
            )
            if not options["forever"]:
                break
            time.sleep(options["interval"])
