"""QuerySets and managers.

Bulk state transitions (:meth:`mark_read`, :meth:`archive`, ...) are single
``UPDATE`` statements so they stay O(1) queries regardless of row count.
"""

from __future__ import annotations

from django.db import models
from django.utils import timezone

from .constants import DeliveryStatus


class NotificationQuerySet(models.QuerySet):
    """Chainable filters used throughout the services, API and frontend."""

    # -- filtering ----------------------------------------------------------

    def for_user(self, user) -> NotificationQuerySet:
        return self.filter(recipient=user)

    def unread(self) -> NotificationQuerySet:
        return self.filter(read_at__isnull=True)

    def read(self) -> NotificationQuerySet:
        return self.filter(read_at__isnull=False)

    def archived(self) -> NotificationQuerySet:
        return self.filter(archived_at__isnull=False)

    def unarchived(self) -> NotificationQuerySet:
        return self.filter(archived_at__isnull=True)

    def pinned(self) -> NotificationQuerySet:
        return self.filter(pinned=True)

    def unexpired(self) -> NotificationQuerySet:
        now = timezone.now()
        return self.filter(models.Q(expires_at__isnull=True) | models.Q(expires_at__gt=now))

    def expired(self) -> NotificationQuerySet:
        return self.filter(expires_at__isnull=False, expires_at__lte=timezone.now())

    def visible(self) -> NotificationQuerySet:
        """Inbox filter: dispatched, unarchived, unexpired."""
        return self.unarchived().unexpired().filter(sent_at__isnull=False)

    #: Alias kept for readability at call sites.
    active = visible

    def since(self, notification_id: int) -> NotificationQuerySet:
        return self.filter(pk__gt=notification_id)

    def due(self) -> NotificationQuerySet:
        """Scheduled notifications whose time has come and are unsent."""
        return self.filter(
            scheduled_for__isnull=False,
            scheduled_for__lte=timezone.now(),
            sent_at__isnull=True,
        )

    def search(self, term: str) -> NotificationQuerySet:
        term = (term or "").strip()
        if not term:
            return self
        return self.filter(
            models.Q(title__icontains=term)
            | models.Q(message__icontains=term)
            | models.Q(category__icontains=term)
        )

    # -- bulk transitions ---------------------------------------------------

    def mark_read(self) -> int:
        return self.unread().update(read_at=timezone.now(), updated_at=timezone.now())

    def mark_unread(self) -> int:
        return self.read().update(read_at=None, updated_at=timezone.now())

    def archive(self) -> int:
        return self.unarchived().update(archived_at=timezone.now(), updated_at=timezone.now())

    def unarchive(self) -> int:
        return self.archived().update(archived_at=None, updated_at=timezone.now())

    def prune_expired(self) -> int:
        _, per_model = self.expired().delete()
        return per_model.get("django_notifications.Notification", 0)


class NotificationManager(models.Manager.from_queryset(NotificationQuerySet)):
    """Default manager; adds convenience entry points."""

    def unread_count(self, user) -> int:
        return self.for_user(user).visible().unread().count()


class DeliveryQuerySet(models.QuerySet):
    def pending(self) -> DeliveryQuerySet:
        return self.filter(status=DeliveryStatus.PENDING)

    def failed(self) -> DeliveryQuerySet:
        return self.filter(status=DeliveryStatus.FAILED)

    def deferred_due(self) -> DeliveryQuerySet:
        return self.filter(
            status=DeliveryStatus.DEFERRED,
            deliver_after__isnull=False,
            deliver_after__lte=timezone.now(),
        )

    def requeue(self) -> int:
        """Reset failed deliveries to pending (admin 'retry' action)."""
        return self.failed().update(
            status=DeliveryStatus.PENDING, last_error="", updated_at=timezone.now()
        )


DeliveryManager = models.Manager.from_queryset(DeliveryQuerySet)
