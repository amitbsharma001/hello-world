"""DRF serializers."""

from __future__ import annotations

from typing import Any

from rest_framework import serializers

from .models import Notification, NotificationPreference


class NotificationSerializer(serializers.ModelSerializer):
    """Read serializer used by the API, WebSocket pushes and the widget."""

    is_read = serializers.BooleanField(read_only=True)
    is_archived = serializers.BooleanField(read_only=True)
    actor_display = serializers.SerializerMethodField()
    target_display = serializers.SerializerMethodField()

    class Meta:
        model = Notification
        fields = [
            "id",
            "type",
            "level",
            "category",
            "priority",
            "thread_key",
            "event",
            "title",
            "message",
            "body_html",
            "content_format",
            "icon",
            "image",
            "url",
            "actions",
            "attachments",
            "data",
            "pinned",
            "is_read",
            "is_archived",
            "read_at",
            "archived_at",
            "created_at",
            "actor_display",
            "target_display",
        ]
        read_only_fields = fields

    def get_actor_display(self, obj: Notification) -> str | None:
        return str(obj.actor) if obj.actor_object_id else None

    def get_target_display(self, obj: Notification) -> str | None:
        return str(obj.target) if obj.target_object_id else None


class NotificationCreateSerializer(serializers.Serializer):
    """Write serializer for POST /notifications/ (self or privileged)."""

    recipient = serializers.IntegerField(required=False, allow_null=True)
    type = serializers.CharField(default="info", max_length=64)
    title = serializers.CharField(max_length=255)
    message = serializers.CharField(required=False, allow_blank=True, default="")
    body_html = serializers.CharField(required=False, allow_blank=True, default="")
    category = serializers.CharField(required=False, allow_blank=True, default=None)
    url = serializers.CharField(required=False, allow_blank=True, default="")
    icon = serializers.CharField(required=False, allow_blank=True, default=None)
    data = serializers.JSONField(required=False, default=dict)
    actions = serializers.JSONField(required=False, default=list)
    channels = serializers.ListField(
        child=serializers.CharField(max_length=32), required=False, default=None
    )

    def create(self, validated: dict[str, Any]) -> Notification:
        from .services import service

        request = self.context.get("request")
        recipient_id = validated.pop("recipient", None) or request.user.pk
        result = service.send(user_id=recipient_id, request=request, **validated)
        return result  # single user_id → Notification instance


class BroadcastSerializer(serializers.Serializer):
    """Write serializer for POST /broadcast/ — send to whole groups.

    Accepts group **ids** (unambiguous; the picker lists id + name) and
    fans out to every active member of the selected groups. One
    notification row is created per user by the service layer.
    """

    LEVELS = ["debug", "info", "success", "warning", "error", "critical"]

    title = serializers.CharField(max_length=255)
    message = serializers.CharField(required=False, allow_blank=True, default="")
    body_html = serializers.CharField(required=False, allow_blank=True, default="")
    url = serializers.CharField(required=False, allow_blank=True, default="")
    level = serializers.ChoiceField(choices=LEVELS, required=False, default="info")
    type = serializers.CharField(required=False, default="announcement", max_length=64)
    groups = serializers.ListField(
        child=serializers.IntegerField(),
        allow_empty=False,
        help_text="Group ids; every active member receives the notification.",
    )

    def validate_groups(self, value: list[int]) -> list:
        from django.contrib.auth.models import Group

        groups = list(Group.objects.filter(pk__in=value))
        if not groups:
            raise serializers.ValidationError("No matching groups.")
        return groups

    def create(self, validated: dict[str, Any]) -> dict[str, Any]:
        from .services import BulkResult, service

        request = self.context.get("request")
        groups = validated["groups"]
        result = service.send(
            groups=groups,
            type=validated["type"],
            level=validated["level"],
            title=validated["title"],
            message=validated["message"],
            body_html=validated["body_html"],
            url=validated["url"],
            actor=getattr(request, "user", None),
            source="broadcast",
            request=request,
        )
        created = result.created if isinstance(result, BulkResult) else 1
        return {
            "created": created,
            "queued": getattr(result, "queued", False),
            "groups": [{"id": g.pk, "name": g.name} for g in groups],
        }


class PreferenceSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationPreference
        fields = [
            "enabled",
            "channel_settings",
            "muted_categories",
            "muted_types",
            "quiet_hours_start",
            "quiet_hours_end",
            "timezone",
            "language",
            "digest",
            "digest_hour",
        ]
