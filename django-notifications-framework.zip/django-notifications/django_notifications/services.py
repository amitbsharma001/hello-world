"""Service layer — the engine behind the ``notify`` facade.

Responsibilities
----------------
* Resolve recipients (chunked, memory-safe for millions of users).
* Apply type presets, sanitize rich content, validate payloads.
* Persist notifications with ``bulk_create``.
* Enforce per-user preferences (channel opt-outs, mutes, quiet hours).
* Create per-channel :class:`~django_notifications.models.Delivery` records
  and execute them — via Celery when available, synchronously otherwise.
* Dispatch scheduled/recurring notifications and deferred deliveries.

Import :data:`service` (module singleton) or use the ``notify`` facade.
"""

from __future__ import annotations

import datetime as dt
import logging
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from django.contrib.contenttypes.models import ContentType
from django.core.cache import cache
from django.db import transaction
from django.utils import timezone

from . import repository
from .constants import TYPE_PRESETS
from .exceptions import (
    ConfigurationError,
    DeliveryError,
    RateLimitedError,
    RetryableDeliveryError,
    ValidationError,
)
from .models import Delivery, Notification, NotificationPreference
from .settings import app_settings
from .signals import (
    delivery_failed,
    delivery_sent,
    notification_created,
    notification_read,
)
from .validators import validate_actions, validate_attachments
from .websocket import push_counts

logger = logging.getLogger(app_settings.LOGGER)

_RATE_RE = re.compile(r"^(\d+)/([smhd])$")
_RATE_WINDOWS = {"s": 1, "m": 60, "h": 3600, "d": 86400}
_MAX_RESULT_IDS = 1000


@dataclass
class BulkResult:
    """Return value of multi-recipient sends."""

    created: int = 0
    ids: list[int] = field(default_factory=list)
    truncated: bool = False
    queued: bool = False  # True when creation itself was offloaded to Celery

    def __bool__(self) -> bool:
        return self.queued or self.created > 0


# --------------------------------------------------------------------------
# Celery detection
# --------------------------------------------------------------------------

def celery_available() -> bool:
    """Whether async delivery should be used, honouring ``USE_CELERY``."""
    mode = app_settings.USE_CELERY
    if mode is False:
        return False
    try:
        from celery import current_app
    except ImportError:
        if mode is True:
            raise ConfigurationError(
                "USE_CELERY=True but 'celery' is not installed."
            ) from None
        return False
    if mode is True:
        return True
    # "auto": require an explicitly configured broker.
    from django.conf import settings as django_settings

    broker = current_app.conf.get("broker_url") or getattr(
        django_settings, "CELERY_BROKER_URL", None
    )
    return bool(broker)


def _safe_delay(task_name: str, *args: Any) -> bool:
    """Queue a package task; return False (→ sync fallback) on broker errors."""
    try:
        from . import celery_tasks

        task = getattr(celery_tasks, task_name)
        if task is None:
            return False
        options: dict[str, Any] = {}
        if app_settings.CELERY_QUEUE:
            options["queue"] = app_settings.CELERY_QUEUE
        task.apply_async(args=args, **options)
        return True
    except Exception as exc:  # broker down, task not registered, ...
        logger.warning(
            "Celery enqueue failed (%s); falling back to synchronous delivery.", exc
        )
        return False


# --------------------------------------------------------------------------
# Service
# --------------------------------------------------------------------------

class NotificationService:
    """Stateless orchestrator; safe to share (module singleton below)."""

    # ------------------------------------------------------------- sending

    def send(
        self,
        *,
        # recipients
        user: Any = None,
        user_id: int | None = None,
        users: Any = None,
        user_ids: Iterable[int] | None = None,
        group: Any = None,
        groups: Iterable[Any] | None = None,
        permission: str | None = None,
        everyone: bool = False,
        recipients: Any = None,
        # classification
        type: str = "info",
        level: str | None = None,
        category: str | None = None,
        priority: int | None = None,
        thread_key: str = "",
        source: str = "",
        event: str = "",
        # content
        title: str = "",
        message: str = "",
        body_html: str = "",
        content_format: str | None = None,
        icon: str | None = None,
        image: str = "",
        url: str = "",
        actions: list[dict] | None = None,
        attachments: list[dict] | None = None,
        data: dict | None = None,
        actor: Any = None,
        target: Any = None,
        # routing / lifecycle
        channels: list[str] | None = None,
        scheduled_for: dt.datetime | None = None,
        delay: int | dt.timedelta | None = None,
        expires_at: dt.datetime | None = None,
        ttl: int | dt.timedelta | None = None,
        repeat_interval: int | dt.timedelta | None = None,
        repeat_until: dt.datetime | None = None,
        # infrastructure
        request: Any = None,
        enqueue: bool = False,
        sync: bool | None = None,
    ) -> Notification | BulkResult:
        """Create and dispatch notification(s). See ``notify`` for usage.

        Returns the :class:`Notification` when exactly one recipient was
        addressed directly (``user``/``user_id``), otherwise a
        :class:`BulkResult`.
        """
        self._check_rate_limit(request)

        # -- defaults from type presets -----------------------------------
        preset = TYPE_PRESETS.get(type, {})
        level = level or preset.get("level", "info")
        icon = icon if icon is not None else preset.get("icon", "")
        category = category if category is not None else preset.get("category", "")
        priority = priority if priority is not None else 20

        # -- default recipients for operational types ----------------------
        no_recipients = not any(
            (user, user_id, users, user_ids, group, groups, permission, everyone, recipients)
        )
        if no_recipients:
            if type in ("system", "maintenance"):
                users = repository.system_recipients()
            elif type == "announcement":
                everyone = True

        # -- schedule / expiry math ------------------------------------------
        now = timezone.now()
        if delay is not None:
            if scheduled_for is not None:
                raise ValidationError("Pass either 'delay' or 'scheduled_for'.")
            delay = dt.timedelta(seconds=delay) if isinstance(delay, (int, float)) else delay
            scheduled_for = now + delay
        if ttl is not None:
            ttl = dt.timedelta(seconds=ttl) if isinstance(ttl, (int, float)) else ttl
            expires_at = (scheduled_for or now) + ttl
        elif expires_at is None and app_settings.DEFAULT_TTL:
            default_ttl = app_settings.DEFAULT_TTL
            if isinstance(default_ttl, (int, float)):
                default_ttl = dt.timedelta(seconds=default_ttl)
            expires_at = (scheduled_for or now) + default_ttl
        if isinstance(repeat_interval, (int, float)):
            repeat_interval = dt.timedelta(seconds=repeat_interval)
        if repeat_interval and not scheduled_for:
            raise ValidationError(
                "Recurring notifications need 'scheduled_for' or 'delay' for "
                "the first occurrence."
            )

        # -- content validation ------------------------------------------------
        if not title:
            raise ValidationError("'title' is required.")
        if body_html:
            sanitizer = app_settings.resolve("SANITIZER")
            body_html = sanitizer(
                body_html,
                allowed_tags=app_settings.ALLOWED_TAGS,
                allowed_attributes=app_settings.ALLOWED_ATTRIBUTES,
            )
        actions = validate_actions(actions)
        attachments = validate_attachments(attachments)

        # -- channel validation (fail fast on typos) ---------------------------
        channels = list(channels) if channels else []
        for key in channels or self._resolve_channels(type):
            app_settings.channel_backend(key)

        payload: dict[str, Any] = {
            "type": type,
            "level": level,
            "category": category or "",
            "priority": priority,
            "thread_key": thread_key,
            "source": source,
            "event": event,
            "title": title[:255],
            "message": message,
            "body_html": body_html,
            "content_format": content_format or "plain",
            "icon": icon or "",
            "image": image,
            "url": url,
            "actions": actions,
            "attachments": attachments,
            "data": data or {},
            "channels": channels,
            "scheduled_for": scheduled_for,
            "expires_at": expires_at,
            "repeat_interval": repeat_interval,
            "repeat_until": repeat_until,
        }
        if actor is not None:
            payload["actor_content_type"] = ContentType.objects.get_for_model(actor)
            payload["actor_object_id"] = str(actor.pk)
        if target is not None:
            payload["target_content_type"] = ContentType.objects.get_for_model(target)
            payload["target_object_id"] = str(target.pk)

        recipient_spec = {
            "user": user,
            "user_id": user_id,
            "users": users,
            "user_ids": user_ids,
            "group": group,
            "groups": groups,
            "permission": permission,
            "everyone": everyone,
            "recipients": recipients,
        }
        single = (user is not None or user_id is not None) and not any(
            v for k, v in recipient_spec.items() if k not in ("user", "user_id")
        )

        use_celery = celery_available() if sync is None else not sync

        # -- optionally offload creation itself (huge broadcasts) --------------
        if enqueue and use_celery:
            queued = self._enqueue_fanout(recipient_spec, payload)
            if queued is not None:
                return queued

        # -- chunked create + dispatch --------------------------------------------
        result = BulkResult()
        first: Notification | None = None
        # Explicitly scheduled notifications (even with past timestamps)
        # always flow through dispatch_due() so recurrence stays in one place.
        deliver_now = scheduled_for is None

        for chunk in repository.resolve_recipient_id_chunks(**recipient_spec):
            instances = [Notification(recipient_id=pk, **payload) for pk in chunk]
            created = repository.bulk_create_notifications(instances)
            result.created += len(created)
            if first is None and created:
                first = created[0]
            for notification in created:
                if len(result.ids) < _MAX_RESULT_IDS:
                    result.ids.append(notification.pk)
                else:
                    result.truncated = True
                notification_created.send_robust(
                    sender=Notification, notification=notification
                )
            if not deliver_now:
                continue
            if use_celery and _safe_delay("deliver_chunk_task", [n.pk for n in created]):
                continue  # deliveries created + executed inside the task
            preferences = repository.preferences_by_user(chunk)
            for notification in created:
                self.dispatch(
                    notification,
                    preferences.get(notification.recipient_id),
                    allow_retry=False,
                )

        logger.info(
            "notification.sent",
            extra={
                "djn_type": type,
                "djn_count": result.created,
                "djn_event": event,
                "djn_scheduled": bool(scheduled_for and scheduled_for > now),
            },
        )
        if single and result.created == 1 and first is not None:
            return first
        return result

    # ------------------------------------------------------------------ event

    def send_event(
        self,
        event: str,
        context: dict | None = None,
        strict: bool = True,
        **kwargs: Any,
    ) -> Notification | BulkResult:
        """Render a registered/DB template for ``event`` and send it."""
        from . import events as event_registry

        context = dict(context or {})
        if kwargs.get("user") is not None:
            context.setdefault("user", kwargs["user"])
        rendered = event_registry.resolve(event, context, strict=strict) or {}
        for key, value in rendered.items():
            kwargs.setdefault(key, value)
        kwargs.setdefault("event", event)
        return self.send(**kwargs)

    # ---------------------------------------------------------------- schedule

    def schedule(
        self,
        *,
        at: dt.datetime | None = None,
        delay: int | dt.timedelta | None = None,
        every: int | dt.timedelta | None = None,
        until: dt.datetime | None = None,
        **kwargs: Any,
    ) -> Notification | BulkResult:
        """Sugar over :meth:`send` for delayed/recurring notifications."""
        if at is None and delay is None:
            raise ValidationError("schedule() needs 'at' or 'delay'.")
        return self.send(
            scheduled_for=at,
            delay=delay,
            repeat_interval=every,
            repeat_until=until,
            **kwargs,
        )

    # ---------------------------------------------------------------- dispatch

    def dispatch(
        self,
        notification: Notification,
        preference: NotificationPreference | None = None,
        *,
        execute: bool = True,
        allow_retry: bool = True,
    ) -> list[Delivery]:
        """Create :class:`Delivery` rows for a notification and execute them.

        Preference enforcement happens here (dispatch time), so quiet hours
        and mutes reflect the user's settings at delivery, not at creation.
        """
        if notification.sent_at is None:
            notification.sent_at = timezone.now()
            notification.save(update_fields=["sent_at", "updated_at"])

        channel_keys = list(
            dict.fromkeys(  # de-dupe, keep order
                notification.channels or self._resolve_channels(notification.type)
            )
        )

        enforce = app_settings.PREFERENCES["ENFORCE"]
        if enforce and preference is None:
            preference = NotificationPreference.objects.filter(
                user_id=notification.recipient_id
            ).first()
        enforce = enforce and preference is not None

        mandatory = notification.type in app_settings.MANDATORY_TYPES
        quiet_channels = set(app_settings.PREFERENCES["QUIET_HOURS_CHANNELS"])
        deliveries: list[Delivery] = []

        for key in channel_keys:
            deferred_until = None
            if enforce:
                always = mandatory and key in ("in_app", "websocket")
                muted = (
                    not preference.enabled
                    or preference.category_muted(notification.category)
                    or preference.type_muted(notification.type)
                    or not preference.channel_enabled(key)
                )
                if muted and not always:
                    continue
                if key in quiet_channels and preference.in_quiet_hours():
                    deferred_until = preference.quiet_hours_end_datetime()
            deliveries.append(
                Delivery(
                    notification=notification,
                    channel=key,
                    status="deferred" if deferred_until else "pending",
                    deliver_after=deferred_until,
                )
            )

        deliveries = repository.bulk_create_deliveries(deliveries)
        if execute:
            self.execute_deliveries(
                notification,
                [d for d in deliveries if d.status == "pending"],
                allow_retry=allow_retry,
            )
        return deliveries

    def execute_deliveries(
        self,
        notification: Notification,
        deliveries: Iterable[Delivery] | None = None,
        *,
        allow_retry: bool = True,
    ) -> tuple[int, int]:
        """Run channel backends for ``deliveries`` (default: all pending).

        Returns ``(sent, retryable_pending)``. When ``allow_retry`` is False
        (synchronous mode), transient failures are marked failed after one
        attempt instead of being left pending for a Celery retry.
        """
        if deliveries is None:
            deliveries = list(notification.deliveries.pending())
        max_attempts = app_settings.MAX_DELIVERY_ATTEMPTS
        sent = retryable = 0

        for delivery in deliveries:
            backend = app_settings.channel_backend(delivery.channel)()
            delivery.attempts += 1
            try:
                outcome = backend.send(notification)
            except RetryableDeliveryError as exc:
                delivery.last_error = str(exc)[:2000]
                if allow_retry and delivery.attempts < max_attempts:
                    delivery.status = "pending"
                    retryable += 1
                else:
                    delivery.status = "failed"
                    delivery_failed.send_robust(
                        sender=Delivery, delivery=delivery, error=exc
                    )
                logger.warning(
                    "delivery.retryable_failure",
                    extra={
                        "djn_channel": delivery.channel,
                        "djn_notification": notification.pk,
                        "djn_attempt": delivery.attempts,
                    },
                )
            except (DeliveryError, Exception) as exc:  # permanent
                delivery.status = "failed"
                delivery.last_error = str(exc)[:2000]
                delivery_failed.send_robust(
                    sender=Delivery, delivery=delivery, error=exc
                )
                logger.exception(
                    "delivery.failed",
                    extra={
                        "djn_channel": delivery.channel,
                        "djn_notification": notification.pk,
                    },
                )
            else:
                delivery.status = "skipped" if outcome is False else "sent"
                if delivery.status == "sent":
                    delivery.sent_at = timezone.now()
                    sent += 1
                    delivery_sent.send_robust(sender=Delivery, delivery=delivery)
            delivery.save(
                update_fields=["status", "attempts", "last_error", "sent_at", "updated_at"]
            )
        return sent, retryable

    # ----------------------------------------------------------- scheduler entry

    def dispatch_due(self, limit: int = 500) -> dict[str, int]:
        """Send due scheduled notifications and due deferred deliveries.

        Called by the ``notifications_send_scheduled`` management command or
        the bundled Celery beat task. Uses ``SELECT ... FOR UPDATE SKIP
        LOCKED`` when the database supports it so multiple workers can run
        concurrently without double-sends.
        """
        from django.db import connection

        stats = {"scheduled_sent": 0, "deferred_sent": 0, "recurred": 0}

        # -- due scheduled notifications -----------------------------------
        with transaction.atomic():
            queryset = Notification.objects.due().order_by("scheduled_for")
            if connection.features.has_select_for_update_skip_locked:
                queryset = queryset.select_for_update(skip_locked=True)
            due_ids = list(queryset.values_list("pk", flat=True)[:limit])
            # Claim inside the lock window so concurrent runners skip these.
            Notification.objects.filter(pk__in=due_ids, sent_at__isnull=True).update(
                sent_at=timezone.now(), updated_at=timezone.now()
            )

        use_celery = celery_available()
        for notification in Notification.objects.filter(pk__in=due_ids):
            if use_celery and _safe_delay("deliver_chunk_task", [notification.pk]):
                pass
            else:
                self.dispatch(notification, allow_retry=False)
            stats["scheduled_sent"] += 1
            if self._maybe_recur(notification):
                stats["recurred"] += 1

        # -- deferred deliveries whose quiet hours ended ---------------------
        deferred = (
            Delivery.objects.deferred_due()
            .select_related("notification")
            .order_by("deliver_after")[:limit]
        )
        for delivery in deferred:
            delivery.status = "pending"
            delivery.save(update_fields=["status", "updated_at"])
            self.execute_deliveries(
                delivery.notification, [delivery], allow_retry=use_celery
            )
            stats["deferred_sent"] += 1

        if any(stats.values()):
            logger.info("scheduler.run", extra={f"djn_{k}": v for k, v in stats.items()})
        return stats

    def _maybe_recur(self, notification: Notification) -> bool:
        """Clone a recurring notification for its next occurrence."""
        if not notification.repeat_interval or not notification.scheduled_for:
            return False
        next_time = notification.scheduled_for + notification.repeat_interval
        if notification.repeat_until and next_time > notification.repeat_until:
            return False
        clone = Notification(
            recipient_id=notification.recipient_id,
            scheduled_for=next_time,
            sent_at=None,
            read_at=None,
            archived_at=None,
        )
        for fieldname in (
            "type", "level", "category", "priority", "thread_key", "source",
            "event", "title", "message", "body_html", "content_format", "icon",
            "image", "url", "actions", "attachments", "data", "channels",
            "expires_at", "repeat_interval", "repeat_until",
            "actor_content_type", "actor_object_id",
            "target_content_type", "target_object_id",
        ):
            setattr(clone, fieldname, getattr(notification, fieldname))
        if notification.expires_at and notification.scheduled_for:
            # Preserve the relative TTL for the next occurrence.
            clone.expires_at = next_time + (
                notification.expires_at - notification.scheduled_for
            )
        clone.save()
        return True

    # ------------------------------------------------------- inbox state helpers

    def mark_read(self, user, ids: Iterable[int] | None = None, everything: bool = False) -> int:
        queryset = Notification.objects.for_user(user)
        queryset = queryset.visible() if everything else queryset.filter(pk__in=list(ids or []))
        count = queryset.mark_read()
        if count:
            notification_read.send_robust(
                sender=Notification, user=user, notification_ids=list(ids or []), all=everything
            )
            push_counts(user)
        return count

    def mark_unread(self, user, ids: Iterable[int]) -> int:
        count = Notification.objects.for_user(user).filter(pk__in=list(ids)).mark_unread()
        if count:
            push_counts(user)
        return count

    def archive(self, user, ids: Iterable[int] | None = None, everything: bool = False) -> int:
        queryset = Notification.objects.for_user(user)
        queryset = queryset.visible() if everything else queryset.filter(pk__in=list(ids or []))
        count = queryset.archive()
        if count:
            push_counts(user)
        return count

    def delete(self, user, ids: Iterable[int] | None = None, everything: bool = False) -> int:
        queryset = Notification.objects.for_user(user)
        if not everything:
            queryset = queryset.filter(pk__in=list(ids or []))
        _, per_model = queryset.delete()
        count = per_model.get("django_notifications.Notification", 0)
        if count:
            push_counts(user)
        return count

    # ------------------------------------------------------------------ internals

    def _resolve_channels(self, type_: str) -> list[str]:
        type_channels: dict[str, list[str]] = app_settings.TYPE_CHANNELS
        if type_ in type_channels:
            return list(type_channels[type_])
        return list(app_settings.DEFAULT_CHANNELS)

    def _enqueue_fanout(self, recipient_spec: dict, payload: dict) -> BulkResult | None:
        """Offload creation to Celery. Returns None to fall back to inline."""
        serializable = {
            k: v
            for k, v in recipient_spec.items()
            if k in ("user_id", "user_ids", "permission", "everyone")
            and v not in (None, False)
        }
        if recipient_spec.get("user") is not None:
            serializable.setdefault("user_ids", []).append(recipient_spec["user"].pk)
        for key in ("group", "groups"):
            value = recipient_spec.get(key)
            if value:
                names = [g if isinstance(g, str) else g.name for g in
                         ([value] if key == "group" else value)]
                serializable.setdefault("groups", []).extend(names)
        queryset_like = recipient_spec.get("users") or recipient_spec.get("recipients")
        if queryset_like is not None:
            # Materialize ids chunk-wise; each chunk becomes one task.
            spec = dict(recipient_spec)
            task_payload = _serialize_payload(payload)
            queued_any = False
            for chunk in repository.resolve_recipient_id_chunks(**spec):
                queued_any = (
                    _safe_delay("fanout_chunk_task", chunk, task_payload) or queued_any
                )
            if queued_any:
                return BulkResult(queued=True)
            return None
        if not serializable:
            return None
        if _safe_delay("fanout_task", serializable, _serialize_payload(payload)):
            return BulkResult(queued=True)
        return None

    def _check_rate_limit(self, request: Any) -> None:
        spec = app_settings.RATE_LIMIT
        if not spec:
            return
        match = _RATE_RE.match(str(spec))
        if not match:
            raise ConfigurationError(
                f"RATE_LIMIT must look like '100/m', got {spec!r}."
            )
        limit, unit = int(match.group(1)), match.group(2)
        window = _RATE_WINDOWS[unit]
        scope = "anon"
        if request is not None and getattr(request, "user", None) is not None:
            if getattr(request.user, "is_authenticated", False):
                scope = str(request.user.pk)
        bucket = int(timezone.now().timestamp() // window)
        key = f"djn:rl:{scope}:{bucket}"
        cache.add(key, 0, timeout=window + 1)
        try:
            count = cache.incr(key)
        except ValueError:  # key expired between add and incr
            cache.set(key, 1, timeout=window + 1)
            count = 1
        if count > limit:
            raise RateLimitedError(
                f"Notification rate limit exceeded ({spec}) for scope {scope}."
            )


def _serialize_payload(payload: dict) -> dict:
    """JSON-safe copy of the model payload for Celery fan-out tasks."""
    out: dict[str, Any] = {}
    for key, value in payload.items():
        if key in ("actor_content_type", "target_content_type") and value is not None:
            out[key + "_id"] = value.pk
        elif isinstance(value, dt.datetime):
            out[key] = value.isoformat()
        elif isinstance(value, dt.timedelta):
            out[key] = value.total_seconds()
        else:
            out[key] = value
    return out


def deserialize_payload(payload: dict) -> dict:
    """Inverse of :func:`_serialize_payload` (used by celery_tasks)."""
    out = dict(payload)
    for key in ("scheduled_for", "expires_at", "repeat_until"):
        if out.get(key):
            out[key] = dt.datetime.fromisoformat(out[key])
    if out.get("repeat_interval") is not None:
        out["repeat_interval"] = dt.timedelta(seconds=out["repeat_interval"])
    for prefix in ("actor", "target"):
        ct_id = out.pop(f"{prefix}_content_type_id", None)
        if ct_id:
            out[f"{prefix}_content_type"] = ContentType.objects.get(pk=ct_id)
    return out


#: Module-level singleton used by the ``notify`` facade and Celery tasks.
service = NotificationService()
