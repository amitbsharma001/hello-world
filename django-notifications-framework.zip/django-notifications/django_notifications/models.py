"""Data models.

Design notes
------------
* ``Notification`` rows are always fanned out per recipient (one row per
  user). This keeps read/archive state trivially per-user and lets Postgres
  partial/composite indexes do the heavy lifting at millions of rows.
* ``Delivery`` tracks each (notification, channel) attempt independently so
  a failing email never blocks the in-app record, and retries are precise.
* ``NotificationTemplate`` stores event templates editable in the admin;
  code-registered templates (``events.py``) act as fallbacks.
"""

from __future__ import annotations

from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models
from django.utils import timezone as dj_tz
from django.utils.translation import gettext_lazy as _

from .constants import ContentFormat, DeliveryStatus, Digest, Level, Priority
from .managers import DeliveryManager, NotificationManager


class Notification(models.Model):
    """A single notification for a single recipient."""

    recipient = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="notifications",
        null=True,
        blank=True,
        db_index=True,
        help_text=_("Null only for anonymous/system records."),
    )

    # -- classification -----------------------------------------------------
    type = models.CharField(max_length=64, default="info", db_index=True)
    level = models.CharField(max_length=16, choices=Level.choices, default=Level.INFO)
    category = models.CharField(max_length=64, blank=True, default="", db_index=True)
    priority = models.PositiveSmallIntegerField(
        choices=Priority.choices, default=Priority.NORMAL
    )
    thread_key = models.CharField(
        max_length=64,
        blank=True,
        default="",
        db_index=True,
        help_text=_("Group related notifications (e.g. per order, per chat)."),
    )
    source = models.CharField(
        max_length=64,
        blank=True,
        default="",
        help_text=_("Originating app/task, for auditing."),
    )
    event = models.CharField(max_length=128, blank=True, default="", db_index=True)

    # -- content -------------------------------------------------------------
    title = models.CharField(max_length=255)
    message = models.TextField(blank=True, default="")
    body_html = models.TextField(
        blank=True, default="", help_text=_("Sanitized rich body (optional).")
    )
    content_format = models.CharField(
        max_length=16, choices=ContentFormat.choices, default=ContentFormat.PLAIN
    )
    icon = models.CharField(max_length=64, blank=True, default="")
    image = models.URLField(max_length=500, blank=True, default="")
    url = models.CharField(
        max_length=500, blank=True, default="", help_text=_("Deep link / click target.")
    )
    actions = models.JSONField(
        default=list, blank=True, help_text=_("CTA buttons: [{label, url, style}].")
    )
    attachments = models.JSONField(default=list, blank=True)
    data = models.JSONField(default=dict, blank=True, help_text=_("Free-form payload."))
    channels = models.JSONField(
        default=list,
        blank=True,
        help_text=_("Requested delivery channels; empty = resolve defaults at dispatch."),
    )

    # -- optional graph context (who did what to what) ------------------------
    actor_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
    )
    actor_object_id = models.CharField(max_length=64, null=True, blank=True)
    actor = GenericForeignKey("actor_content_type", "actor_object_id")

    target_content_type = models.ForeignKey(
        ContentType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="+",
    )
    target_object_id = models.CharField(max_length=64, null=True, blank=True)
    target = GenericForeignKey("target_content_type", "target_object_id")

    # -- state ----------------------------------------------------------------
    pinned = models.BooleanField(default=False)
    read_at = models.DateTimeField(null=True, blank=True)
    archived_at = models.DateTimeField(null=True, blank=True)

    # -- scheduling / lifecycle ------------------------------------------------
    scheduled_for = models.DateTimeField(null=True, blank=True, db_index=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True, db_index=True)
    repeat_interval = models.DurationField(
        null=True, blank=True, help_text=_("Re-issue this notification every interval.")
    )
    repeat_until = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(default=dj_tz.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    objects = NotificationManager()

    class Meta:
        ordering = ("-created_at", "-id")
        verbose_name = _("notification")
        verbose_name_plural = _("notifications")
        indexes = [
            models.Index(
                fields=["recipient", "-created_at"], name="djn_recipient_created_idx"
            ),
            models.Index(
                fields=["recipient", "read_at"], name="djn_recipient_read_idx"
            ),
            models.Index(
                fields=["recipient", "archived_at"], name="djn_recipient_arch_idx"
            ),
        ]

    def __str__(self) -> str:
        return f"[{self.type}] {self.title}"

    # -- convenience ---------------------------------------------------------

    @property
    def is_read(self) -> bool:
        return self.read_at is not None

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None

    @property
    def is_expired(self) -> bool:
        return self.expires_at is not None and self.expires_at <= dj_tz.now()

    def mark_read(self, commit: bool = True) -> None:
        if self.read_at is None:
            self.read_at = dj_tz.now()
            if commit:
                self.save(update_fields=["read_at", "updated_at"])

    def mark_unread(self, commit: bool = True) -> None:
        if self.read_at is not None:
            self.read_at = None
            if commit:
                self.save(update_fields=["read_at", "updated_at"])


class Delivery(models.Model):
    """One delivery attempt record per (notification, channel)."""

    notification = models.ForeignKey(
        Notification, on_delete=models.CASCADE, related_name="deliveries"
    )
    channel = models.CharField(max_length=32, db_index=True)
    status = models.CharField(
        max_length=16,
        choices=DeliveryStatus.choices,
        default=DeliveryStatus.PENDING,
        db_index=True,
    )
    attempts = models.PositiveSmallIntegerField(default=0)
    last_error = models.TextField(blank=True, default="")
    deliver_after = models.DateTimeField(
        null=True, blank=True, db_index=True, help_text=_("Quiet-hours deferral.")
    )
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(default=dj_tz.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    objects = DeliveryManager()

    class Meta:
        verbose_name = _("delivery")
        verbose_name_plural = _("deliveries")
        constraints = [
            models.UniqueConstraint(
                fields=["notification", "channel"], name="djn_unique_channel_per_notif"
            )
        ]

    def __str__(self) -> str:
        return f"{self.channel}:{self.status} (#{self.notification_id})"


class NotificationTemplate(models.Model):
    """Admin-editable template bound to an event key (``order.created``...).

    Title/message/url fields are Django templates rendered with the context
    passed to ``notify.event``. DB templates override code-registered ones.
    """

    event = models.CharField(max_length=128, unique=True, db_index=True)
    name = models.CharField(max_length=120, blank=True, default="")
    description = models.TextField(blank=True, default="")

    title_template = models.CharField(max_length=500)
    message_template = models.TextField(blank=True, default="")
    body_html_template = models.TextField(blank=True, default="")
    url_template = models.CharField(max_length=500, blank=True, default="")

    type = models.CharField(max_length=64, blank=True, default="")
    level = models.CharField(max_length=16, choices=Level.choices, blank=True, default="")
    category = models.CharField(max_length=64, blank=True, default="")
    icon = models.CharField(max_length=64, blank=True, default="")
    channels = models.JSONField(
        null=True, blank=True, help_text=_("Override channels, e.g. ['in_app','email'].")
    )
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(default=dj_tz.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("notification template")
        verbose_name_plural = _("notification templates")
        ordering = ("event",)

    def __str__(self) -> str:
        return self.name or self.event

    def render(self, context: dict) -> dict:
        """Render all template fields with ``context``; see templates.py."""
        from .templates import render_string

        rendered = {
            "title": render_string(self.title_template, context),
            "message": render_string(self.message_template, context),
            "url": render_string(self.url_template, context),
        }
        if self.body_html_template:
            rendered["body_html"] = render_string(self.body_html_template, context)
        for field in ("type", "level", "category", "icon"):
            value = getattr(self, field)
            if value:
                rendered[field] = value
        if self.channels:
            rendered["channels"] = list(self.channels)
        return rendered


class NotificationPreference(models.Model):
    """Per-user delivery preferences, created lazily on first send/read."""

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="notification_preferences",
    )
    enabled = models.BooleanField(default=True, help_text=_("Master switch."))
    channel_settings = models.JSONField(
        default=dict,
        blank=True,
        help_text=_('Per-channel opt-in/out, e.g. {"email": false}.'),
    )
    muted_categories = models.JSONField(default=list, blank=True)
    muted_types = models.JSONField(default=list, blank=True)

    quiet_hours_start = models.TimeField(null=True, blank=True)
    quiet_hours_end = models.TimeField(null=True, blank=True)
    timezone = models.CharField(max_length=64, blank=True, default="")
    language = models.CharField(max_length=16, blank=True, default="")

    digest = models.CharField(max_length=8, choices=Digest.choices, default=Digest.OFF)
    digest_hour = models.PositiveSmallIntegerField(default=8)

    created_at = models.DateTimeField(default=dj_tz.now, editable=False)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("notification preference")
        verbose_name_plural = _("notification preferences")

    def __str__(self) -> str:
        return f"Preferences for {self.user}"

    # -- evaluation helpers (pure, unit-testable) -----------------------------

    def channel_enabled(self, channel: str) -> bool:
        if not self.enabled:
            return False
        value = (self.channel_settings or {}).get(channel)
        return True if value is None else bool(value)

    def category_muted(self, category: str) -> bool:
        return bool(category) and category in (self.muted_categories or [])

    def type_muted(self, type_: str) -> bool:
        return bool(type_) and type_ in (self.muted_types or [])

    def in_quiet_hours(self, when=None) -> bool:
        """True when ``when`` (aware datetime, default now) falls in quiet
        hours, evaluated in the user's preferred timezone when set."""
        if not (self.quiet_hours_start and self.quiet_hours_end):
            return False
        when = when or dj_tz.now()
        if self.timezone:
            try:
                import zoneinfo

                when = when.astimezone(zoneinfo.ZoneInfo(self.timezone))
            except Exception:  # invalid tz name: fall back to server tz
                when = dj_tz.localtime(when)
        else:
            when = dj_tz.localtime(when)
        now_t = when.time()
        start, end = self.quiet_hours_start, self.quiet_hours_end
        if start <= end:
            return start <= now_t < end
        return now_t >= start or now_t < end  # window crosses midnight

    def quiet_hours_end_datetime(self, when=None):
        """Next datetime (server tz, aware) at which quiet hours end."""
        import datetime as dt
        import zoneinfo

        when = when or dj_tz.now()
        tz = dj_tz.get_current_timezone()
        if self.timezone:
            try:
                tz = zoneinfo.ZoneInfo(self.timezone)
            except Exception:
                pass
        local = when.astimezone(tz)
        end_local = local.replace(
            hour=self.quiet_hours_end.hour,
            minute=self.quiet_hours_end.minute,
            second=0,
            microsecond=0,
        )
        if end_local <= local:
            end_local += dt.timedelta(days=1)
        return end_local.astimezone(dj_tz.get_current_timezone())
