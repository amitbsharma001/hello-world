"""Flatten nested SEMP attribute objects into dotted scalar columns.

A handful of SEMP v2 config attributes are nested objects - most notably the
event thresholds, e.g.::

    "eventMsgSpoolUsageThreshold": {"clearPercent": 18, "setPercent": 25}

For a filterable, audit-friendly worksheet these become two columns::

    eventMsgSpoolUsageThreshold.clearPercent | eventMsgSpoolUsageThreshold.setPercent

Lists are left untouched here; :func:`solace_exporter.utils.text.clean_cell`
serialises them at write time (scalar lists join with commas, anything else
becomes compact JSON).
"""

from __future__ import annotations

from typing import Any, Mapping


def flatten_record(record: Mapping[str, Any], *, sep: str = ".", _prefix: str = "") -> dict[str, Any]:
    """Return ``record`` with nested mappings expanded into dotted keys."""
    out: dict[str, Any] = {}
    for key, value in record.items():
        dotted = f"{_prefix}{sep}{key}" if _prefix else str(key)
        if isinstance(value, Mapping):
            out.update(flatten_record(value, sep=sep, _prefix=dotted))
        else:
            out[dotted] = value
    return out
