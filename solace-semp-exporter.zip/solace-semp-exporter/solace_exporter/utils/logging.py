"""Logging configuration: rich console handler + rotating file handler."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from rich.logging import RichHandler

_FILE_FORMAT = "%(asctime)s %(levelname)-8s %(name)s :: %(message)s"


def setup_logging(level: str = "INFO", log_file: Path | None = Path("logs/export.log")) -> logging.Logger:
    """Configure the ``solace_exporter`` logger tree.

    Console output goes through Rich at the requested level; the file handler
    always captures DEBUG so post-mortems have full API URL / retry detail.
    """
    root = logging.getLogger("solace_exporter")
    root.setLevel(logging.DEBUG)
    root.handlers.clear()
    root.propagate = False

    console = RichHandler(rich_tracebacks=True, show_path=False, markup=False)
    console.setLevel(getattr(logging, level.upper(), logging.INFO))
    console.setFormatter(logging.Formatter("%(message)s", datefmt="[%X]"))
    root.addHandler(console)

    if log_file is not None:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(log_file, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(_FILE_FORMAT))
        root.addHandler(fh)

    # Keep noisy third-party loggers quiet on the console.
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    return root


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"solace_exporter.{name}")
