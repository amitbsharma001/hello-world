"""Checkpointing: cache fetched collections so a failed run can resume.

Each *root* exporter's raw rows - for every spec in its subtree - are dumped
to JSON as soon as fetching completes. When ``--resume`` is passed, completed
roots are loaded from cache instead of being re-fetched, so an export that
died at sheet 30 of 40 does not re-download the first 29.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .logging import get_logger

log = get_logger("checkpoint")

Rows = list[tuple[dict[str, Any], dict[str, Any]]]
Subtree = dict[str, Rows]  # spec_key -> rows


def default_cache_root() -> Path:
    return Path.home() / ".cache" / "solace-exporter"


class Checkpoint:
    """JSON-file backed cache of fetched subtrees, keyed by run identity."""

    def __init__(
        self,
        *,
        host: str,
        port: int,
        scopes: tuple[str, ...],
        vpns: tuple[str, ...],
        cache_dir: Path | None = None,
        enabled_read: bool = False,
    ) -> None:
        digest = hashlib.sha1(
            "|".join([host, str(port), ",".join(sorted(scopes)), ",".join(sorted(vpns))]).encode()
        ).hexdigest()[:16]
        self.directory = (cache_dir or default_cache_root()) / digest
        self.enabled_read = enabled_read

    def _path(self, root_key: str) -> Path:
        return self.directory / f"{root_key.replace('/', '_')}.json"

    def load(self, root_key: str) -> Subtree | None:
        """Return the cached subtree for ``root_key`` or ``None``."""
        if not self.enabled_read:
            return None
        path = self._path(root_key)
        if not path.exists():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            subtree: Subtree = {
                spec_key: [(item["ctx"], item["row"]) for item in items]
                for spec_key, items in payload.items()
            }
            log.info("Resumed %s from cache (%d collections)", root_key, len(subtree))
            return subtree
        except (json.JSONDecodeError, KeyError, TypeError, AttributeError) as exc:
            log.warning("Ignoring corrupt checkpoint %s: %s", path, exc)
            return None

    def save(self, root_key: str, subtree: Subtree) -> None:
        try:
            self.directory.mkdir(parents=True, exist_ok=True)
            payload = {
                spec_key: [{"ctx": ctx, "row": row} for ctx, row in rows]
                for spec_key, rows in subtree.items()
            }
            self._path(root_key).write_text(
                json.dumps(payload, ensure_ascii=False, default=str), encoding="utf-8"
            )
        except OSError as exc:  # cache failures must never abort an export
            log.warning("Could not write checkpoint for %s: %s", root_key, exc)

    def clear(self) -> None:
        if not self.directory.exists():
            return
        for item in self.directory.glob("*.json"):
            try:
                item.unlink()
            except OSError:
                pass
        try:
            self.directory.rmdir()
        except OSError:
            pass
