"""Utility helpers: logging, text sanitisation, checkpointing."""
