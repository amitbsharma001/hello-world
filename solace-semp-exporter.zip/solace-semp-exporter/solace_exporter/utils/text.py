"""Text helpers: SEMP path encoding, Excel sheet/cell sanitisation."""

from __future__ import annotations

import json
import math
import re
from datetime import date, datetime
from typing import Any, Iterable
from urllib.parse import quote

_ILLEGAL_SHEET_CHARS = re.compile(r"[\[\]:*?/\\]")
# Characters openpyxl refuses inside cell values (control chars except \t \n \r).
_ILLEGAL_CELL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t")
MAX_SHEET_NAME = 31


def encode_path_param(value: Any) -> str:
    """Percent-encode a SEMP URI path parameter.

    Solace object names may contain ``/``, spaces, ``#`` etc., so *every*
    reserved character is encoded (``safe=''``).
    """
    return quote(str(value), safe="")


def render_path(template: str, ctx: dict[str, Any]) -> str:
    """Substitute ``{placeholders}`` in a SEMP path template with encoded values."""
    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in ctx:
            raise KeyError(f"Path template {template!r} missing context value {key!r}")
        return encode_path_param(ctx[key])

    return re.sub(r"\{(\w+)\}", repl, template)


def sanitize_sheet_name(name: str) -> str:
    """Make ``name`` a legal Excel worksheet name (<=31 chars, no []:*?/\\)."""
    clean = _ILLEGAL_SHEET_CHARS.sub(" ", name).strip().strip("'") or "Sheet"
    return clean[:MAX_SHEET_NAME]


def unique_name(name: str, taken: set[str], limit: int = MAX_SHEET_NAME) -> str:
    """Return ``name`` (or a ``~N`` suffixed variant) that is not in ``taken``."""
    candidate = name[:limit]
    counter = 2
    while candidate.lower() in {t.lower() for t in taken}:
        suffix = f"~{counter}"
        candidate = name[: limit - len(suffix)] + suffix
        counter += 1
    taken.add(candidate)
    return candidate


def table_display_name(sheet_name: str, taken: set[str]) -> str:
    """Derive a valid, unique Excel table displayName from a sheet name."""
    base = "T_" + re.sub(r"\W+", "_", sheet_name).strip("_")
    candidate, counter = base, 2
    while candidate in taken:
        candidate = f"{base}_{counter}"
        counter += 1
    taken.add(candidate)
    return candidate


def clean_cell(value: Any) -> Any:
    """Coerce an arbitrary JSON-ish value into a safe Excel cell value.

    * scalars pass through (bools/numbers stay typed)
    * lists of scalars become comma-joined text; nested structures become JSON
    * control characters are stripped
    * strings that would be parsed as formulas are prefixed with ``'``
      (defence against spreadsheet formula injection in exported names)
    """
    if value is None:
        return ""
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return ""  # pandas fills missing cells with NaN; Excel has no NaN
    if isinstance(value, bool) or isinstance(value, (int, float)):
        return value
    if isinstance(value, (datetime, date)):
        return value
    if isinstance(value, (list, tuple)):
        if all(isinstance(v, (str, int, float, bool)) or v is None for v in value):
            value = ", ".join("" if v is None else str(v) for v in value)
        else:
            value = json.dumps(value, ensure_ascii=False, default=str)
    elif isinstance(value, dict):
        value = json.dumps(value, ensure_ascii=False, default=str)
    text = _ILLEGAL_CELL_CHARS.sub("", str(value))
    if text.startswith(_FORMULA_PREFIXES):
        text = "'" + text
    return text


def sanitize_filename(name: str) -> str:
    """Filesystem-safe file-name fragment (used for host in workbook name)."""
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("_") or "broker"


# --------------------------------------------------------------------------- #
# Header humanisation
# --------------------------------------------------------------------------- #
# SEMP attribute names are camelCase (``maxMsgSpoolUsage``). For the default
# "friendly" workbook they are rendered as ``Max Msg Spool Usage``; well-known
# messaging acronyms keep their canonical casing. Nested attributes flattened
# with dots render each segment separately: ``Event ... Threshold / Set Percent``.
_ACRONYMS: dict[str, str] = {
    "acl": "ACL", "amqp": "AMQP", "api": "API", "cn": "CN", "crl": "CRL",
    "dmq": "DMQ", "dmr": "DMR", "dns": "DNS", "http": "HTTP", "https": "HTTPS",
    "id": "ID", "ip": "IP", "jms": "JMS", "jndi": "JNDI", "jwt": "JWT",
    "mqtt": "MQTT", "oauth": "OAuth", "ocsp": "OCSP", "oidc": "OIDC",
    "qos": "QoS", "rdp": "RDP", "rest": "REST", "sasl": "SASL", "semp": "SEMP",
    "smf": "SMF", "ssl": "SSL", "tcp": "TCP", "tls": "TLS", "ttl": "TTL",
    "udp": "UDP", "uri": "URI", "url": "URL", "vpn": "VPN",
}
_CAMEL_BOUNDARY = re.compile(
    r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|(?<=[A-Za-z])(?=[0-9])"
)


def _humanize_run(part: str) -> str:
    tokens = _CAMEL_BOUNDARY.sub(" ", part).split()
    pretty = " ".join(_ACRONYMS.get(t.lower(), t[:1].upper() + t[1:]) for t in tokens)
    return pretty or part


def humanize_header(name: str) -> str:
    """Turn a SEMP attribute name into a human-readable column header.

    Names that already contain a space (the hierarchy columns renamed via
    ``CollectionSpec.friendly``, or pre-built headers like ``Setting``) pass
    through untouched.
    """
    if " " in name:
        return name
    return " / ".join(_humanize_run(part) for part in name.split("."))


def dedupe_headers(headers: Iterable[str]) -> list[str]:
    """Suffix duplicate header names so Excel tables stay valid."""
    seen: dict[str, int] = {}
    out: list[str] = []
    for header in headers:
        count = seen.get(header, 0)
        seen[header] = count + 1
        out.append(header if count == 0 else f"{header} ({count + 1})")
    return out
