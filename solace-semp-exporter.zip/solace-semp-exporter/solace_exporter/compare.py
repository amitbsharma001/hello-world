"""VPN comparison: turn one export's sheets into a side-by-side audit report.

Given the flattened sheets of a completed export covering (at least) two
VPNs, :func:`compare_vpns` classifies every per-VPN object as *only in A*,
*only in B*, *different* (with exact attribute-level deltas) or *identical*,
and renders one diff frame per object type plus roll-up statistics.

An object's identity across VPNs is its ancestor chain minus the VPN itself -
a queue subscription is matched by ``(Queue, Subscription Topic)`` - taken
from :attr:`~solace_exporter.models.SheetData.id_columns`, so the comparison
stays in lock-step with the spec tree, including any custom exporters.

Design choices (documented so audits can rely on them):

* Missing attributes (``NaN``) compare as empty strings, so "attribute absent
  on one side" surfaces as a *Different* row with a blank cell.
* Objects present in both VPNs with zero attribute deltas are counted as
  *identical* but not listed row-by-row; the Summary sheet carries the counts.
* Identity columns can never be ignored; ``ignore`` globs apply to attribute
  names only (matched against the raw SEMP name *and* the friendly header).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from fnmatch import fnmatchcase
from typing import Any, Sequence

import pandas as pd

from .enrich import DERIVED_COLUMNS
from .models import SheetData
from .utils.logging import get_logger
from .utils.text import humanize_header

log = get_logger("compare")

PRESENT = "present"
MISSING = "missing"
STATUS_DIFFERENT = "Different"


def _norm(value: Any) -> Any:
    """Normalise a cell for identity/equality: None and NaN become ''."""
    if value is None:
        return ""
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return ""
    return value


def _ignored(attribute: str, patterns: Sequence[str]) -> bool:
    if not patterns:
        return False
    friendly = humanize_header(attribute)
    return any(fnmatchcase(attribute, p) or fnmatchcase(friendly, p) for p in patterns)


@dataclass
class ObjectTypeComparison:
    """Comparison outcome for one worksheet / object type."""

    sheet: str
    spec_key: str
    key_columns: tuple[str, ...]   # identity columns (VPN excluded)
    count_a: int
    count_b: int
    only_a: int
    only_b: int
    different: int                 # objects with >=1 attribute delta
    identical: int
    frame: pd.DataFrame            # delta rows only (may be empty)

    @property
    def has_deltas(self) -> bool:
        return bool(self.only_a or self.only_b or self.different)

    @property
    def compared(self) -> int:
        return self.only_a + self.only_b + self.different + self.identical

    @property
    def match_pct(self) -> float:
        return 100.0 if self.compared == 0 else self.identical / self.compared * 100.0


@dataclass
class VpnComparison:
    """Full A-vs-B comparison across every per-VPN object type."""

    vpn_a: str
    vpn_b: str
    ignored: tuple[str, ...]
    types: list[ObjectTypeComparison]

    @property
    def delta_types(self) -> list[ObjectTypeComparison]:
        return [t for t in self.types if t.has_deltas]

    @property
    def total_only_a(self) -> int:
        return sum(t.only_a for t in self.types)

    @property
    def total_only_b(self) -> int:
        return sum(t.only_b for t in self.types)

    @property
    def total_different(self) -> int:
        return sum(t.different for t in self.types)

    @property
    def total_identical(self) -> int:
        return sum(t.identical for t in self.types)

    @property
    def total_deltas(self) -> int:
        return self.total_only_a + self.total_only_b + self.total_different


def compare_vpns(
    sheets: Sequence[SheetData],
    vpn_a: str,
    vpn_b: str,
    *,
    ignore: Sequence[str] = (),
    friendly: bool = True,
) -> VpnComparison:
    """Compare two VPNs across every per-VPN sheet of a completed export."""
    types: list[ObjectTypeComparison] = []
    for sheet in sheets:
        outcome = _compare_sheet(sheet, vpn_a, vpn_b, tuple(ignore), friendly)
        if outcome is not None:
            types.append(outcome)
    comparison = VpnComparison(vpn_a=vpn_a, vpn_b=vpn_b, ignored=tuple(ignore), types=types)
    log.info(
        "Compared %s vs %s: %d object types, %d only-in-%s, %d only-in-%s, "
        "%d different, %d identical",
        vpn_a, vpn_b, len(types), comparison.total_only_a, vpn_a,
        comparison.total_only_b, vpn_b, comparison.total_different,
        comparison.total_identical,
    )
    return comparison


# --------------------------------------------------------------------------- #
# Per-sheet comparison
# --------------------------------------------------------------------------- #
def _compare_sheet(
    sheet: SheetData, vpn_a: str, vpn_b: str, ignore: tuple[str, ...], friendly: bool
) -> ObjectTypeComparison | None:
    frame = sheet.frame
    if not sheet.id_columns or sheet.id_columns[0] != "VPN" or "VPN" not in frame.columns:
        # Only sheets whose identity chain is rooted in the VPN participate:
        # that covers every per-VPN collection *and* the VPNs sheet itself
        # (identity == the VPN, so its attributes diff directly), while
        # excluding broker-level sheets - including ones that merely
        # *reference* a VPN, such as Virtual Hostnames.
        return None

    key_cols = tuple(c for c in sheet.id_columns if c != "VPN" and c in frame.columns)
    records_a = frame[frame["VPN"] == vpn_a].to_dict("records")
    records_b = frame[frame["VPN"] == vpn_b].to_dict("records")

    if not key_cols and (len(records_a) > 1 or len(records_b) > 1):
        log.warning("%s: no identity columns but multiple rows per VPN; sheet skipped", sheet.name)
        return None

    index_a = _index(records_a, key_cols, sheet.name)
    index_b = _index(records_b, key_cols, sheet.name)
    attr_cols = [
        c for c in frame.columns
        if c != "VPN" and c not in key_cols and str(c) not in DERIVED_COLUMNS
        and not _ignored(str(c), ignore)
    ]

    col_a, col_b = _value_column_labels(vpn_a, vpn_b, key_cols)
    columns = ["Status", *key_cols, "Attribute", col_a, col_b]
    sort_key = lambda ident: tuple(str(v) for v in ident)  # noqa: E731

    rows: list[dict[str, Any]] = []

    def only_rows(idents: set[tuple], present_in_a: bool) -> None:
        status = f"Only in {vpn_a if present_in_a else vpn_b}"
        for ident in sorted(idents, key=sort_key):
            row: dict[str, Any] = {"Status": status, **dict(zip(key_cols, ident)), "Attribute": ""}
            row[col_a] = PRESENT if present_in_a else MISSING
            row[col_b] = MISSING if present_in_a else PRESENT
            rows.append(row)

    only_a_ids = set(index_a) - set(index_b)
    only_b_ids = set(index_b) - set(index_a)
    only_rows(only_a_ids, present_in_a=True)
    only_rows(only_b_ids, present_in_a=False)

    different = identical = 0
    for ident in sorted(set(index_a) & set(index_b), key=sort_key):
        row_a, row_b = index_a[ident], index_b[ident]
        deltas = [
            attr for attr in attr_cols
            if _norm(row_a.get(attr)) != _norm(row_b.get(attr))
        ]
        if not deltas:
            identical += 1
            continue
        different += 1
        for attr in deltas:
            rows.append({
                "Status": STATUS_DIFFERENT,
                **dict(zip(key_cols, ident)),
                "Attribute": humanize_header(str(attr)) if friendly else str(attr),
                col_a: _norm(row_a.get(attr)),
                col_b: _norm(row_b.get(attr)),
            })

    delta_frame = (
        pd.DataFrame.from_records(rows, columns=columns)
        if rows else pd.DataFrame(columns=columns)
    )
    return ObjectTypeComparison(
        sheet=sheet.name,
        spec_key=sheet.spec_key,
        key_columns=key_cols,
        count_a=len(index_a),
        count_b=len(index_b),
        only_a=len(only_a_ids),
        only_b=len(only_b_ids),
        different=different,
        identical=identical,
        frame=delta_frame,
    )


def _index(records: list[dict[str, Any]], key_cols: tuple[str, ...], sheet: str) -> dict[tuple, dict[str, Any]]:
    out: dict[tuple, dict[str, Any]] = {}
    for record in records:
        ident = tuple(_norm(record.get(c)) for c in key_cols)
        if ident in out:
            log.warning("%s: duplicate identity %s within one VPN; keeping first", sheet, ident)
            continue
        out[ident] = record
    return out


def _value_column_labels(vpn_a: str, vpn_b: str, key_cols: tuple[str, ...]) -> tuple[str, str]:
    """VPN names become value-column headers; dodge the fixed column names."""
    reserved = {"Status", "Attribute", *key_cols}
    col_a = f"{vpn_a} (A)" if vpn_a in reserved else vpn_a
    col_b = f"{vpn_b} (B)" if vpn_b in reserved or vpn_b == col_a else vpn_b
    return col_a, col_b
