"""Testing/demo support: an in-memory SEMP client with a realistic dataset.

:class:`FakeSempClient` satisfies :class:`~solace_exporter.semp_client.
SempClientProtocol` from a ``path -> rows`` mapping and raises
:class:`SempNotAvailableError` for anything unmapped - mirroring how a real
broker answers for features that are absent on its edition.

:func:`sample_client` returns a fake pre-loaded with a small but structurally
complete broker (2 VPNs, queues with subscriptions, a bridge with remote VPN
and remote subscriptions, ACL exceptions, DMR, MQTT, RDP, JNDI ...). It powers
both the unit tests and ``scripts/make_sample.py``, which renders
``examples/sample_export.xlsx`` - so the shipped sample is a true end-to-end
artifact of the pipeline.
"""

from __future__ import annotations

from typing import Any, Mapping

from .exceptions import SempNotAvailableError

Rows = list[dict[str, Any]]


class FakeSempClient:
    """SempClientProtocol implementation backed by a static path mapping."""

    def __init__(
        self,
        collections: Mapping[str, Rows],
        objects: Mapping[str, dict[str, Any]] | None = None,
        about_info: dict[str, Any] | None = None,
        not_found: set[str] | None = None,
    ) -> None:
        self._collections = dict(collections)
        self._objects = dict(objects or {})
        self._about = about_info or {"sempVersion": "2.41", "platform": "VMR"}
        self._not_found = set(not_found or ())
        self._calls = 0
        #: write journals + injectable write errors (for migration tests)
        self.posted: list[tuple[str, dict[str, Any]]] = []
        self.patched: list[tuple[str, dict[str, Any]]] = []
        self.post_errors: dict[str, list[tuple[int, str, str]]] = {}
        self.patch_errors: dict[str, list[tuple[int, str, str]]] = {}
        self.user_info: dict[str, Any] = {"globalAccessLevel": "admin", "username": "fake"}

    # -- SempClientProtocol -------------------------------------------- #
    def get_collection(self, path: str, params: dict[str, Any] | None = None) -> Rows:
        self._calls += 1
        if path in self._not_found:  # a single parent object vanished
            raise SempNotAvailableError(
                f"HTTP 404 NOT_FOUND: /{path}", url=path, status=404, semp_status="NOT_FOUND"
            )
        if path not in self._collections:
            raise SempNotAvailableError(
                f"HTTP 400 INVALID_PATH: /{path} not available",
                url=path, status=400, semp_status="INVALID_PATH",
            )
        return [dict(row) for row in self._collections[path]]

    def get_object(self, path: str) -> dict[str, Any] | None:
        self._calls += 1
        if path not in self._objects:
            raise SempNotAvailableError(
                f"HTTP 400 INVALID_PATH: /{path} not available",
                url=path, status=400, semp_status="INVALID_PATH",
            )
        return dict(self._objects[path])

    def _maybe_raise(self, errors: dict[str, list[tuple[int, str, str]]], path: str) -> None:
        from .exceptions import SempWriteError

        queue = errors.get(path)
        if queue:
            status, semp_status, description = queue.pop(0)
            raise SempWriteError(
                f"HTTP {status} {semp_status}: {description}",
                url=path, status=status, semp_status=semp_status, description=description,
            )

    def post_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        self._calls += 1
        self._maybe_raise(self.post_errors, path)
        self.posted.append((path, dict(body)))
        self._collections.setdefault(path, []).append(dict(body))
        return {"data": dict(body)}

    def patch_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        self._calls += 1
        self._maybe_raise(self.patch_errors, path)
        self.patched.append((path, dict(body)))
        return {"data": dict(body)}

    def about_user(self) -> dict[str, Any]:
        return dict(self.user_info)

    def about(self) -> dict[str, Any]:
        return dict(self._about)

    def verify_connection(self) -> dict[str, Any]:
        return self.about()

    def vpn_names(self) -> list[str]:
        return [str(r["msgVpnName"]) for r in self._collections.get("msgVpns", [])]

    @property
    def call_count(self) -> int:
        return self._calls


def sample_client() -> FakeSempClient:
    """A fake broker: 2 VPNs, full object-type coverage, one encoded name."""
    vpns = ["prod", "dev"]

    collections: dict[str, Rows] = {
        "msgVpns": [
            {
                "msgVpnName": "prod", "enabled": True, "maxMsgSpoolUsage": 60000,
                "authenticationBasicEnabled": True, "authenticationBasicType": "internal", "replicationEnabled": True,
                "replicationRole": "active", "serviceSmfPlainTextEnabled": True,
                "serviceMqttPlainTextEnabled": True, "serviceRestIncomingPlainTextEnabled": True,
            },
            {
                "msgVpnName": "dev", "enabled": True, "maxMsgSpoolUsage": 5000,
                "authenticationBasicEnabled": True, "authenticationBasicType": "internal", "replicationEnabled": False,
                "serviceSmfPlainTextEnabled": True,
            },
        ],
        "virtualHostnames": [
            {"virtualHostname": "prod.broker.example.com", "enabled": True, "msgVpnName": "prod"},
        ],
        "oauthProfiles": [
            {"oauthProfileName": "mgmt-azure", "enabled": True, "issuer": "https://login.example.com"},
        ],
        "clientCertAuthorities": [
            {"certAuthorityName": "corp-root-ca", "crlDayList": "daily", "revocationCheckEnabled": True},
        ],
        "domainCertAuthorities": [
            {"certAuthorityName": "public-root-ca"},
        ],
        "dmrClusters": [
            {"dmrClusterName": "emea-cluster", "enabled": True, "nodeName": "broker-1",
             "authenticationBasicEnabled": True, "tlsEnabled": True},
        ],
        "dmrClusters/emea-cluster/links": [
            {"remoteNodeName": "broker-2", "enabled": True, "span": "internal", "initiator": "local"},
        ],
        "dmrClusters/emea-cluster/links/broker-2/remoteAddresses": [
            {"remoteAddress": "broker-2.example.com:55555"},
        ],
    }

    def per_vpn(path: str, rows_by_vpn: Mapping[str, Rows]) -> None:
        for vpn in vpns:
            collections[f"msgVpns/{vpn}/{path}"] = list(rows_by_vpn.get(vpn, []))

    extra_children = {
        "msgVpns/dev/queues/BULK.LOAD/subscriptions": [],
        "msgVpns/dev/queues/SANDBOX.Q1/subscriptions": [],
        "msgVpns/dev/clientUsernames/default/attributes": [],
    }
    collections.update(extra_children)
    per_vpn("queues", {
        "prod": [
            {"queueName": "ORDERS.IN", "accessType": "exclusive", "egressEnabled": True,
             "ingressEnabled": True, "maxMsgSpoolUsage": 5000, "owner": "app-orders",
             "permission": "consume", "respectTtlEnabled": True, "maxRedeliveryCount": 3,
             "deadMsgQueue": "#DEAD_MSG_QUEUE", "maxBindCount": 100,
             "eventMsgSpoolUsageThreshold": {"clearPercent": 18, "setPercent": 25}},
            {"queueName": "billing/eu", "accessType": "non-exclusive", "egressEnabled": True,
             "ingressEnabled": True, "maxMsgSpoolUsage": 1500, "owner": "app-billing",
             "maxRedeliveryCount": 0,
             "permission": "consume", "maxBindCount": 10},
        ],
        "dev": [
            {"queueName": "BULK.LOAD", "accessType": "non-exclusive", "egressEnabled": True,
             "ingressEnabled": True, "maxMsgSpoolUsage": 8000, "owner": "dev-team",
             "permission": "delete"},
            {"queueName": "SANDBOX.Q1", "accessType": "exclusive", "egressEnabled": False,
             "ingressEnabled": True, "maxMsgSpoolUsage": 100, "owner": "dev-team",
             "permission": "delete"},
        ],
    })
    collections["msgVpns/prod/queues/ORDERS.IN/subscriptions"] = [
        {"subscriptionTopic": "orders/created/>"},
        {"subscriptionTopic": "orders/updated/>"},
    ]
    collections["msgVpns/prod/queues/billing%2Feu/subscriptions"] = [
        {"subscriptionTopic": "billing/eu/invoices/>"},
    ]
    collections["msgVpns/dev/queues/SANDBOX.Q1/subscriptions"] = []

    per_vpn("queueTemplates", {
        "prod": [{"queueTemplateName": "audit-queues", "accessType": "exclusive",
                  "queueNameFilter": "audit/>", "maxMsgSpoolUsage": 200}],
    })
    per_vpn("topicEndpoints", {
        "prod": [{"topicEndpointName": "TE.ANALYTICS", "accessType": "non-exclusive",
                  "owner": "app-analytics", "permission": "consume", "maxSpoolUsage": 800,
                  "respectTtlEnabled": False, "maxTtl": 60, "maxBindCount": 5}],
    })
    per_vpn("topicEndpointTemplates", {
        "prod": [{"topicEndpointTemplateName": "default-te", "maxSpoolUsage": 100}],
    })
    per_vpn("sequencedTopics", {"prod": [{"sequencedTopic": "audit/sequence/>"}]})
    per_vpn("authenticationOauthProfiles", {
        "prod": [{"oauthProfileName": "apps-oidc", "enabled": True,
                  "issuer": "https://idp.example.com", "oauthRole": "resource-server"}],
    })

    per_vpn("bridges", {
        "prod": [{"bridgeName": "b2b-partner", "bridgeVirtualRouter": "auto", "enabled": True,
                  "maxTtl": 8, "remoteAuthenticationScheme": "basic",
                  "remoteDeliverToOnePriority": "p1", "tlsEnabled": True}],
    })
    collections["msgVpns/prod/bridges/b2b-partner,auto/remoteMsgVpns"] = [
        {"remoteMsgVpnName": "partner-vpn", "remoteMsgVpnLocation": "203.0.113.9:55555",
         "remoteMsgVpnInterface": "", "enabled": True, "compressedDataEnabled": False,
         "queueBinding": "BRIDGE.INBOUND", "tlsEnabled": False, "egressFlowWindowSize": 255,
         "unidirectionalClientProfile": "#client-profile", "connectOrder": 1},
        {"remoteMsgVpnName": "partner-vpn", "remoteMsgVpnLocation": "partner-dr.example.com:55443",
         "remoteMsgVpnInterface": "", "enabled": True, "compressedDataEnabled": True,
         "queueBinding": "BRIDGE.INBOUND", "tlsEnabled": True, "egressFlowWindowSize": 255,
         "unidirectionalClientProfile": "#client-profile", "connectOrder": 2},
    ]
    collections["msgVpns/prod/bridges/b2b-partner,auto/remoteSubscriptions"] = [
        {"remoteSubscriptionTopic": "partner/orders/>", "deliverAlwaysEnabled": True},
        {"remoteSubscriptionTopic": "partner/invoices/>", "deliverAlwaysEnabled": False},
    ]

    per_vpn("clientUsernames", {
        "prod": [
            {"clientUsername": "app-orders", "enabled": True, "aclProfileName": "app-acl",
             "clientProfileName": "guaranteed", "guaranteedEndpointPermissionOverrideEnabled": False,
             "passwordExpiryEnabled": False},
            {"clientUsername": "app-billing", "enabled": True, "aclProfileName": "app-acl",
             "clientProfileName": "guaranteed"},
        ],
        "dev": [{"clientUsername": "default", "enabled": True, "aclProfileName": "default",
                 "clientProfileName": "default"},
                {"clientUsername": "dev-user", "enabled": True, "aclProfileName": "default",
                 "clientProfileName": "default"}],
    })
    collections["msgVpns/prod/clientUsernames/app-orders/attributes"] = [
        {"attributeName": "team", "attributeValue": "order-management"},
        {"attributeName": "cost-center", "attributeValue": "CC-1042"},
    ]
    collections["msgVpns/prod/clientUsernames/app-billing/attributes"] = []
    collections["msgVpns/dev/clientUsernames/dev-user/attributes"] = []

    per_vpn("clientProfiles", {
        "prod": [{"clientProfileName": "guaranteed", "allowGuaranteedMsgSendEnabled": True,
                  "allowGuaranteedMsgReceiveEnabled": True, "maxConnectionCountPerClientUsername": 10,
                  "serviceSmfMaxConnectionCountPerClientUsername": 10}],
        "dev": [{"clientProfileName": "default", "allowGuaranteedMsgSendEnabled": True,
                 "allowGuaranteedMsgReceiveEnabled": True}],
    })

    per_vpn("aclProfiles", {
        "prod": [{"aclProfileName": "app-acl", "clientConnectDefaultAction": "allow",
                  "publishTopicDefaultAction": "disallow", "subscribeTopicDefaultAction": "disallow"}],
        "dev": [{"aclProfileName": "default", "clientConnectDefaultAction": "allow",
                 "publishTopicDefaultAction": "allow", "subscribeTopicDefaultAction": "allow"}],
    })
    acl = "msgVpns/prod/aclProfiles/app-acl"
    collections[f"{acl}/publishTopicExceptions"] = [
        {"publishTopicExceptionSyntax": "smf", "publishTopicException": "orders/>"},
        {"publishTopicExceptionSyntax": "smf", "publishTopicException": "billing/eu/>"},
    ]
    collections[f"{acl}/subscribeTopicExceptions"] = [
        {"subscribeTopicExceptionSyntax": "smf", "subscribeTopicException": "orders/created/>"},
    ]
    collections[f"{acl}/subscribeShareNameExceptions"] = [
        {"subscribeShareNameExceptionSyntax": "smf", "subscribeShareNameException": "order-workers"},
    ]
    collections[f"{acl}/clientConnectExceptions"] = [
        {"clientConnectExceptionAddress": "10.20.0.0/16"},
    ]
    dev_acl = "msgVpns/dev/aclProfiles/default"
    for child in ("publishTopicExceptions", "subscribeTopicExceptions",
                  "subscribeShareNameExceptions", "clientConnectExceptions"):
        collections[f"{dev_acl}/{child}"] = []

    per_vpn("authorizationGroups", {
        "prod": [{"authorizationGroupName": "CN=solace-apps,OU=Groups,DC=example,DC=com",
                  "enabled": True, "aclProfileName": "app-acl", "clientProfileName": "guaranteed",
                  "orderAfterAuthorizationGroupName": ""}],
    })

    per_vpn("replayLogs", {
        "prod": [{"replayLogName": "audit-replay", "egressEnabled": True,
                  "ingressEnabled": True, "maxSpoolUsage": 10000}],
    })
    collections["msgVpns/prod/replayLogs/audit-replay/topicFilterSubscriptions"] = [
        {"topicFilterSubscription": "orders/>"},
    ]

    per_vpn("dmrBridges", {
        "prod": [{"remoteNodeName": "broker-2", "remoteMsgVpnName": "prod", "enabled": True}],
    })

    per_vpn("mqttSessions", {
        "prod": [{"mqttSessionClientId": "sensor-gateway-01", "mqttSessionVirtualRouter": "primary",
                  "enabled": True, "owner": "app-orders", "queueMaxMsgSpoolUsage": 250}],
    })
    collections["msgVpns/prod/mqttSessions/sensor-gateway-01,primary/subscriptions"] = [
        {"subscriptionTopic": "factory/+/telemetry", "subscriptionQos": 1},
    ]
    per_vpn("mqttRetainCaches", {
        "prod": [{"mqttRetainCacheName": "default-retain", "enabled": True, "msgLifetime": 0}],
    })

    per_vpn("restDeliveryPoints", {
        "prod": [{"restDeliveryPointName": "webhook-rdp", "enabled": True,
                  "clientProfileName": "guaranteed"}],
    })
    rdp = "msgVpns/prod/restDeliveryPoints/webhook-rdp"
    collections[f"{rdp}/restConsumers"] = [
        {"restConsumerName": "orders-webhook", "enabled": True,
         "remoteHost": "hooks.example.com", "remotePort": 443, "tlsEnabled": True,
         "httpMethod": "post", "outgoingConnectionCount": 3},
    ]
    collections[f"{rdp}/queueBindings"] = [
        {"queueBindingName": "ORDERS.IN", "postRequestTarget": "/v1/orders", "gatewayReplaceTargetAuthorityEnabled": False},
    ]
    collections[f"{rdp}/queueBindings/ORDERS.IN/requestHeaders"] = [
        {"headerName": "X-Source", "headerValue": "solace-prod"},
    ]

    per_vpn("jndiConnectionFactories", {
        "prod": [{"connectionFactoryName": "/jms/cf/orders", "guaranteedReceiveWindowSize": 18,
                  "transportConnectRetryCount": 5}],
    })
    per_vpn("jndiQueues", {
        "prod": [{"queueName": "/jms/queue/orders", "physicalName": "ORDERS.IN"}],
    })
    per_vpn("jndiTopics", {
        "prod": [{"topicName": "/jms/topic/orders", "physicalName": "orders/created"}],
    })

    per_vpn("replicatedTopics", {
        "prod": [{"replicatedTopic": "orders/>", "replicationMode": "sync"}],
    })

    # distributedCaches deliberately unmapped -> exercises graceful skipping.

    objects = {
        "": {  # the broker object itself
            "authClientCertRevocationCheckMode": "none",
            "guaranteedMsgingEnabled": True,
            "guaranteedMsgingMaxMsgSpoolUsage": 100000,
            "serviceAmqpEnabled": True,
            "serviceMqttEnabled": True,
            "serviceRestEventOutgoingConnectionCountMax": 100,
            "serviceSempPlainTextListenPort": 8080,
            "serviceSempTlsListenPort": 1943,
            "serviceSmfEnabled": True,
            "tlsBlockVersion11Enabled": True,
        },
    }

    return FakeSempClient(collections, objects)
