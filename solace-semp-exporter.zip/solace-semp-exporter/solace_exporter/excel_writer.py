"""Excel workbook writer.

Produces a professional, audit-ready workbook:

* visible **Summary** cover sheet (connection, broker, run statistics,
  per-sheet row counts, skipped endpoints, errors)
* one worksheet per exported collection, formatted as an Excel *Table*
  (bold header, autofilter, banded rows), frozen header row, sensible
  column widths
* hidden ``_metadata`` sheet carrying the redacted run configuration as
  JSON for tooling / diffing
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from dataclasses import asdict
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.worksheet import Worksheet

from .exceptions import ExcelWriteError
from .models import ExportMetadata, ExportResult, SheetData
from .utils.logging import get_logger
if TYPE_CHECKING:  # pragma: no cover - typing only, avoids import cycle
    from .compare import VpnComparison

from .utils.text import (
    clean_cell,
    dedupe_headers,
    humanize_header,
    sanitize_sheet_name,
    table_display_name,
    unique_name,
)

log = get_logger("excel")

FONT_NAME = "Arial"
MAX_DATA_ROWS = 1_048_575  # Excel limit minus the header row
_TABLE_STYLE = TableStyleInfo(
    name="TableStyleMedium9",
    showFirstColumn=False,
    showLastColumn=False,
    showRowStripes=True,
    showColumnStripes=False,
)

_TITLE_FONT = Font(name=FONT_NAME, size=16, bold=True, color="1F4E79")
_H2_FONT = Font(name=FONT_NAME, size=12, bold=True, color="1F4E79")
_LABEL_FONT = Font(name=FONT_NAME, size=10, bold=True)
_BODY_FONT = Font(name=FONT_NAME, size=10)
_HEADER_FONT = Font(name=FONT_NAME, size=10, bold=True, color="FFFFFF")
_HEADER_FILL = PatternFill("solid", fgColor="1F4E79")


def write_workbook(
    path: Path,
    sheets: list[SheetData],
    metadata: ExportMetadata,
    result: ExportResult,
    *,
    friendly_headers: bool = True,
) -> Path:
    """Write the complete workbook to ``path`` and return it.

    ``friendly_headers`` renders SEMP camelCase attribute names as spaced
    Title Case with canonical acronyms (``maxMsgSpoolUsage`` ->
    ``Max Msg Spool Usage``); pass ``False`` (CLI ``--raw-headers``) to keep
    the raw SEMP names for 1:1 traceability with the official API docs.
    """
    try:
        return _write(path, sheets, metadata, result, friendly_headers)
    except ExcelWriteError:
        raise
    except OSError as exc:
        raise ExcelWriteError(f"Cannot write workbook {path}: {exc}") from exc


def _write(
    path: Path,
    sheets: list[SheetData],
    metadata: ExportMetadata,
    result: ExportResult,
    friendly_headers: bool,
) -> Path:
    workbook = Workbook()
    summary = workbook.active
    summary.title = "Summary"

    taken_names = {"Summary", "_metadata"}
    taken_tables: set[str] = set()
    written: list[tuple[str, SheetData]] = []

    for sheet in sheets:
        name = unique_name(sanitize_sheet_name(sheet.name), taken_names)
        taken_names.add(name)
        worksheet = workbook.create_sheet(title=name)
        _write_data_sheet(worksheet, sheet.frame, taken_tables, friendly_headers)
        written.append((name, sheet))
        log.debug("Sheet %-31s %6d rows x %d cols", name, sheet.rows, sheet.columns)

    _write_summary(summary, metadata, result, written)
    _write_metadata_sheet(workbook, metadata)

    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)
    log.info("Workbook written: %s (%d data sheets)", path, len(written))
    return path


# --------------------------------------------------------------------------- #
# Data sheets
# --------------------------------------------------------------------------- #
def _write_data_sheet(
    worksheet: Worksheet,
    frame: pd.DataFrame,
    taken_tables: set[str],
    friendly_headers: bool = True,
) -> None:
    if len(frame) > MAX_DATA_ROWS:
        raise ExcelWriteError(
            f"Sheet {worksheet.title!r} has {len(frame)} rows; Excel allows "
            f"{MAX_DATA_ROWS}. Re-run with --vpn filters to split the export."
        )

    columns = [str(c) for c in frame.columns] or ["(empty)"]
    if friendly_headers:
        columns = [humanize_header(c) for c in columns]
    columns = dedupe_headers(columns)
    worksheet.append(columns)
    for cell in worksheet[1]:
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = Alignment(vertical="center")

    widths = [len(c) for c in columns]
    for record in frame.itertuples(index=False, name=None):
        row = [clean_cell(value) for value in record]
        worksheet.append(row)
        for index, value in enumerate(row):
            if value is not None:
                length = len(str(value))
                if length > widths[index]:
                    widths[index] = length

    for index, width in enumerate(widths, start=1):
        letter = get_column_letter(index)
        worksheet.column_dimensions[letter].width = max(10, min(width + 2, 60))

    worksheet.freeze_panes = "A2"

    if len(frame) and len(frame.columns):
        ref = f"A1:{get_column_letter(len(columns))}{len(frame) + 1}"
        table = Table(displayName=table_display_name(worksheet.title, taken_tables), ref=ref)
        table.tableStyleInfo = _TABLE_STYLE
        worksheet.add_table(table)
    else:
        # Empty collection: keep a styled header + autofilter, note emptiness.
        worksheet.auto_filter.ref = f"A1:{get_column_letter(len(columns))}1"

    for row in worksheet.iter_rows(min_row=2):
        for cell in row:
            cell.font = _BODY_FONT


# --------------------------------------------------------------------------- #
# Summary sheet
# --------------------------------------------------------------------------- #
def _write_summary(
    worksheet: Worksheet,
    metadata: ExportMetadata,
    result: ExportResult,
    written: list[tuple[str, SheetData]],
) -> None:
    worksheet.sheet_view.showGridLines = False

    def put(row: int, col: int, value: object, font: Font = _BODY_FONT) -> None:
        cell = worksheet.cell(row=row, column=col, value=clean_cell(value))
        cell.font = font

    put(1, 1, "Solace SEMP Configuration Export", _TITLE_FONT)

    info: list[tuple[str, object]] = [
        ("Host", metadata.host),
        ("SEMP base URL", metadata.base_url),
        ("SEMP version", metadata.semp_version),
        ("Platform", metadata.platform),
        ("Generated", metadata.generated_at.strftime("%Y-%m-%d %H:%M:%S")),
        ("Tool version", metadata.tool_version),
        ("Scopes", ", ".join(metadata.scopes) or "all"),
        ("VPN filter", ", ".join(metadata.vpn_filter) or "(all VPNs)"),
        ("VPN count", metadata.vpn_count),
        ("Worksheets", len(written)),
        ("Total rows", result.total_rows),
        ("API calls", result.api_calls),
        ("Duration (s)", round(result.duration_s, 1)),
    ]
    row = 3
    for label, value in info:
        put(row, 1, label, _LABEL_FONT)
        put(row, 2, value)
        row += 1

    row += 1
    put(row, 1, "Worksheet statistics", _H2_FONT)
    row += 1
    for col, header in enumerate(("Sheet", "Rows", "Columns", "SEMP endpoint"), start=1):
        cell = worksheet.cell(row=row, column=col, value=header)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
    for name, sheet in written:
        row += 1
        put(row, 1, name)
        put(row, 2, sheet.rows)
        put(row, 3, sheet.columns)
        put(row, 4, sheet.endpoint or "/")

    if result.skipped:
        row += 2
        put(row, 1, "Skipped endpoints (not available on this broker/edition)", _H2_FONT)
        row += 1
        for col, header in enumerate(("Sheet", "SEMP endpoint", "Reason"), start=1):
            cell = worksheet.cell(row=row, column=col, value=header)
            cell.font = _HEADER_FONT
            cell.fill = _HEADER_FILL
        for skip in result.skipped:
            row += 1
            put(row, 1, skip.sheet)
            put(row, 2, skip.endpoint)
            put(row, 3, skip.reason)

    if result.errors:
        row += 2
        put(row, 1, "Errors", _H2_FONT)
        for error in result.errors:
            row += 1
            put(row, 1, error)

    for column, width in (("A", 34), ("B", 52), ("C", 12), ("D", 64)):
        worksheet.column_dimensions[column].width = width
    worksheet.freeze_panes = "A2"


# --------------------------------------------------------------------------- #
# Hidden metadata sheet
# --------------------------------------------------------------------------- #
def _write_metadata_sheet(workbook: Workbook, metadata: ExportMetadata) -> None:
    worksheet = workbook.create_sheet(title="_metadata")
    payload = asdict(metadata)
    payload["generated_at"] = metadata.generated_at.isoformat()
    worksheet["A1"] = "solace-semp-exporter run metadata (machine readable JSON; concatenate A2:A_n)"
    worksheet["A1"].font = _LABEL_FONT
    text = json.dumps(payload, indent=2, default=str)
    chunk_size = 30_000  # Excel caps a cell at 32,767 characters
    for index in range(0, max(len(text), 1), chunk_size):
        cell = worksheet.cell(row=2 + index // chunk_size, column=1, value=text[index : index + chunk_size])
        cell.alignment = Alignment(vertical="top", wrap_text=True)
    worksheet.column_dimensions["A"].width = 100
    worksheet.sheet_state = "hidden"


# --------------------------------------------------------------------------- #
# VPN comparison workbook
# --------------------------------------------------------------------------- #
_STATUS_FILLS: dict[str, PatternFill] = {
    "different": PatternFill("solid", fgColor="FFF2CC"),  # amber
    "only_a": PatternFill("solid", fgColor="FDE9D9"),     # orange tint
    "only_b": PatternFill("solid", fgColor="DCE6F1"),     # blue tint
}


def write_comparison_workbook(
    path: Path,
    comparison: "VpnComparison",
    metadata: ExportMetadata,
    *,
    friendly_headers: bool = True,
) -> Path:
    """Write the A-vs-B VPN comparison audit workbook.

    Layout: a ``Summary`` sheet with per-object-type statistics for *every*
    compared type, followed by one delta sheet per object type that actually
    has differences (status-tinted rows: only-in-A orange, only-in-B blue,
    attribute deltas amber), plus the hidden ``_metadata`` sheet.
    """
    try:
        return _write_comparison(path, comparison, metadata, friendly_headers)
    except ExcelWriteError:
        raise
    except OSError as exc:
        raise ExcelWriteError(f"Cannot write comparison workbook {path}: {exc}") from exc


def _write_comparison(
    path: Path,
    comparison: "VpnComparison",
    metadata: ExportMetadata,
    friendly_headers: bool,
) -> Path:
    workbook = Workbook()
    summary = workbook.active
    summary.title = "Summary"

    taken_names = {"Summary", "_metadata"}
    taken_tables: set[str] = set()
    for outcome in comparison.delta_types:
        name = unique_name(sanitize_sheet_name(outcome.sheet), taken_names)
        taken_names.add(name)
        worksheet = workbook.create_sheet(title=name)
        # Frames are already display-ready (friendly attribute names inside the
        # Attribute column, literal VPN names as value-column headers), so raw
        # header mode avoids mangling e.g. a VPN called "prod" into "Prod".
        _write_data_sheet(worksheet, outcome.frame, taken_tables, friendly_headers=False)
        _tint_status_column(worksheet, comparison)
        log.debug("Delta sheet %-31s %5d rows", name, len(outcome.frame))

    _write_comparison_summary(summary, metadata, comparison)
    _write_metadata_sheet(workbook, metadata)

    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)
    log.info(
        "Comparison workbook written: %s (%d object types, %d with deltas)",
        path, len(comparison.types), len(comparison.delta_types),
    )
    return path


def _tint_status_column(worksheet: Worksheet, comparison: "VpnComparison") -> None:
    only_a = f"Only in {comparison.vpn_a}"
    for row in range(2, worksheet.max_row + 1):
        cell = worksheet.cell(row=row, column=1)
        value = str(cell.value or "")
        if value == "Different":
            cell.fill = _STATUS_FILLS["different"]
        elif value == only_a:
            cell.fill = _STATUS_FILLS["only_a"]
        elif value.startswith("Only in "):
            cell.fill = _STATUS_FILLS["only_b"]


def _write_comparison_summary(
    worksheet: Worksheet,
    metadata: ExportMetadata,
    comparison: "VpnComparison",
) -> None:
    worksheet.sheet_view.showGridLines = False

    def put(row: int, col: int, value: object, font: Font = _BODY_FONT) -> None:
        cell = worksheet.cell(row=row, column=col, value=clean_cell(value))
        cell.font = font

    put(1, 1, "Solace VPN Comparison - Audit Report", _TITLE_FONT)

    info: list[tuple[str, object]] = [
        ("VPN A", comparison.vpn_a),
        ("VPN B", comparison.vpn_b),
        ("Host", metadata.host),
        ("SEMP base URL", metadata.base_url),
        ("SEMP version", metadata.semp_version),
        ("Platform", metadata.platform),
        ("Generated", metadata.generated_at.strftime("%Y-%m-%d %H:%M:%S")),
        ("Tool version", metadata.tool_version),
        ("Scopes", ", ".join(metadata.scopes) or "all"),
        ("Ignored attributes", ", ".join(comparison.ignored) or "(none)"),
        ("Object types compared", len(comparison.types)),
        ("Object types with deltas", len(comparison.delta_types)),
        ("Total deltas", comparison.total_deltas),
    ]
    row = 3
    for label, value in info:
        put(row, 1, label, _LABEL_FONT)
        put(row, 2, value)
        row += 1

    row += 1
    put(row, 1, "Per object type", _H2_FONT)
    row += 1
    headers = (
        "Object Type", f"{comparison.vpn_a} objects", f"{comparison.vpn_b} objects",
        f"Only in {comparison.vpn_a}", f"Only in {comparison.vpn_b}",
        "Different", "Identical", "Match",
    )
    for col, header in enumerate(headers, start=1):
        cell = worksheet.cell(row=row, column=col, value=header)
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
    for outcome in comparison.types:
        row += 1
        put(row, 1, outcome.sheet, _LABEL_FONT if outcome.has_deltas else _BODY_FONT)
        for col, value in enumerate(
            (outcome.count_a, outcome.count_b, outcome.only_a, outcome.only_b,
             outcome.different, outcome.identical, f"{outcome.match_pct:.1f}%"),
            start=2,
        ):
            put(row, col, value)
        if outcome.has_deltas:
            worksheet.cell(row=row, column=1).fill = _STATUS_FILLS["different"]
    row += 1
    put(row, 1, "TOTAL", _H2_FONT)
    for col, value in enumerate(
        (sum(t.count_a for t in comparison.types), sum(t.count_b for t in comparison.types),
         comparison.total_only_a, comparison.total_only_b,
         comparison.total_different, comparison.total_identical, ""),
        start=2,
    ):
        put(row, col, value, _LABEL_FONT)

    widths = (34, 16, 16, 16, 16, 12, 12, 10)
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = width
    worksheet.freeze_panes = "A2"
