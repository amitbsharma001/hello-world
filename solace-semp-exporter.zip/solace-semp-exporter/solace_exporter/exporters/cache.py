"""Distributed Cache specs (SolCache).

Hierarchy::

    Distributed Cache -> Home Cluster -> Topic Prefixes
                                      -> Global Caching Home Clusters -> Topic Prefixes
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

CACHE_PREFIX = f"{VPN_PREFIX}/distributedCaches/{{cacheName}}"
CLUSTER_PREFIX = f"{CACHE_PREFIX}/clusters/{{clusterName}}"

CACHE_CLUSTER_TOPICS = CollectionSpec(
    key="caches.clusters.topics",
    sheet="Cache Cluster Topics",
    path=f"{CLUSTER_PREFIX}/topics",
    id_fields=("topic",),
    friendly={"topic": "Cached Topic"},
)

CACHE_GLOBAL_HOME_TOPIC_PREFIXES = CollectionSpec(
    key="caches.clusters.globalHomes.topicPrefixes",
    sheet="Cache GCH Topic Prefixes",
    path=(
        f"{CLUSTER_PREFIX}/globalCachingHomeClusters/"
        "{homeClusterName}/topicPrefixes"
    ),
    id_fields=("topicPrefix",),
    friendly={"topicPrefix": "Topic Prefix"},
)

CACHE_GLOBAL_HOME_CLUSTERS = CollectionSpec(
    key="caches.clusters.globalHomes",
    sheet="Cache Global Home Clusters",
    path=f"{CLUSTER_PREFIX}/globalCachingHomeClusters",
    id_fields=("homeClusterName",),
    friendly={"homeClusterName": "Home Cluster"},
    children=(CACHE_GLOBAL_HOME_TOPIC_PREFIXES,),
)

CACHE_CLUSTERS = CollectionSpec(
    key="caches.clusters",
    sheet="Cache Clusters",
    path=f"{CACHE_PREFIX}/clusters",
    id_fields=("clusterName",),
    friendly={"clusterName": "Cache Cluster"},
    children=(CACHE_CLUSTER_TOPICS, CACHE_GLOBAL_HOME_CLUSTERS),
)

DISTRIBUTED_CACHES = CollectionSpec(
    key="caches",
    sheet="Distributed Caches",
    path=f"{VPN_PREFIX}/distributedCaches",
    id_fields=("cacheName",),
    friendly={"cacheName": "Cache"},
    children=(CACHE_CLUSTERS,),
    per_vpn=True,
)
