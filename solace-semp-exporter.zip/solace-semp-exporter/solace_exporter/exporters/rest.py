"""REST Delivery Point specs.

Hierarchy: ``RDP -> REST Consumers`` and ``RDP -> Queue Bindings -> Request
Headers``. Every child sheet carries ``VPN | RDP | ...`` identity columns.
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

RDP_PREFIX = f"{VPN_PREFIX}/restDeliveryPoints/{{restDeliveryPointName}}"

REST_CONSUMERS = CollectionSpec(
    key="rdps.restConsumers",
    sheet="REST Consumers",
    path=f"{RDP_PREFIX}/restConsumers",
    id_fields=("restConsumerName",),
    friendly={"restConsumerName": "REST Consumer"},
)

RDP_QUEUE_BINDING_REQUEST_HEADERS = CollectionSpec(
    key="rdps.queueBindings.requestHeaders",
    sheet="RDP Binding Req Headers",
    path=f"{RDP_PREFIX}/queueBindings/{{queueBindingName}}/requestHeaders",
    id_fields=("headerName",),
    friendly={"headerName": "Header"},
)

RDP_QUEUE_BINDINGS = CollectionSpec(
    key="rdps.queueBindings",
    sheet="RDP Queue Bindings",
    path=f"{RDP_PREFIX}/queueBindings",
    id_fields=("queueBindingName",),
    friendly={"queueBindingName": "Queue Binding"},
    children=(RDP_QUEUE_BINDING_REQUEST_HEADERS,),
)

REST_DELIVERY_POINTS = CollectionSpec(
    key="rdps",
    sheet="REST Delivery Points",
    path=f"{VPN_PREFIX}/restDeliveryPoints",
    id_fields=("restDeliveryPointName",),
    friendly={"restDeliveryPointName": "RDP"},
    children=(REST_CONSUMERS, RDP_QUEUE_BINDINGS),
    per_vpn=True,
)
