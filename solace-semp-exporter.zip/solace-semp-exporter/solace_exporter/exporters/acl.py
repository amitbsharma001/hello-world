"""ACL profile specs: profiles plus every exception collection, each row
prefixed with ``VPN | ACL Profile`` so exceptions are audit-ready."""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

_ACL_PATH = f"{VPN_PREFIX}/aclProfiles/{{aclProfileName}}"

ACL_PUBLISH_EXCEPTIONS = CollectionSpec(
    key="aclProfiles.publishTopicExceptions",
    sheet="ACL Publish Exceptions",
    path=f"{_ACL_PATH}/publishTopicExceptions",
    id_fields=("publishTopicExceptionSyntax", "publishTopicException"),
    friendly={
        "publishTopicExceptionSyntax": "Syntax",
        "publishTopicException": "Publish Topic Exception",
    },
)

ACL_SUBSCRIBE_EXCEPTIONS = CollectionSpec(
    key="aclProfiles.subscribeTopicExceptions",
    sheet="ACL Subscribe Exceptions",
    path=f"{_ACL_PATH}/subscribeTopicExceptions",
    id_fields=("subscribeTopicExceptionSyntax", "subscribeTopicException"),
    friendly={
        "subscribeTopicExceptionSyntax": "Syntax",
        "subscribeTopicException": "Subscribe Topic Exception",
    },
)

ACL_SHARE_NAME_EXCEPTIONS = CollectionSpec(
    key="aclProfiles.subscribeShareNameExceptions",
    sheet="ACL Share Name Exceptions",
    path=f"{_ACL_PATH}/subscribeShareNameExceptions",
    id_fields=("subscribeShareNameExceptionSyntax", "subscribeShareNameException"),
    friendly={
        "subscribeShareNameExceptionSyntax": "Syntax",
        "subscribeShareNameException": "Share Name Exception",
    },
)

ACL_CONNECT_EXCEPTIONS = CollectionSpec(
    key="aclProfiles.clientConnectExceptions",
    sheet="ACL Connect Exceptions",
    path=f"{_ACL_PATH}/clientConnectExceptions",
    id_fields=("clientConnectExceptionAddress",),
    friendly={"clientConnectExceptionAddress": "Connect Exception Address"},
)

ACL_PROFILES = CollectionSpec(
    key="aclProfiles",
    sheet="ACL Profiles",
    path=f"{VPN_PREFIX}/aclProfiles",
    id_fields=("aclProfileName",),
    friendly={"aclProfileName": "ACL Profile"},
    children=(
        ACL_PUBLISH_EXCEPTIONS,
        ACL_SUBSCRIBE_EXCEPTIONS,
        ACL_SHARE_NAME_EXCEPTIONS,
        ACL_CONNECT_EXCEPTIONS,
    ),
    per_vpn=True,
)
