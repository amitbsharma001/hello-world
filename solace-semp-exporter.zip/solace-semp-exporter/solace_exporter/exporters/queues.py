"""Queue specs: queues with their topic subscriptions, plus queue templates.

Queue Subscriptions is the canonical hierarchy example: each row carries
``VPN | Queue | Subscription Topic`` rather than a bare topic string.
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

QUEUE_SUBSCRIPTIONS = CollectionSpec(
    key="queues.subscriptions",
    sheet="Queue Subscriptions",
    path=f"{VPN_PREFIX}/queues/{{queueName}}/subscriptions",
    id_fields=("subscriptionTopic",),
    friendly={"subscriptionTopic": "Subscription Topic"},
)

QUEUES = CollectionSpec(
    key="queues",
    sheet="Queues",
    path=f"{VPN_PREFIX}/queues",
    id_fields=("queueName",),
    friendly={"queueName": "Queue"},
    children=(QUEUE_SUBSCRIPTIONS,),
    per_vpn=True,
)

QUEUE_TEMPLATES = CollectionSpec(
    key="queueTemplates",
    sheet="Queue Templates",
    path=f"{VPN_PREFIX}/queueTemplates",
    id_fields=("queueTemplateName",),
    friendly={"queueTemplateName": "Queue Template"},
    per_vpn=True,
)
