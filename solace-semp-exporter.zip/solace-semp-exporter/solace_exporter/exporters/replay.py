"""Replay log specs: logs plus their topic filter subscriptions."""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

REPLAY_LOG_TOPIC_FILTERS = CollectionSpec(
    key="replayLogs.topicFilterSubscriptions",
    sheet="Replay Log Topic Filters",
    path=f"{VPN_PREFIX}/replayLogs/{{replayLogName}}/topicFilterSubscriptions",
    id_fields=("topicFilterSubscription",),
    friendly={"topicFilterSubscription": "Topic Filter"},
)

REPLAY_LOGS = CollectionSpec(
    key="replayLogs",
    sheet="Replay Logs",
    path=f"{VPN_PREFIX}/replayLogs",
    id_fields=("replayLogName",),
    friendly={"replayLogName": "Replay Log"},
    children=(REPLAY_LOG_TOPIC_FILTERS,),
    per_vpn=True,
)
