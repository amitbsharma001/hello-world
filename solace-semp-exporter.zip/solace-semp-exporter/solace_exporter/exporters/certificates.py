"""Certificate authority specs.

Uses the modern split collections (``clientCertAuthorities`` /
``domainCertAuthorities``); the deprecated combined ``certAuthorities``
endpoint is intentionally not queried. Older brokers that only expose the
deprecated endpoint simply record these sheets as skipped.
"""

from __future__ import annotations

from ..models import CollectionSpec

CLIENT_CERT_AUTHORITIES = CollectionSpec(
    key="clientCertAuthorities",
    sheet="Client Cert Authorities",
    path="clientCertAuthorities",
    id_fields=("certAuthorityName",),
    friendly={"certAuthorityName": "Cert Authority"},
)

DOMAIN_CERT_AUTHORITIES = CollectionSpec(
    key="domainCertAuthorities",
    sheet="Domain Cert Authorities",
    path="domainCertAuthorities",
    id_fields=("certAuthorityName",),
    friendly={"certAuthorityName": "Cert Authority"},
)
