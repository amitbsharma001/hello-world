"""Broker-level service specs.

* ``Broker`` - the single broker object: global service ports/enablement
  (SMF, AMQP, MQTT, REST, web transport), TLS config, spool sizing, etc.
* ``Virtual Hostnames`` - hostname -> VPN routing for multi-tenant access.
* ``Mgmt OAuth Profiles`` - broker management-plane OAuth profiles.

High Availability / redundancy status is only observable through the SEMP
*monitor* API, which is out of scope for a *config* export; the README
documents this limitation.
"""

from __future__ import annotations

from ..models import CollectionSpec

BROKER = CollectionSpec(
    key="broker",
    sheet="Broker",
    path="",  # /SEMP/v2/config itself is the broker object
    id_fields=(),
    single=True,
    transpose=True,
)

VIRTUAL_HOSTNAMES = CollectionSpec(
    key="virtualHostnames",
    sheet="Virtual Hostnames",
    path="virtualHostnames",
    id_fields=("virtualHostname",),
    friendly={"virtualHostname": "Virtual Hostname"},
)

MGMT_OAUTH_PROFILES = CollectionSpec(
    key="oauthProfiles",
    sheet="Mgmt OAuth Profiles",
    path="oauthProfiles",
    id_fields=("oauthProfileName",),
    friendly={"oauthProfileName": "OAuth Profile"},
)
