"""MQTT specs: configured sessions with their subscriptions, retain caches."""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

MQTT_SESSION_SUBSCRIPTIONS = CollectionSpec(
    key="mqttSessions.subscriptions",
    sheet="MQTT Session Subscriptions",
    path=(
        f"{VPN_PREFIX}/mqttSessions/"
        "{mqttSessionClientId},{mqttSessionVirtualRouter}/subscriptions"
    ),
    id_fields=("subscriptionTopic",),
    friendly={"subscriptionTopic": "Subscription Topic"},
)

MQTT_SESSIONS = CollectionSpec(
    key="mqttSessions",
    sheet="MQTT Sessions",
    path=f"{VPN_PREFIX}/mqttSessions",
    id_fields=("mqttSessionClientId", "mqttSessionVirtualRouter"),
    friendly={
        "mqttSessionClientId": "MQTT Client Id",
        "mqttSessionVirtualRouter": "Virtual Router",
    },
    children=(MQTT_SESSION_SUBSCRIPTIONS,),
    per_vpn=True,
)

MQTT_RETAIN_CACHES = CollectionSpec(
    key="mqttRetainCaches",
    sheet="MQTT Retain Caches",
    path=f"{VPN_PREFIX}/mqttRetainCaches",
    id_fields=("mqttRetainCacheName",),
    friendly={"mqttRetainCacheName": "Retain Cache"},
    per_vpn=True,
)
