"""Exporter framework.

:class:`BaseExporter` defines the four-phase contract every exporter follows::

    fetch() -> resolve_relationships() -> flatten() -> export()

:class:`TreeExporter` is the generic, spec-driven implementation used for all
built-in object types. It walks a :class:`CollectionSpec` tree breadth-first,
fetching each level's contexts concurrently on a shared thread pool, then
flattens every collection into a DataFrame whose leading columns are the full
ancestor identity chain (``VPN | Bridge | Remote VPN | ...``).

Adding a new object type therefore usually means *declaring a spec*, not
writing code; subclass :class:`BaseExporter` directly only when an endpoint
needs bespoke fetching or post-processing.
"""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod
from collections import deque
from concurrent.futures import Executor
from dataclasses import dataclass, field
from typing import Any, Callable

import pandas as pd

from ..exceptions import SempNotAvailableError
from ..models import CollectionSpec, SheetData, SkipInfo
from ..semp_client import SempClientProtocol
from ..utils.flatten import flatten_record
from ..utils.logging import get_logger
from ..utils.text import render_path

log = get_logger("exporter")

GLOBAL_FRIENDLY = {"msgVpnName": "VPN"}

Rows = list[tuple[dict[str, Any], dict[str, Any]]]  # (context, payload) pairs


@dataclass
class ProgressHook:
    """Callbacks the orchestrator wires to a rich progress bar."""

    announce: Callable[[str], None] = lambda text: None
    add_total: Callable[[int], None] = lambda n: None
    advance: Callable[[int], None] = lambda n: None


@dataclass
class RunContext:
    """Everything an exporter needs at run time (dependency injection)."""

    client: SempClientProtocol
    pool: Executor
    vpns: tuple[str, ...]
    progress: ProgressHook = field(default_factory=ProgressHook)
    cached_rows: dict[str, Rows] | None = None  # pre-fetched rows for resume


@dataclass
class ExporterOutput:
    sheets: list[SheetData] = field(default_factory=list)
    skipped: list[SkipInfo] = field(default_factory=list)
    raw_rows: dict[str, Rows] = field(default_factory=dict)  # for checkpointing


class BaseExporter(ABC):
    """Contract for all exporters (SOLID: open for extension via subclassing)."""

    #: Human-readable name shown in progress output.
    name: str = "exporter"

    @abstractmethod
    def fetch(self, ctx: RunContext) -> None:
        """Download raw data from the broker (or load it from cache)."""

    @abstractmethod
    def resolve_relationships(self, ctx: RunContext) -> None:
        """Ensure every child row carries its full ancestor identity."""

    @abstractmethod
    def flatten(self, ctx: RunContext) -> list[SheetData]:
        """Produce one hierarchy-flattened DataFrame per worksheet."""

    def export(self, ctx: RunContext) -> ExporterOutput:
        """Template method executing the full pipeline."""
        self.fetch(ctx)
        self.resolve_relationships(ctx)
        sheets = self.flatten(ctx)
        return ExporterOutput(sheets=sheets, skipped=self.skipped, raw_rows=self.raw_rows)

    # Populated by implementations:
    skipped: list[SkipInfo]
    raw_rows: dict[str, Rows]


class TreeExporter(BaseExporter):
    """Generic exporter driven entirely by a :class:`CollectionSpec` tree."""

    def __init__(self, root: CollectionSpec) -> None:
        self.root = root
        self.name = root.sheet
        self.raw_rows = {}
        self.skipped = []
        self._friendly: dict[str, dict[str, str]] = {}

    # ------------------------------------------------------------------ #
    # fetch
    # ------------------------------------------------------------------ #
    def fetch(self, ctx: RunContext) -> None:
        if ctx.cached_rows is not None:
            self.raw_rows = ctx.cached_rows
            self._compute_friendly()
            done = sum(len(v) for v in self.raw_rows.values())
            ctx.progress.announce(f"Loaded {self.name} from resume cache")
            ctx.progress.add_total(1)
            ctx.progress.advance(1)
            log.info("%s: resumed %d cached rows", self.name, done)
            return

        self._compute_friendly()
        root_contexts: list[dict[str, Any]]
        if self.root.per_vpn:
            root_contexts = [{"msgVpnName": vpn} for vpn in ctx.vpns]
        else:
            root_contexts = [{}]

        work: deque[tuple[CollectionSpec, list[dict[str, Any]]]] = deque([(self.root, root_contexts)])
        while work:
            spec, contexts = work.popleft()
            if not contexts:
                self.raw_rows.setdefault(spec.key, [])
                continue
            ctx.progress.announce(f"Downloading {spec.sheet}...")
            ctx.progress.add_total(len(contexts))
            pairs, unavailable = self._fetch_level(ctx, spec, contexts)
            self.raw_rows[spec.key] = pairs
            if unavailable is not None and not pairs:
                self._record_skip(spec, unavailable, ctx)
                continue  # children of an unavailable collection are moot
            if unavailable is not None:
                log.warning("%s: some parents unavailable: %s", spec.key, unavailable)
            for child in spec.children:
                work.append((child, self._child_contexts(spec, pairs)))

    def _fetch_level(
        self, ctx: RunContext, spec: CollectionSpec, contexts: list[dict[str, Any]]
    ) -> tuple[Rows, str | None]:
        """Fetch one spec across all contexts concurrently on the shared pool.

        Two failure modes are told apart via
        :attr:`SempNotAvailableError.endpoint_missing`:

        * the *collection* is not supported on this broker (``INVALID_PATH`` /
          ``NOT_ALLOWED`` / untagged 400): a shared event short-circuits every
          remaining context so an unsupported child endpoint costs O(workers)
          requests instead of one per parent;
        * a single *parent object* vanished mid-export (``NOT_FOUND``/404):
          logged and tolerated - its siblings still export.
        """
        endpoint_dead = threading.Event()
        dead_reasons: list[str] = []

        def fetch_one(walk_ctx: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]] | None]:
            try:
                if endpoint_dead.is_set():
                    return walk_ctx, None
                path = render_path(spec.path, walk_ctx)
                try:
                    if spec.single:
                        data = ctx.client.get_object(path)
                        return walk_ctx, ([data] if data else [])
                    return walk_ctx, ctx.client.get_collection(path)
                except SempNotAvailableError as exc:
                    if exc.endpoint_missing:
                        dead_reasons.append(str(exc))
                        endpoint_dead.set()
                    else:
                        log.warning("%s: %s (object removed mid-export?)", spec.key, exc)
                    return walk_ctx, None
            finally:
                ctx.progress.advance(1)

        pairs: Rows = []
        for walk_ctx, rows in ctx.pool.map(fetch_one, contexts):
            if rows is None:
                continue
            pairs.extend((walk_ctx, row) for row in rows)
        unavailable = dead_reasons[0] if dead_reasons else None
        log.info("%s: %d objects", spec.key, len(pairs))
        return pairs, unavailable

    def _child_contexts(self, spec: CollectionSpec, pairs: Rows) -> list[dict[str, Any]]:
        contexts: list[dict[str, Any]] = []
        for walk_ctx, row in pairs:
            try:
                identity = {f: row[f] for f in spec.id_fields}
            except KeyError as exc:
                log.warning("%s: row missing id field %s; skipping children", spec.key, exc)
                continue
            contexts.append({**walk_ctx, **identity})
        return contexts

    def _record_skip(self, spec: CollectionSpec, reason: str, ctx: RunContext) -> None:
        for node in spec.walk():
            self.skipped.append(SkipInfo(node.key, node.sheet, node.path, reason))
            self.raw_rows.pop(node.key, None)
        log.warning("Skipping %s (%s): %s", spec.sheet, spec.path, reason)

    # ------------------------------------------------------------------ #
    # resolve_relationships
    # ------------------------------------------------------------------ #
    def resolve_relationships(self, ctx: RunContext) -> None:
        """Back-fill ancestor identity attributes into every payload row.

        SEMP v2 normally echoes ancestor keys inside child objects; this makes
        it a guarantee even for endpoints that omit them.
        """
        for pairs in self.raw_rows.values():
            for walk_ctx, row in pairs:
                for key, value in walk_ctx.items():
                    row.setdefault(key, value)

    # ------------------------------------------------------------------ #
    # flatten
    # ------------------------------------------------------------------ #
    def flatten(self, ctx: RunContext) -> list[SheetData]:
        sheets: list[SheetData] = []
        skipped_keys = {s.spec_key for s in self.skipped}
        for spec in self.root.walk():
            if spec.key in skipped_keys:
                continue
            pairs = self.raw_rows.get(spec.key, [])
            sheets.append(self._to_sheet(spec, pairs))
        return sheets

    def _to_sheet(self, spec: CollectionSpec, pairs: Rows) -> SheetData:
        if spec.single and spec.transpose:
            return self._to_transposed_sheet(spec, pairs)

        # Static ancestor chain: correct headers even for empty collections.
        hierarchy = list(self._chains[spec.key])
        hierarchy.extend(f for f in spec.id_fields if f not in hierarchy)

        flat_pairs = [(walk_ctx, flatten_record(row)) for walk_ctx, row in pairs]
        other = sorted(
            {k for _, row in flat_pairs for k in row} - set(hierarchy),
            key=str.lower,
        )
        columns = hierarchy + other
        # The walk context wins over the object's own copy of the ancestor key
        # fields. SEMP echoes those on child objects and may report a resolved
        # value where the parent reported a symbolic one (a bridge listed with
        # bridgeVirtualRouter "auto" can echo "primary" on its remoteMsgVpns).
        # Hierarchy columns must describe where the object was *found*, or
        # child rows no longer join to their parent sheet.
        records = [{**row, **walk_ctx} for walk_ctx, row in flat_pairs]
        frame = pd.DataFrame.from_records(records, columns=columns) if columns else pd.DataFrame()
        full_renames = self._friendly.get(spec.key, {})
        renames = {k: v for k, v in full_renames.items() if k in frame.columns}
        frame = frame.rename(columns=renames)
        return SheetData(
            name=spec.sheet,
            frame=frame,
            spec_key=spec.key,
            endpoint=spec.path,
            id_columns=tuple(full_renames.get(c, c) for c in hierarchy),
            per_vpn=self.root.per_vpn,
        )

    def _to_transposed_sheet(self, spec: CollectionSpec, pairs: Rows) -> SheetData:
        """Render a single-object spec (e.g. the Broker) as Setting | Value rows."""
        record = flatten_record(pairs[0][1]) if pairs else {}
        frame = pd.DataFrame(
            {"Setting": list(record), "Value": [record[k] for k in record]}
        ).sort_values("Setting", ignore_index=True) if record else pd.DataFrame(columns=["Setting", "Value"])
        return SheetData(
            name=spec.sheet, frame=frame, spec_key=spec.key,
            endpoint=spec.path or "/", id_columns=("Setting",), per_vpn=False,
        )

    def _compute_friendly(self) -> None:
        """Merge friendly renames and ancestor-id chains down the spec tree."""
        self._chains: dict[str, tuple[str, ...]] = {}

        def descend(spec: CollectionSpec, inherited: dict[str, str], chain: tuple[str, ...]) -> None:
            merged = {**inherited, **spec.friendly}
            self._friendly[spec.key] = merged
            self._chains[spec.key] = chain
            for child in spec.children:
                descend(child, merged, chain + spec.id_fields)

        root_chain: tuple[str, ...] = ("msgVpnName",) if self.root.per_vpn else ()
        descend(self.root, dict(GLOBAL_FRIENDLY), root_chain)
