"""Authorization group specs (LDAP/OAuth group -> profile mapping)."""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

AUTHORIZATION_GROUPS = CollectionSpec(
    key="authorizationGroups",
    sheet="Authorization Groups",
    path=f"{VPN_PREFIX}/authorizationGroups",
    id_fields=("authorizationGroupName",),
    friendly={"authorizationGroupName": "Authorization Group"},
    per_vpn=True,
)
