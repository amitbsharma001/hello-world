"""Bridge specs.

The flattened hierarchy is::

    VPN -> Bridge -> Remote VPN (carries the queueBinding) -> Remote Subscription

so the ``Bridge Remote VPNs`` sheet answers "which queue on which remote VPN
does this bridge bind, over which host list, compressed/TLS or not", and the
``Bridge Remote Subscriptions`` sheet lists every subscription a bridge pulls,
each row prefixed with ``VPN | Bridge | Bridge Virtual Router``.
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

_BRIDGE_PATH = f"{VPN_PREFIX}/bridges/{{bridgeName}},{{bridgeVirtualRouter}}"

BRIDGE_REMOTE_VPNS = CollectionSpec(
    key="bridges.remoteMsgVpns",
    sheet="Bridge Remote VPNs",
    path=f"{_BRIDGE_PATH}/remoteMsgVpns",
    id_fields=("remoteMsgVpnName", "remoteMsgVpnLocation", "remoteMsgVpnInterface"),
    friendly={
        "remoteMsgVpnName": "Remote VPN",
        "remoteMsgVpnLocation": "Remote Location",
        "remoteMsgVpnInterface": "Remote Interface",
    },
)

BRIDGE_REMOTE_SUBSCRIPTIONS = CollectionSpec(
    key="bridges.remoteSubscriptions",
    sheet="Bridge Remote Subscriptions",
    path=f"{_BRIDGE_PATH}/remoteSubscriptions",
    id_fields=("remoteSubscriptionTopic",),
    friendly={"remoteSubscriptionTopic": "Remote Subscription Topic"},
)

BRIDGES = CollectionSpec(
    key="bridges",
    sheet="Bridges",
    path=f"{VPN_PREFIX}/bridges",
    id_fields=("bridgeName", "bridgeVirtualRouter"),
    friendly={"bridgeName": "Bridge", "bridgeVirtualRouter": "Bridge Virtual Router"},
    children=(BRIDGE_REMOTE_VPNS, BRIDGE_REMOTE_SUBSCRIPTIONS),
    per_vpn=True,
)
