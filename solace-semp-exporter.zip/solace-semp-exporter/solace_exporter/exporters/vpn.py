"""Message VPN specs: the VPN objects themselves plus VPN-scoped extras.

Note: per-VPN replication settings, event thresholds and service enablement
(SMF/AMQP/MQTT/REST ports, TLS flags, ...) are *attributes of the msgVpn
object* and therefore appear as columns on the ``VPNs`` sheet.
"""

from __future__ import annotations

from ..models import CollectionSpec

VPN_PREFIX = "msgVpns/{msgVpnName}"

VPNS = CollectionSpec(
    key="vpns",
    sheet="VPNs",
    path="msgVpns",
    id_fields=("msgVpnName",),
    friendly={"msgVpnName": "VPN"},
)

SEQUENCED_TOPICS = CollectionSpec(
    key="vpns.sequencedTopics",
    sheet="Sequenced Topics",
    path=f"{VPN_PREFIX}/sequencedTopics",
    id_fields=("sequencedTopic",),
    friendly={"sequencedTopic": "Sequenced Topic"},
    per_vpn=True,
)

VPN_OAUTH_PROFILES = CollectionSpec(
    key="vpns.oauthProfiles",
    sheet="VPN OAuth Profiles",
    path=f"{VPN_PREFIX}/authenticationOauthProfiles",
    id_fields=("oauthProfileName",),
    friendly={"oauthProfileName": "OAuth Profile"},
    per_vpn=True,
)
