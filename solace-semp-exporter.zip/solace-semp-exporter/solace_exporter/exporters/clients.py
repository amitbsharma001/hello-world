"""Client username and client profile specs."""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

CLIENT_USERNAME_ATTRIBUTES = CollectionSpec(
    key="clientUsernames.attributes",
    sheet="Client Username Attributes",
    path=f"{VPN_PREFIX}/clientUsernames/{{clientUsername}}/attributes",
    id_fields=("attributeName", "attributeValue"),
    friendly={"attributeName": "Attribute", "attributeValue": "Value"},
)

CLIENT_USERNAMES = CollectionSpec(
    key="clientUsernames",
    sheet="Client Usernames",
    path=f"{VPN_PREFIX}/clientUsernames",
    id_fields=("clientUsername",),
    friendly={"clientUsername": "Client Username"},
    children=(CLIENT_USERNAME_ATTRIBUTES,),
    per_vpn=True,
)

CLIENT_PROFILES = CollectionSpec(
    key="clientProfiles",
    sheet="Client Profiles",
    path=f"{VPN_PREFIX}/clientProfiles",
    id_fields=("clientProfileName",),
    friendly={"clientProfileName": "Client Profile"},
    per_vpn=True,
)
