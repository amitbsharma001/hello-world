"""JNDI object store specs (JMS connection factories, queues, topics)."""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

JNDI_CONNECTION_FACTORIES = CollectionSpec(
    key="jndi.connectionFactories",
    sheet="JNDI Connection Factories",
    path=f"{VPN_PREFIX}/jndiConnectionFactories",
    id_fields=("connectionFactoryName",),
    friendly={"connectionFactoryName": "Connection Factory"},
    per_vpn=True,
)

JNDI_QUEUES = CollectionSpec(
    key="jndi.queues",
    sheet="JNDI Queues",
    path=f"{VPN_PREFIX}/jndiQueues",
    id_fields=("queueName",),
    friendly={"queueName": "JNDI Queue"},
    per_vpn=True,
)

JNDI_TOPICS = CollectionSpec(
    key="jndi.topics",
    sheet="JNDI Topics",
    path=f"{VPN_PREFIX}/jndiTopics",
    id_fields=("topicName",),
    friendly={"topicName": "JNDI Topic"},
    per_vpn=True,
)
