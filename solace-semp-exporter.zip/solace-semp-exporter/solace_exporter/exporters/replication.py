"""Replication specs.

Per-VPN replication *settings* (state, bridge auth, queue reject-on-disabled,
...) are attributes of the ``msgVpn`` object and therefore live as columns on
the ``VPNs`` sheet. This module exports the replicated-topic list.
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

REPLICATED_TOPICS = CollectionSpec(
    key="replication.replicatedTopics",
    sheet="Replicated Topics",
    path=f"{VPN_PREFIX}/replicatedTopics",
    id_fields=("replicatedTopic",),
    friendly={"replicatedTopic": "Replicated Topic"},
    per_vpn=True,
)
