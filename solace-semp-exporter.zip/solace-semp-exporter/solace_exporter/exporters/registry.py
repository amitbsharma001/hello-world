"""Scope registry: maps user-facing export scopes to root collection specs.

The interactive menu, ``--scope`` flag values and ``--list-scopes`` output are
all derived from :data:`SCOPES`, so adding a new object type is a two-line
change here once its spec exists.
"""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass

from ..models import CollectionSpec
from . import (
    acl,
    bridges,
    cache,
    certificates,
    clients,
    dmr,
    jndi,
    mqtt,
    queues,
    replay,
    replication,
    rest,
    services,
    topics,
    users,
    vpn,
)


@dataclass(frozen=True)
class ScopeGroup:
    """A selectable export scope (one menu entry / ``--scope`` value)."""

    title: str
    roots: tuple[CollectionSpec, ...]


SCOPES: "OrderedDict[str, ScopeGroup]" = OrderedDict(
    [
        ("all", ScopeGroup("All Objects", ())),  # roots filled in below
        ("vpn", ScopeGroup("Message VPNs", (vpn.VPNS, vpn.SEQUENCED_TOPICS, vpn.VPN_OAUTH_PROFILES))),
        ("queues", ScopeGroup("Queues & Subscriptions", (queues.QUEUES,))),
        ("topic-endpoints", ScopeGroup("Topic Endpoints", (topics.TOPIC_ENDPOINTS,))),
        ("bridges", ScopeGroup("Bridges", (bridges.BRIDGES,))),
        ("client-usernames", ScopeGroup("Client Usernames", (clients.CLIENT_USERNAMES,))),
        ("acl", ScopeGroup("ACL Profiles", (acl.ACL_PROFILES,))),
        ("authorization-groups", ScopeGroup("Authorization Groups", (users.AUTHORIZATION_GROUPS,))),
        ("replay", ScopeGroup("Replay Logs", (replay.REPLAY_LOGS,))),
        ("dmr", ScopeGroup("DMR (Clusters, Links, Bridges)", (dmr.DMR_CLUSTERS, dmr.DMR_BRIDGES))),
        (
            "certificates",
            ScopeGroup(
                "Certificate Authorities",
                (certificates.CLIENT_CERT_AUTHORITIES, certificates.DOMAIN_CERT_AUTHORITIES),
            ),
        ),
        (
            "broker",
            ScopeGroup(
                "Broker & Services",
                (services.BROKER, services.VIRTUAL_HOSTNAMES, services.MGMT_OAUTH_PROFILES),
            ),
        ),
        ("mqtt", ScopeGroup("MQTT (Sessions, Retain Caches)", (mqtt.MQTT_SESSIONS, mqtt.MQTT_RETAIN_CACHES))),
        ("rest", ScopeGroup("REST Delivery Points", (rest.REST_DELIVERY_POINTS,))),
        ("cache", ScopeGroup("Distributed Caches", (cache.DISTRIBUTED_CACHES,))),
        ("client-profiles", ScopeGroup("Client Profiles", (clients.CLIENT_PROFILES,))),
        ("queue-templates", ScopeGroup("Queue Templates", (queues.QUEUE_TEMPLATES,))),
        ("topic-templates", ScopeGroup("Topic Endpoint Templates", (topics.TOPIC_ENDPOINT_TEMPLATES,))),
        ("replication", ScopeGroup("Replication (Replicated Topics)", (replication.REPLICATED_TOPICS,))),
        ("jndi", ScopeGroup("JNDI (CFs, Queues, Topics)", (jndi.JNDI_CONNECTION_FACTORIES, jndi.JNDI_QUEUES, jndi.JNDI_TOPICS))),
    ]
)

# "all" = every root of every other scope, in menu order, de-duplicated.
_all_roots: list[CollectionSpec] = []
for _name, _group in SCOPES.items():
    for _root in _group.roots:
        if _root not in _all_roots:
            _all_roots.append(_root)
SCOPES["all"] = ScopeGroup("All Objects", tuple(_all_roots))


def resolve_scopes(names: tuple[str, ...]) -> list[CollectionSpec]:
    """Turn scope names (or 1-based menu numbers) into unique root specs."""
    keys = list(SCOPES)
    roots: list[CollectionSpec] = []
    for name in names:
        token = name.strip().lower()
        if token.isdigit():
            index = int(token) - 1
            if not (0 <= index < len(keys)):
                raise KeyError(f"Scope number out of range: {name}")
            token = keys[index]
        group = SCOPES.get(token)
        if group is None:
            raise KeyError(f"Unknown scope: {name!r}")
        for root in group.roots:
            if root not in roots:
                roots.append(root)
    return roots


def all_root_specs() -> tuple[CollectionSpec, ...]:
    return SCOPES["all"].roots


def scope_table() -> list[tuple[int, str, str]]:
    """(number, scope-name, title) rows for the menu and ``--list-scopes``."""
    return [(i + 1, name, group.title) for i, (name, group) in enumerate(SCOPES.items())]


def _validate_registry() -> None:
    """Fail fast on duplicate spec keys or worksheet names (import-time)."""
    seen_keys: dict[str, str] = {}
    seen_sheets: dict[str, str] = {}
    for root in all_root_specs():
        for spec in root.walk():
            if spec.key in seen_keys and seen_keys[spec.key] != spec.sheet:
                raise RuntimeError(f"Duplicate spec key with different sheets: {spec.key}")
            if spec.sheet in seen_sheets and seen_sheets[spec.sheet] != spec.key:
                raise RuntimeError(f"Duplicate sheet name across specs: {spec.sheet}")
            seen_keys[spec.key] = spec.sheet
            seen_sheets[spec.sheet] = spec.key


_validate_registry()
