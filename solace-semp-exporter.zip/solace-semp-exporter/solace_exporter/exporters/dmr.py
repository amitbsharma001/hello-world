"""Dynamic Message Routing specs.

Broker level: ``DMR Clusters -> DMR Links -> Remote Addresses``.
VPN level:    ``DMR Bridges`` (per-VPN attachment to a cluster link).
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

DMR_LINK_REMOTE_ADDRESSES = CollectionSpec(
    key="dmrClusters.links.remoteAddresses",
    sheet="DMR Link Remote Addresses",
    path="dmrClusters/{dmrClusterName}/links/{remoteNodeName}/remoteAddresses",
    id_fields=("remoteAddress",),
    friendly={"remoteAddress": "Remote Address"},
)

DMR_LINKS = CollectionSpec(
    key="dmrClusters.links",
    sheet="DMR Links",
    path="dmrClusters/{dmrClusterName}/links",
    id_fields=("remoteNodeName",),
    friendly={"remoteNodeName": "Remote Node"},
    children=(DMR_LINK_REMOTE_ADDRESSES,),
)

DMR_CLUSTERS = CollectionSpec(
    key="dmrClusters",
    sheet="DMR Clusters",
    path="dmrClusters",
    id_fields=("dmrClusterName",),
    friendly={"dmrClusterName": "DMR Cluster"},
    children=(DMR_LINKS,),
)

DMR_BRIDGES = CollectionSpec(
    key="dmrBridges",
    sheet="DMR Bridges",
    path=f"{VPN_PREFIX}/dmrBridges",
    id_fields=("remoteNodeName",),
    friendly={"remoteNodeName": "Remote Node"},
    per_vpn=True,
)
