"""Topic endpoint specs.

Note: a topic endpoint's subscription is established by the binding consumer
at run time; the SEMP v2 *Config* API therefore has no
``topicEndpoints/{name}/subscriptions`` collection (that lives in the Monitor
API). The configured attributes are all present on the Topic Endpoints sheet.
"""

from __future__ import annotations

from ..models import CollectionSpec
from .vpn import VPN_PREFIX

TOPIC_ENDPOINTS = CollectionSpec(
    key="topicEndpoints",
    sheet="Topic Endpoints",
    path=f"{VPN_PREFIX}/topicEndpoints",
    id_fields=("topicEndpointName",),
    friendly={"topicEndpointName": "Topic Endpoint"},
    per_vpn=True,
)

TOPIC_ENDPOINT_TEMPLATES = CollectionSpec(
    key="topicEndpointTemplates",
    sheet="Topic Endpoint Templates",
    path=f"{VPN_PREFIX}/topicEndpointTemplates",
    id_fields=("topicEndpointTemplateName",),
    friendly={"topicEndpointTemplateName": "Topic Endpoint Template"},
    per_vpn=True,
)
