"""Command-line interface (single ``solace-export`` command, Typer-based).

Modes:

* **Interactive** (default when required values are missing): prompts for
  host, port, credentials, SSL, scope menu and output file - exactly the
  flow described in the project brief.
* **Non-interactive**: every prompt has a corresponding flag, environment
  variable (``SOLACE_*``) and TOML config-file key, resolved in ascending
  precedence ``defaults < file < env < flags``.
"""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table

from . import __version__
from .analysis import AnalysisReport, build_analysis
from .migrate import MigrationResult, VpnMigrator, roots_for_scopes
from .compare import VpnComparison, compare_vpns
from .config import (ConnectionConfig, ExportConfig, MigrationConfig,
                     build_configs, build_migration_config, with_updates)
from .exceptions import ConfigError, SempExporterError
from .excel_writer import (write_comparison_workbook, write_migration_workbook,
                           write_workbook)
from .exporter import ExportOrchestrator
from .exporters import SCOPES, ProgressHook, scope_table
from .models import ExportMetadata
from .semp_client import SempClient
from .utils.checkpoint import Checkpoint
from .utils.logging import get_logger, setup_logging
from .utils.text import sanitize_filename

app = typer.Typer(add_completion=False, rich_markup_mode="rich")
console = Console()
log = get_logger("cli")

DEFAULT_PASSWORD_ENV = "SOLACE_PASSWORD"


def _print_scopes() -> None:
    table = Table(title="Export Scopes", show_lines=False)
    table.add_column("#", justify="right", style="cyan")
    table.add_column("Scope", style="bold")
    table.add_column("Contents")
    for number, name, title in scope_table():
        table.add_row(str(number), name, title)
    console.print(table)


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"solace-semp-exporter {__version__}")
        raise typer.Exit()


def _list_scopes_callback(value: bool) -> None:
    if value:
        _print_scopes()
        raise typer.Exit()


def _prompt_missing(conn: ConnectionConfig) -> ConnectionConfig:
    """Interactively fill any missing connection values.

    SSL is asked before the port so the suggested default can switch between
    the conventional plain-text (8080) and TLS (1943) SEMP management ports.
    """
    if not conn.host:
        conn = with_updates(conn, host=typer.prompt("Solace Host"))
        use_ssl = typer.confirm("Use SSL (HTTPS)?", default=conn.use_ssl)
        conn = with_updates(conn, use_ssl=use_ssl)
        suggested_port = 1943 if use_ssl and conn.port == 8080 else conn.port
        conn = with_updates(conn, port=typer.prompt("Management Port", default=str(suggested_port)))
        if use_ssl:
            conn = with_updates(
                conn, verify_ssl=typer.confirm("Verify SSL certificate?", default=conn.verify_ssl)
            )
    if not conn.username:
        conn = with_updates(conn, username=typer.prompt("Username"))
    if not conn.password:
        conn = with_updates(conn, password=typer.prompt("Password", hide_input=True))
    return conn


def _prompt_vpns(export: ExportConfig) -> ExportConfig:
    raw = typer.prompt(
        "VPNs to export (comma-separated, blank = all VPNs)", default="", show_default=False
    )
    vpns = tuple(part.strip() for part in raw.split(",") if part.strip())
    return ExportConfig(**{**export.__dict__, "vpns": vpns})


def _prompt_scopes(export: ExportConfig) -> ExportConfig:
    _print_scopes()
    raw = typer.prompt("Export scope (numbers or names, comma-separated)", default="1")
    scopes = tuple(part.strip() for part in raw.split(",") if part.strip())
    return ExportConfig(**{**export.__dict__, "scopes": scopes})


_OPERATIONS: tuple[tuple[str, str, str], ...] = (
    ("export", "Export", "Export broker configuration to an Excel workbook (read-only)"),
    ("compare", "Compare", "Export and diff two Message VPNs side by side (read-only)"),
    ("migrate", "Migrate", "Copy a VPN to another VPN and/or another broker (writes)"),
)

#: Options that only make sense in migration mode; any of them implies intent.
_MIGRATION_FLAGS = (
    "migrate_to_host", "migrate_to_port", "migrate_to_username", "migrate_to_password",
    "migrate_to_ssl", "migrate_to_verify_ssl", "source_vpn", "target_vpn",
    "migrate_exists", "migrate_dry_run", "migrate_report",
)


def _stdin_is_tty() -> bool:
    """Interactive only on a real terminal (indirection keeps tests honest)."""
    try:
        return sys.stdin.isatty()
    except (AttributeError, ValueError):  # closed or replaced stream
        return False


def _print_operations() -> None:
    table = Table(title="What would you like to do?")
    table.add_column("#", justify="right", style="bold")
    table.add_column("Operation", style="bold")
    table.add_column("Description")
    for index, (_, label, description) in enumerate(_OPERATIONS, start=1):
        table.add_row(str(index), label, description)
    console.print(table)


def _prompt_operation() -> str:
    """Ask which operation to run; accepts a number or a name."""
    _print_operations()
    while True:
        raw = typer.prompt("Operation", default="1").strip().lower()
        for index, (name, label, _) in enumerate(_OPERATIONS, start=1):
            if raw in (str(index), name, label.lower()):
                return name
        console.print("[yellow]Enter 1, 2 or 3 - or export / compare / migrate.[/yellow]")


def _resolve_operation(cli: dict[str, object], export: ExportConfig, interactive: bool) -> str:
    """Decide between export / compare / migrate.

    Explicit flags always win, so scripts keep their exact behaviour. Migration
    options passed *without* ``--migrate`` used to be silently ignored; they are
    now honoured interactively and rejected non-interactively.
    """
    if cli.get("migrate") or os.environ.get("SOLACE_MIGRATE", "").lower() in ("1", "true", "yes"):
        return "migrate"
    if export.compare:
        return "compare"
    implied = [name for name in _MIGRATION_FLAGS if cli.get(name)]
    if implied:
        if not interactive:
            raise ConfigError(
                f"Migration option(s) given without --migrate: "
                f"{', '.join('--' + name.replace('_', '-') for name in implied)}. "
                "Add --migrate to run a migration, or remove them to export."
            )
        console.print("[dim]Migration options detected - selecting Migrate.[/dim]")
        return "migrate"
    return _prompt_operation() if interactive else "export"


def _prompt_compare(export: ExportConfig) -> ExportConfig:
    """Ask for the VPN pair to diff (and optional attribute globs to ignore)."""
    console.print(
        "[dim]Both VPNs are fetched automatically - no need to select them separately. "
        "Names are case-sensitive.[/dim]"
    )
    vpn_a = typer.prompt("First VPN to compare").strip()
    vpn_b = typer.prompt("Second VPN to compare").strip()
    raw = typer.prompt(
        "Attributes to ignore, glob-style (comma-separated, blank = none)",
        default="", show_default=False,
    )
    ignore = tuple(part.strip() for part in raw.split(",") if part.strip())
    return ExportConfig(**{
        **export.__dict__,
        "compare": (vpn_a, vpn_b),
        "compare_ignore": ignore or export.compare_ignore,
    })


def _default_output(host: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path(f"{sanitize_filename(host)}_{stamp}.xlsx")


def _default_compare_output(host: str, vpn_a: str, vpn_b: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path(
        f"{sanitize_filename(host)}_compare_"
        f"{sanitize_filename(vpn_a)}_vs_{sanitize_filename(vpn_b)}_{stamp}.xlsx"
    )


def _split_multi(values: object) -> tuple[str, ...]:
    """Flatten repeatable options that may also carry comma-joined values."""
    if not values:
        return ()
    return tuple(
        part.strip()
        for value in values  # type: ignore[union-attr]
        for part in str(value).split(",")
        if part.strip()
    )


@app.command()
def export(  # noqa: PLR0913 - a CLI front door legitimately has many knobs
    host: Optional[str] = typer.Option(None, "--host", "-H", help="Broker management host."),
    port: Optional[int] = typer.Option(None, "--port", "-P", help="SEMP management port (default 8080/1943)."),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Management username."),
    password: Optional[str] = typer.Option(None, "--password", help="Management password (prefer --password-env)."),
    password_env: str = typer.Option(
        DEFAULT_PASSWORD_ENV, "--password-env", help="Environment variable to read the password from."
    ),
    ssl: Optional[bool] = typer.Option(None, "--ssl/--no-ssl", help="Use HTTPS for SEMP."),
    verify_ssl: Optional[bool] = typer.Option(None, "--verify-ssl/--no-verify-ssl", help="Verify TLS certificates."),
    scope: list[str] = typer.Option(None, "--scope", "-s", help="Scope name or menu number (repeatable)."),
    vpn: list[str] = typer.Option(None, "--vpn", "-m", help="Export only these VPN(s) (repeatable)."),
    compare: list[str] = typer.Option(
        None, "--compare",
        help="Two VPN names to diff, e.g. --compare prod,dr (or repeat the flag). "
             "Also writes a side-by-side comparison audit workbook.",
    ),
    compare_ignore: list[str] = typer.Option(
        None, "--compare-ignore",
        help="Attribute-name glob to exclude from the comparison (repeatable), "
             "e.g. --compare-ignore 'replication*'. Identity columns are never ignored.",
    ),
    compare_output: Optional[Path] = typer.Option(
        None, "--compare-output",
        help="Comparison workbook path (default <host>_compare_<A>_vs_<B>_<timestamp>.xlsx).",
    ),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output .xlsx path."),
    config_file: Optional[Path] = typer.Option(None, "--config", "-c", help="TOML config file."),
    env_file: Optional[Path] = typer.Option(None, "--env-file", help=".env file to load (SOLACE_* keys)."),
    page_size: Optional[int] = typer.Option(
        None, "--page-size",
        help="SEMP pagination size (default 100; 0 disables paging on every endpoint).",
    ),
    workers: Optional[int] = typer.Option(None, "--workers", "-w", help="Concurrent request threads (default 8)."),
    timeout: Optional[float] = typer.Option(None, "--timeout", help="Per-request timeout in seconds."),
    retries: Optional[int] = typer.Option(None, "--retries", help="Automatic retries for 429/5xx."),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Prompt for missing values."),
    migrate: bool = typer.Option(
        False, "--migrate",
        help="Migration mode: copy every object of one VPN to another VPN "
             "and/or another broker (create/update only - never deletes).",
    ),
    migrate_to_host: Optional[str] = typer.Option(
        None, "--migrate-to-host",
        help="Target broker host (omit for a VPN-to-VPN copy on the same broker).",
    ),
    migrate_to_port: Optional[int] = typer.Option(None, "--migrate-to-port"),
    migrate_to_username: Optional[str] = typer.Option(None, "--migrate-to-username"),
    migrate_to_password: Optional[str] = typer.Option(
        None, "--migrate-to-password", help="Or set SOLACE_TARGET_PASSWORD."
    ),
    migrate_to_ssl: Optional[bool] = typer.Option(
        None, "--migrate-to-ssl/--migrate-to-no-ssl"
    ),
    migrate_to_verify_ssl: Optional[bool] = typer.Option(
        None, "--migrate-to-verify-ssl/--migrate-to-no-verify-ssl"
    ),
    source_vpn: Optional[str] = typer.Option(None, "--source-vpn"),
    target_vpn: Optional[str] = typer.Option(
        None, "--target-vpn", help="Target VPN name (may equal the source name on a different broker)."
    ),
    migrate_exists: Optional[str] = typer.Option(
        None, "--migrate-exists",
        help="If an object already exists on the target: skip (default) | update | fail.",
    ),
    migrate_dry_run: bool = typer.Option(
        False, "--migrate-dry-run", help="Fetch, plan and report - write nothing."
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y", help="Skip the migration confirmation prompt."
    ),
    migrate_report: Optional[Path] = typer.Option(
        None, "--migrate-report", help="Migration report workbook path."
    ),
    resume: bool = typer.Option(False, "--resume", help="Reuse checkpointed data from a previous failed run."),
    raw_headers: Optional[bool] = typer.Option(
        None,
        "--raw-headers/--friendly-headers",
        help="Keep raw SEMP camelCase column headers instead of humanised ones.",
    ),
    analysis: Optional[bool] = typer.Option(
        None, "--analysis/--no-analysis",
        help="Add Overview, Findings, Inventory, Capacity and Security Posture "
             "sheets to the workbook (default: on).",
    ),
    report_title: Optional[str] = typer.Option(
        None, "--report-title", help="Headline on the Overview sheet."
    ),
    prepared_for: Optional[str] = typer.Option(
        None, "--prepared-for", help="Customer/recipient name shown on the Overview sheet."
    ),
    prepared_by: Optional[str] = typer.Option(
        None, "--prepared-by", help="Author/organisation shown on the Overview sheet."
    ),
    cache_dir: Optional[Path] = typer.Option(None, "--cache-dir", help="Checkpoint cache directory."),
    clear_cache: bool = typer.Option(False, "--clear-cache", help="Delete matching checkpoints and exit."),
    keep_cache: bool = typer.Option(False, "--keep-cache", help="Keep checkpoints after a successful export."),
    log_level: Optional[str] = typer.Option(None, "--log-level", help="Console log level (DEBUG/INFO/WARNING)."),
    log_file: Optional[Path] = typer.Option(None, "--log-file", help="Log file path (default logs/export.log)."),
    list_scopes: bool = typer.Option(
        False, "--list-scopes", callback=_list_scopes_callback, is_eager=True, help="List scopes and exit."
    ),
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit."
    ),
) -> None:
    """Export Solace PubSub+ broker configuration to a hierarchical Excel workbook."""
    try:
        _run(**locals())
    except ConfigError as exc:
        console.print(f"[bold red]Configuration error:[/bold red] {exc}")
        log.debug("Config error", exc_info=True)
        raise typer.Exit(code=2) from exc
    except SempExporterError as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        log.debug("Fatal", exc_info=True)
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow] Re-run with [bold]--resume[/bold] to continue.")
        raise typer.Exit(code=130) from None


def _run(**cli: object) -> None:  # noqa: PLR0915 - linear top-level workflow
    if cli.get("env_file"):
        from dotenv import load_dotenv

        load_dotenv(cli["env_file"])  # type: ignore[arg-type]

    if not cli.get("password") and os.environ.get(str(cli["password_env"])):
        cli["password"] = os.environ[str(cli["password_env"])]

    conn, export_cfg = build_configs(
        file_path=cli.get("config_file"),  # type: ignore[arg-type]
        cli={
            "host": cli.get("host"), "port": cli.get("port"),
            "username": cli.get("username"), "password": cli.get("password"),
            "use_ssl": cli.get("ssl"), "verify_ssl": cli.get("verify_ssl"),
            "timeout": cli.get("timeout"), "retries": cli.get("retries"),
            "page_size": cli.get("page_size"), "workers": cli.get("workers"),
            "scopes": tuple(cli["scope"]) if cli.get("scope") else None,  # type: ignore[arg-type]
            "vpns": tuple(cli["vpn"]) if cli.get("vpn") else None,  # type: ignore[arg-type]
            "compare": _split_multi(cli.get("compare")) or None,
            "compare_ignore": _split_multi(cli.get("compare_ignore")) or None,
            "compare_output": cli.get("compare_output"),
            "output": cli.get("output"), "resume": cli.get("resume"),
            "cache_dir": cli.get("cache_dir"), "keep_cache": cli.get("keep_cache"),
            "raw_headers": cli.get("raw_headers"),
            "analysis": cli.get("analysis"),
            "report_title": cli.get("report_title"),
            "prepared_for": cli.get("prepared_for"),
            "prepared_by": cli.get("prepared_by"),
            "log_level": cli.get("log_level"), "log_file": cli.get("log_file"),
        },
    )

    setup_logging(level=export_cfg.log_level, log_file=export_cfg.log_file)

    interactive = bool(cli.get("interactive")) and _stdin_is_tty()
    operation = _resolve_operation(cli, export_cfg, interactive)
    if interactive:
        conn = _prompt_missing(conn)

    if operation == "migrate":
        _run_migration(conn, export_cfg, cli, interactive)
        return

    if interactive:
        if not cli.get("scope") and not cli.get("config_file"):
            export_cfg = _prompt_scopes(export_cfg)
        if operation == "compare" and not export_cfg.compare:
            export_cfg = _prompt_compare(export_cfg)
        if not cli.get("vpn") and not export_cfg.vpns and not export_cfg.compare:
            export_cfg = _prompt_vpns(export_cfg)
    conn.validate()
    export_cfg.validate(set(SCOPES) | {str(i + 1) for i in range(len(SCOPES))})
    if export_cfg.compare:
        # Fetch exactly the compared pair; the orchestrator verifies both
        # exist on the broker and raises a ConfigError listing VPNs if not.
        export_cfg = ExportConfig(**{**export_cfg.__dict__, "vpns": export_cfg.compare})

    checkpoint = Checkpoint(
        host=conn.host, port=conn.port,
        scopes=export_cfg.scopes, vpns=export_cfg.vpns,
        cache_dir=export_cfg.cache_dir, enabled_read=export_cfg.resume,
    )
    if cli.get("clear_cache"):
        checkpoint.clear()
        console.print("[green]Checkpoint cache cleared.[/green]")
        return

    output_path = export_cfg.output or _default_output(conn.host)
    if interactive and not export_cfg.output:
        output_path = Path(typer.prompt("Output file name", default=str(output_path)))

    client = SempClient(conn)
    console.print(f"Connecting to [bold]{conn.base_url}[/bold] ...")
    about = client.verify_connection()

    orchestrator = ExportOrchestrator(client, conn, export_cfg, checkpoint=checkpoint)
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Starting export...", total=0)
        hook = ProgressHook(
            announce=lambda text: progress.update(task, description=text),
            add_total=lambda n: progress.update(task, total=(progress.tasks[0].total or 0) + n),
            advance=lambda n: progress.advance(task, n),
        )
        result = orchestrator.run(progress=hook)
        progress.update(task, description="Writing Excel...")
        metadata = ExportMetadata(
            host=conn.host,
            base_url=conn.base_url,
            semp_version=str(about.get("sempVersion", "unknown")),
            platform=str(about.get("platform", "unknown")),
            scopes=export_cfg.scopes,
            vpn_filter=export_cfg.vpns,
            vpn_count=result.vpn_count,
            tool_version=__version__,
            options={"connection": conn.redacted(), "export": {**export_cfg.__dict__,
                     "output": str(output_path), "cache_dir": str(export_cfg.cache_dir or "")}},
        )
        report: AnalysisReport | None = None
        if export_cfg.analysis:
            progress.update(task, description="Analysing configuration...")
            report = build_analysis(
                result.sheets,
                report_title=export_cfg.report_title,
                prepared_for=export_cfg.prepared_for,
                prepared_by=export_cfg.prepared_by,
            )
        progress.update(task, description="Writing workbook...")
        write_workbook(output_path, result.sheets, metadata, result,
                       friendly_headers=not export_cfg.raw_headers,
                       analysis=report)

        comparison: VpnComparison | None = None
        compare_path: Path | None = None
        if export_cfg.compare:
            vpn_a, vpn_b = export_cfg.compare
            progress.update(task, description=f"Comparing {vpn_a} vs {vpn_b}...")
            comparison = compare_vpns(
                result.sheets, vpn_a, vpn_b,
                ignore=export_cfg.compare_ignore,
                friendly=not export_cfg.raw_headers,
            )
            compare_path = export_cfg.compare_output or _default_compare_output(
                conn.host, vpn_a, vpn_b
            )
            write_comparison_workbook(compare_path, comparison, metadata,
                                      friendly_headers=not export_cfg.raw_headers)
        progress.update(task, description="Done")

    if not export_cfg.keep_cache and not result.errors:
        checkpoint.clear()

    _print_result(output_path, result)
    if report is not None:
        _print_findings(report)
    if comparison is not None and compare_path is not None:
        _print_comparison(compare_path, comparison)
    if result.errors and not result.sheets:
        raise typer.Exit(code=1)


def _prompt_migration(conn: ConnectionConfig, mig: MigrationConfig) -> MigrationConfig:
    """Interactive migration questions: target broker, VPN names, exists policy."""
    values = dict(mig.__dict__)
    if not mig.target_host and typer.confirm("Copy to a different broker?", default=False):
        values["target_host"] = typer.prompt("Target Solace Host")
        values["target_use_ssl"] = typer.confirm("Target uses SSL (HTTPS)?", default=mig.target_use_ssl)
        default_port = 1943 if values["target_use_ssl"] else 8080
        values["target_port"] = int(typer.prompt("Target Management Port", default=str(default_port)))
        if values["target_use_ssl"]:
            values["target_verify_ssl"] = typer.confirm(
                "Verify target SSL certificate?", default=mig.target_verify_ssl
            )
        values["target_username"] = typer.prompt("Target Username", default=conn.username)
        values["target_password"] = typer.prompt("Target Password", hide_input=True)
    if not values.get("source_vpn"):
        values["source_vpn"] = typer.prompt("Source VPN")
    if not values.get("target_vpn"):
        if values.get("target_host"):
            if typer.confirm("Use the same VPN name on the target?", default=True):
                values["target_vpn"] = values["source_vpn"]
            else:
                values["target_vpn"] = typer.prompt("Target VPN name")
        else:
            console.print("[dim]Same broker: the target VPN needs a different name.[/dim]")
            values["target_vpn"] = typer.prompt("Target VPN name")
    if mig.exists == "skip" and not values.get("yes"):
        values["exists"] = typer.prompt(
            "If an object already exists on the target (skip/update/fail)",
            default="skip",
        ).strip().lower()
    return MigrationConfig(**values)


def _run_migration(
    conn: ConnectionConfig,
    export_cfg: ExportConfig,
    cli: dict[str, object],
    interactive: bool,
) -> None:
    if not cli.get("migrate_to_password") and os.environ.get("SOLACE_TARGET_PASSWORD"):
        cli["migrate_to_password"] = os.environ["SOLACE_TARGET_PASSWORD"]
    mig = build_migration_config({
        "target_host": cli.get("migrate_to_host"),
        "target_port": cli.get("migrate_to_port"),
        "target_username": cli.get("migrate_to_username"),
        "target_password": cli.get("migrate_to_password"),
        "target_use_ssl": cli.get("migrate_to_ssl"),
        "target_verify_ssl": cli.get("migrate_to_verify_ssl"),
        "source_vpn": cli.get("source_vpn") or (export_cfg.vpns[0] if len(export_cfg.vpns) == 1 else None),
        "target_vpn": cli.get("target_vpn"),
        "exists": cli.get("migrate_exists"),
        "dry_run": cli.get("migrate_dry_run") or None,
        "yes": cli.get("yes") or None,
        "report": cli.get("migrate_report"),
    })
    if interactive:
        mig = _prompt_migration(conn, mig)
    conn.validate()
    mig.validate(conn)

    target_conn = mig.target_connection(conn)
    source_client = SempClient(conn)
    about = source_client.verify_connection()
    if mig.cross_broker:
        target_client = SempClient(target_conn)
        target_client.verify_connection()
    else:
        target_client = source_client
    access = str(target_client.about_user().get("globalAccessLevel", ""))
    if access and access not in ("admin", "read-write"):
        console.print(
            f"[yellow]Warning:[/yellow] target SEMP user has global access level "
            f"'{access}' - writes will likely be rejected."
        )

    console.print(
        f"Migrating VPN [bold]{mig.source_vpn}[/bold] on {conn.host} -> "
        f"VPN [bold]{mig.target_vpn}[/bold] on {target_conn.host} "
        f"(exists: {mig.exists}, {'dry run' if mig.dry_run else 'live'})"
    )

    migrator = VpnMigrator(
        source_client, target_client,
        source_vpn=mig.source_vpn, target_vpn=mig.target_vpn,
        exists_policy=mig.exists, roots=roots_for_scopes(export_cfg.scopes),
        source_host=conn.host, target_host=target_conn.host,
    )
    with ThreadPoolExecutor(max_workers=conn.workers) as pool:
        with Progress(
            SpinnerColumn(), TextColumn("[progress.description]{task.description}"),
            BarColumn(), TextColumn("{task.completed}/{task.total}"),
            TimeElapsedColumn(), console=console,
        ) as progress:
            fetch_task = progress.add_task("Reading source VPN...", total=None)
            plan, sheets, source_skipped = migrator.prepare(pool)
            progress.update(fetch_task, total=1, completed=1,
                            description=f"Source read: {len(plan)} objects")

            _print_migration_plan(plan, mig)
            execute = not mig.dry_run
            if execute and not mig.yes:
                if interactive:
                    execute = typer.confirm(
                        f"Proceed and write {len(plan)} objects to "
                        f"{target_conn.host} / VPN '{mig.target_vpn}'?",
                        default=False,
                    )
                    if not execute:
                        console.print("[yellow]Aborted - treating as dry run; "
                                      "report will show the plan only.[/yellow]")
                else:
                    raise ConfigError(
                        "Non-interactive migration needs --yes to execute "
                        "(or --migrate-dry-run for a plan-only report)."
                    )

            work = progress.add_task(
                "Migrating..." if execute else "Recording plan...", total=len(plan)
            )

            def tick(sheet: str, obj: str) -> None:
                progress.update(work, advance=1, description=f"{sheet}: {obj}"[:60])

            result = migrator.apply(plan, sheets, source_skipped,
                                    execute=execute, progress=tick)
            progress.update(work, description="Done")

    metadata = ExportMetadata(
        host=conn.host,
        base_url=conn.base_url,
        semp_version=str(about.get("sempVersion", "unknown")),
        platform=str(about.get("platform", "unknown")),
        scopes=export_cfg.scopes,
        vpn_filter=(mig.source_vpn,),
        vpn_count=1,
        tool_version=__version__,
        options={"connection": conn.redacted()},
    )
    metadata.options["migration"] = {
        k: ("***" if k == "target_password" and v else (str(v) if isinstance(v, Path) else v))
        for k, v in mig.__dict__.items()
    }
    report_path = mig.report or Path(
        f"{sanitize_filename(conn.host)}_{sanitize_filename(mig.source_vpn)}"
        f"_to_{sanitize_filename(mig.target_vpn)}_migration_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    )
    write_migration_workbook(report_path, result, metadata,
                             friendly_headers=not export_cfg.raw_headers)
    _print_migration_result(report_path, result)
    if not result.ok:
        raise typer.Exit(code=1)


def _print_migration_plan(plan: list, mig: MigrationConfig) -> None:
    from collections import Counter

    counts = Counter(spec.sheet for spec, _, _ in plan)
    table = Table(title=f"Migration plan: {len(plan)} objects -> VPN '{mig.target_vpn}'")
    table.add_column("Object Type", style="bold")
    table.add_column("Objects", justify="right")
    for sheet, count in counts.most_common():
        table.add_row(sheet, str(count))
    console.print(table)


def _print_migration_result(report_path: Path, result: MigrationResult) -> None:
    table = Table(title=("Migration dry run" if result.dry_run else "Migration result")
                        + f" -> {report_path}")
    for column in ("Planned", "Created", "Updated", "Skipped", "Failed"):
        table.add_column(column, justify="right")
    table.add_row(*(str(result.count(a)) for a in
                    ("planned", "created", "updated", "skipped", "failed")))
    console.print(table)
    for entry in [e for e in result.entries if e.action == "failed"][:10]:
        console.print(f"  [red]failed[/red] {entry.sheet} / {entry.obj}: {entry.detail}")
    if result.secret_notes and not result.dry_run:
        console.print(
            "[yellow]Secrets are not readable via SEMP and were NOT migrated - "
            "set manually on the target:[/yellow] " + "; ".join(result.secret_notes)
        )


def _print_result(output_path: Path, result: object) -> None:
    table = Table(title=f"Export complete -> {output_path}", show_lines=False)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_row("Worksheets", str(len(result.sheets)))  # type: ignore[attr-defined]
    table.add_row("Total rows", f"{result.total_rows:,}")  # type: ignore[attr-defined]
    table.add_row("VPNs", str(result.vpn_count))  # type: ignore[attr-defined]
    table.add_row("Skipped endpoints", str(len(result.skipped)))  # type: ignore[attr-defined]
    table.add_row("Errors", str(len(result.errors)))  # type: ignore[attr-defined]
    table.add_row("API calls", str(result.api_calls))  # type: ignore[attr-defined]
    table.add_row("Duration", f"{result.duration_s:.1f}s")  # type: ignore[attr-defined]
    console.print(table)
    for error in result.errors:  # type: ignore[attr-defined]
        console.print(f"[red]![/red] {error}")
    if result.errors:  # type: ignore[attr-defined]
        console.print("[yellow]Partial export - re-run with --resume to retry failed roots.[/yellow]")


def _print_findings(report: AnalysisReport) -> None:
    counts = report.severity_counts
    if not report.findings:
        console.print("[green]Configuration review: no findings.[/green] "
                      "See the Overview sheet for the environment summary.")
        return
    styled = "  ".join(
        f"[{style}]{severity}: {counts.get(severity, 0)}[/{style}]"
        for severity, style in (
            ("High", "bold red"), ("Medium", "yellow"),
            ("Low", "cyan"), ("Info", "dim"),
        )
    )
    console.print(f"Configuration review findings -> {styled}  "
                  f"(details on the [bold]Findings[/bold] sheet)")


def _print_comparison(compare_path: Path, comparison: VpnComparison) -> None:
    if not comparison.total_deltas:
        console.print(
            f"[green]VPNs [bold]{comparison.vpn_a}[/bold] and "
            f"[bold]{comparison.vpn_b}[/bold] are identical across all "
            f"{comparison.total_identical} compared objects.[/green] "
            f"Report: {compare_path}"
        )
        return
    table = Table(
        title=f"VPN comparison {comparison.vpn_a} vs {comparison.vpn_b} -> {compare_path}",
        show_lines=False,
    )
    table.add_column("Object Type", style="bold")
    table.add_column(f"Only in {comparison.vpn_a}", justify="right")
    table.add_column(f"Only in {comparison.vpn_b}", justify="right")
    table.add_column("Different", justify="right")
    table.add_column("Identical", justify="right")
    table.add_column("Match", justify="right")
    for outcome in comparison.delta_types:
        table.add_row(
            outcome.sheet, str(outcome.only_a), str(outcome.only_b),
            str(outcome.different), str(outcome.identical), f"{outcome.match_pct:.1f}%",
        )
    table.add_row(
        "[bold]TOTAL[/bold]",
        f"[bold]{comparison.total_only_a}[/bold]",
        f"[bold]{comparison.total_only_b}[/bold]",
        f"[bold]{comparison.total_different}[/bold]",
        f"[bold]{comparison.total_identical}[/bold]",
        "",
    )
    console.print(table)
    clean = len(comparison.types) - len(comparison.delta_types)
    if clean:
        console.print(f"[dim]{clean} object type(s) fully identical (see Summary sheet).[/dim]")


def main() -> None:
    """Console-script entry point."""
    app()


if __name__ == "__main__":
    main()
