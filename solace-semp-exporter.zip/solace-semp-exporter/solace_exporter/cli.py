"""Command-line interface (single ``solace-export`` command, Typer-based).

Modes:

* **Interactive** (default when required values are missing): prompts for
  host, port, credentials, SSL, scope menu and output file - exactly the
  flow described in the project brief.
* **Non-interactive**: every prompt has a corresponding flag, environment
  variable (``SOLACE_*``) and TOML config-file key, resolved in ascending
  precedence ``defaults < file < env < flags``.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table

from . import __version__
from .compare import VpnComparison, compare_vpns
from .config import ConnectionConfig, ExportConfig, build_configs, with_updates
from .exceptions import ConfigError, SempExporterError
from .excel_writer import write_comparison_workbook, write_workbook
from .exporter import ExportOrchestrator
from .exporters import SCOPES, ProgressHook, scope_table
from .models import ExportMetadata
from .semp_client import SempClient
from .utils.checkpoint import Checkpoint
from .utils.logging import get_logger, setup_logging
from .utils.text import sanitize_filename

app = typer.Typer(add_completion=False, rich_markup_mode="rich")
console = Console()
log = get_logger("cli")

DEFAULT_PASSWORD_ENV = "SOLACE_PASSWORD"


def _print_scopes() -> None:
    table = Table(title="Export Scopes", show_lines=False)
    table.add_column("#", justify="right", style="cyan")
    table.add_column("Scope", style="bold")
    table.add_column("Contents")
    for number, name, title in scope_table():
        table.add_row(str(number), name, title)
    console.print(table)


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"solace-semp-exporter {__version__}")
        raise typer.Exit()


def _list_scopes_callback(value: bool) -> None:
    if value:
        _print_scopes()
        raise typer.Exit()


def _prompt_missing(conn: ConnectionConfig) -> ConnectionConfig:
    """Interactively fill any missing connection values.

    SSL is asked before the port so the suggested default can switch between
    the conventional plain-text (8080) and TLS (1943) SEMP management ports.
    """
    if not conn.host:
        conn = with_updates(conn, host=typer.prompt("Solace Host"))
        use_ssl = typer.confirm("Use SSL (HTTPS)?", default=conn.use_ssl)
        conn = with_updates(conn, use_ssl=use_ssl)
        suggested_port = 1943 if use_ssl and conn.port == 8080 else conn.port
        conn = with_updates(conn, port=typer.prompt("Management Port", default=str(suggested_port)))
        if use_ssl:
            conn = with_updates(
                conn, verify_ssl=typer.confirm("Verify SSL certificate?", default=conn.verify_ssl)
            )
    if not conn.username:
        conn = with_updates(conn, username=typer.prompt("Username"))
    if not conn.password:
        conn = with_updates(conn, password=typer.prompt("Password", hide_input=True))
    return conn


def _prompt_vpns(export: ExportConfig) -> ExportConfig:
    raw = typer.prompt(
        "VPNs to export (comma-separated, blank = all VPNs)", default="", show_default=False
    )
    vpns = tuple(part.strip() for part in raw.split(",") if part.strip())
    return ExportConfig(**{**export.__dict__, "vpns": vpns})


def _prompt_scopes(export: ExportConfig) -> ExportConfig:
    _print_scopes()
    raw = typer.prompt("Export scope (numbers or names, comma-separated)", default="1")
    scopes = tuple(part.strip() for part in raw.split(",") if part.strip())
    return ExportConfig(**{**export.__dict__, "scopes": scopes})


def _default_output(host: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path(f"{sanitize_filename(host)}_{stamp}.xlsx")


def _default_compare_output(host: str, vpn_a: str, vpn_b: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return Path(
        f"{sanitize_filename(host)}_compare_"
        f"{sanitize_filename(vpn_a)}_vs_{sanitize_filename(vpn_b)}_{stamp}.xlsx"
    )


def _split_multi(values: object) -> tuple[str, ...]:
    """Flatten repeatable options that may also carry comma-joined values."""
    if not values:
        return ()
    return tuple(
        part.strip()
        for value in values  # type: ignore[union-attr]
        for part in str(value).split(",")
        if part.strip()
    )


@app.command()
def export(  # noqa: PLR0913 - a CLI front door legitimately has many knobs
    host: Optional[str] = typer.Option(None, "--host", "-H", help="Broker management host."),
    port: Optional[int] = typer.Option(None, "--port", "-P", help="SEMP management port (default 8080/1943)."),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="Management username."),
    password: Optional[str] = typer.Option(None, "--password", help="Management password (prefer --password-env)."),
    password_env: str = typer.Option(
        DEFAULT_PASSWORD_ENV, "--password-env", help="Environment variable to read the password from."
    ),
    ssl: Optional[bool] = typer.Option(None, "--ssl/--no-ssl", help="Use HTTPS for SEMP."),
    verify_ssl: Optional[bool] = typer.Option(None, "--verify-ssl/--no-verify-ssl", help="Verify TLS certificates."),
    scope: list[str] = typer.Option(None, "--scope", "-s", help="Scope name or menu number (repeatable)."),
    vpn: list[str] = typer.Option(None, "--vpn", "-m", help="Export only these VPN(s) (repeatable)."),
    compare: list[str] = typer.Option(
        None, "--compare",
        help="Two VPN names to diff, e.g. --compare prod,dr (or repeat the flag). "
             "Also writes a side-by-side comparison audit workbook.",
    ),
    compare_ignore: list[str] = typer.Option(
        None, "--compare-ignore",
        help="Attribute-name glob to exclude from the comparison (repeatable), "
             "e.g. --compare-ignore 'replication*'. Identity columns are never ignored.",
    ),
    compare_output: Optional[Path] = typer.Option(
        None, "--compare-output",
        help="Comparison workbook path (default <host>_compare_<A>_vs_<B>_<timestamp>.xlsx).",
    ),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output .xlsx path."),
    config_file: Optional[Path] = typer.Option(None, "--config", "-c", help="TOML config file."),
    env_file: Optional[Path] = typer.Option(None, "--env-file", help=".env file to load (SOLACE_* keys)."),
    page_size: Optional[int] = typer.Option(None, "--page-size", help="SEMP pagination size (default 100)."),
    workers: Optional[int] = typer.Option(None, "--workers", "-w", help="Concurrent request threads (default 8)."),
    timeout: Optional[float] = typer.Option(None, "--timeout", help="Per-request timeout in seconds."),
    retries: Optional[int] = typer.Option(None, "--retries", help="Automatic retries for 429/5xx."),
    interactive: bool = typer.Option(True, "--interactive/--no-interactive", help="Prompt for missing values."),
    resume: bool = typer.Option(False, "--resume", help="Reuse checkpointed data from a previous failed run."),
    raw_headers: Optional[bool] = typer.Option(
        None,
        "--raw-headers/--friendly-headers",
        help="Keep raw SEMP camelCase column headers instead of humanised ones.",
    ),
    cache_dir: Optional[Path] = typer.Option(None, "--cache-dir", help="Checkpoint cache directory."),
    clear_cache: bool = typer.Option(False, "--clear-cache", help="Delete matching checkpoints and exit."),
    keep_cache: bool = typer.Option(False, "--keep-cache", help="Keep checkpoints after a successful export."),
    log_level: Optional[str] = typer.Option(None, "--log-level", help="Console log level (DEBUG/INFO/WARNING)."),
    log_file: Optional[Path] = typer.Option(None, "--log-file", help="Log file path (default logs/export.log)."),
    list_scopes: bool = typer.Option(
        False, "--list-scopes", callback=_list_scopes_callback, is_eager=True, help="List scopes and exit."
    ),
    version: bool = typer.Option(
        False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit."
    ),
) -> None:
    """Export Solace PubSub+ broker configuration to a hierarchical Excel workbook."""
    try:
        _run(**locals())
    except ConfigError as exc:
        console.print(f"[bold red]Configuration error:[/bold red] {exc}")
        log.debug("Config error", exc_info=True)
        raise typer.Exit(code=2) from exc
    except SempExporterError as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        log.debug("Fatal", exc_info=True)
        raise typer.Exit(code=1) from exc
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/yellow] Re-run with [bold]--resume[/bold] to continue.")
        raise typer.Exit(code=130) from None


def _run(**cli: object) -> None:  # noqa: PLR0915 - linear top-level workflow
    if cli.get("env_file"):
        from dotenv import load_dotenv

        load_dotenv(cli["env_file"])  # type: ignore[arg-type]

    if not cli.get("password") and os.environ.get(str(cli["password_env"])):
        cli["password"] = os.environ[str(cli["password_env"])]

    conn, export_cfg = build_configs(
        file_path=cli.get("config_file"),  # type: ignore[arg-type]
        cli={
            "host": cli.get("host"), "port": cli.get("port"),
            "username": cli.get("username"), "password": cli.get("password"),
            "use_ssl": cli.get("ssl"), "verify_ssl": cli.get("verify_ssl"),
            "timeout": cli.get("timeout"), "retries": cli.get("retries"),
            "page_size": cli.get("page_size"), "workers": cli.get("workers"),
            "scopes": tuple(cli["scope"]) if cli.get("scope") else None,  # type: ignore[arg-type]
            "vpns": tuple(cli["vpn"]) if cli.get("vpn") else None,  # type: ignore[arg-type]
            "compare": _split_multi(cli.get("compare")) or None,
            "compare_ignore": _split_multi(cli.get("compare_ignore")) or None,
            "compare_output": cli.get("compare_output"),
            "output": cli.get("output"), "resume": cli.get("resume"),
            "cache_dir": cli.get("cache_dir"), "keep_cache": cli.get("keep_cache"),
            "raw_headers": cli.get("raw_headers"),
            "log_level": cli.get("log_level"), "log_file": cli.get("log_file"),
        },
    )

    setup_logging(level=export_cfg.log_level, log_file=export_cfg.log_file)

    interactive = bool(cli.get("interactive")) and sys.stdin.isatty()
    if interactive:
        conn = _prompt_missing(conn)
        if not cli.get("scope") and not cli.get("config_file"):
            export_cfg = _prompt_scopes(export_cfg)
        if not cli.get("vpn") and not export_cfg.vpns and not export_cfg.compare:
            export_cfg = _prompt_vpns(export_cfg)
    conn.validate()
    export_cfg.validate(set(SCOPES) | {str(i + 1) for i in range(len(SCOPES))})
    if export_cfg.compare:
        # Fetch exactly the compared pair; the orchestrator verifies both
        # exist on the broker and raises a ConfigError listing VPNs if not.
        export_cfg = ExportConfig(**{**export_cfg.__dict__, "vpns": export_cfg.compare})

    checkpoint = Checkpoint(
        host=conn.host, port=conn.port,
        scopes=export_cfg.scopes, vpns=export_cfg.vpns,
        cache_dir=export_cfg.cache_dir, enabled_read=export_cfg.resume,
    )
    if cli.get("clear_cache"):
        checkpoint.clear()
        console.print("[green]Checkpoint cache cleared.[/green]")
        return

    output_path = export_cfg.output or _default_output(conn.host)
    if interactive and not export_cfg.output:
        output_path = Path(typer.prompt("Output file name", default=str(output_path)))

    client = SempClient(conn)
    console.print(f"Connecting to [bold]{conn.base_url}[/bold] ...")
    about = client.verify_connection()

    orchestrator = ExportOrchestrator(client, conn, export_cfg, checkpoint=checkpoint)
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Starting export...", total=0)
        hook = ProgressHook(
            announce=lambda text: progress.update(task, description=text),
            add_total=lambda n: progress.update(task, total=(progress.tasks[0].total or 0) + n),
            advance=lambda n: progress.advance(task, n),
        )
        result = orchestrator.run(progress=hook)
        progress.update(task, description="Writing Excel...")
        metadata = ExportMetadata(
            host=conn.host,
            base_url=conn.base_url,
            semp_version=str(about.get("sempVersion", "unknown")),
            platform=str(about.get("platform", "unknown")),
            scopes=export_cfg.scopes,
            vpn_filter=export_cfg.vpns,
            vpn_count=result.vpn_count,
            tool_version=__version__,
            options={"connection": conn.redacted(), "export": {**export_cfg.__dict__,
                     "output": str(output_path), "cache_dir": str(export_cfg.cache_dir or "")}},
        )
        write_workbook(output_path, result.sheets, metadata, result,
                       friendly_headers=not export_cfg.raw_headers)

        comparison: VpnComparison | None = None
        compare_path: Path | None = None
        if export_cfg.compare:
            vpn_a, vpn_b = export_cfg.compare
            progress.update(task, description=f"Comparing {vpn_a} vs {vpn_b}...")
            comparison = compare_vpns(
                result.sheets, vpn_a, vpn_b,
                ignore=export_cfg.compare_ignore,
                friendly=not export_cfg.raw_headers,
            )
            compare_path = export_cfg.compare_output or _default_compare_output(
                conn.host, vpn_a, vpn_b
            )
            write_comparison_workbook(compare_path, comparison, metadata,
                                      friendly_headers=not export_cfg.raw_headers)
        progress.update(task, description="Done")

    if not export_cfg.keep_cache and not result.errors:
        checkpoint.clear()

    _print_result(output_path, result)
    if comparison is not None and compare_path is not None:
        _print_comparison(compare_path, comparison)
    if result.errors and not result.sheets:
        raise typer.Exit(code=1)


def _print_result(output_path: Path, result: object) -> None:
    table = Table(title=f"Export complete -> {output_path}", show_lines=False)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_row("Worksheets", str(len(result.sheets)))  # type: ignore[attr-defined]
    table.add_row("Total rows", f"{result.total_rows:,}")  # type: ignore[attr-defined]
    table.add_row("VPNs", str(result.vpn_count))  # type: ignore[attr-defined]
    table.add_row("Skipped endpoints", str(len(result.skipped)))  # type: ignore[attr-defined]
    table.add_row("Errors", str(len(result.errors)))  # type: ignore[attr-defined]
    table.add_row("API calls", str(result.api_calls))  # type: ignore[attr-defined]
    table.add_row("Duration", f"{result.duration_s:.1f}s")  # type: ignore[attr-defined]
    console.print(table)
    for error in result.errors:  # type: ignore[attr-defined]
        console.print(f"[red]![/red] {error}")
    if result.errors:  # type: ignore[attr-defined]
        console.print("[yellow]Partial export - re-run with --resume to retry failed roots.[/yellow]")


def _print_comparison(compare_path: Path, comparison: VpnComparison) -> None:
    if not comparison.total_deltas:
        console.print(
            f"[green]VPNs [bold]{comparison.vpn_a}[/bold] and "
            f"[bold]{comparison.vpn_b}[/bold] are identical across all "
            f"{comparison.total_identical} compared objects.[/green] "
            f"Report: {compare_path}"
        )
        return
    table = Table(
        title=f"VPN comparison {comparison.vpn_a} vs {comparison.vpn_b} -> {compare_path}",
        show_lines=False,
    )
    table.add_column("Object Type", style="bold")
    table.add_column(f"Only in {comparison.vpn_a}", justify="right")
    table.add_column(f"Only in {comparison.vpn_b}", justify="right")
    table.add_column("Different", justify="right")
    table.add_column("Identical", justify="right")
    table.add_column("Match", justify="right")
    for outcome in comparison.delta_types:
        table.add_row(
            outcome.sheet, str(outcome.only_a), str(outcome.only_b),
            str(outcome.different), str(outcome.identical), f"{outcome.match_pct:.1f}%",
        )
    table.add_row(
        "[bold]TOTAL[/bold]",
        f"[bold]{comparison.total_only_a}[/bold]",
        f"[bold]{comparison.total_only_b}[/bold]",
        f"[bold]{comparison.total_different}[/bold]",
        f"[bold]{comparison.total_identical}[/bold]",
        "",
    )
    console.print(table)
    clean = len(comparison.types) - len(comparison.delta_types)
    if clean:
        console.print(f"[dim]{clean} object type(s) fully identical (see Summary sheet).[/dim]")


def main() -> None:
    """Console-script entry point."""
    app()


if __name__ == "__main__":
    main()
