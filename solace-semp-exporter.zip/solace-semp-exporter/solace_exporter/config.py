"""Configuration management.

Two dataclasses drive the application:

* :class:`ConnectionConfig` - everything needed to reach the SEMP API.
* :class:`ExportConfig`     - what to export and where to write it.

Values are resolved in ascending precedence::

    built-in defaults  <  config file (TOML)  <  environment  <  CLI flags

Interactive prompting (in :mod:`solace_exporter.cli`) only fills fields that
are still missing after this resolution.
"""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Mapping

from .exceptions import ConfigError

ENV_PREFIX = "SOLACE_"

_TRUE = {"1", "true", "yes", "y", "on"}
_FALSE = {"0", "false", "no", "n", "off"}


def _as_bool(value: Any, name: str) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in _TRUE:
        return True
    if text in _FALSE:
        return False
    raise ConfigError(f"Invalid boolean for {name!r}: {value!r}")


@dataclass(frozen=True)
class ConnectionConfig:
    """Connection parameters for the SEMP v2 management interface."""

    host: str = ""
    port: int = 8080
    username: str = ""
    password: str = ""
    use_ssl: bool = False
    verify_ssl: bool = True
    timeout: float = 30.0
    retries: int = 3
    page_size: int = 100
    workers: int = 8

    @property
    def base_url(self) -> str:
        scheme = "https" if self.use_ssl else "http"
        return f"{scheme}://{self.host}:{self.port}/SEMP/v2/config"

    def validate(self) -> None:
        missing = [n for n in ("host", "username", "password") if not getattr(self, n)]
        if missing:
            raise ConfigError(f"Missing required connection settings: {', '.join(missing)}")
        if not (0 < self.port < 65536):
            raise ConfigError(f"Port out of range: {self.port}")
        if self.page_size < 1:
            raise ConfigError("page_size must be >= 1")
        if self.workers < 1:
            raise ConfigError("workers must be >= 1")

    def redacted(self) -> dict[str, Any]:
        """Dict representation safe for logging / metadata (no password)."""
        data = self.__dict__.copy()
        data["password"] = "***" if self.password else ""
        return data


@dataclass(frozen=True)
class ExportConfig:
    """What to export and how to persist it."""

    scopes: tuple[str, ...] = ("all",)
    vpns: tuple[str, ...] = ()          # empty tuple => all VPNs
    output: Path | None = None
    resume: bool = False
    cache_dir: Path | None = None       # None => platform default
    keep_cache: bool = False
    raw_headers: bool = False           # keep SEMP camelCase column headers
    compare: tuple[str, ...] = ()       # exactly two VPN names -> audit diff workbook
    compare_ignore: tuple[str, ...] = ()  # attribute-name globs excluded from the diff
    compare_output: Path | None = None  # None => <host>_compare_<A>_vs_<B>_<ts>.xlsx
    log_level: str = "INFO"
    log_file: Path = Path("logs/export.log")

    def validate(self, known_scopes: set[str]) -> None:
        unknown = [s for s in self.scopes if s not in known_scopes]
        if unknown:
            raise ConfigError(
                f"Unknown scope(s): {', '.join(unknown)}. "
                f"Valid scopes: {', '.join(sorted(known_scopes))}"
            )
        if self.compare:
            if len(self.compare) != 2:
                raise ConfigError(
                    "--compare needs exactly two VPN names, e.g. --compare prod,dr"
                )
            if self.compare[0] == self.compare[1]:
                raise ConfigError("--compare needs two *different* VPN names")
            if self.vpns and set(self.vpns) != set(self.compare):
                raise ConfigError(
                    "--vpn and --compare disagree; drop --vpn (the compared "
                    "VPNs are fetched automatically)"
                )
        elif self.compare_output:
            raise ConfigError("--compare-output requires --compare")


# --------------------------------------------------------------------------- #
# Layered loading
# --------------------------------------------------------------------------- #

_CONN_FIELDS: dict[str, type] = {
    "host": str, "port": int, "username": str, "password": str,
    "use_ssl": bool, "verify_ssl": bool, "timeout": float,
    "retries": int, "page_size": int, "workers": int,
}
_EXPORT_FIELDS: dict[str, type] = {
    "scopes": tuple, "vpns": tuple, "output": Path, "resume": bool,
    "cache_dir": Path, "keep_cache": bool, "raw_headers": bool,
    "compare": tuple, "compare_ignore": tuple, "compare_output": Path,
    "log_level": str, "log_file": Path,
}


def _coerce(name: str, kind: type, value: Any) -> Any:
    if value is None:
        return None
    try:
        if kind is bool:
            return _as_bool(value, name)
        if kind is tuple:
            if isinstance(value, (list, tuple)):
                return tuple(str(v) for v in value)
            return tuple(p.strip() for p in str(value).split(",") if p.strip())
        if kind is Path:
            return Path(str(value)).expanduser()
        return kind(value)
    except (TypeError, ValueError) as exc:
        raise ConfigError(f"Invalid value for {name!r}: {value!r} ({exc})") from exc


def load_config_file(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    """Read a TOML config file with ``[connection]`` and ``[export]`` tables."""
    try:
        with path.open("rb") as fh:
            raw = tomllib.load(fh)
    except FileNotFoundError as exc:
        raise ConfigError(f"Config file not found: {path}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"Invalid TOML in {path}: {exc}") from exc
    return dict(raw.get("connection", {})), dict(raw.get("export", {}))


def env_overrides(environ: Mapping[str, str] | None = None) -> dict[str, Any]:
    """Extract ``SOLACE_*`` environment variables into a flat mapping."""
    env = os.environ if environ is None else environ
    out: dict[str, Any] = {}
    for name in (*_CONN_FIELDS, *_EXPORT_FIELDS):
        key = ENV_PREFIX + name.upper()
        if key in env and env[key] != "":
            out[name] = env[key]
    return out


def build_configs(
    *,
    file_path: Path | None = None,
    environ: Mapping[str, str] | None = None,
    cli: Mapping[str, Any] | None = None,
) -> tuple[ConnectionConfig, ExportConfig]:
    """Merge all configuration layers into final config objects.

    ``cli`` values of ``None`` are treated as "not provided".
    """
    conn_kwargs: dict[str, Any] = {}
    exp_kwargs: dict[str, Any] = {}

    def apply(source: Mapping[str, Any]) -> None:
        for name, value in source.items():
            if value is None:
                continue
            if name in _CONN_FIELDS:
                conn_kwargs[name] = _coerce(name, _CONN_FIELDS[name], value)
            elif name in _EXPORT_FIELDS:
                exp_kwargs[name] = _coerce(name, _EXPORT_FIELDS[name], value)
            else:
                raise ConfigError(f"Unknown configuration key: {name!r}")

    if file_path is not None:
        file_conn, file_exp = load_config_file(file_path)
        apply(file_conn)
        apply(file_exp)
    apply(env_overrides(environ))
    if cli:
        apply({k: v for k, v in cli.items() if v is not None})

    return ConnectionConfig(**conn_kwargs), ExportConfig(**exp_kwargs)


def with_updates(conn: ConnectionConfig, **updates: Any) -> ConnectionConfig:
    """Return a copy of ``conn`` with coerced field updates (used by prompts)."""
    coerced = {k: _coerce(k, _CONN_FIELDS[k], v) for k, v in updates.items() if v is not None}
    return replace(conn, **coerced)
