"""Solace SEMP Configuration Export CLI.

Exports the complete configuration of a Solace PubSub+ broker via the
SEMP v2 Config API into a hierarchical, human-readable Excel workbook.
"""

__version__ = "1.1.0"
__all__ = ["__version__"]
