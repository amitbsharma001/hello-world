"""Declarative description of a SEMP v2 collection and its place in the tree.

The whole export philosophy hangs on this class: a :class:`CollectionSpec`
names a SEMP endpoint, the fields that identify each object, and its child
collections. The generic :class:`~solace_exporter.exporters.base.TreeExporter`
walks the tree, fetches every level, and *flattens* each child row with every
ancestor identity column prepended - so a queue subscription row reads::

    VPN | Queue | Subscription Topic | <all other attributes...>

instead of a bare topic string.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator


@dataclass(frozen=True)
class CollectionSpec:
    """One SEMP v2 Config collection (or single object) to export.

    Attributes:
        key: Unique machine identifier, e.g. ``"queues.subscriptions"``.
        sheet: Excel worksheet name for this collection.
        path: SEMP path template relative to ``/SEMP/v2/config``. Placeholders
            (``{msgVpnName}``, ``{queueName}`` ...) are filled from the walk
            context and percent-encoded. Multi-key resources join their keys
            with a literal comma, exactly as SEMP expects
            (``bridges/{bridgeName},{bridgeVirtualRouter}/remoteMsgVpns``).
        id_fields: Attribute names identifying an object in this collection.
            They become both the child-walk context and the leading columns.
        friendly: Column-header renames applied to hierarchy/id columns
            (``{"queueName": "Queue"}``). Non-key attributes keep their SEMP
            camelCase names so auditors can match the official docs 1:1.
        children: Nested collections; each child row is exported with all
            ancestor id columns prepended.
        per_vpn: Root-only flag - the walk seeds ``{msgVpnName}`` from the
            selected VPNs. Children always inherit their parent's context.
        single: The path addresses a single object (e.g. the broker root),
            returning a dict rather than a list.
        transpose: Render a ``single`` object as vertical ``Setting | Value``
            rows instead of one very wide row (readability for the ~200
            broker-level attributes).
        optional: Endpoint may be absent on older brokers / editions; a
            NOT-available response is recorded as a skip, never an error.
    """

    key: str
    sheet: str
    path: str
    id_fields: tuple[str, ...]
    friendly: dict[str, str] = field(default_factory=dict)
    children: tuple["CollectionSpec", ...] = ()
    per_vpn: bool = False
    single: bool = False
    transpose: bool = False
    optional: bool = True

    def walk(self) -> Iterator["CollectionSpec"]:
        """Depth-first iteration over this spec and all descendants."""
        yield self
        for child in self.children:
            yield from child.walk()

    def __post_init__(self) -> None:
        if self.single and self.children:
            raise ValueError(f"single-object spec {self.key!r} cannot have children")
