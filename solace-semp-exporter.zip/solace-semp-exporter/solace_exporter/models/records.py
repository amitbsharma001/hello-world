"""Result and metadata records passed between orchestrator, writer and CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import pandas as pd


@dataclass
class SheetData:
    """One worksheet: a flattened, hierarchy-preserving DataFrame."""

    name: str
    frame: pd.DataFrame
    spec_key: str
    endpoint: str
    #: Renamed identity/hierarchy columns (e.g. ``("VPN", "Queue")``). Used by
    #: the VPN comparator to match objects across VPNs; ``()`` disables it.
    id_columns: tuple[str, ...] = ()
    #: True when the sheet's root collection is VPN-scoped. Broker-level
    #: sheets that merely *reference* a VPN (e.g. Virtual Hostnames) stay
    #: False and are excluded from the VPN comparison.
    per_vpn: bool = False

    @property
    def rows(self) -> int:
        return len(self.frame)

    @property
    def columns(self) -> int:
        return len(self.frame.columns)


@dataclass
class SkipInfo:
    """An endpoint that could not be exported (and why)."""

    spec_key: str
    sheet: str
    endpoint: str
    reason: str


@dataclass
class ExportMetadata:
    """Run-level metadata rendered on the Summary / hidden metadata sheets."""

    host: str
    base_url: str
    semp_version: str = "unknown"
    platform: str = "unknown"
    generated_at: datetime = field(default_factory=datetime.now)
    scopes: tuple[str, ...] = ()
    vpn_filter: tuple[str, ...] = ()
    vpn_count: int = 0
    tool_version: str = "0"
    options: dict[str, Any] = field(default_factory=dict)


@dataclass
class ExportResult:
    """Everything a completed export produced."""

    sheets: list[SheetData] = field(default_factory=list)
    skipped: list[SkipInfo] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    duration_s: float = 0.0
    api_calls: int = 0
    vpn_count: int = 0

    @property
    def total_rows(self) -> int:
        return sum(sheet.rows for sheet in self.sheets)
