"""Derived columns: cross-sheet enrichment applied after the export walk.

The export tree mirrors SEMP exactly - one sheet per collection - which is
correct but occasionally inconvenient: a bridge's *destination* lives on the
child ``Bridge Remote VPNs`` sheet, so answering "where does this bridge
actually go?" means jumping sheets and matching keys by hand.

This module adds **derived columns** to the exported frames after the walk
finishes. Derived values are pure functions of data already fetched - no extra
SEMP calls, no invented facts - and they are recorded in
:data:`DERIVED_COLUMNS` so the VPN comparator can skip them (the underlying
source attribute is compared instead, avoiding double-reported deltas).

Extending: add a function decorated with ``@enricher``; it receives the sheets
indexed by spec key and mutates frames in place. A broken enricher is logged
and skipped - it can never sink an export.
"""

from __future__ import annotations

from typing import Callable, Iterable, Sequence

import pandas as pd

from .models import SheetData
from .utils.logging import get_logger

log = get_logger("enrich")

#: Column headers produced by enrichers (excluded from the VPN comparison).
DERIVED_COLUMNS: set[str] = set()

EnricherFunc = Callable[[dict[str, SheetData]], None]
ENRICHERS: list[EnricherFunc] = []


def enricher(func: EnricherFunc) -> EnricherFunc:
    """Register a cross-sheet enrichment pass."""
    ENRICHERS.append(func)
    return func


def enrich_sheets(sheets: Sequence[SheetData]) -> list[SheetData]:
    """Run every registered enricher over ``sheets`` (mutated in place)."""
    by_key = {sheet.spec_key: sheet for sheet in sheets}
    for func in ENRICHERS:
        try:
            func(by_key)
        except Exception:  # never let a derived column break the export
            log.exception("Enricher %s failed; skipped",
                          getattr(func, "__name__", func))
    return list(sheets)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def split_location(location: object) -> tuple[str, str]:
    """Split a SEMP location string into ``(host, port)``.

    Handles the forms SEMP returns for bridge/RDP remotes::

        "broker.example.com:55555"  -> ("broker.example.com", "55555")
        "203.0.113.9:55443"         -> ("203.0.113.9", "55443")
        "[2001:db8::1]:55555"       -> ("2001:db8::1", "55555")
        "2001:db8::1"               -> ("2001:db8::1", "")
        "v:solace-primary"          -> ("solace-primary", "")   # virtual router
        "hostA:55555,hostB:55555"   -> ("hostA", "55555")       # first entry
        ""                          -> ("", "")

    The full original string is always kept in the ``Remote Location`` column,
    so a redundancy list is never lost - only summarised.
    """
    text = str(location or "").strip()
    if not text:
        return "", ""
    if text[:2].lower() == "v:":          # virtual-router reference, not a host
        return text[2:].strip(), ""
    first = text.split(",")[0].strip()
    if first.startswith("["):             # bracketed IPv6 literal
        host, _, rest = first[1:].partition("]")
        return host, rest.lstrip(":").strip()
    host, separator, port = first.rpartition(":")
    if not separator or not port.isdigit() or ":" in host:
        return first, ""                  # bare host, or unbracketed IPv6
    return host, port


def _join(values: Iterable[object]) -> str:
    """Join distinct, non-empty values in first-seen order."""
    seen: list[str] = []
    for value in values:
        text = "" if value is None else str(value).strip()
        if text and text.lower() != "nan" and text not in seen:
            seen.append(text)
    return " | ".join(seen)


def _insert_columns(
    frame: pd.DataFrame,
    after: str | None,
    columns: dict[str, list],
) -> None:
    """Insert ``columns`` into ``frame`` immediately after column ``after``."""
    for name in columns:
        if name in frame.columns:
            frame.drop(columns=[name], inplace=True)
    existing = list(frame.columns)
    position = existing.index(after) + 1 if after in existing else len(existing)
    for offset, (name, values) in enumerate(columns.items()):
        frame.insert(position + offset, name, values)
        DERIVED_COLUMNS.add(name)


# --------------------------------------------------------------------------- #
# Bridges: surface the remote VPN and remote host on the Bridges sheet
# --------------------------------------------------------------------------- #
_BRIDGE_KEYS = ("VPN", "Bridge", "Bridge Virtual Router")


@enricher
def bridge_remote_details(sheets: dict[str, SheetData]) -> None:
    """Split remote locations and lift the destination onto ``Bridges``.

    * ``Bridge Remote VPNs`` gains ``Remote Host`` / ``Remote Port`` next to
      ``Remote Location``.
    * ``Bridges`` gains ``Remote VPN``, ``Remote Host``, ``Remote Port``,
      ``Remote Location``, ``Remote Interface``, ``Remote Queue Binding``,
      ``Remote TLS`` and ``Remote Connections`` directly after its identity
      columns - so one row answers "which bridge, to which VPN, on which
      host, over TLS or not".

    A bridge with several remote entries (redundant locations) shows every
    distinct value joined with ``" | "``; ``Remote Connections`` carries the
    count so a multi-homed bridge is obvious at a glance.
    """
    remotes = sheets.get("bridges.remoteMsgVpns")
    if remotes is not None and not remotes.frame.empty and \
            "Remote Location" in remotes.frame.columns:
        frame = remotes.frame
        split = [split_location(v) for v in frame["Remote Location"]]
        _insert_columns(frame, "Remote Location", {
            "Remote Host": [host for host, _ in split],
            "Remote Port": [port for _, port in split],
        })
        log.debug("Bridge Remote VPNs: added Remote Host/Port for %d row(s)", len(frame))

    bridges = sheets.get("bridges")
    if bridges is None:
        return
    frame = bridges.frame
    if "Bridge" not in frame.columns:
        return

    grouped: dict[tuple[str, ...], list[dict]] = {}
    if remotes is not None and not remotes.frame.empty:
        remote_frame = remotes.frame
        keys = [k for k in _BRIDGE_KEYS if k in remote_frame.columns]
        if keys:
            for record in remote_frame.to_dict("records"):
                identity = tuple(str(record.get(k, "")) for k in keys)
                grouped.setdefault(identity, []).append(record)

    keys = [k for k in _BRIDGE_KEYS if k in frame.columns]
    derived: dict[str, list] = {name: [] for name in (
        "Remote VPN", "Remote Host", "Remote Port", "Remote Location",
        "Remote Interface", "Remote Queue Binding", "Remote TLS",
        "Remote Connections",
    )}
    for record in frame.to_dict("records"):
        identity = tuple(str(record.get(k, "")) for k in keys)
        matches = grouped.get(identity, [])
        derived["Remote VPN"].append(_join(m.get("Remote VPN") for m in matches))
        derived["Remote Host"].append(_join(m.get("Remote Host") for m in matches))
        derived["Remote Port"].append(_join(m.get("Remote Port") for m in matches))
        derived["Remote Location"].append(_join(m.get("Remote Location") for m in matches))
        derived["Remote Interface"].append(_join(m.get("Remote Interface") for m in matches))
        derived["Remote Queue Binding"].append(_join(m.get("queueBinding") for m in matches))
        derived["Remote TLS"].append(_join(m.get("tlsEnabled") for m in matches))
        derived["Remote Connections"].append(len(matches))

    _insert_columns(frame, keys[-1] if keys else None, derived)
    log.debug("Bridges: lifted remote details onto %d row(s)", len(frame))


# --------------------------------------------------------------------------- #
# REST delivery points: same treatment for the consumer endpoint
# --------------------------------------------------------------------------- #
@enricher
def rdp_remote_details(sheets: dict[str, SheetData]) -> None:
    """Lift REST consumer endpoints onto the ``REST Delivery Points`` sheet.

    Adds ``Remote Host``, ``Remote Port``, ``Remote TLS`` and
    ``REST Consumers`` (count) so an RDP row shows where it actually delivers
    without opening the consumers sheet.
    """
    consumers = sheets.get("rdps.restConsumers")
    rdps = sheets.get("rdps")
    if rdps is None or "RDP" not in rdps.frame.columns:
        return

    grouped: dict[tuple[str, str], list[dict]] = {}
    if consumers is not None and not consumers.frame.empty:
        consumer_frame = consumers.frame
        if {"VPN", "RDP"} <= set(consumer_frame.columns):
            for record in consumer_frame.to_dict("records"):
                identity = (str(record.get("VPN", "")), str(record.get("RDP", "")))
                grouped.setdefault(identity, []).append(record)

    frame = rdps.frame
    derived: dict[str, list] = {
        "Remote Host": [], "Remote Port": [], "Remote TLS": [], "REST Consumers": [],
    }
    for record in frame.to_dict("records"):
        identity = (str(record.get("VPN", "")), str(record.get("RDP", "")))
        matches = grouped.get(identity, [])
        derived["Remote Host"].append(_join(m.get("remoteHost") for m in matches))
        derived["Remote Port"].append(_join(m.get("remotePort") for m in matches))
        derived["Remote TLS"].append(_join(m.get("tlsEnabled") for m in matches))
        derived["REST Consumers"].append(len(matches))
    _insert_columns(frame, "RDP", derived)
