"""Export orchestration.

:class:`ExportOrchestrator` turns a scope selection into an
:class:`~solace_exporter.models.ExportResult`:

1. resolve scopes -> root :class:`CollectionSpec` trees
2. discover / filter the VPN list (for per-VPN roots)
3. run one :class:`TreeExporter` per root, sequentially, sharing a single
   :class:`ThreadPoolExecutor` (parallelism lives *inside* each level, so
   nested-pool deadlocks are impossible)
4. checkpoint every fetched subtree so ``--resume`` can skip completed roots
5. aggregate sheets, skips, errors and timings
"""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor

from .config import ConnectionConfig, ExportConfig
from .exceptions import ConfigError, SempExporterError
from .exporters import ProgressHook, RunContext, TreeExporter, resolve_scopes
from .models import CollectionSpec, ExportResult
from .semp_client import SempClientProtocol
from .utils.checkpoint import Checkpoint
from .utils.logging import get_logger

log = get_logger("orchestrator")


class ExportOrchestrator:
    """Runs the full export pipeline for a scope/VPN selection."""

    def __init__(
        self,
        client: SempClientProtocol,
        connection: ConnectionConfig,
        export: ExportConfig,
        checkpoint: Checkpoint | None = None,
    ) -> None:
        self._client = client
        self._connection = connection
        self._export = export
        self._checkpoint = checkpoint

    # ------------------------------------------------------------------ #
    def _select_vpns(self, roots: list[CollectionSpec]) -> tuple[str, ...]:
        """Resolve the VPN list, honouring ``--vpn`` filters."""
        if not any(spec.per_vpn for root in roots for spec in root.walk()):
            return self._export.vpns
        available = self._client.vpn_names()  # type: ignore[attr-defined]
        if not self._export.vpns:
            return tuple(available)
        missing = sorted(set(self._export.vpns) - set(available))
        if missing:
            raise ConfigError(
                f"Requested VPN(s) not found on broker: {', '.join(missing)}. "
                f"Available: {', '.join(sorted(available)) or '(none)'}"
            )
        return tuple(v for v in available if v in set(self._export.vpns))

    # ------------------------------------------------------------------ #
    def run(self, progress: ProgressHook | None = None) -> ExportResult:
        started = time.monotonic()
        result = ExportResult()
        progress = progress or ProgressHook()

        roots = resolve_scopes(self._export.scopes)
        vpns = self._select_vpns(roots)
        result.vpn_count = len(vpns)
        log.info(
            "Exporting %d root object type(s) across %d VPN(s)",
            len(roots), len(vpns),
        )

        with ThreadPoolExecutor(
            max_workers=self._connection.workers, thread_name_prefix="semp"
        ) as pool:
            for root in roots:
                exporter = TreeExporter(root)
                cached = self._checkpoint.load(root.key) if self._checkpoint else None
                ctx = RunContext(
                    client=self._client,
                    pool=pool,
                    vpns=vpns,
                    progress=progress,
                    cached_rows=cached,
                )
                try:
                    output = exporter.export(ctx)
                except SempExporterError as exc:
                    # A hard failure on one root must not sink the others.
                    message = f"{root.sheet}: {exc}"
                    log.error("Export failed for %s", message)
                    result.errors.append(message)
                    continue
                result.sheets.extend(output.sheets)
                result.skipped.extend(output.skipped)
                # Cache only fully-clean roots: a resumed run must re-probe
                # endpoints that were unavailable, so skips are re-detected
                # and never silently reappear as empty sheets.
                if self._checkpoint and not output.skipped:
                    self._checkpoint.save(root.key, output.raw_rows)

        result.duration_s = time.monotonic() - started
        result.api_calls = getattr(self._client, "call_count", 0)
        log.info(
            "Export finished: %d sheets, %d rows, %d skipped, %d errors in %.1fs "
            "(%d API calls)",
            len(result.sheets), result.total_rows, len(result.skipped),
            len(result.errors), result.duration_s, result.api_calls,
        )
        return result
