# solace-semp-exporter

Export the complete configuration of a **Solace PubSub+** broker - via the
**SEMP v2 Config API** - into a single, hierarchical, audit-ready **Excel
workbook**. Built for documentation, configuration audits, VPN comparisons and
environment reviews in enterprise estates with thousands of queues, bridges
and users.

```
$ solace-export
Solace Host: broker.example.com
Use SSL (HTTPS)? [y/N]: y
Management Port [1943]:
Verify SSL certificate? [Y/n]: y
Username: admin
Password: ********
                       Export Scopes
  #  Scope                 Contents
  1  all                   All Objects
  2  vpn                   Message VPNs
  3  queues                Queues & Subscriptions
  4  topic-endpoints       Topic Endpoints
  5  bridges               Bridges
  ...
Export scope (numbers or names, comma-separated) [1]: 1
VPNs to export (comma-separated, blank = all VPNs):
Output file name [broker.example.com_20260710_094501.xlsx]:
Connecting to https://broker.example.com:1943/SEMP/v2/config ...
⠸ Downloading Queue Subscriptions... ━━━━━━━━━━━━━━━ 412/460 0:00:07
```

## The export philosophy: hierarchy, not JSON dumps

Every worksheet is **flattened with its full ancestor identity**. A queue
subscription is never a bare topic - it is:

| VPN  | Queue      | Subscription Topic      | ...all SEMP attributes... |
|------|------------|-------------------------|---------------------------|
| prod | ORDERS.IN  | orders/created/>        | ...                       |
| prod | billing/eu | billing/eu/invoices/>   | ...                       |

and a bridge remote subscription is:

| VPN | Bridge | Bridge Virtual Router | Remote Subscription Topic | Deliver Always Enabled |
|-----|--------|-----------------------|---------------------------|------------------------|

Leading columns are always the parent chain (`VPN`, `Queue`, `Bridge`, ...).
All remaining SEMP attributes are rendered as **friendly headers** by default
(`maxMsgSpoolUsage` -> `Max Msg Spool Usage`, acronym-aware: `TLS`, `MQTT`,
`DMR`, `ACL`, ...). Auditors who prefer 1:1 traceability with the official
SEMP API docs can keep the raw camelCase names with `--raw-headers`. Nested
attribute objects (the `event*Threshold` pairs) are flattened into dotted
columns (`Event Msg Spool Usage Threshold / Set Percent`) so they filter and
sort like everything else.

## Features

- **47 worksheets across 20 scopes**: VPNs, Queues + Subscriptions, Topic
  Endpoints, Bridges (+ Remote VPNs + Remote Subscriptions), Client Usernames
  (+ Attributes), Client Profiles, ACL Profiles (+ publish / subscribe /
  share-name / connect exceptions), Authorization Groups, Replay Logs
  (+ topic filters), DMR (Clusters -> Links -> Remote Addresses, VPN Bridges),
  Certificate Authorities, Broker + Virtual Hostnames + Mgmt OAuth, MQTT
  (Sessions + Subscriptions, Retain Caches), REST Delivery Points
  (+ Consumers + Queue Bindings + Request Headers), Distributed Caches
  (full 4-level tree), Queue / Topic-Endpoint Templates, Replicated Topics,
  JNDI (CFs / Queues / Topics).
- **VPN comparison audit report** (`--compare prod,dr`): a second workbook
  classifying every per-VPN object as *only in A*, *only in B*, *different*
  (with exact attribute-level deltas, side by side) or *identical* - VPN
  settings included. Status-tinted rows, per-type match percentages, and
  `--compare-ignore 'replication*'` globs for intentionally-different
  attributes.
- **Interactive and non-interactive**: every prompt is also a flag, a
  `SOLACE_*` environment variable and a TOML key
  (precedence: `defaults < file < env < CLI`).
- **Scales**: shared `ThreadPoolExecutor` (default 8 workers), transparent
  cursor **pagination**, connection pooling, automatic **retries** (429/5xx,
  exponential backoff), per-request timeout.
- **Resilient**: endpoints not supported by the broker edition/version are
  detected via the SEMP error status (`INVALID_PATH`/`NOT_ALLOWED`) and
  **skipped gracefully** (listed on the Summary sheet) - and the very first
  such answer **short-circuits** the remaining per-parent calls for that
  endpoint. A `NOT_FOUND` on a single parent (object deleted mid-export) is
  tolerated without cascading. A hard failure on one object type never sinks
  the rest; `--resume` reloads checkpointed data instead of re-downloading
  completed roots.
- **Professional Excel output**: Summary cover sheet (broker, SEMP version,
  per-sheet statistics, skipped endpoints), frozen headers, autofilter,
  banded-row Excel Tables, auto column widths, friendly (or `--raw-headers`)
  column names, a transposed `Broker` sheet (`Setting | Value` instead of one
  200-column row), hidden `_metadata` sheet with the redacted run
  configuration, formula-injection-safe cells.
- **Safe with hostile names**: object names containing `/`, spaces or `#` are
  percent-encoded on the wire and exported verbatim.
- **Clean architecture**: declarative `CollectionSpec` trees + one generic
  `TreeExporter`; adding an object type is ~10 lines of data, not code.

## Installation

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .            # installs the `solace-export` command
# dev extras:
pip install -e ".[dev]" && pytest
```

Requires Python 3.12+.

## Quick start

Interactive (prompts for anything missing):

```bash
solace-export
```

Fully non-interactive:

```bash
export SOLACE_PASSWORD='s3cret'
solace-export --no-interactive \
  --host broker.example.com --port 1943 --ssl \
  --username admin --password-env SOLACE_PASSWORD \
  --scope queues --scope bridges --scope acl \
  --vpn prod --vpn staging \
  --workers 12 --output prod_audit.xlsx
```

With a config file (see `examples/export.example.toml`):

```bash
solace-export --config examples/export.example.toml
```

Useful commands:

```bash
solace-export --list-scopes      # numbered scope table
solace-export --version
solace-export ... --resume       # reuse checkpoints after a failed run
solace-export ... --clear-cache  # drop checkpoints for this host/scope/vpn set
```

## CLI reference

| Flag | Env var | Default | Purpose |
|---|---|---|---|
| `--host, -H` | `SOLACE_HOST` | prompt | Broker management host |
| `--port, -P` | `SOLACE_PORT` | `8080` | SEMP port (1943 for TLS) |
| `--username, -u` | `SOLACE_USERNAME` | prompt | Management user |
| `--password` | `SOLACE_PASSWORD` | prompt (hidden) | Prefer `--password-env` |
| `--password-env` | - | `SOLACE_PASSWORD` | Env var to read password from |
| `--ssl/--no-ssl` | `SOLACE_USE_SSL` | `--no-ssl` | HTTPS to SEMP |
| `--verify-ssl/--no-verify-ssl` | `SOLACE_VERIFY_SSL` | verify | TLS cert verification |
| `--scope, -s` | `SOLACE_SCOPES` | `all` | Scope name or menu number, repeatable |
| `--vpn, -m` | `SOLACE_VPNS` | all VPNs | Restrict per-VPN objects, repeatable |
| `--compare` | `SOLACE_COMPARE` | - | Two VPNs to diff (`prod,dr`); writes the audit workbook |
| `--compare-ignore` | `SOLACE_COMPARE_IGNORE` | - | Attribute glob(s) excluded from the diff, repeatable |
| `--compare-output` | `SOLACE_COMPARE_OUTPUT` | `<host>_compare_<A>_vs_<B>_<ts>.xlsx` | Comparison workbook path |
| `--output, -o` | `SOLACE_OUTPUT` | `<host>_<timestamp>.xlsx` | Workbook path |
| `--config, -c` | - | - | TOML file (`[connection]`, `[export]`) |
| `--env-file` | - | - | Load a `.env` file |
| `--page-size` | `SOLACE_PAGE_SIZE` | `100` | SEMP pagination size |
| `--workers, -w` | `SOLACE_WORKERS` | `8` | Concurrent request threads |
| `--timeout` | `SOLACE_TIMEOUT` | `30` | Per-request timeout (s) |
| `--retries` | `SOLACE_RETRIES` | `3` | Retries for 429/5xx |
| `--resume` | `SOLACE_RESUME` | off | Load checkpoints from a previous run |
| `--raw-headers/--friendly-headers` | `SOLACE_RAW_HEADERS` | friendly | Keep SEMP camelCase column names |
| `--cache-dir` | `SOLACE_CACHE_DIR` | `~/.cache/solace-exporter` | Checkpoint location |
| `--keep-cache` | `SOLACE_KEEP_CACHE` | off | Keep checkpoints after success |
| `--clear-cache` | - | - | Delete matching checkpoints and exit |
| `--no-interactive` | - | interactive | Never prompt (CI mode) |
| `--log-level` / `--log-file` | `SOLACE_LOG_LEVEL/_FILE` | `INFO`, `logs/export.log` | Logging |

Logs always capture full DEBUG detail (every API URL, timings, retries,
skips) in the log file; the console shows `--log-level` and the progress bar.
`python -m solace_exporter` is equivalent to `solace-export`.

**Exit codes:** `0` success (including partial exports with skips), `1`
transport/API/write failure, `2` configuration error (missing host, unknown
scope, VPN not found), `130` interrupted (`Ctrl-C`; re-run with `--resume`).

## Architecture

```
cli.py            Typer front door: prompts, flags, progress bar, summary table
config.py         Layered config (defaults < TOML < env < CLI), validation
semp_client.py    HTTP: sessions, retries, pagination, error mapping, about()
exporter.py       ExportOrchestrator: scopes -> TreeExporters -> ExportResult
excel_writer.py   Summary sheet, formatted data sheets, hidden metadata
models/spec.py    CollectionSpec - declarative endpoint tree
models/records.py SheetData / SkipInfo / ExportMetadata / ExportResult
exporters/base.py BaseExporter contract + generic TreeExporter (BFS + pool)
exporters/*.py    One module of CollectionSpecs per object family
exporters/registry.py  Scope menu <-> root specs (single source of truth)
utils/            path encoding, Excel sanitisation, logging, checkpoints
testing.py        FakeSempClient + sample dataset (tests + sample workbook)
```

Every exporter follows the `BaseExporter` pipeline
`fetch() -> resolve_relationships() -> flatten() -> export()`. The generic
`TreeExporter` walks a `CollectionSpec` tree breadth-first, fetching each
level's contexts concurrently on one shared thread pool, then back-fills
ancestor keys into every row and emits one hierarchy-flattened DataFrame per
spec.

### Adding a new object type

1. Declare a spec (in an existing or new `exporters/<family>.py`):

```python
MY_CHILD = CollectionSpec(
    key="widgets.parts", sheet="Widget Parts",
    path=f"{VPN_PREFIX}/widgets/{{widgetName}}/parts",
    id_fields=("partName",), friendly={"partName": "Part"},
)
WIDGETS = CollectionSpec(
    key="widgets", sheet="Widgets",
    path=f"{VPN_PREFIX}/widgets",
    id_fields=("widgetName",), friendly={"widgetName": "Widget"},
    children=(MY_CHILD,), per_vpn=True,
)
```

2. Register it in `exporters/registry.py`:

```python
("widgets", ScopeGroup("Widgets", (widgets.WIDGETS,))),
```

Done - menu entry, `--scope widgets`, hierarchy columns, pagination,
concurrency, skip handling, checkpointing and Excel formatting all apply
automatically. Endpoints needing bespoke logic can subclass `BaseExporter`
directly instead.

## VPN comparison audit report

Compare two VPNs - prod vs DR, prod vs staging, pre- vs post-migration -
across **every per-VPN object type in one run**:

```bash
solace-export --host broker --username auditor --scope all \
  --compare prod,dr --compare-ignore 'replication*'
```

One fetch produces two workbooks: the full export (the raw evidence) and
`<host>_compare_prod_vs_dr_<ts>.xlsx` (the findings). The comparison workbook
contains:

- **Summary** - for *every* compared object type: object counts per VPN,
  `Only in A` / `Only in B` / `Different` / `Identical` counts and a match
  percentage, plus roll-up totals. Types with deltas are highlighted.
- **One delta sheet per object type that differs** (clean types stay on the
  Summary only). Long-format rows, status-tinted for scanning:

  | Status | Queue | Attribute | prod | dr |
  |---|---|---|---|---|
  | Only in prod | ORDERS.IN |  | present | missing |
  | Only in dr | SANDBOX.Q1 |  | missing | present |
  | Different | BILLING.EU | Max Msg Spool Usage | 5000 | 1500 |
  | Different | BILLING.EU | Owner | app-billing | app-billing-dr |

  Orange = only in A, blue = only in B, amber = attribute delta.

How matching works: an object's identity is its ancestor chain **minus the
VPN** - a queue subscription matches by `(Queue, Subscription Topic)`, a
bridge remote by `(Bridge, Bridge Virtual Router, Remote VPN, ...)`. The
`VPNs` sheet itself diffs attribute-by-attribute (spool sizing, auth,
service enablement, ...). Broker-level objects (DMR clusters, cert
authorities, virtual hostnames, the Broker object) are out of scope for a
VPN diff by design.

Notes for auditors:

- An attribute **absent on one side** shows as `Different` with a blank cell.
- Objects present in both VPNs with zero deltas are counted as `Identical`
  but not listed row-by-row.
- `--compare-ignore` globs match both the raw SEMP name and the friendly
  header (`'replication*'` == `'Replication *'`); identity columns can never
  be ignored. Ignored patterns are recorded on the Summary sheet, so the
  report always states its own blind spots.
- The compared pair is fetched automatically; combining `--compare` with a
  conflicting `--vpn` filter is rejected.

## Resume after failure

Fetched data is checkpointed per root object type under
`~/.cache/solace-exporter/<run-id>/` (run-id = hash of host + port + scopes +
VPN filter). If a run dies - network drop, Ctrl-C, broker restart - re-run the
same command with `--resume`: completed roots load from cache, only the rest
is re-downloaded. Roots that contained *skipped* endpoints are deliberately
never cached, so a resumed run re-probes them and skip reasons stay accurate
(they can never silently reappear as empty sheets). Checkpoints are cleared
automatically after a fully successful export unless `--keep-cache` is set.

## Sample output

`examples/sample_export.xlsx` (full export, 42 sheets) and
`examples/sample_vpn_compare.xlsx` (prod-vs-dev comparison audit) are
generated by `scripts/make_sample.py`, which runs the **real pipeline**
against the built-in fake broker - regenerate any time with:

```bash
python scripts/make_sample.py
```

## Security notes

- Passwords are never written to logs, checkpoints, the workbook or the
  hidden metadata sheet (config is redacted first).
- Prefer `--password-env` / `SOLACE_PASSWORD` over `--password` (which can
  leak via shell history and process lists).
- Cell values are guarded against Excel formula injection (`=`, `+`, `-`,
  `@` prefixes are escaped) and illegal control characters are stripped.
- `--no-verify-ssl` prints a warning; use only against trusted lab brokers.
- A read-only SEMP user (`read-only` management access level) is sufficient.

## Limitations

- **Config API only.** Runtime state - HA/redundancy status, spool usage,
  client connections, stats - lives in the SEMP *monitor* API and is out of
  scope. High Availability is therefore not exported as a sheet.
- Topic Endpoint *subscriptions* are not exposed by the SEMP v2 Config API
  (a subscription is set by the consuming client), so no such sheet exists.
- Sheets are capped at Excel's limit of 1,048,575 data rows; split giant
  estates with `--vpn` filters if you ever hit it.
- Legacy/deprecated endpoints superseded in current SEMP (e.g. broker-level
  `certAuthorities`) are intentionally not queried.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Authentication/authorization failed (HTTP 401/403)` | Check user/password and management access level |
| `TLS error contacting ...` | Wrong port (use 1943 for HTTPS) or untrusted cert -> `--no-verify-ssl` for lab boxes |
| `Cannot reach broker` | Host/port/firewall; SEMP enabled on mgmt interface? |
| Many "Skipped endpoints" on Summary | Normal: feature not licensed/enabled on that edition (e.g. caches on software brokers) |
| Export interrupted | Re-run identical command with `--resume` |
| Empty per-VPN sheets | Check `--vpn` spelling (`ConfigError` lists available VPNs) |

## Development

```bash
pip install -e ".[dev]"
pytest        # 50 tests: client, text utils, tree exporter, compare, writer, pipeline, CLI
python scripts/make_sample.py
```

## License

MIT
