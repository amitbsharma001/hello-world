# 4 — Migrate / clone a VPN (Windows)

Copies every object of one Message VPN to another VPN — on the same broker or
a different one — and writes a report of exactly what happened.

> **This is the only mode that writes to a broker.** It creates and updates;
> it **never deletes**. Read §4.1 and §4.2 before the first live run.

---

## 4.1 Before you start

| Check | Why |
|---|---|
| Target SEMP account has **read-write / admin** global access | Creates will be rejected otherwise. The tool warns if the level looks insufficient, then still tries |
| You have a change record / maintenance window | Objects appear on the target immediately |
| The target VPN name is agreed | Same name only makes sense on a *different* broker |
| You know which secrets you must re-enter afterwards | SEMP never returns passwords — see §4.7 |
| Do **not** use `--no-verify-ssl` against a production target | Writes to an unverified endpoint |

Two supported shapes:

* **Cross-broker clone** — `prod` on broker A becomes `prod` (or any name) on broker B.
* **Same-broker copy** — `prod` becomes `prod-copy` on the same broker. A
  different target name is mandatory here; the tool enforces it.

---

## 4.2 Always dry-run first

A dry run fetches the source, builds the full plan, and writes **nothing**:

```powershell
$env:SOLACE_PASSWORD        = Read-Host "Source SEMP password"
$env:SOLACE_TARGET_PASSWORD = Read-Host "Target SEMP password"

solace-export `
  --host prod-broker.example.com --ssl --username admin `
  --migrate `
  --migrate-to-host dr-broker.example.com --migrate-to-ssl --migrate-to-username admin `
  --source-vpn prod --target-vpn prod `
  --migrate-dry-run `
  --migrate-report "C:\Reports\prod_to_dr_PLAN.xlsx" `
  --no-interactive
```

Open the report. **Migration Log** lists every object with its action:

| Colour | Action | Meaning |
|---|---|---|
| Amber | `planned` | Would be created (dry run only) |
| Green | `created` | Created on the target (live run) |
| Blue | `updated` | Existed and was PATCHed (`--migrate-exists update`) |
| Grey | `skipped` | Existed and was left alone, or a system object |
| Red | `failed` | Rejected by the target — reason in the detail column |

Review the plan with whoever owns the target, then re-run without
`--migrate-dry-run`.

---

## 4.3 Interactive migration (recommended for one-offs)

```powershell
solace-export --host prod-broker.example.com --migrate
```

Or just run `solace-export` and choose `3` (Migrate) at the operation menu -
`--migrate` simply skips that question.

The prompts are, in order:

```
Operation [1]: 3                         <- only when --migrate wasn't passed
Copy to a different broker? [y/N]        <- n = same-broker copy
  Target Solace Host
  Target uses SSL (HTTPS)? [Y/n]
  Target Management Port [1943]
  Verify target SSL certificate? [Y/n]
  Target Username [<source username>]
  Target Password                        <- hidden
Source VPN
Use the same VPN name on the target? [Y/n]
  Target VPN name                        <- asked if you answered n,
                                            and always on the same broker
If an object already exists on the target (skip/update/fail) [skip]
...plan is displayed...
Proceed and write N objects to <host> / VPN '<name>'? [y/N]
```

Answering **no** at the final confirmation is safe: the run degrades to a dry
run and still produces the plan report.

> Passing any migration option (`--source-vpn`, `--migrate-to-host`, …) without
> `--migrate` selects Migrate automatically on a terminal, and is rejected with
> exit code 2 in a script - those options are never silently ignored.

---

## 4.4 Same-broker copy (e.g. clone PROD to build a test VPN)

```powershell
solace-export --host broker.example.com --ssl --username admin `
  --migrate `
  --source-vpn prod --target-vpn prod-uat `
  --migrate-dry-run
```

No target connection flags — omitting `--migrate-to-host` means "same broker".
Drop `--migrate-dry-run` and add `--yes` to execute.

---

## 4.5 Live cross-broker run

```powershell
solace-export `
  --host prod-broker.example.com --ssl --username admin `
  --migrate `
  --migrate-to-host dr-broker.example.com --migrate-to-ssl `
  --migrate-to-username admin `
  --source-vpn prod --target-vpn prod `
  --migrate-exists skip `
  --migrate-report "C:\Reports\prod_to_dr_RUN.xlsx" `
  --yes --no-interactive
```

`--yes` is **required** in non-interactive mode — without it the run exits
with code 2 rather than writing silently. Keep the report; it is the record of
the change.

Target credentials can come from the environment instead of flags:

```powershell
$env:SOLACE_TARGET_HOST     = "dr-broker.example.com"
$env:SOLACE_TARGET_SSL      = "true"
$env:SOLACE_TARGET_USERNAME = "admin"
$env:SOLACE_TARGET_PASSWORD = Read-Host "Target password"
$env:SOLACE_SOURCE_VPN      = "prod"
$env:SOLACE_TARGET_VPN      = "prod"

solace-export --host prod-broker.example.com --migrate --migrate-dry-run
```

---

## 4.6 What gets migrated, and in what order

Dependency-ordered so parents exist before children:

```
Message VPN
  -> ACL profiles (+ topic/connect exceptions)
  -> client profiles
  -> queue templates -> topic endpoint templates
  -> client usernames -> authorization groups
  -> queues -> queue subscriptions
  -> topic endpoints
  -> JNDI connection factories / queues / topics
  -> replay logs
  -> MQTT retain caches -> MQTT sessions (+ subscriptions)
  -> REST delivery points -> REST consumers + queue bindings
  -> bridges -> bridge remote VPNs / remote subscriptions
  -> replicated topics -> distributed caches -> DMR bridges
  -> OAuth profiles -> sequenced topics
```

`--scope` narrows migration exactly as it narrows export — useful for
"just push the new ACLs to DR":

```powershell
solace-export --host prod-broker --migrate `
  --migrate-to-host dr-broker --migrate-to-username admin `
  --source-vpn prod --target-vpn prod `
  --scope acl --scope client-usernames `
  --migrate-exists update --migrate-dry-run
```

**Not migrated (by design):**

* Broker-level configuration — certificate authorities, virtual hostnames,
  syslog, system-wide settings. Those are not VPN-scoped; export them with
  `--scope broker --scope certificates` and apply per your platform process.
* System objects prefixed with `#` (except `#DEAD_MSG_QUEUE`).
* Anything runtime — bindings, spooled messages, live connections.
* DMR bridges will fail on the target unless the corresponding cluster exists
  there first.

---

## 4.7 Passwords do not migrate — plan for it

SEMP **never returns secrets**, so objects that need one arrive without it.
The report's Summary sheet lists exactly which ones. Typically:

| Object | What to re-enter on the target |
|---|---|
| Client usernames | The password for each username |
| Bridge remote VPNs | Remote broker credentials |
| REST consumers | Authentication (basic / OAuth / client cert) |
| OAuth profiles | Client secrets |

Until these are set, the objects exist but will not authenticate. Budget this
step into the change window.

---

## 4.8 Existing objects: `skip` / `update` / `fail`

| Policy | Behaviour | Use when |
|---|---|---|
| `skip` (default) | Leave the existing object untouched | First sync, or filling gaps on a partly-built VPN |
| `update` | PATCH the existing object to match the source | Re-syncing DR after a change window |
| `fail` | Stop and record a failure | You expect a clean target and want to know immediately if it isn't |

`update` overwrites attributes on the target — dry-run it first and read the
`updated` rows before committing.

---

## 4.9 Safety behaviour you can rely on

* **Nothing is ever deleted.** Objects on the target that don't exist in the
  source are left alone — this is a copy, not a sync-to-identical.
* **Unknown attributes are stripped and retried.** If the target runs an older
  broker version that rejects an attribute, the migrator removes it and retries
  (up to 15 times per object); every stripped attribute is recorded in the log
  so nothing silently disappears.
* **Failed parents cascade.** If a queue can't be created, its subscriptions
  are skipped rather than failing one by one.
* **VPN creation failure aborts the run** — no half-built VPN.
* **Aborting at the confirmation prompt** produces a plan-only report.

---

## 4.10 After the run — verify

```powershell
# 1 - compare source and target VPN on the target broker, if both live there
solace-export --host dr-broker.example.com --scope all `
  --compare prod --compare prod-uat

# 2 - or export the target and read the Findings sheet
solace-export --host dr-broker.example.com --scope all --vpn prod `
  --report-title "DR VPN after migration" `
  --output "C:\Reports\dr_after_migration.xlsx"
```

Checklist: re-enter the passwords from §4.7 → enable client usernames if the
source had them disabled → confirm bridges connect → review the new export's
Findings sheet for anything the copy carried over.

---

## 4.11 Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Exit 2, "Non-interactive migration needs --yes" | Add `--yes`, or use `--migrate-dry-run` for a plan |
| Warning about `globalAccessLevel` | The target account is read-only — get read-write/admin credentials |
| Many `failed` rows: `400 INVALID_PARAMETER` | Target broker is an older version; check the stripped-attribute notes in the log — usually harmless, occasionally means a feature isn't available there |
| `ALREADY_EXISTS` everywhere | Target VPN was already populated — switch to `--migrate-exists update` if you intend to overwrite |
| Bridges `failed` | Remote VPN or cluster doesn't exist on the target; create it, then re-run (existing objects skip) |
| DMR bridges `failed` | The DMR cluster must exist on the target broker first |
| Same-broker run refuses the VPN name | A VPN cannot be copied onto itself — supply a different `--target-vpn` |
| Clients can't connect after migration | Passwords weren't migrated (§4.7), or the `default` client username is disabled on the target |

Re-running a migration is safe with `--migrate-exists skip`: everything that
already exists is skipped, so only the gaps get filled.

---

Back to: [1 — Setup](01-setup-windows.md) ·
[2 — Export](02-export-windows.md) · [3 — Compare](03-compare-windows.md)
