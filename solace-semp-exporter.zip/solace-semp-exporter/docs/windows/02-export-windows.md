# 2 — Export a broker to Excel (Windows)

Reads the SEMP v2 **Config** API and writes one workbook: an audit Overview,
a rule-based Findings review, Inventory / Capacity / Security Posture views,
and one sheet per object type. Read-only — the export never writes to the
broker.

---

## 2.1 Fastest path — interactive

```powershell
cd C:\Tools\solace-semp-exporter
.\.venv\Scripts\Activate.ps1
solace-export
```

First it asks which operation you want:

```
                     What would you like to do?
 #   Operation   Description
 1   Export      Export broker configuration to an Excel workbook (read-only)
 2   Compare     Export and diff two Message VPNs side by side (read-only)
 3   Migrate     Copy a VPN to another VPN and/or another broker (writes)
Operation [1]:
```

Press Enter (or `1`) for a plain export. Then it asks for host, SSL, port,
username, password (hidden), followed by the scope menu - `1` for everything,
or comma-separated menu numbers. Output lands in the current folder as
`<host>_<yyyymmdd>_<hhmmss>.xlsx`.

The menu only appears on a real terminal and only when you haven't already
chosen an operation with `--compare` or `--migrate`, so scripts and scheduled
tasks are unaffected.

Use this the first time against a new broker — the prompts double as a
connectivity test.

---

## 2.2 Scripted — full broker

```powershell
$env:SOLACE_PASSWORD = Read-Host "SEMP password"

solace-export `
  --host broker.example.com --port 1943 --ssl `
  --username svc-solace-audit `
  --scope all `
  --output "C:\Reports\prod_config_$(Get-Date -f yyyyMMdd).xlsx" `
  --no-interactive
```

`--no-interactive` makes the run fail fast (exit 2) instead of blocking on a
prompt — always set it in scheduled tasks.

---

## 2.3 Narrowing the export

**By VPN** (repeat the flag):

```powershell
solace-export --host broker.example.com --scope all --vpn prod --vpn staging
```

**By scope** — 20 scopes are available, `solace-export --list-scopes` prints
them with menu numbers:

```powershell
solace-export --host broker.example.com `
  --scope queues --scope acl --scope client-usernames --scope bridges
```

Common combinations:

| Goal | Scopes |
|---|---|
| Everything (42 sheets) | `all` |
| Messaging objects only | `queues topic-endpoints` |
| Security review | `acl client-usernames client-profiles authorization-groups` |
| Connectivity | `bridges rest dmr replication` |
| Broker-level (non-VPN) config | `broker certificates` |

Fewer scopes = faster. A full `all` export of a large broker is dominated by
queue subscriptions, which SEMP only exposes one queue at a time.

---

## 2.4 Making it a customer deliverable

```powershell
solace-export --host broker.example.com --scope all `
  --report-title "ACME Broker Configuration Audit" `
  --prepared-for "ACME Corp" `
  --prepared-by  "Bosch Integration Competence Center" `
  --output "C:\Reports\ACME_audit.xlsx"
```

The workbook opens on **Overview** — headline, attribution, environment counts,
findings by severity with charts, top High/Medium findings, and a scope note
stating that only configuration (not runtime state) was assessed.

Sheet order: `Overview → Summary → Findings → Inventory → Capacity →
Security Posture → <object sheets> → _metadata` (hidden).

Add `--no-analysis` when you want the raw object sheets only, and
`--raw-headers` to keep SEMP's camelCase attribute names for 1:1 traceability
with the Solace API docs (default is humanised, e.g. `Max Msg Spool Usage`).

---

## 2.5 Speed and large brokers

| Flag | Default | When to change |
|---|---|---|
| `--workers` | `8` | `4` if the broker is busy or SEMP is rate-limiting; `12–16` on a well-resourced appliance |
| `--page-size` | `100` | `0` turns paging off everywhere. Endpoints that reject `count` are detected and retried automatically, so this is only worth setting if your broker rejects it on many collections |
| `--timeout` | `30` | raise to `60` for slow WAN links to a remote data centre |
| `--retries` | `3` | raise for flaky links; retries apply to 429/5xx on reads |

If a run dies half way (VPN drop, laptop sleep, Ctrl-C):

```powershell
solace-export --host broker.example.com --scope all --resume
```

Completed collections are read from the checkpoint cache, so only the missing
parts are re-fetched. `--clear-cache` discards checkpoints, `--keep-cache`
retains them after success.

---

## 2.6 Reading the result

| Sheet | What it answers |
|---|---|
| **Overview** | "What is this environment, and what should worry me?" |
| **Summary** | Run facts: connection, broker version, per-sheet row counts, skipped endpoints, errors |
| **Findings** | Every rule hit: severity, VPN, object, the config fact, the recommendation |
| **Inventory** | Object counts per type per VPN |
| **Capacity** | Spool limits, sum of queue quotas, oversubscription ratio, largest queue |
| **Security Posture** | Auth schemes, plain-text services, permissive ACLs, `default` username state per VPN |
| Object sheets | The raw evidence, formatted as filterable Excel tables |

**Remote endpoints are readable inline.** The `Bridges` sheet shows
`Remote VPN`, `Remote Host`, `Remote Port`, `Remote Location`,
`Remote Interface`, `Remote Queue Binding`, `Remote TLS` and
`Remote Connections` right after the bridge name - no cross-referencing the
`Bridge Remote VPNs` sheet to answer "where does this bridge go?". A bridge
with redundant remote locations shows every distinct value joined with `|`
and a connection count. `Bridge Remote VPNs` additionally splits
`Remote Location` into `Remote Host` / `Remote Port` (handles `host:port`,
bracketed IPv6 and the `v:<router>` virtual-router form). REST Delivery
Points carry their consumers' `Remote Host` / `Remote Port` / `Remote TLS`
the same way.

**Skipped endpoints are normal.** Software brokers, appliances and older SEMP
versions do not implement every collection; the Summary sheet lists exactly
what was skipped and why, so a reviewer can tell "not present" from "not
collected".

**Deliberately out of scope:** anything the Config API does not return —
runtime bindings, spool usage, HA/redundancy state, and passwords (SEMP never
returns them).

---

## 2.7 Scheduling a weekly export (Task Scheduler)

`C:\Tools\solace-semp-exporter\run-export.ps1`:

```powershell
$ErrorActionPreference = "Stop"
Set-Location C:\Tools\solace-semp-exporter
.\.venv\Scripts\Activate.ps1

$env:SOLACE_PASSWORD = (Get-Content C:\Secrets\solace.pw -Raw).Trim()
$stamp = Get-Date -Format yyyyMMdd

solace-export --config .\bosch-prod.toml --no-interactive `
  --output "C:\Reports\prod_$stamp.xlsx" `
  --log-file "C:\Reports\logs\export_$stamp.log"

exit $LASTEXITCODE
```

Register it (adjust the account to one with rights to the report share):

```powershell
$action  = New-ScheduledTaskAction -Execute "powershell.exe" `
  -Argument "-NoProfile -ExecutionPolicy Bypass -File C:\Tools\solace-semp-exporter\run-export.ps1"
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At 6:00am
Register-ScheduledTask -TaskName "Solace config export" -Action $action -Trigger $trigger
```

Store the password with your standard secret mechanism rather than a plain
file where one is available.

---

## 2.8 Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `Configuration error: ...` (exit 2) | Bad flag combination or unknown scope — check `--list-scopes` |
| `401 Unauthorized` | Wrong credentials, or the account lacks SEMP access |
| `403 Forbidden` on some collections | Read-only account without rights to that object type — export continues, Summary records it |
| `SSLError / CERTIFICATE_VERIFY_FAILED` | Set `REQUESTS_CA_BUNDLE` to the corporate root CA (§1.6); `--no-verify-ssl` only for labs |
| `ConnectionError` / timeout | Wrong port (8080 plain vs 1943 TLS), firewall, or proxy hijacking internal traffic — set `NO_PROXY` |
| Workbook won't save | The `.xlsx` is open in Excel, or the folder is being synced — close it, or write elsewhere |
| A sheet is empty and the Summary says the endpoint was skipped | If the broker answered `400 INVALID_PARAMETER`, the tool now retries that endpoint without paging automatically and logs it. If it still fails, the collection genuinely is not available on that broker/version |
| Very slow on `all` | Queue subscriptions are one call per queue; raise `--workers`, or drop the `queues` scope for a quick pass |
| Want more detail | `--log-level DEBUG --log-file C:\Reports\debug.log` |
| `Remote Host` blank on the Bridges sheet | The console prints a warning naming the cause. Usually `Bridge Remote VPNs` is empty because `msgVpns/*/bridges/*/remoteMsgVpns` was skipped or refused - check the Summary sheet's skipped list, and confirm the SEMP account can read bridge sub-collections |

Next: **[3 — Compare](03-compare-windows.md)** ·
[4 — Migrate](04-migrate-windows.md) · [1 — Setup](01-setup-windows.md)
