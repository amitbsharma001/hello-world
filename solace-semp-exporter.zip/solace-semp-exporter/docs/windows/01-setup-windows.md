# 1 — Setup on Windows

Applies to Windows 10 / 11 and Windows Server 2019+. Everything below is
PowerShell unless marked `cmd.exe`. No admin rights are required if Python is
already installed.

---

## 1.1 Prerequisites

| Item | Requirement | Check |
|---|---|---|
| Python | **3.12 or newer** | `py -0p` (lists installed versions) |
| Network | TCP to the broker's SEMP port (`8080` plain / `1943` TLS) | `Test-NetConnection broker.example.com -Port 1943` |
| SEMP account | read-only is enough for export & compare; **read-write / admin needed for migration** | see 4.1 |
| Excel | any version that opens `.xlsx` (or LibreOffice) | — |

If `py -0p` shows nothing, install Python 3.12 from python.org or the Microsoft
Store, or ask IT for the packaged build. Tick **"Add python.exe to PATH"**.

---

## 1.2 Install (machine with internet)

```powershell
# 1 - unpack
Expand-Archive .\solace-semp-exporter.zip -DestinationPath C:\Tools
cd C:\Tools\solace-semp-exporter

# 2 - isolated environment (never install into system Python)
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1

# 3 - install the tool and its dependencies
python -m pip install --upgrade pip
pip install -e .

# 4 - verify
solace-export --version      # -> solace-semp-exporter 1.3.0
solace-export --list-scopes
```

> **`Activate.ps1 cannot be loaded because running scripts is disabled`**
> Either use cmd.exe (`.\.venv\Scripts\activate.bat`) or unblock for the current
> window only — this does not change machine policy:
> ```powershell
> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
> ```

### Behind a corporate proxy

```powershell
$env:HTTPS_PROXY = "http://rb-proxy.example.com:8080"
$env:HTTP_PROXY  = $env:HTTPS_PROXY
# keep internal brokers off the proxy:
$env:NO_PROXY    = "broker.internal,.example.com,10.0.0.0/8"
pip install -e .
```

---

## 1.3 Install (firewalled machine, no PyPI)

Do step **A** on any machine with internet, copy the folder over, do **B** on
the target machine.

**A — on the connected machine** (same OS + same Python minor version):

```powershell
cd C:\Tools\solace-semp-exporter
py -3.12 -m pip download . -d wheels
```

Copy `solace-semp-exporter\` *and* `wheels\` to the target host (USB, file
share, artefact repo — whatever your policy allows).

**B — on the firewalled machine:**

```powershell
cd C:\Tools\solace-semp-exporter
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install --no-index --find-links .\wheels -e .
solace-export --version
```

---

## 1.4 Running without installing

If pip installs are blocked entirely, the package runs straight from the
folder as long as the six dependencies are importable
(`requests`, `typer`, `rich`, `openpyxl`, `pandas`, `python-dotenv`):

```powershell
cd C:\Tools\solace-semp-exporter
py -3.12 -m solace_exporter --host broker.example.com --scope all
```

Everywhere in these guides `solace-export ...` and
`py -3.12 -m solace_exporter ...` are interchangeable.

---

## 1.5 Credentials — three options

**Option 1 — type it (safest for one-off runs).** Omit `--password`; the tool
prompts with hidden input.

**Option 2 — environment variable (best for scripts).** The variable lives only
in the current PowerShell window:

```powershell
$env:SOLACE_PASSWORD = Read-Host "SEMP password"
solace-export --host broker.example.com --username admin --scope all
```

`--password-env` points at a different variable name if you prefer:

```powershell
$env:BROKER_PW = Read-Host "SEMP password"
solace-export --host broker.example.com --password-env BROKER_PW --scope all
```

**Option 3 — `.env` file** (mark it read-only, exclude it from Git/OneDrive):

```ini
# C:\Tools\solace-semp-exporter\.env
SOLACE_HOST=broker.example.com
SOLACE_USERNAME=admin
SOLACE_PASSWORD=...
SOLACE_USE_SSL=true
```
```powershell
solace-export --env-file .env --scope all
```

Never put `--password` on the command line on a shared machine — it lands in
the PowerShell history file (`(Get-PSReadlineOption).HistorySavePath`).

---

## 1.6 TLS on corporate networks

If SEMP is behind a TLS-inspecting proxy or uses an internal CA, point requests
at the corporate bundle instead of disabling verification:

```powershell
$env:REQUESTS_CA_BUNDLE = "C:\certs\corporate-root-ca.pem"
solace-export --host broker.example.com --ssl --verify-ssl --scope all
```

`--no-verify-ssl` exists for lab brokers with self-signed certificates. Do not
use it against production — and never combine it with `--migrate`.

---

## 1.7 Configuration precedence

`defaults < TOML file < SOLACE_* environment < CLI flags`

A reusable TOML keeps long commands short (`[connection]` and `[export]`
tables only — migration is always flags/prompts, never a file):

```toml
# C:\Tools\solace-semp-exporter\bosch-prod.toml
[connection]
host = "broker.example.com"
port = 1943
username = "svc-solace-audit"
use_ssl = true
verify_ssl = true
workers = 8

[export]
scopes = ["all"]
log_level = "INFO"
```
```powershell
solace-export --config .\bosch-prod.toml
```

Supported environment variables:

`SOLACE_HOST` `SOLACE_PORT` `SOLACE_USERNAME` `SOLACE_PASSWORD` `SOLACE_USE_SSL`
`SOLACE_VERIFY_SSL` `SOLACE_TIMEOUT` `SOLACE_RETRIES` `SOLACE_PAGE_SIZE`
`SOLACE_WORKERS` `SOLACE_SCOPES` `SOLACE_VPNS` `SOLACE_OUTPUT` `SOLACE_RESUME`
`SOLACE_CACHE_DIR` `SOLACE_KEEP_CACHE` `SOLACE_RAW_HEADERS` `SOLACE_COMPARE`
`SOLACE_COMPARE_IGNORE` `SOLACE_COMPARE_OUTPUT` `SOLACE_ANALYSIS`
`SOLACE_REPORT_TITLE` `SOLACE_PREPARED_FOR` `SOLACE_PREPARED_BY`
`SOLACE_LOG_LEVEL` `SOLACE_LOG_FILE`
— plus, for migration: `SOLACE_TARGET_HOST` `SOLACE_TARGET_PORT`
`SOLACE_TARGET_USERNAME` `SOLACE_TARGET_PASSWORD` `SOLACE_TARGET_SSL`
`SOLACE_TARGET_VERIFY_SSL` `SOLACE_SOURCE_VPN` `SOLACE_TARGET_VPN`
`SOLACE_MIGRATE_EXISTS` `SOLACE_MIGRATE_REPORT`.

---

## 1.8 PowerShell syntax traps

| Trap | Wrong | Right |
|---|---|---|
| Line continuation | `\` (that's bash) | backtick `` ` `` in PowerShell, `^` in cmd.exe |
| Comma lists | `--compare prod,dr` (usually fine, but fragile) | `--compare prod --compare dr` |
| Globs / `*` | `--compare-ignore replication*` | `--compare-ignore 'replication*'` |
| Password with `$` | `"P@ss$word"` (PowerShell expands `$word`) | `'P@ss$word'` (single quotes) |
| Password with `!` in cmd.exe | breaks under delayed expansion | use PowerShell, or the prompt |
| Paths with spaces | `-o C:\My Reports\a.xlsx` | `-o "C:\My Reports\a.xlsx"` |
| Output file open in Excel | write fails, file is locked | close the workbook first |

Keep output paths off OneDrive/SharePoint-synced folders while a run is in
progress; sync clients lock the file mid-write.

---

## 1.9 Exit codes (for Task Scheduler / CI)

| Code | Meaning |
|---|---|
| `0` | success |
| `1` | runtime failure (connection, HTTP, write error, empty export) |
| `2` | configuration error (bad flag combination, missing `--yes`, unknown scope) |
| `130` | interrupted with Ctrl-C — re-run with `--resume` |

```powershell
solace-export --config .\bosch-prod.toml --no-interactive
if ($LASTEXITCODE -ne 0) { Write-Error "Export failed ($LASTEXITCODE)"; exit $LASTEXITCODE }
```

---

## 1.10 Smoke test without a broker

Confirms the install (Excel engine, pandas, CLI wiring) using the built-in fake
broker — no network, no credentials:

```powershell
python .\scripts\make_sample.py
# writes examples\sample_export.xlsx and examples\sample_vpn_compare.xlsx
pytest -q      # 71 tests, if you installed with: pip install -e ".[dev]"
```

Next: **[2 — Export](02-export-windows.md)** ·
[3 — Compare](03-compare-windows.md) ·
[4 — Migrate](04-migrate-windows.md)
