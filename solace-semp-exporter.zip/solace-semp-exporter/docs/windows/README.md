# solace-semp-exporter — Windows operations guides

Runbooks for operating the tool from a Windows workstation or jump host.
Read them in order the first time; after that use the quick reference below.

| # | Guide | Covers |
|---|---|---|
| 1 | [Setup](01-setup-windows.md) | Install (online / offline / no-pip), credentials, proxy & TLS, config precedence, PowerShell traps, exit codes |
| 2 | [Export](02-export-windows.md) | Exporting a broker to Excel, scopes, customer-ready audit reports, scheduling, troubleshooting |
| 3 | [Compare](03-compare-windows.md) | Diffing two VPNs, reading the delta workbook, suppressing expected differences, cross-broker gap analysis |
| 4 | [Migrate](04-migrate-windows.md) | Cloning a VPN to another VPN or another broker, dry runs, exists policy, secrets, verification |

Read-only modes: **export**, **compare**. Write-capable mode: **migrate** —
and it only ever creates or updates, never deletes.

---

## Not sure which command you need?

Just run it with no arguments and pick from the menu:

```powershell
solace-export
```

```
 #   Operation   Description
 1   Export      Export broker configuration to an Excel workbook (read-only)
 2   Compare     Export and diff two Message VPNs side by side (read-only)
 3   Migrate     Copy a VPN to another VPN and/or another broker (writes)
```

Each choice then asks only the questions that operation needs. The menu is
skipped when `--compare` or `--migrate` is already on the command line, and
never appears in non-interactive runs.

## Quick reference

```powershell
cd C:\Tools\solace-semp-exporter
.\.venv\Scripts\Activate.ps1
$env:SOLACE_PASSWORD = Read-Host "SEMP password"
```

**Export everything**
```powershell
solace-export --host broker --ssl --username admin --scope all -o C:\Reports\prod.xlsx
```

**Customer audit report**
```powershell
solace-export --host broker --scope all `
  --report-title "ACME Broker Audit" --prepared-for "ACME Corp" --prepared-by "Bosch ICC"
```

**Compare two VPNs**
```powershell
solace-export --host broker --scope all --compare prod --compare dr `
  --compare-ignore 'replication*'
```

**Migrate — always dry-run first**
```powershell
$env:SOLACE_TARGET_PASSWORD = Read-Host "Target password"
solace-export --host prod-broker --migrate `
  --migrate-to-host dr-broker --migrate-to-ssl --migrate-to-username admin `
  --source-vpn prod --target-vpn prod --migrate-dry-run `
  --migrate-report C:\Reports\PLAN.xlsx
```
Then repeat without `--migrate-dry-run`, adding `--yes` for unattended runs.

**Interactive (menu, then only the relevant questions)**
```powershell
solace-export             # asks Export / Compare / Migrate first
solace-export --migrate   # jumps straight into the migration questions
```

---

## Windows one-liners worth remembering

| Need | Command |
|---|---|
| List scopes | `solace-export --list-scopes` |
| All flags | `solace-export --help` |
| Line continuation | backtick `` ` `` (PowerShell), `^` (cmd.exe) — **not** `\` |
| Two VPNs safely | `--compare prod --compare dr` (avoids comma parsing) |
| Quote globs | `--compare-ignore 'replication*'` |
| Corporate CA | `$env:REQUESTS_CA_BUNDLE = "C:\certs\root-ca.pem"` |
| Skip the proxy for internal hosts | `$env:NO_PROXY = "broker.internal,.example.com"` |
| Resume a broken run | add `--resume` |
| Debug | `--log-level DEBUG --log-file C:\Reports\debug.log` |
| Exit codes | `0` ok · `1` runtime failure · `2` config error · `130` Ctrl-C |
