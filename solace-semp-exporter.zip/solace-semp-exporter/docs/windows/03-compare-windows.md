# 3 — Compare two VPNs (Windows)

Answers "is DR really a copy of PROD?" — object by object, attribute by
attribute. Produces a **second workbook** alongside the normal export. Also
read-only.

---

## 3.1 Interactive — pick Compare from the menu

```powershell
solace-export
```

Choose `2` (Compare) at the operation menu. You are then asked for the
connection, the export scope, and the pair to diff:

```
Operation [1]: 2
Solace Host: broker.example.com
...
First VPN to compare: prod
Second VPN to compare: dr
Attributes to ignore, glob-style (comma-separated, blank = none): replication*
Output file name [broker.example.com_20260722_101500.xlsx]:
```

VPN names are case-sensitive. Both VPNs are fetched automatically - you are
not asked to select VPNs separately. If a name doesn't exist the run stops
and lists the VPNs the broker actually has.

## 3.2 Basic comparison (flags)

```powershell
$env:SOLACE_PASSWORD = Read-Host "SEMP password"

solace-export `
  --host broker.example.com --ssl --username svc-solace-audit `
  --scope all `
  --compare prod --compare dr `
  --no-interactive
```

Two files are written:

* `broker.example.com_<timestamp>.xlsx` — the normal export of both VPNs
* `broker.example.com_compare_prod_vs_dr_<timestamp>.xlsx` — the diff

> **Use the repeated flag form on Windows.** `--compare prod,dr` also works,
> but `--compare prod --compare dr` avoids every PowerShell/cmd comma-parsing
> question. Exactly two VPN names are required.

You do not need `--vpn`; the comparison fetches both VPNs itself. If you pass
`--vpn` as well and it disagrees with the compared pair, the run stops with a
configuration error (exit 2).

---

## 3.3 Where the comparison workbook goes

```powershell
solace-export --host broker.example.com --scope all `
  --compare prod --compare dr `
  --output         "C:\Reports\prod_dr_export.xlsx" `
  --compare-output "C:\Reports\prod_vs_dr_diff.xlsx"
```

Default name: `<host>_compare_<A>_vs_<B>_<timestamp>.xlsx` in the current
folder.

---

## 3.4 Reading the diff

**Summary** sheet — one row per object type: counts on each side, number of
deltas, and a match percentage. Start here; it tells you whether the drift is
one stray queue or a structurally different VPN.

Then one sheet per object type that has deltas, colour-coded:

| Colour | Status | Meaning |
|---|---|---|
| Orange | `only in A` | Exists in the first VPN, missing in the second |
| Blue | `only in B` | Exists in the second VPN only |
| Amber | `different` | Same object, different attribute values — the sheet shows attribute, value A, value B |
| — | `identical` | Not listed; counted on the Summary sheet |

Object identity is the ancestor chain **minus the VPN name** — so
`prod/ORDERS.IN` is compared against `dr/ORDERS.IN`, and a queue subscription
is matched by queue + topic. Broker-level objects (certificate authorities,
virtual hostnames…) are not VPN-scoped and are excluded automatically.

---

## 3.5 Suppressing expected differences

DR VPNs legitimately differ in replication and bridge attributes. Exclude them
by attribute-name glob (repeatable) so real drift stands out:

```powershell
solace-export --host broker.example.com --scope all `
  --compare prod --compare dr `
  --compare-ignore 'replication*' `
  --compare-ignore '*Bridge*' `
  --compare-ignore 'eventLarge*'
```

Quote every glob — the quotes protect `*` from the shell and make intent
obvious in a runbook. Identity columns (VPN, object names) are never ignored,
so a glob can hide a differing attribute but can never hide a missing object.

---

## 3.6 Comparing across two brokers

The `--compare` flag diffs two VPNs **on one broker**. To compare the same VPN
on two different brokers, export each and diff the plan a migration would
produce — that is exactly what a dry run gives you:

```powershell
# What would have to change on DR to make it match PROD?
solace-export --host prod-broker.example.com --scope all --migrate `
  --migrate-to-host dr-broker.example.com --migrate-to-username admin `
  --source-vpn prod --target-vpn prod `
  --migrate-dry-run `
  --migrate-report "C:\Reports\prod_vs_dr_broker.xlsx"
```

`--migrate-dry-run` writes nothing to either broker. The Migration Log lists
every object as `planned` (would be created) or `skipped` (already exists) —
a cross-broker gap analysis. See [4 — Migrate](04-migrate-windows.md).

---

## 3.7 Typical uses

| Question | Command shape |
|---|---|
| Is DR a faithful copy of PROD? | `--compare prod --compare dr --compare-ignore 'replication*'` |
| What did the last change window alter? | Export before and after; diff the two workbooks in Excel, or re-run the comparison |
| Why does staging behave differently? | `--compare prod --compare staging --scope queues --scope acl --scope client-usernames` |
| Security-only drift | `--scope acl --scope client-usernames --scope client-profiles --compare prod --compare dr` |

Narrowing `--scope` speeds up the run and keeps the diff readable.

---

## 3.8 Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `--compare needs exactly two VPN names` | Three flags passed, or a typo left one empty |
| `--vpn and --compare disagree` | Drop `--vpn`; the comparison selects both VPNs itself |
| A VPN shows zero objects | The name is wrong (case-sensitive), or the account can't read it — check the export workbook first |
| "Everything is different" | The two VPNs use different naming conventions, so no objects match by identity — expected; read it as *only in A* / *only in B* |
| Too much noise | Add `--compare-ignore` globs for environment-specific attributes, or narrow `--scope` |

Next: **[4 — Migrate](04-migrate-windows.md)** ·
[2 — Export](02-export-windows.md) · [1 — Setup](01-setup-windows.md)
