"""Shared fixtures."""

from __future__ import annotations

import pytest

from solace_exporter.testing import FakeSempClient, sample_client


@pytest.fixture()
def fake_client() -> FakeSempClient:
    return sample_client()
