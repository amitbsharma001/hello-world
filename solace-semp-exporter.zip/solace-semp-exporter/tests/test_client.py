"""Pagination, error mapping and path handling of the real HTTP client."""

from __future__ import annotations

import json
from typing import Any

import pytest
import requests

from solace_exporter.config import ConnectionConfig
from solace_exporter.exceptions import SempAuthError, SempNotAvailableError
from solace_exporter.semp_client import SempClient


class _Response:
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        self._payload = payload
        self.status_code = status
        self.reason = "OK"

    def json(self) -> dict[str, Any]:
        return self._payload


class _Session(requests.Session):
    """Scripted session returning queued payloads and recording URLs."""

    def __init__(self, responses: list[_Response]) -> None:
        super().__init__()
        self.responses = responses
        self.calls: list[tuple[str, Any]] = []

    def get(self, url, params=None, timeout=None, **kw):  # type: ignore[override]
        self.calls.append((url, params))
        return self.responses.pop(0)


def _client(responses: list[_Response]) -> tuple[SempClient, _Session]:
    session = _Session(responses)
    config = ConnectionConfig(host="h", port=8080, username="u", password="p")
    return SempClient(config, session_factory=lambda: session), session


def test_pagination_follows_next_page_uri_verbatim():
    page2 = "http://h:8080/SEMP/v2/config/msgVpns?cursorQuery=abc"
    client, session = _client([
        _Response({"data": [{"msgVpnName": "a"}],
                   "meta": {"paging": {"nextPageUri": page2}}}),
        _Response({"data": [{"msgVpnName": "b"}], "meta": {}}),
    ])
    rows = client.get_collection("msgVpns")
    assert [r["msgVpnName"] for r in rows] == ["a", "b"]
    assert session.calls[0][1] == {"count": 100}
    assert session.calls[1] == (page2, None)  # cursor used as-is, params dropped
    assert client.call_count == 2


def test_auth_error_maps_to_semp_auth_error():
    client, _ = _client([_Response({"meta": {}}, status=401)])
    with pytest.raises(SempAuthError):
        client.get_collection("msgVpns")


def test_skippable_status_maps_to_not_available():
    body = {"meta": {"error": {"description": "not supported", "status": "NOT_ALLOWED"}}}
    client, _ = _client([_Response(body, status=400)])
    with pytest.raises(SempNotAvailableError):
        client.get_collection("msgVpns/x/distributedCaches")


def test_single_object_endpoint_returns_dict():
    client, _ = _client([_Response({"data": {"serviceSmfEnabled": True}})])
    assert client.get_object("")["serviceSmfEnabled"] is True
