"""Pagination, error mapping and path handling of the real HTTP client."""

from __future__ import annotations

import json
from typing import Any

import pytest
import requests

from solace_exporter.config import ConnectionConfig
from solace_exporter.exceptions import SempAuthError, SempNotAvailableError
from solace_exporter.semp_client import SempClient


class _Response:
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        self._payload = payload
        self.status_code = status
        self.reason = "OK"

    def json(self) -> dict[str, Any]:
        return self._payload


class _Session(requests.Session):
    """Scripted session returning queued payloads and recording URLs."""

    def __init__(self, responses: list[_Response]) -> None:
        super().__init__()
        self.responses = responses
        self.calls: list[tuple[str, Any]] = []

    def get(self, url, params=None, timeout=None, **kw):  # type: ignore[override]
        self.calls.append((url, params))
        return self.responses.pop(0)


def _client(responses: list[_Response]) -> tuple[SempClient, _Session]:
    session = _Session(responses)
    config = ConnectionConfig(host="h", port=8080, username="u", password="p")
    return SempClient(config, session_factory=lambda: session), session


def test_pagination_follows_next_page_uri_verbatim():
    page2 = "http://h:8080/SEMP/v2/config/msgVpns?cursorQuery=abc"
    client, session = _client([
        _Response({"data": [{"msgVpnName": "a"}],
                   "meta": {"paging": {"nextPageUri": page2}}}),
        _Response({"data": [{"msgVpnName": "b"}], "meta": {}}),
    ])
    rows = client.get_collection("msgVpns")
    assert [r["msgVpnName"] for r in rows] == ["a", "b"]
    assert session.calls[0][1] == {"count": 100}
    assert session.calls[1] == (page2, None)  # cursor used as-is, params dropped
    assert client.call_count == 2


def test_auth_error_maps_to_semp_auth_error():
    client, _ = _client([_Response({"meta": {}}, status=401)])
    with pytest.raises(SempAuthError):
        client.get_collection("msgVpns")


def test_skippable_status_maps_to_not_available():
    """Genuinely absent collections still raise - after one unpaged retry."""
    body = {"meta": {"error": {"description": "not supported", "status": "NOT_ALLOWED"}}}
    client, session = _client([_Response(body, status=400), _Response(body, status=400)])
    with pytest.raises(SempNotAvailableError):
        client.get_collection("msgVpns/x/distributedCaches")
    assert [params for _, params in session.calls] == [{"count": 100}, None]


def test_404_is_not_retried_without_paging():
    """A missing path cannot be fixed by dropping the query string."""
    body = {"meta": {"error": {"description": "not found", "status": "NOT_FOUND"}}}
    client, session = _client([_Response(body, status=404)])
    with pytest.raises(SempNotAvailableError):
        client.get_collection("msgVpns/x/nope")
    assert len(session.calls) == 1


def test_endpoint_rejecting_count_is_retried_unpaginated():
    """The real-broker case: 400 INVALID_PARAMETER on the paging parameter."""
    rejection = {"meta": {"error": {"description": "invalid query parameter 'count'",
                                    "status": "INVALID_PARAMETER"}}}
    client, session = _client([
        _Response(rejection, status=400),
        _Response({"data": [{"queueName": "Q1"}], "meta": {}}),
    ])
    rows = client.get_collection("msgVpns/prod/queues")
    assert [r["queueName"] for r in rows] == ["Q1"]
    assert [params for _, params in session.calls] == [{"count": 100}, None]


def test_unpaged_decision_is_remembered_per_endpoint_shape():
    """The retry is paid once per collection, not once per parent object."""
    rejection = {"meta": {"error": {"description": "invalid query parameter 'count'",
                                    "status": "INVALID_PARAMETER"}}}
    client, session = _client([
        _Response(rejection, status=400),                      # bridge 1: probe
        _Response({"data": [{"remoteMsgVpnName": "a"}], "meta": {}}),   # bridge 1: retry
        _Response({"data": [{"remoteMsgVpnName": "b"}], "meta": {}}),   # bridge 2: direct
    ])
    first = client.get_collection("msgVpns/prod/bridges/b1,auto/remoteMsgVpns")
    second = client.get_collection("msgVpns/prod/bridges/b2,auto/remoteMsgVpns")
    assert len(first) == len(second) == 1
    assert [params for _, params in session.calls] == [{"count": 100}, None, None]


def test_unpaged_retry_still_follows_cursors():
    """Dropping 'count' must not truncate: nextPageUri is still followed."""
    page2 = "http://h:8080/SEMP/v2/config/msgVpns?cursor=xyz"
    rejection = {"meta": {"error": {"description": "count not supported",
                                    "status": "INVALID_PARAMETER"}}}
    client, session = _client([
        _Response(rejection, status=400),
        _Response({"data": [{"msgVpnName": "a"}], "meta": {"paging": {"nextPageUri": page2}}}),
        _Response({"data": [{"msgVpnName": "b"}], "meta": {}}),
    ])
    rows = client.get_collection("msgVpns")
    assert [r["msgVpnName"] for r in rows] == ["a", "b"]
    assert session.calls[-1] == (page2, None)


def test_caller_supplied_params_survive_the_unpaged_retry():
    rejection = {"meta": {"error": {"description": "bad count",
                                    "status": "INVALID_PARAMETER"}}}
    client, session = _client([
        _Response(rejection, status=400),
        _Response({"data": [{"msgVpnName": "a"}], "meta": {}}),
    ])
    client.get_collection("msgVpns", params={"select": "msgVpnName"})
    assert session.calls[0][1] == {"count": 100, "select": "msgVpnName"}
    assert session.calls[1][1] == {"select": "msgVpnName"}   # only 'count' dropped


def test_auth_failure_is_never_retried():
    client, session = _client([_Response({"meta": {}}, status=403)])
    with pytest.raises(SempAuthError):
        client.get_collection("msgVpns")
    assert len(session.calls) == 1


@pytest.mark.parametrize("path, shape", [
    ("msgVpns", "msgVpns"),
    ("msgVpns/prod/queues", "msgVpns/queues"),
    ("msgVpns/prod/queues/ORDERS.IN/subscriptions", "msgVpns/queues/subscriptions"),
    ("msgVpns/prod/bridges/b2b,auto/remoteMsgVpns", "msgVpns/bridges/remoteMsgVpns"),
    ("", "/"),
])
def test_endpoint_shape_ignores_object_names(path, shape):
    from solace_exporter.semp_client import _endpoint_shape

    assert _endpoint_shape(path) == shape


def test_single_object_endpoint_returns_dict():
    client, _ = _client([_Response({"data": {"serviceSmfEnabled": True}})])
    assert client.get_object("")["serviceSmfEnabled"] is True


def test_page_size_zero_never_sends_count():
    """Escape hatch for brokers where many endpoints reject paging."""
    session = _Session([_Response({"data": [{"msgVpnName": "a"}], "meta": {}})])
    config = ConnectionConfig(host="h", port=8080, username="u", password="p", page_size=0)
    client = SempClient(config, session_factory=lambda: session)
    client.get_collection("msgVpns")
    assert session.calls[0][1] is None
