"""Derived columns: location parsing, bridge/RDP enrichment, comparator interaction."""

from __future__ import annotations

import pandas as pd
import pytest

from solace_exporter.compare import compare_vpns
from solace_exporter.config import ConnectionConfig, ExportConfig
from solace_exporter.enrich import DERIVED_COLUMNS, enrich_sheets, split_location
from solace_exporter.exporter import ExportOrchestrator
from solace_exporter.models import SheetData
from solace_exporter.testing import sample_client


def _export(*scopes: str):
    connection = ConnectionConfig(host="demo", username="u", password="p")
    result = ExportOrchestrator(sample_client(), connection, ExportConfig(scopes=scopes)).run()
    return {sheet.spec_key: sheet.frame for sheet in result.sheets}, result


@pytest.mark.parametrize("location, expected", [
    ("broker.example.com:55555", ("broker.example.com", "55555")),
    ("203.0.113.9:55443", ("203.0.113.9", "55443")),
    ("[2001:db8::1]:55555", ("2001:db8::1", "55555")),
    ("2001:db8::1", ("2001:db8::1", "")),          # unbracketed IPv6, no port
    ("v:solace-primary", ("solace-primary", "")),  # virtual-router reference
    ("V:Router1", ("Router1", "")),                # case-insensitive
    ("hostA:55555,hostB:55555", ("hostA", "55555")),  # redundancy list -> first
    ("plain-host", ("plain-host", "")),
    ("host:notaport", ("host:notaport", "")),
    ("", ("", "")),
    (None, ("", "")),
])
def test_split_location(location, expected):
    assert split_location(location) == expected


def test_bridge_remote_vpns_sheet_gains_host_and_port():
    frames, _ = _export("bridges")
    frame = frames["bridges.remoteMsgVpns"]
    columns = list(frame.columns)
    # inserted directly after the source column, not appended at the end
    assert columns.index("Remote Host") == columns.index("Remote Location") + 1
    assert columns.index("Remote Port") == columns.index("Remote Location") + 2
    rows = frame.to_dict("records")
    assert (rows[0]["Remote Host"], rows[0]["Remote Port"]) == ("203.0.113.9", "55555")
    assert (rows[1]["Remote Host"], rows[1]["Remote Port"]) == ("partner-dr.example.com", "55443")


def test_bridges_sheet_shows_remote_vpn_and_host_inline():
    frames, _ = _export("bridges")
    frame = frames["bridges"]
    columns = list(frame.columns)
    # derived block sits immediately after the identity columns
    assert columns[:3] == ["VPN", "Bridge", "Bridge Virtual Router"]
    assert columns[3:11] == [
        "Remote VPN", "Remote Host", "Remote Port", "Remote Location",
        "Remote Interface", "Remote Queue Binding", "Remote TLS", "Remote Connections",
    ]
    row = frame.to_dict("records")[0]
    assert row["Remote VPN"] == "partner-vpn"                      # distinct values only
    assert row["Remote Host"] == "203.0.113.9 | partner-dr.example.com"
    assert row["Remote Port"] == "55555 | 55443"
    assert row["Remote Queue Binding"] == "BRIDGE.INBOUND"
    assert row["Remote TLS"] == "False | True"
    assert row["Remote Connections"] == 2                          # multi-homed bridge


def test_rdp_sheet_shows_consumer_endpoint():
    frames, _ = _export("rest")
    row = frames["rdps"].to_dict("records")[0]
    assert (row["Remote Host"], row["Remote Port"]) == ("hooks.example.com", "443")
    assert row["REST Consumers"] == 1


def test_derived_columns_excluded_from_vpn_comparison():
    connection = ConnectionConfig(host="demo", username="u", password="p")
    result = ExportOrchestrator(
        sample_client(), connection, ExportConfig(scopes=("all",))
    ).run()
    comparison = compare_vpns(result.sheets, "prod", "dev")
    compared = {
        str(attribute)
        for object_type in comparison.types
        for attribute in object_type.frame.get("Attribute", pd.Series(dtype=str))
    }
    assert "Remote Host" not in compared      # derived from Remote Location
    assert "Remote Connections" not in compared
    assert DERIVED_COLUMNS                    # registry actually populated


def test_enrichment_is_safe_on_empty_and_missing_sheets():
    # no bridges sheet at all
    assert enrich_sheets([]) == []

    # bridges present, remote VPNs missing entirely -> columns still added, blank
    bridges = SheetData(
        name="Bridges",
        frame=pd.DataFrame([{"VPN": "prod", "Bridge": "b1", "Bridge Virtual Router": "auto"}]),
        spec_key="bridges", endpoint="msgVpns/{v}/bridges",
        id_columns=("VPN", "Bridge", "Bridge Virtual Router"), per_vpn=True,
    )
    enrich_sheets([bridges])
    row = bridges.frame.to_dict("records")[0]
    assert row["Remote VPN"] == "" and row["Remote Connections"] == 0

    # empty frame keeps its headers stable
    empty = SheetData(
        name="Bridges", frame=pd.DataFrame(columns=["VPN", "Bridge", "Bridge Virtual Router"]),
        spec_key="bridges", endpoint="e",
        id_columns=("VPN", "Bridge", "Bridge Virtual Router"), per_vpn=True,
    )
    enrich_sheets([empty])
    assert "Remote Host" in empty.frame.columns and empty.frame.empty


def test_enrichment_is_idempotent():
    frames, result = _export("bridges")
    before = list(frames["bridges"].columns)
    enrich_sheets(result.sheets)          # run a second time
    assert list(result.sheets[0].frame.columns) == before


# --------------------------------------------------------------------------- #
# Real-broker shapes the fake client does not produce
# --------------------------------------------------------------------------- #
def _bridge_tree(client):
    from concurrent.futures import ThreadPoolExecutor

    from solace_exporter.exporters.base import RunContext, TreeExporter
    from solace_exporter.exporters.bridges import BRIDGES

    with ThreadPoolExecutor(max_workers=2) as pool:
        output = TreeExporter(BRIDGES).export(
            RunContext(client=client, pool=pool, vpns=("prod",))
        )
    enrich_sheets(output.sheets)
    return {sheet.spec_key: sheet.frame for sheet in output.sheets}, output


class _Client:
    """Minimal client returning canned collections."""

    call_count = 0

    def __init__(self, collections):
        self._collections = collections

    def get_collection(self, path, **_):
        value = self._collections.get(path, [])
        if isinstance(value, Exception):
            raise value
        return value

    def get_object(self, path, **_):
        return {}


def test_child_echoing_a_different_ancestor_key_still_joins():
    """Real SEMP echoes ancestor keys on child objects and may resolve them.

    A bridge listed with bridgeVirtualRouter 'auto' can report 'primary' on its
    remoteMsgVpns. The hierarchy column must describe where the object was
    found, otherwise the child never joins back to its parent sheet.
    """
    frames, _ = _bridge_tree(_Client({
        "msgVpns/prod/bridges": [
            {"bridgeName": "b2b", "bridgeVirtualRouter": "auto", "enabled": True},
        ],
        "msgVpns/prod/bridges/b2b,auto/remoteMsgVpns": [
            {"msgVpnName": "prod", "bridgeName": "b2b",
             "bridgeVirtualRouter": "primary",          # resolved, differs from parent
             "remoteMsgVpnName": "partner",
             "remoteMsgVpnLocation": "partner.example.com:55555",
             "tlsEnabled": True, "queueBinding": "BRIDGE.IN"},
        ],
    }))
    row = frames["bridges"].to_dict("records")[0]
    assert row["Remote VPN"] == "partner"
    assert row["Remote Host"] == "partner.example.com"
    assert row["Remote Port"] == "55555"
    assert row["Remote Connections"] == 1
    # the hierarchy column reflects the parent, not the echoed value
    assert frames["bridges.remoteMsgVpns"].iloc[0]["Bridge Virtual Router"] == "auto"


def test_unavailable_child_endpoint_warns_instead_of_silent_blanks(caplog):
    """The failure mode that looks like 'the feature does not work'."""
    from solace_exporter.exceptions import SempNotAvailableError

    with caplog.at_level("WARNING"):
        frames, output = _bridge_tree(_Client({
            "msgVpns/prod/bridges": [
                {"bridgeName": "b2b", "bridgeVirtualRouter": "auto"},
            ],
            "msgVpns/prod/bridges/b2b,auto/remoteMsgVpns":
                SempNotAvailableError("HTTP 400 INVALID_PATH"),
        }))

    row = frames["bridges"].to_dict("records")[0]
    assert row["Remote Host"] == "" and row["Remote Connections"] == 0
    assert [s.sheet for s in output.skipped] == ["Bridge Remote VPNs"]
    warning = "\n".join(caplog.messages)
    assert "no remote details attached" in warning
    assert "Summary sheet" in warning          # points at the real cause


def test_mismatched_identity_is_reported_not_guessed(caplog):
    """A wrong join would be worse than a blank, so it warns and stays blank."""
    with caplog.at_level("WARNING"):
        frames, _ = _bridge_tree(_Client({
            "msgVpns/prod/bridges": [
                {"bridgeName": "b2b", "bridgeVirtualRouter": "auto"},
            ],
            "msgVpns/prod/bridges/b2b,auto/remoteMsgVpns": [],
        }))
    assert frames["bridges"].to_dict("records")[0]["Remote Connections"] == 0


def test_lift_falls_back_to_raw_semp_column_names():
    """If a frame kept unrenamed headers the lift still finds the values."""
    bridges = SheetData(
        name="Bridges",
        frame=pd.DataFrame([{"msgVpnName": "prod", "bridgeName": "b2b",
                             "bridgeVirtualRouter": "auto"}]),
        spec_key="bridges", endpoint="e", id_columns=(), per_vpn=True,
    )
    remotes = SheetData(
        name="Bridge Remote VPNs",
        frame=pd.DataFrame([{"msgVpnName": "prod", "bridgeName": "b2b",
                             "bridgeVirtualRouter": "auto",
                             "remoteMsgVpnName": "partner",
                             "remoteMsgVpnLocation": "10.0.0.5:55555"}]),
        spec_key="bridges.remoteMsgVpns", endpoint="e", id_columns=(), per_vpn=True,
    )
    enrich_sheets([bridges, remotes])
    row = bridges.frame.to_dict("records")[0]
    assert row["Remote VPN"] == "partner"
    assert (row["Remote Host"], row["Remote Port"]) == ("10.0.0.5", "55555")
