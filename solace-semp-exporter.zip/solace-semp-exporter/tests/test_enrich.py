"""Derived columns: location parsing, bridge/RDP enrichment, comparator interaction."""

from __future__ import annotations

import pandas as pd
import pytest

from solace_exporter.compare import compare_vpns
from solace_exporter.config import ConnectionConfig, ExportConfig
from solace_exporter.enrich import DERIVED_COLUMNS, enrich_sheets, split_location
from solace_exporter.exporter import ExportOrchestrator
from solace_exporter.models import SheetData
from solace_exporter.testing import sample_client


def _export(*scopes: str):
    connection = ConnectionConfig(host="demo", username="u", password="p")
    result = ExportOrchestrator(sample_client(), connection, ExportConfig(scopes=scopes)).run()
    return {sheet.spec_key: sheet.frame for sheet in result.sheets}, result


@pytest.mark.parametrize("location, expected", [
    ("broker.example.com:55555", ("broker.example.com", "55555")),
    ("203.0.113.9:55443", ("203.0.113.9", "55443")),
    ("[2001:db8::1]:55555", ("2001:db8::1", "55555")),
    ("2001:db8::1", ("2001:db8::1", "")),          # unbracketed IPv6, no port
    ("v:solace-primary", ("solace-primary", "")),  # virtual-router reference
    ("V:Router1", ("Router1", "")),                # case-insensitive
    ("hostA:55555,hostB:55555", ("hostA", "55555")),  # redundancy list -> first
    ("plain-host", ("plain-host", "")),
    ("host:notaport", ("host:notaport", "")),
    ("", ("", "")),
    (None, ("", "")),
])
def test_split_location(location, expected):
    assert split_location(location) == expected


def test_bridge_remote_vpns_sheet_gains_host_and_port():
    frames, _ = _export("bridges")
    frame = frames["bridges.remoteMsgVpns"]
    columns = list(frame.columns)
    # inserted directly after the source column, not appended at the end
    assert columns.index("Remote Host") == columns.index("Remote Location") + 1
    assert columns.index("Remote Port") == columns.index("Remote Location") + 2
    rows = frame.to_dict("records")
    assert (rows[0]["Remote Host"], rows[0]["Remote Port"]) == ("203.0.113.9", "55555")
    assert (rows[1]["Remote Host"], rows[1]["Remote Port"]) == ("partner-dr.example.com", "55443")


def test_bridges_sheet_shows_remote_vpn_and_host_inline():
    frames, _ = _export("bridges")
    frame = frames["bridges"]
    columns = list(frame.columns)
    # derived block sits immediately after the identity columns
    assert columns[:3] == ["VPN", "Bridge", "Bridge Virtual Router"]
    assert columns[3:11] == [
        "Remote VPN", "Remote Host", "Remote Port", "Remote Location",
        "Remote Interface", "Remote Queue Binding", "Remote TLS", "Remote Connections",
    ]
    row = frame.to_dict("records")[0]
    assert row["Remote VPN"] == "partner-vpn"                      # distinct values only
    assert row["Remote Host"] == "203.0.113.9 | partner-dr.example.com"
    assert row["Remote Port"] == "55555 | 55443"
    assert row["Remote Queue Binding"] == "BRIDGE.INBOUND"
    assert row["Remote TLS"] == "False | True"
    assert row["Remote Connections"] == 2                          # multi-homed bridge


def test_rdp_sheet_shows_consumer_endpoint():
    frames, _ = _export("rest")
    row = frames["rdps"].to_dict("records")[0]
    assert (row["Remote Host"], row["Remote Port"]) == ("hooks.example.com", "443")
    assert row["REST Consumers"] == 1


def test_derived_columns_excluded_from_vpn_comparison():
    connection = ConnectionConfig(host="demo", username="u", password="p")
    result = ExportOrchestrator(
        sample_client(), connection, ExportConfig(scopes=("all",))
    ).run()
    comparison = compare_vpns(result.sheets, "prod", "dev")
    compared = {
        str(attribute)
        for object_type in comparison.types
        for attribute in object_type.frame.get("Attribute", pd.Series(dtype=str))
    }
    assert "Remote Host" not in compared      # derived from Remote Location
    assert "Remote Connections" not in compared
    assert DERIVED_COLUMNS                    # registry actually populated


def test_enrichment_is_safe_on_empty_and_missing_sheets():
    # no bridges sheet at all
    assert enrich_sheets([]) == []

    # bridges present, remote VPNs missing entirely -> columns still added, blank
    bridges = SheetData(
        name="Bridges",
        frame=pd.DataFrame([{"VPN": "prod", "Bridge": "b1", "Bridge Virtual Router": "auto"}]),
        spec_key="bridges", endpoint="msgVpns/{v}/bridges",
        id_columns=("VPN", "Bridge", "Bridge Virtual Router"), per_vpn=True,
    )
    enrich_sheets([bridges])
    row = bridges.frame.to_dict("records")[0]
    assert row["Remote VPN"] == "" and row["Remote Connections"] == 0

    # empty frame keeps its headers stable
    empty = SheetData(
        name="Bridges", frame=pd.DataFrame(columns=["VPN", "Bridge", "Bridge Virtual Router"]),
        spec_key="bridges", endpoint="e",
        id_columns=("VPN", "Bridge", "Bridge Virtual Router"), per_vpn=True,
    )
    enrich_sheets([empty])
    assert "Remote Host" in empty.frame.columns and empty.frame.empty


def test_enrichment_is_idempotent():
    frames, result = _export("bridges")
    before = list(frames["bridges"].columns)
    enrich_sheets(result.sheets)          # run a second time
    assert list(result.sheets[0].frame.columns) == before
