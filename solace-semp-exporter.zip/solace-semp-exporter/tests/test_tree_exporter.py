"""TreeExporter: hierarchy flattening, ancestor columns, skips, resume."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

import pytest

from solace_exporter.exporters import RunContext, TreeExporter
from solace_exporter.exporters.bridges import BRIDGES
from solace_exporter.exporters.cache import DISTRIBUTED_CACHES
from solace_exporter.exporters.queues import QUEUES
from solace_exporter.testing import FakeSempClient


@pytest.fixture()
def pool():
    with ThreadPoolExecutor(max_workers=4) as executor:
        yield executor


def _run(root, client, pool, vpns=("prod", "dev"), cached=None):
    exporter = TreeExporter(root)
    ctx = RunContext(client=client, pool=pool, vpns=vpns, cached_rows=cached)
    return exporter, exporter.export(ctx)


def test_child_rows_carry_full_ancestor_identity(fake_client, pool):
    _, output = _run(QUEUES, fake_client, pool)
    sheets = {s.name: s.frame for s in output.sheets}

    queues = sheets["Queues"]
    assert list(queues.columns[:2]) == ["VPN", "Queue"]
    assert set(queues["VPN"]) == {"prod", "dev"}

    subs = sheets["Queue Subscriptions"]
    assert list(subs.columns[:3]) == ["VPN", "Queue", "Subscription Topic"]
    # the slash-named queue proves percent-encoded child fetches work
    assert ("prod", "billing/eu", "billing/eu/invoices/>") in {
        tuple(r) for r in subs[["VPN", "Queue", "Subscription Topic"]].itertuples(index=False)
    }


def test_multi_key_bridge_hierarchy_flattens(fake_client, pool):
    _, output = _run(BRIDGES, fake_client, pool, vpns=("prod",))
    sheets = {s.name: s.frame for s in output.sheets}

    remotes = sheets["Bridge Remote VPNs"]
    assert list(remotes.columns[:4]) == ["VPN", "Bridge", "Bridge Virtual Router", "Remote VPN"]
    assert remotes.iloc[0]["Remote VPN"] == "partner-vpn"

    subs = sheets["Bridge Remote Subscriptions"]
    assert {"VPN", "Bridge", "Bridge Virtual Router", "Remote Subscription Topic"} <= set(subs.columns)
    assert len(subs) == 2


def test_unavailable_endpoint_becomes_skip_not_error(fake_client, pool):
    _, output = _run(DISTRIBUTED_CACHES, fake_client, pool)
    assert output.sheets == []
    skipped = {s.sheet for s in output.skipped}
    # the whole subtree cascades into the skip list
    assert {"Distributed Caches", "Cache Clusters", "Cache Cluster Topics"} <= skipped


def test_resume_uses_cached_rows_without_api_calls(fake_client, pool):
    exporter, output = _run(QUEUES, fake_client, pool)
    calls_after_first = fake_client.call_count

    exporter2, output2 = _run(QUEUES, fake_client, pool, cached=output.raw_rows)
    assert fake_client.call_count == calls_after_first  # no new HTTP traffic
    assert {s.name for s in output2.sheets} == {s.name for s in output.sheets}
    assert output2.sheets[0].frame.equals(output.sheets[0].frame)


def test_empty_child_sheet_keeps_full_ancestor_headers(pool):
    """A VPN with zero queues must still yield the complete Queue Subscriptions header chain."""
    client = FakeSempClient({
        "msgVpns": [{"msgVpnName": "empty"}],
        "msgVpns/empty/queues": [],
    })
    _, output = _run(QUEUES, client, pool, vpns=("empty",))
    subs = next(s.frame for s in output.sheets if s.name == "Queue Subscriptions")
    assert list(subs.columns[:3]) == ["VPN", "Queue", "Subscription Topic"]
    assert subs.empty


def test_unsupported_child_endpoint_short_circuits(pool):
    """One INVALID_PATH answer must stop per-parent fan-out for that endpoint."""
    queues = [{"queueName": f"Q{i}"} for i in range(50)]
    client = FakeSempClient({
        "msgVpns/prod/queues": queues,
        # no .../subscriptions mappings -> every call answers INVALID_PATH
    })
    with ThreadPoolExecutor(max_workers=1) as serial_pool:
        exporter = TreeExporter(QUEUES)
        ctx = RunContext(client=client, pool=serial_pool, vpns=("prod",))
        output = exporter.export(ctx)
    # 1 queues call + exactly 1 subscriptions probe (49 short-circuited)
    assert client.call_count == 2
    assert {s.sheet for s in output.skipped} == {"Queue Subscriptions"}


def test_single_missing_parent_tolerated_not_cascaded(pool):
    """A 404 on one parent (deleted mid-export) must not skip the whole endpoint."""
    client = FakeSempClient(
        {
            "msgVpns/prod/queues": [{"queueName": "A"}, {"queueName": "B"}],
            "msgVpns/prod/queues/A/subscriptions": [{"subscriptionTopic": "a/>"}],
        },
        not_found={"msgVpns/prod/queues/B/subscriptions"},
    )
    _, output = _run(QUEUES, client, pool, vpns=("prod",))
    assert output.skipped == []
    subs = next(s.frame for s in output.sheets if s.name == "Queue Subscriptions")
    assert list(subs["Queue"]) == ["A"]


def test_nested_attributes_flatten_to_dotted_columns(fake_client, pool):
    _, output = _run(QUEUES, fake_client, pool, vpns=("prod",))
    queues = next(s.frame for s in output.sheets if s.name == "Queues")
    assert "eventMsgSpoolUsageThreshold.setPercent" in queues.columns
    row = queues[queues["Queue"] == "ORDERS.IN"].iloc[0]
    assert row["eventMsgSpoolUsageThreshold.setPercent"] == 25


def test_single_object_spec_transposes_to_setting_value(fake_client, pool):
    from solace_exporter.exporters.services import BROKER

    _, output = _run(BROKER, fake_client, pool, vpns=())
    broker = output.sheets[0].frame
    assert list(broker.columns) == ["Setting", "Value"]
    assert "guaranteedMsgingEnabled" in set(broker["Setting"])
    assert list(broker["Setting"]) == sorted(broker["Setting"])
