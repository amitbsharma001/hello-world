"""Excel writer: formatting, friendly headers, safety guards, metadata."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

from solace_exporter.excel_writer import write_workbook
from solace_exporter.models import ExportMetadata, ExportResult, SheetData


def _meta() -> ExportMetadata:
    return ExportMetadata(host="demo", base_url="http://demo:8080/SEMP/v2/config")


def _sheet(name: str, frame: pd.DataFrame) -> SheetData:
    return SheetData(name=name, frame=frame, spec_key=name.lower(), endpoint=f"x/{name}")


def test_friendly_headers_default_and_raw_opt_out(tmp_path: Path):
    frame = pd.DataFrame(
        [{"VPN": "prod", "Queue": "Q1", "maxMsgSpoolUsage": 10, "respectTtlEnabled": True}]
    )
    friendly = tmp_path / "friendly.xlsx"
    raw = tmp_path / "raw.xlsx"
    write_workbook(friendly, [_sheet("Queues", frame)], _meta(), ExportResult())
    write_workbook(raw, [_sheet("Queues", frame)], _meta(), ExportResult(), friendly_headers=False)

    friendly_header = [c.value for c in load_workbook(friendly)["Queues"][1]]
    raw_header = [c.value for c in load_workbook(raw)["Queues"][1]]
    assert friendly_header == ["VPN", "Queue", "Max Msg Spool Usage", "Respect TTL Enabled"]
    assert raw_header == ["VPN", "Queue", "maxMsgSpoolUsage", "respectTtlEnabled"]


def test_formula_injection_guard_and_nan_blank(tmp_path: Path):
    frame = pd.DataFrame.from_records(
        [{"name": "=HYPERLINK(evil)", "extra": "x"}, {"name": "ok"}],  # row 2 lacks "extra" -> NaN
        columns=["name", "extra"],
    )
    target = tmp_path / "guard.xlsx"
    write_workbook(target, [_sheet("Data", frame)], _meta(), ExportResult())
    worksheet = load_workbook(target)["Data"]
    assert worksheet["A2"].value == "'=HYPERLINK(evil)"  # neutralised, still visible
    assert worksheet["A2"].data_type == "s"
    assert worksheet["B3"].value in ("", None)  # NaN never leaks into the file


def test_sheet_names_sanitised_truncated_unique(tmp_path: Path):
    frame = pd.DataFrame([{"a": 1}])
    long_a = _sheet("A really really long worksheet name [1/2]", frame)
    long_b = _sheet("A really really long worksheet name [2/2]", frame)
    target = tmp_path / "names.xlsx"
    write_workbook(target, [long_a, long_b], _meta(), ExportResult())
    names = [n for n in load_workbook(target).sheetnames if n not in ("Summary", "_metadata")]
    assert len(names) == 2 and len(set(names)) == 2
    assert all(len(n) <= 31 for n in names)
    assert all(not set("[]:*?/\\") & set(n) for n in names)


def test_summary_first_metadata_hidden_and_parseable(tmp_path: Path):
    frame = pd.DataFrame([{"a": 1}])
    target = tmp_path / "meta.xlsx"
    write_workbook(target, [_sheet("Data", frame)], _meta(), ExportResult())
    workbook = load_workbook(target)
    assert workbook.sheetnames[0] == "Summary"
    hidden = workbook["_metadata"]
    assert hidden.sheet_state == "hidden"
    chunks = []
    row = 2
    while hidden.cell(row=row, column=1).value:
        chunks.append(str(hidden.cell(row=row, column=1).value))
        row += 1
    payload = json.loads("".join(chunks))
    assert payload["host"] == "demo"
    assert "password" not in json.dumps(payload).lower() or "***" in json.dumps(payload)


def test_empty_frame_still_gets_header_filter_freeze(tmp_path: Path):
    frame = pd.DataFrame(columns=["VPN", "Queue", "Subscription Topic"])
    target = tmp_path / "empty.xlsx"
    write_workbook(target, [_sheet("Queue Subscriptions", frame)], _meta(), ExportResult())
    worksheet = load_workbook(target)["Queue Subscriptions"]
    assert [c.value for c in worksheet[1]] == ["VPN", "Queue", "Subscription Topic"]
    assert worksheet.freeze_panes == "A2"
    assert worksheet.auto_filter.ref is not None


def test_comparison_workbook_layout_and_status_tinting(tmp_path: Path):
    from solace_exporter.compare import compare_vpns

    rows = [
        {"VPN": "prod", "Queue": "Q1", "maxMsgSpoolUsage": 100},
        {"VPN": "prod", "Queue": "Q2", "maxMsgSpoolUsage": 50},
        {"VPN": "dr", "Queue": "Q1", "maxMsgSpoolUsage": 200},
    ]
    frame = pd.DataFrame.from_records(rows)
    sheet = SheetData(name="Queues", frame=frame, spec_key="queues",
                      endpoint="x", id_columns=("VPN", "Queue"), per_vpn=True)
    identical = SheetData(
        name="ACL Profiles",
        frame=pd.DataFrame.from_records([
            {"VPN": "prod", "ACL Profile": "p", "clientConnectDefaultAction": "allow"},
            {"VPN": "dr", "ACL Profile": "p", "clientConnectDefaultAction": "allow"},
        ]),
        spec_key="acl", endpoint="y", id_columns=("VPN", "ACL Profile"), per_vpn=True,
    )
    comparison = compare_vpns([sheet, identical], "prod", "dr")

    from solace_exporter.excel_writer import write_comparison_workbook
    target = tmp_path / "compare.xlsx"
    write_comparison_workbook(target, comparison, _meta())

    workbook = load_workbook(target)
    assert workbook.sheetnames[0] == "Summary"
    assert "Queues" in workbook.sheetnames
    assert "ACL Profiles" not in workbook.sheetnames        # no deltas -> summary only
    assert workbook["_metadata"].sheet_state == "hidden"

    queues = workbook["Queues"]
    header = [c.value for c in queues[1]]
    assert header == ["Status", "Queue", "Attribute", "prod", "dr"]
    statuses = {queues.cell(row=r, column=1).value for r in range(2, queues.max_row + 1)}
    assert {"Only in prod", "Different"} <= statuses
    fills = {
        queues.cell(row=r, column=1).value: queues.cell(row=r, column=1).fill.fgColor.rgb
        for r in range(2, queues.max_row + 1)
    }
    assert fills["Only in prod"].endswith("FDE9D9")
    assert fills["Different"].endswith("FFF2CC")

    # Summary lists every compared type, including the fully identical one
    summary_values = {str(c.value) for row in workbook["Summary"].iter_rows() for c in row if c.value}
    assert {"Queues", "ACL Profiles", "VPN A", "VPN B", "TOTAL"} <= summary_values
