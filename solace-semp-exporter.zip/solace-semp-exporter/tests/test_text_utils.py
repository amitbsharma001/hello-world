"""Path rendering, sheet/cell sanitisation."""

from __future__ import annotations

import pytest

from solace_exporter.utils.text import (
    clean_cell,
    encode_path_param,
    render_path,
    sanitize_sheet_name,
    table_display_name,
    unique_name,
)


def test_encode_path_param_encodes_everything_reserved():
    assert encode_path_param("billing/eu #1") == "billing%2Feu%20%231"


def test_render_path_multi_key_comma_literal():
    path = render_path(
        "msgVpns/{msgVpnName}/bridges/{bridgeName},{bridgeVirtualRouter}/remoteMsgVpns",
        {"msgVpnName": "prod", "bridgeName": "b2b/partner", "bridgeVirtualRouter": "auto"},
    )
    assert path == "msgVpns/prod/bridges/b2b%2Fpartner,auto/remoteMsgVpns"


def test_render_path_missing_context_raises():
    with pytest.raises(KeyError):
        render_path("msgVpns/{msgVpnName}/queues", {})


def test_sheet_name_sanitised_and_unique():
    taken = {"ACL Publish Exceptions"}
    name = unique_name(sanitize_sheet_name("ACL Publish Exceptions [*?]"), taken)
    assert name != "ACL Publish Exceptions"
    assert len(name) <= 31
    assert "[" not in name and "*" not in name


def test_table_display_name_is_valid_identifier():
    taken: set[str] = set()
    first = table_display_name("Queue Subscriptions", taken)
    taken.add(first)
    second = table_display_name("Queue Subscriptions", taken)
    assert first != second
    assert first.isidentifier()


def test_clean_cell_guards_formula_injection_and_serialises():
    assert clean_cell("=cmd|' /C calc'!A0").startswith("'=")
    assert clean_cell("@SUM(A1)").startswith("'@")
    assert clean_cell(["a", "b"]) == "a, b"
    assert clean_cell({"k": 1}) == '{"k": 1}'
    assert clean_cell("bad\x00char") == "badchar"
    assert clean_cell(5) == 5


def test_clean_cell_blanks_nan_and_inf():
    assert clean_cell(float("nan")) == ""
    assert clean_cell(float("inf")) == ""
    assert clean_cell(None) == ""


def test_humanize_header_camel_case_and_acronyms():
    from solace_exporter.utils.text import dedupe_headers, humanize_header

    assert humanize_header("maxMsgSpoolUsage") == "Max Msg Spool Usage"
    assert humanize_header("serviceSmfPlainTextEnabled") == "Service SMF Plain Text Enabled"
    assert humanize_header("mqttSessionClientId") == "MQTT Session Client ID"
    assert humanize_header("tlsBlockVersion11Enabled") == "TLS Block Version 11 Enabled"
    # nested (dot-flattened) attributes render per segment
    assert (
        humanize_header("eventMsgSpoolUsageThreshold.setPercent")
        == "Event Msg Spool Usage Threshold / Set Percent"
    )
    # already-friendly hierarchy headers pass through untouched
    assert humanize_header("Subscription Topic") == "Subscription Topic"
    assert humanize_header("VPN") == "VPN"
    assert dedupe_headers(["Enabled", "Enabled", "Owner"]) == ["Enabled", "Enabled (2)", "Owner"]
