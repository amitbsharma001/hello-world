"""Interactive operation menu: export / compare / migrate selection."""

from __future__ import annotations

from pathlib import Path

import pytest
from openpyxl import load_workbook
from typer.testing import CliRunner

import solace_exporter.cli as cli_mod
from solace_exporter.cli import app
from solace_exporter.testing import sample_client

runner = CliRunner()


@pytest.fixture
def tty(monkeypatch):
    """Pretend we are on a terminal and talking to the fake broker."""
    monkeypatch.setattr(cli_mod, "_stdin_is_tty", lambda: True)
    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())


def _answers(*lines: str) -> str:
    return "\n".join(lines) + "\n"


def _base(tmp_path: Path, name: str) -> list[str]:
    return ["--log-file", str(tmp_path / f"{name}.log"), "--cache-dir", str(tmp_path / name)]


CONNECT = ("demo-broker", "n", "8080", "admin", "pw")   # host, ssl, port, user, password


def test_menu_lists_all_three_operations(tty, tmp_path):
    result = runner.invoke(
        app, _base(tmp_path, "menu"),
        input=_answers("1", *CONNECT, "queues", "", str(tmp_path / "out.xlsx")),
    )
    assert result.exit_code == 0, result.output
    assert "What would you like to do?" in result.output
    for label in ("Export", "Compare", "Migrate"):
        assert label in result.output
    assert (tmp_path / "out.xlsx").exists()


def test_default_answer_is_export(tty, tmp_path):
    """Bare Enter keeps the pre-menu behaviour: a plain export."""
    result = runner.invoke(
        app, _base(tmp_path, "default"),
        input=_answers("", *CONNECT, "queues", "", str(tmp_path / "out.xlsx")),
    )
    assert result.exit_code == 0, result.output
    names = load_workbook(tmp_path / "out.xlsx").sheetnames
    assert "Queues" in names
    assert not list(tmp_path.glob("*compare*.xlsx"))


def test_invalid_choice_reprompts(tty, tmp_path):
    result = runner.invoke(
        app, _base(tmp_path, "retry"),
        input=_answers("9", "banana", "1", *CONNECT, "queues", "", str(tmp_path / "out.xlsx")),
    )
    assert result.exit_code == 0, result.output
    assert "Enter 1, 2 or 3" in result.output
    assert (tmp_path / "out.xlsx").exists()


def test_choosing_compare_prompts_for_the_vpn_pair(tty, tmp_path):
    export_path = tmp_path / "export.xlsx"
    compare_path = tmp_path / "compare.xlsx"
    result = runner.invoke(
        app, [*_base(tmp_path, "cmp"), "--compare-output", str(compare_path)],
        input=_answers("2", *CONNECT, "1", "prod", "dev", "", str(export_path)),
    )
    assert result.exit_code == 0, result.output
    assert "First VPN to compare" in result.output
    assert "Second VPN to compare" in result.output
    assert compare_path.exists()
    assert "Summary" in load_workbook(compare_path).sheetnames


def test_compare_accepts_ignore_globs_from_the_prompt(tty, tmp_path):
    compare_path = tmp_path / "compare.xlsx"
    result = runner.invoke(
        app, [*_base(tmp_path, "glob"), "--compare-output", str(compare_path)],
        input=_answers("compare", *CONNECT, "queues", "prod", "dev",
                       "replication*, eventLarge*", str(tmp_path / "e.xlsx")),
    )
    assert result.exit_code == 0, result.output
    assert compare_path.exists()


def test_choosing_migrate_enters_the_migration_flow(tty, tmp_path):
    report = tmp_path / "migration.xlsx"
    result = runner.invoke(
        app, [*_base(tmp_path, "mig"), "--migrate-report", str(report)],
        input=_answers("3", *CONNECT, "n", "prod", "prod-uat", "skip", "n"),
    )
    assert result.exit_code == 0, result.output
    assert "Copy to a different broker?" in result.output
    assert "Same broker: the target VPN needs a different name" in result.output
    assert "Aborted" in result.output          # declined -> plan-only
    assert report.exists()


def test_explicit_flags_skip_the_menu(tty, tmp_path):
    """--compare / --migrate are unambiguous: no extra question."""
    result = runner.invoke(
        app, [*_base(tmp_path, "flag"), "--compare", "prod", "--compare", "dev",
              "--compare-output", str(tmp_path / "c.xlsx")],
        input=_answers(*CONNECT, "queues", str(tmp_path / "e.xlsx")),
    )
    assert result.exit_code == 0, result.output
    assert "What would you like to do?" not in result.output
    assert (tmp_path / "c.xlsx").exists()


def test_migration_flags_imply_migrate_interactively(tty, tmp_path):
    report = tmp_path / "m.xlsx"
    result = runner.invoke(
        app, [*_base(tmp_path, "imply"), "--source-vpn", "prod", "--target-vpn", "prod-uat",
              "--migrate-report", str(report), "--migrate-dry-run"],
        input=_answers(*CONNECT, "n", "skip"),   # different broker? / exists policy
    )
    assert result.exit_code == 0, result.output
    assert "Migration options detected" in result.output
    assert "What would you like to do?" not in result.output
    assert report.exists()


def test_migration_flags_without_migrate_are_rejected_non_interactively(tmp_path, monkeypatch):
    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())
    result = runner.invoke(app, [
        *_base(tmp_path, "reject"),
        "--host", "demo", "--username", "u", "--password", "p",
        "--source-vpn", "prod", "--no-interactive",
    ])
    assert result.exit_code == 2
    assert "without --migrate" in result.output
    assert "--source-vpn" in result.output


def test_non_interactive_never_shows_the_menu(tmp_path, monkeypatch):
    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())
    output = tmp_path / "out.xlsx"
    result = runner.invoke(app, [
        *_base(tmp_path, "quiet"),
        "--host", "demo", "--username", "u", "--password", "p",
        "--scope", "queues", "--no-interactive", "--output", str(output),
    ])
    assert result.exit_code == 0, result.output
    assert "What would you like to do?" not in result.output
    assert output.exists()
