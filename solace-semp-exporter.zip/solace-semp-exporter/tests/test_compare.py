"""VPN comparison engine: classification, attribute diffs, ignores, edge cases."""

from __future__ import annotations

import pandas as pd

from solace_exporter.compare import compare_vpns
from solace_exporter.models import SheetData


def _sheet(name: str, rows: list[dict], id_columns: tuple[str, ...], per_vpn: bool = True) -> SheetData:
    columns = list(dict.fromkeys(k for row in rows for k in row))
    frame = pd.DataFrame.from_records(rows, columns=columns)
    return SheetData(
        name=name, frame=frame, spec_key=name.lower().replace(" ", "_"),
        endpoint=f"x/{name}", id_columns=id_columns, per_vpn=per_vpn,
    )


def test_object_classification_and_attribute_level_diffs():
    rows = [
        {"VPN": "prod", "Queue": "Q1", "maxMsgSpoolUsage": 100, "owner": "app"},
        {"VPN": "prod", "Queue": "Q2", "maxMsgSpoolUsage": 50, "owner": "app"},
        {"VPN": "dr", "Queue": "Q1", "maxMsgSpoolUsage": 200, "owner": "app"},
        {"VPN": "dr", "Queue": "Q3", "maxMsgSpoolUsage": 10, "owner": "app"},
    ]
    comparison = compare_vpns([_sheet("Queues", rows, ("VPN", "Queue"))], "prod", "dr")
    outcome = comparison.types[0]
    assert (outcome.only_a, outcome.only_b, outcome.different, outcome.identical) == (1, 1, 1, 0)
    assert (outcome.count_a, outcome.count_b) == (2, 2)

    frame = outcome.frame
    assert list(frame.columns) == ["Status", "Queue", "Attribute", "prod", "dr"]
    by_status = {s: frame[frame["Status"] == s] for s in frame["Status"].unique()}
    assert list(by_status["Only in prod"]["Queue"]) == ["Q2"]
    assert list(by_status["Only in dr"]["Queue"]) == ["Q3"]
    only_row = by_status["Only in prod"].iloc[0]
    assert (only_row["prod"], only_row["dr"]) == ("present", "missing")

    diff = by_status["Different"].iloc[0]
    assert diff["Queue"] == "Q1"
    assert diff["Attribute"] == "Max Msg Spool Usage"  # friendly by default
    assert (diff["prod"], diff["dr"]) == (100, 200)


def test_identical_objects_counted_but_not_listed():
    rows = [
        {"VPN": "a", "Queue": "Q1", "owner": "x"},
        {"VPN": "b", "Queue": "Q1", "owner": "x"},
    ]
    outcome = compare_vpns([_sheet("Queues", rows, ("VPN", "Queue"))], "a", "b").types[0]
    assert outcome.identical == 1 and not outcome.has_deltas
    assert outcome.frame.empty
    assert outcome.match_pct == 100.0


def test_ignore_globs_match_raw_and_friendly_names():
    rows = [
        {"VPN": "a", "Queue": "Q1", "replicationEnabled": True, "owner": "x"},
        {"VPN": "b", "Queue": "Q1", "replicationEnabled": False, "owner": "x"},
    ]
    sheet = _sheet("Queues", rows, ("VPN", "Queue"))
    noisy = compare_vpns([sheet], "a", "b").types[0]
    assert noisy.different == 1

    for pattern in ("replication*", "Replication *"):
        quiet = compare_vpns([sheet], "a", "b", ignore=(pattern,)).types[0]
        assert quiet.different == 0 and quiet.identical == 1


def test_raw_headers_mode_keeps_semp_attribute_names():
    rows = [
        {"VPN": "a", "Queue": "Q1", "maxMsgSpoolUsage": 1},
        {"VPN": "b", "Queue": "Q1", "maxMsgSpoolUsage": 2},
    ]
    outcome = compare_vpns([_sheet("Queues", rows, ("VPN", "Queue"))], "a", "b", friendly=False).types[0]
    assert outcome.frame.iloc[0]["Attribute"] == "maxMsgSpoolUsage"


def test_missing_attribute_surfaces_as_blank_side():
    rows = [
        {"VPN": "a", "Queue": "Q1", "deadMsgQueue": "#DMQ"},
        {"VPN": "b", "Queue": "Q1"},  # attribute absent -> NaN in the frame
    ]
    outcome = compare_vpns([_sheet("Queues", rows, ("VPN", "Queue"))], "a", "b").types[0]
    diff = outcome.frame.iloc[0]
    assert diff["Attribute"] == "Dead Msg Queue"
    assert (diff["a"], diff["b"]) == ("#DMQ", "")


def test_vpn_settings_sheet_diffs_without_identity_columns():
    rows = [
        {"VPN": "a", "enabled": True, "maxMsgSpoolUsage": 100},
        {"VPN": "b", "enabled": True, "maxMsgSpoolUsage": 500},
    ]
    outcome = compare_vpns([_sheet("VPNs", rows, ("VPN",))], "a", "b").types[0]
    assert outcome.key_columns == ()
    assert (outcome.different, outcome.identical) == (1, 0)
    assert list(outcome.frame.columns) == ["Status", "Attribute", "a", "b"]
    assert set(outcome.frame["Attribute"]) == {"Max Msg Spool Usage"}


def test_broker_level_sheets_are_excluded():
    # per_vpn=False even though a VPN column exists (e.g. Virtual Hostnames)
    rows = [{"VPN": "a", "virtualHostname": "a.example.com"}]
    sheets = [
        _sheet("Virtual Hostnames", rows, ("virtualHostname",), per_vpn=False),
        _sheet("Broker", [{"Setting": "x", "Value": 1}], ("Setting",), per_vpn=False),
    ]
    assert compare_vpns(sheets, "a", "b").types == []


def test_reserved_vpn_names_get_disambiguated_columns():
    rows = [
        {"VPN": "Status", "Queue": "Q1", "owner": "x"},
        {"VPN": "Attribute", "Queue": "Q1", "owner": "y"},
    ]
    outcome = compare_vpns([_sheet("Queues", rows, ("VPN", "Queue"))], "Status", "Attribute").types[0]
    assert list(outcome.frame.columns) == ["Status", "Queue", "Attribute", "Status (A)", "Attribute (B)"]
    diff = outcome.frame.iloc[0]
    assert (diff["Status (A)"], diff["Attribute (B)"]) == ("x", "y")


def test_totals_roll_up_across_types():
    queue_rows = [
        {"VPN": "a", "Queue": "Q1", "owner": "x"},
        {"VPN": "b", "Queue": "Q2", "owner": "x"},
    ]
    user_rows = [
        {"VPN": "a", "Client Username": "u1", "enabled": True},
        {"VPN": "b", "Client Username": "u1", "enabled": True},
    ]
    comparison = compare_vpns(
        [
            _sheet("Queues", queue_rows, ("VPN", "Queue")),
            _sheet("Client Usernames", user_rows, ("VPN", "Client Username")),
        ],
        "a", "b",
    )
    assert (comparison.total_only_a, comparison.total_only_b) == (1, 1)
    assert comparison.total_identical == 1
    assert len(comparison.delta_types) == 1
    assert comparison.total_deltas == 2
