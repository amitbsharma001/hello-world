# Integration Guide — Approvals for any Django app

Add an approval gate to **any** model, action, Celery task, or automation job —
then read its approval status from code, the API, or the console. The engine is
one reusable app (`apps.approvals`); your app depends on it one way and never the
other way around.

**Mental model**

```
your object  ──submit──▶  approval lifecycle  ──approved──▶  your Celery task / job runs
(any model)                (sequential/parallel)              (on_approved automation)
     │                                                                │
     └──────────────── check status any time (.approval_status) ──────┘
```

---

## 1. Install

```python
# settings.py
INSTALLED_APPS = [
    # ...
    "apps.approvals",       # the reusable engine
    "apps.dynamic_forms",   # optional: only if you use the form builder
    "your_app",
]

MIDDLEWARE = [
    # ...
    "apps.approvals.audit.AuditContextMiddleware",   # captures who did what
]
```

Run migrations, and make sure Celery autodiscovers tasks (the engine registers
its shared tasks under `apps.approvals.tasks`):

```bash
python manage.py migrate
```

```python
# config/celery.py
app = Celery("your_project")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()   # finds apps.approvals.tasks automatically
```

> The on-approval task dispatches by **name** to your workers. In local/dev with
> `CELERY_TASK_ALWAYS_EAGER = True` it runs inline; in production it queues normally.

---

## 2. Quickstart (3 steps)

```python
from apps.approvals.flow import Flow

# 1) define the workflow once (idempotent — safe on startup or in a migration)
Flow.define(
    "invoice_approval",
    steps=[
        Flow.step("Manager", approvers=["mgr@acme.com"]),
        Flow.step("Finance", group="Finance", policy="all"),
    ],
    on_approved=Flow.run_task("apps.billing.tasks.charge_customer",
                              args=["{subject_id}"]),
)

# 2) submit any object
req = Flow.submit(invoice, by=request.user)

# 3) read status any time
Flow.status(invoice)        # "under_review" | "approved" | "rejected" | None
```

That's the whole loop: **define → submit → (approve) → your task runs → check status.**

---

## 3. Make a model approvable (optional but recommended)

Add the mixin so any model gets approval helpers for free — no FK, no table change:

```python
from django.db import models
from apps.approvals.mixins import ApprovableMixin

class Invoice(ApprovableMixin, models.Model):
    approval_workflow = "invoice_approval"   # the Flow slug
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    # ...

invoice.submit_for_approval(by=user)   # start the workflow
invoice.approval_status                # "under_review"
invoice.is_approved                    # True / False
invoice.latest_approval                # the ApprovalRequest (timeline, current step…)
```

Binding is generic (a content-type pointer), so the engine never imports your
model and your model carries no approval columns.

---

## 4. Run a Celery task **when approved**

This is the headline for "an app that has a Celery task." Point `on_approved` at
your task; it fires only after the approval completes.

```python
# apps/billing/tasks.py
from celery import shared_task

@shared_task(name="apps.billing.tasks.charge_customer")
def charge_customer(invoice_id):
    invoice = Invoice.objects.get(pk=invoice_id)
    # ... do the real work (charge, post to ledger, etc.)
```

```python
Flow.define(
    "invoice_approval",
    steps=[Flow.step("Finance", group="Finance", policy="all")],
    on_approved=Flow.run_task(
        "apps.billing.tasks.charge_customer",
        args=["{subject_id}"],          # templated — see below
    ),
)
```

**Templated arguments** are filled from the approval context at fire time:
`{subject_id}`, `{subject_type}`, `{data.<field>}`, `{request_id}`, `{workflow}`,
`{state}`, `{initiated_by}`, `{now}`.

Every run is recorded as an **`ActionRun`** (status, attempts, output, error), so
you always have an audit trail of what the approval triggered.

### Different tasks for different apps

The same hook works anywhere — one declarative line per app:

| Subject  | Workflow slug             | `on_approved` Celery task                     |
|----------|---------------------------|-----------------------------------------------|
| Invoice  | `invoice_approval`        | `apps.billing.tasks.charge_customer`          |
| Release  | `release_approval`        | `apps.deploy.tasks.rollout`                   |
| Vendor   | `vendor_onboarding`       | `apps.vendors.tasks.provision_vendor`         |
| Form     | `form_publication_approval` | `apps.dynamic_forms.tasks.publish_and_notify` |

You can also attach **more than one** action, or different events:

```python
Flow.define(
    "release_approval",
    steps=[Flow.step("Eng Lead", approvers=["lead@acme.com"])],
    on_approved=[
        Flow.run_task("apps.deploy.tasks.rollout", args=["{subject_id}"]),
        Flow.trigger("post_deploy_validation"),     # chain another workflow
        Flow.webhook("https://hooks.acme.io/shipped"),
        Flow.notify([10, 11], verb="release_shipped"),
    ],
    on_rejected=Flow.notify([10], verb="release_blocked"),
    on_step=Flow.run_task("apps.deploy.tasks.notify_step"),  # after each step
)
```

---

## 5. Gate an existing **automation job** behind approval

When the job already exists (a periodic Celery beat task, a management command, a
view that kicks off work), don't move it into `on_approved` — instead make its
subject approvable and **let the job check status**.

**Pattern A — guard at the entry point**

```python
def run_payout(invoice):
    if not invoice.is_approved:
        raise PermissionError("Invoice is not approved yet.")
    charge_customer.delay(invoice.id)
```

**Pattern B — a periodic job that only picks up approved items**

```python
# apps/billing/tasks.py
from celery import shared_task
from apps.approvals.models import ApprovalRequest
from apps.approvals.states import ApprovalState

@shared_task
def reconcile_approved_invoices():
    approved_ids = (
        ApprovalRequest.objects
        .filter(content_type__model="invoice", state=ApprovalState.APPROVED)
        .values_list("object_id", flat=True)
    )
    for invoice in Invoice.objects.filter(pk__in=approved_ids, reconciled=False):
        reconcile.delay(invoice.id)
```

Either way the job stays where it is; approval just becomes a precondition you can
query.

---

## 6. See approval status

### In code

```python
invoice.approval_status      # None | "under_review" | "approved" | "rejected" | "cancelled"
invoice.is_approved          # bool
Flow.status(invoice)         # same string as approval_status
req = Flow.latest(invoice)   # ApprovalRequest: req.state, req.current_step, req.tasks
```

### Over the API (DRF, mounted at `/api/v1/`)

```
GET  /api/v1/approval-requests/{id}/            # full state + current step
GET  /api/v1/approval-requests/{id}/timeline/   # ordered audit trail
GET  /api/v1/action-runs/                        # on-approval automation runs + status
```

Approvers act through the same task API (no new endpoints per app):

```
POST /api/v1/approval-tasks/{id}/approve/
POST /api/v1/approval-tasks/{id}/reject/
POST /api/v1/approval-tasks/{id}/request_changes/
POST /api/v1/approval-tasks/{id}/delegate/      {"to_user": 42}
```

If you use the form builder, the form object also exposes `approval_status`,
`published`, and `is_shareable` directly on `GET /api/v1/forms/{id}/`.

### Visually

A drop-in **lifecycle console** ships at `/approvals/console/` — it shows the
workflow graph, current stage, timeline, and the automation runs for a request.
It reads the same `/api/v1/approval-requests/` endpoints.

### Automation status specifically

Each `on_approved` action produces an **`ActionRun`**:

```python
from apps.approvals.models import ActionRun

run = ActionRun.objects.filter(action__action_type="celery_task").latest("created_at")
run.status     # pending | running | success | failed | skipped
run.attempts   # how many tries
run.output     # {"task": "...", "task_id": "...", ...}
run.error      # traceback string if it failed
```

---

## 7. How firing works (guarantees)

```
all approvals done ─▶ fire_event(on_approved) ─▶ enqueue AFTER db commit ─▶ worker runs your task
```

- **After commit** — the task is enqueued on `transaction.on_commit`, so it never
  runs against a rolled-back approval.
- **Retries** — up to `max_retries` (configurable per action).
- **Isolated** — a failing task is logged as a failed `ActionRun` but never
  reverses the approval decision.
- **Logged** — every attempt is recorded; nothing fires silently.

---

## 8. API reference (quick)

| Endpoint | Purpose |
|---|---|
| `GET/POST /api/v1/workflows/` | Workflow definitions (+ `/graph/`) |
| `GET /api/v1/approval-requests/` | Requests (+ `/timeline/`, `/cancel/`) |
| `GET /api/v1/approval-tasks/` | Tasks (+ `/approve/`, `/reject/`, `/request_changes/`, `/delegate/`) |
| `GET/POST /api/v1/automation-actions/` | Actions (+ `/test/` dry-run) |
| `GET /api/v1/action-runs/` | Automation run history (+ `/retry/`) |
| `GET /api/v1/action-types/` | Available action types |
| `GET /api/v1/dashboard/metrics/` | Aggregate metrics |
| `GET /api/v1/schema/`, `/docs/` | OpenAPI schema + docs |
| `GET /approvals/console/` | Lifecycle console UI |

---

## 9. Integration checklist

1. Add `apps.approvals` (and `apps.dynamic_forms` if needed) to `INSTALLED_APPS`.
2. Add `AuditContextMiddleware`; run `migrate`; ensure Celery `autodiscover_tasks()`.
3. `Flow.define(...)` your workflow with `on_approved=Flow.run_task("your.task")`.
4. `Flow.submit(obj, by=user)` — or add `ApprovableMixin` and call
   `obj.submit_for_approval(by=user)`.
5. Point your "Approve / Reject" UI at `/api/v1/approval-tasks/{id}/...`.
6. Read status via `obj.approval_status`, the request API, or `/approvals/console/`.

---

## 10. Notes & caveats

- **Approvers are users.** Tasks are assigned to user accounts, so an approver
  given by email must match an existing user (otherwise submit returns `400`).
- **Eager mode is dev-only.** `run_task` honors `CELERY_TASK_ALWAYS_EAGER` for
  local/test runs; in production it dispatches by name to a running worker, so the
  task must be importable there.
- **Email backend.** Approver/initiator emails use Django's configured
  `EMAIL_BACKEND` (console by default) — set SMTP/SES for real delivery, and toggle
  per workflow with `notify_approvers` / `notify_initiator`.
- **Secrets** (webhook tokens, deploy creds) should come from a secret store, not
  plaintext action config.
- **`Flow.define` is idempotent** — calling it again updates the workflow in place,
  so it's safe to run on every boot or in a data migration.
