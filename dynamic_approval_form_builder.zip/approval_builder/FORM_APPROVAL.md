# Form Publication Approval

A created form must be **approved before it can be shared** with customers.

```
Admin/user builds form ──▶ submit for approval ──▶ reviewer approves
        │                                                   │
        └─ public link is INACTIVE while unapproved         ▼
                                              form.published = True
                                              public link goes LIVE
                                                       │
                              customer submits ────────┘
                                       │
        creator + admins ◀── see submission history (who submitted what)
```

## One-time setup (define the review workflow)

```bash
python manage.py seed_form_approval --group "Form Reviewers"
```

This creates the `form_publication_approval` workflow (one review step, the
`Form Reviewers` group can approve). `FormDefinition` is already registered with
the engine in `DynamicFormsConfig.ready()`, with `on_approved` → publish.

## Lifecycle

1. **Build** — create a `FormDefinition` (+ fields). It starts **unpublished**;
   `form.is_open()` is `False`, so the public link returns *closed*.
2. **Submit for approval**
   ```
   POST /api/v1/forms/{id}/submit-for-approval/
   ```
   or in code: `form.submit_for_approval(by=request.user)`.
3. **Approve** — a reviewer approves via the normal task API
   (`POST /api/v1/approval-tasks/{id}/approve/`). The engine's `on_approved`
   hook (`on_form_published`) sets `published=True, published_at=now`.
4. **Share** — the public link `/forms/{public_token}/` is now live; customers
   submit with no login.
5. **History** — the form's creator (or any staff admin) can see every
   submission and its data:
   ```
   GET /api/v1/forms/{id}/submissions/
   ```
   Each row includes `submitted_by` (username, or a captured email, else
   "anonymous"), the field `values`, `customer_ip`, and `created_at`.
   Anyone who is **not** the creator or an admin gets `403`.

## Status on the form

`GET /api/v1/forms/{id}/` now returns:
- `approval_status` — `null | under_review | approved | rejected`
- `published`, `published_at`
- `is_shareable` — `true` only once approved, active, and unexpired

## Notes

- The publication gate lives in `FormDefinition.is_open()`; the public view
  (`PublicFormView`) honors it, so an unapproved form can never be submitted to.
- Per-submission approval is still available and **separate**: set a form's
  optional `workflow` FK and each submission runs through `customer_form_approval`.

## Approvers are authored on the form (like fields)

Approvers are added inline in the form builder, the same way fields are added.
Each approver row maps to a `FormApprover` row:

```json
POST /api/v1/forms/
{
  "name": "Vendor Onboarding",
  "fields":    [{"label": "Vendor", "name": "vendor", "field_type": "text", "required": true}],
  "approvers": [{"kind": "email", "email": "manager@acme.com",    "step": 1},
                {"kind": "email", "email": "compliance@acme.com", "step": 1}]
}
```

On `POST /api/v1/forms/{id}/submit-for-approval/` the engine **compiles those rows
into a per-form workflow** (`form_pub_{id}`) and starts it:

- approvers sharing a **step** become one parallel step (all must approve);
- steps run in order (`step: 2` runs after `step: 1`);
- `kind` is `email` (resolved to the user with that address), `user`, or `group`;
- an email with no matching user account → `400` with the offending address;
- no approvers → `400` ("add at least one approver").

Once every step is approved, `on_form_published` flips `published=True` and the
public link goes live. The builder UI is served at **`/forms-builder/`**.
