# Architecture & Design — Dynamic Approval Form Builder

## 1. Module boundaries (DDD bounded contexts)

```
apps/
  workflow_engine/   # Pure workflow definitions + registry. Knows NO business models.
  approvals/         # Runtime state machine. Binds to any subject via GenericForeignKey.
  dynamic_forms/     # Form authoring, EAV submissions, public sharing. A *consumer* of the engine.
  audit/             # Append-only cross-cutting trail + request-context middleware.
  notifications/     # Pluggable multi-channel fan-out (Celery).
```

Dependency rule (one direction only):

```
dynamic_forms ─▶ workflow_engine.registry ─▶ approvals.services ─▶ audit + notifications
                                  ▲                                         │
                                  └──────────── never imports business models
```

`workflow_engine` and `approvals` form the reusable core. `dynamic_forms` is just
the first host app; `Vendor`, `Contract`, etc. plug in identically.

## 2. How one model expresses sequential / parallel / mixed

A workflow is an **ordered list of steps**; each step carries an `ApprovalPolicy`
and one or more approver slots. This single relational shape covers all three:

| Pattern    | Steps | Approvers/step | Policy            |
|------------|-------|----------------|-------------------|
| Sequential | N     | 1              | ANY               |
| Parallel   | 1     | M              | ALL               |
| Mixed      | N     | mixed          | per-step ANY/ALL/QUORUM |

Runtime parallelism is materialised as one `ApprovalTask` per resolved approver;
a step completes when its tasks satisfy the policy (ANY=1 / ALL=all / QUORUM=N).

## 3. ER diagram

```mermaid
erDiagram
    WorkflowDefinition ||--o{ WorkflowStep : has
    WorkflowStep ||--o{ StepApprover : has
    WorkflowDefinition ||--o{ ApprovalRequest : instantiates
    ApprovalRequest ||--o{ ApprovalTask : materialises
    ApprovalRequest ||--o{ ApprovalActionLog : records
    WorkflowStep ||--o{ ApprovalTask : drives
    FormDefinition ||--o{ FormField : contains
    FormDefinition ||--o{ FormSubmission : collects
    FormSubmission ||--o{ SubmissionValue : eav
    FormField ||--o{ SubmissionValue : typed_by
    FormDefinition }o--|| WorkflowDefinition : approved_via
    ApprovalRequest }o--|| ContentType : subject_generic_fk
    AuditLog }o--|| ContentType : target_generic_fk
    Notification }o--|| ContentType : target_generic_fk
```

`ApprovalRequest`, `AuditLog`, and `Notification` bind to **any** subject through a
`(content_type, object_id)` GenericForeignKey — the decoupling mechanism.

## 4. Sequence — public submission to approval

```mermaid
sequenceDiagram
    actor Customer
    participant Public as PublicFormView
    participant SVC as SubmissionService
    participant ENG as ApprovalEngine
    participant AS as ApprovalService
    participant N as Notifications

    Customer->>Public: POST /forms/{token}/
    Public->>SVC: save(form, data, meta)
    SVC->>SVC: validate_submission() + write EAV
    SVC->>ENG: start(instance=submission)
    ENG->>AS: initiate(subject, workflow_slug)
    AS->>AS: create ApprovalRequest + activate step 1
    AS->>N: notify(assignees, "task_assigned")
    AS-->>Customer: 201 {submission_uuid, status}
```

## 5. Sequence — approver decision & step evaluation

```mermaid
sequenceDiagram
    actor Approver
    participant API as ApprovalTaskViewSet
    participant AS as ApprovalService
    Approver->>API: POST /approval-tasks/{id}/approve/
    API->>AS: act(task_id, actor, "approve")
    AS->>AS: guard (assignee? pending? not terminal?)
    AS->>AS: _evaluate_step (ANY/ALL/QUORUM)
    alt step satisfied & more steps
        AS->>AS: _activate_step(next)
    else step satisfied & last step
        AS->>AS: _finalise(APPROVED) + host callback
    else rejection
        AS->>AS: _finalise(REJECTED)
    end
```

## 6. State machine

```
draft ─submit─▶ pending ─▶ under_review ──approve(final)──▶ approved ─▶ completed
                                │  ├─reject──▶ rejected
                                │  ├─cancel──▶ cancelled
                                │  └─(SLA)───▶ escalate (re-activates step)
                                └─request_changes──▶ under_review (resubmit loop)
```

## 7. Permission matrix

| Action                  | Initiator | Assignee (pending task) | Group member | Admin |
|-------------------------|:---------:|:-----------------------:|:------------:|:-----:|
| Create form / workflow  |     ✔     |            –            |      –       |   ✔   |
| Initiate approval       |     ✔     |            –            |      –       |   ✔   |
| Approve / Reject task   |     –     |            ✔            |  ✔ (resolved)|   ✔   |
| Delegate task           |     –     |        ✔ (if allowed)   |      –       |   ✔   |
| Cancel request          |     ✔     |            –            |      –       |   ✔   |
| View all tasks/requests |  own only |        own only         |   own only   |   ✔   |
| Dashboard metrics       |     –     |            –            |      –       |   ✔   |

Enforced via DRF permission classes (`IsTaskAssignee`, `IsAdminUser`) plus an
object-level assignee check inside `ApprovalService.act()` — the domain layer is
authoritative, so the rule holds even if called outside the API.

## 8. Security architecture

- **RBAC + object-level**: Django groups/perms; assignee verified in service layer.
- **Public forms**: 192-bit `secrets.token_urlsafe` token + UUID + expiry gate;
  no PII in the URL.
- **CSRF**: enabled; public form uses `ensure_csrf_cookie` + `X-CSRFToken`.
- **Rate limiting**: DRF throttles (anon 60/min, user 1000/min); front public
  endpoint should sit behind a WAF / nginx limit_req in prod.
- **File uploads**: size-capped (`FILE_UPLOAD_MAX_MEMORY_SIZE`), stored outside
  web root, served via signed URLs in prod.
- **XSS/SQLi**: Django ORM (parameterised) + template auto-escaping; all input
  re-validated server-side in `validators.py`.
- **Audit**: append-only `AuditLog` with IP + user-agent from middleware.
- **HTTPS hardening** (DEBUG off): HSTS, secure cookies, SSL redirect, nosniff.

## 9. Index & partition strategy

- Hot lookups indexed: `ApprovalRequest(content_type,object_id)`, `(state)`,
  `(workflow,state)`; `ApprovalTask(assignee,status)`; `FormDefinition(public_token)`;
  `SubmissionValue(field,value)` for EAV reporting.
- At millions of rows: range-**partition** `AuditLog` and `FormSubmission` by
  `created_at` (monthly) via Postgres declarative partitioning; attach BRIN on
  `created_at`. Archive cold partitions to cheaper storage.
- Multi-tenant: add a `tenant_id` column + composite indexes prefixed by tenant,
  and enforce Postgres Row-Level Security policies per tenant.

## 10. Deployment architecture

```
            ┌────────────┐
  Internet ─▶  nginx/WAF  ─▶ gunicorn (web, N replicas)
            └────────────┘        │
                                  ├─▶ Postgres (primary + read replica)
                                  ├─▶ Redis (broker + cache)
                                  └─▶ Celery worker(s) + beat
```

- Stateless web pods → horizontal scale behind an HPA on CPU/RPS.
- Celery workers scale independently for notification/SLA load.
- Migrations as a pre-deploy Job; `collectstatic` to object storage/CDN.
- **K8s / CI-CD**: provided as design only in this drop — Deployment+Service+HPA
  per process group, Secrets for env, readiness on `/api/v1/schema/`; pipeline =
  lint → `manage.py check` → migrate-check → `e2e_test.py` → build → push → rollout.

## 11. React workflow builder contract

The builder is a separate front-end (ReactFlow). Backend contract is ready and
tested: `GET /api/v1/workflows/{id}/graph/` returns
`{nodes:[{id,type,label,policy,approvers}], edges:[{source,target}]}`, and the
builder `POST`s the same `steps[]` shape back to create/patch the workflow.
