from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView
from rest_framework.routers import DefaultRouter

from apps.approvals.views import (
    ApprovalRequestViewSet, ApprovalTaskViewSet, lifecycle_console,
)
from apps.approvals.automation.views import (
    ActionRunViewSet, ActionTypeListView, AutomationActionViewSet,
)
from apps.dynamic_forms.dashboard import DashboardMetricsView
from apps.dynamic_forms.public_views import (PublicFormView, form_builder, form_submissions_view, public_submission_view, public_approval_view)
from apps.approvals.integrations.views import TeamsApprovalCallback, ExternalApprovalCreate
from apps.dynamic_forms.views import FormDefinitionViewSet, SubmissionViewSet
from apps.approvals.views import WorkflowDefinitionViewSet

router = DefaultRouter()
router.register("workflows", WorkflowDefinitionViewSet, basename="workflow")
router.register("forms", FormDefinitionViewSet, basename="form")
router.register("submissions", SubmissionViewSet, basename="submission")
router.register("approval-requests", ApprovalRequestViewSet, basename="approval-request")
router.register("approval-tasks", ApprovalTaskViewSet, basename="approval-task")
router.register("automation-actions", AutomationActionViewSet, basename="automation-action")
router.register("action-runs", ActionRunViewSet, basename="action-run")

api_v1 = [
    path("", include(router.urls)),
    path("action-types/", ActionTypeListView.as_view(), name="action-types"),
    path("dashboard/metrics/", DashboardMetricsView.as_view(), name="dashboard-metrics"),
    path("schema/", SpectacularAPIView.as_view(), name="schema"),
    path("docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger"),
]

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/", include((api_v1, "api"), namespace="v1")),
    path("api-auth/", include("rest_framework.urls")),
    # Public, no-login customer form
    path("forms/<str:token>/", PublicFormView.as_view(), name="public-form"),
    # Approval Lifecycle console (separate from the form builder app)
    path("approvals/console/", lifecycle_console, name="approval-console"),
    path("forms-builder/", form_builder, name="form-builder"),
    path("api/v1/teams/callback/", TeamsApprovalCallback.as_view(), name="teams-callback"),
    path("api/v1/external/approvals/", ExternalApprovalCreate.as_view(), name="external-approval-create"),
    path("form-submissions/", form_submissions_view, name="form-submissions"),
    path("forms/submission/<uuid:sub_uuid>/", public_submission_view, name="public-submission"),
    path("forms/approve/<str:token>/", public_approval_view, name="public-approval"),
]
