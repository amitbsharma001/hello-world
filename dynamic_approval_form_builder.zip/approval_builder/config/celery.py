import os

from celery import Celery
from celery.schedules import crontab

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")

app = Celery("approval_builder")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()

app.conf.beat_schedule = {
    "sla-escalations": {
        "task": "apps.approvals.notifications.tasks.check_sla_escalations",
        "schedule": crontab(minute="*/15"),
    },
    "expire-forms": {
        "task": "apps.approvals.notifications.tasks.expire_public_forms",
        "schedule": crontab(minute=0, hour="*"),
    },
}
