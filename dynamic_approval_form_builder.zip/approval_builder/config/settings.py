"""
Production-oriented settings. Uses Postgres + Redis + Celery when env vars are
set; falls back to sqlite so the app can be checked/migrated locally without
infra. Secrets always come from the environment.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-insecure-change-me")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"
ALLOWED_HOSTS = os.environ.get("DJANGO_ALLOWED_HOSTS", "*").split(",")

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # third-party
    "rest_framework",
    "django_filters",
    "drf_spectacular",
    # local apps — just two: a reusable approvals engine + the form builder
    "apps.approvals",
    "apps.dynamic_forms",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "apps.approvals.audit.AuditContextMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"
ASGI_APPLICATION = "config.asgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

if os.environ.get("POSTGRES_DB"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ["POSTGRES_DB"],
            "USER": os.environ.get("POSTGRES_USER", "postgres"),
            "PASSWORD": os.environ.get("POSTGRES_PASSWORD", ""),
            "HOST": os.environ.get("POSTGRES_HOST", "db"),
            "PORT": os.environ.get("POSTGRES_PORT", "5432"),
            "CONN_MAX_AGE": 60,
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --- DRF ---------------------------------------------------------------------
REST_FRAMEWORK = {
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
    "DEFAULT_FILTER_BACKENDS": [
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ],
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": 25,
    "DEFAULT_AUTHENTICATION_CLASSES": [
        "rest_framework.authentication.SessionAuthentication",
    ],
    "DEFAULT_PERMISSION_CLASSES": ["rest_framework.permissions.IsAuthenticated"],
    "DEFAULT_THROTTLE_CLASSES": [
        "rest_framework.throttling.AnonRateThrottle",
        "rest_framework.throttling.UserRateThrottle",
    ],
    "DEFAULT_THROTTLE_RATES": {"anon": "60/min", "user": "1000/min"},
}

SPECTACULAR_SETTINGS = {
    "TITLE": "Dynamic Approval Form Builder API",
    "VERSION": "1.0.0",
    "SERVE_INCLUDE_SCHEMA": False,
}

# --- Celery / Redis ----------------------------------------------------------
CELERY_BROKER_URL = os.environ.get("CELERY_BROKER_URL", "redis://redis:6379/0")
CELERY_RESULT_BACKEND = os.environ.get("CELERY_RESULT_BACKEND", "redis://redis:6379/1")
CELERY_TASK_ALWAYS_EAGER = os.environ.get("CELERY_EAGER", "0") == "1"

# --- Notifications -----------------------------------------------------------
NOTIFICATION_CHANNELS = os.environ.get("NOTIFICATION_CHANNELS", "inapp,email").split(",")
NOTIFICATIONS_USE_CELERY = os.environ.get("NOTIFICATIONS_USE_CELERY", "0") == "1"  # async email needs a running Celery worker
DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "noreply@example.com")

# Email: set EMAIL_HOST in the environment and SMTP is used automatically.
# Without it, mail prints to the console (safe default for dev).
EMAIL_HOST = os.environ.get("EMAIL_HOST", "")
if EMAIL_HOST:
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_PORT = int(os.environ.get("EMAIL_PORT", "587"))
    EMAIL_HOST_USER = os.environ.get("EMAIL_HOST_USER", "")
    EMAIL_HOST_PASSWORD = os.environ.get("EMAIL_HOST_PASSWORD", "")
    EMAIL_USE_TLS = os.environ.get("EMAIL_USE_TLS", "1") == "1"
    EMAIL_USE_SSL = os.environ.get("EMAIL_USE_SSL", "0") == "1"
else:
    EMAIL_BACKEND = os.environ.get(
        "EMAIL_BACKEND", "django.core.mail.backends.console.EmailBackend"
    )

# --- Security hardening (active when DEBUG is off) ---------------------------
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    X_FRAME_OPTIONS = "DENY"

# Secure file uploads
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
DATA_UPLOAD_MAX_MEMORY_SIZE = 10 * 1024 * 1024


# --- Security hardening (auto-on in production, i.e. when DJANGO_DEBUG=0) -----
CSRF_TRUSTED_ORIGINS = [
    o for o in os.environ.get("DJANGO_CSRF_TRUSTED_ORIGINS", "").split(",") if o
]
if not DEBUG:
    SECURE_SSL_REDIRECT = os.environ.get("DJANGO_SSL_REDIRECT", "1") == "1"
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = int(os.environ.get("DJANGO_HSTS_SECONDS", "31536000"))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    X_FRAME_OPTIONS = "DENY"


# --- Microsoft Teams Approvals (optional, via Graph API) ----------------------
# Enable per-workflow with route_to_teams=True; this block holds the credentials.
TEAMS_APPROVAL = {
    "ENABLED": os.environ.get("TEAMS_APPROVAL_ENABLED", "0") == "1",
    "TENANT_ID": os.environ.get("AZURE_TENANT_ID", ""),
    "CLIENT_ID": os.environ.get("AZURE_CLIENT_ID", ""),
    "CLIENT_SECRET": os.environ.get("AZURE_CLIENT_SECRET", ""),
    # Where to create the approval. Default = Graph beta approvals endpoint;
    # set to a Power Automate "When an HTTP request is received" trigger URL to
    # drive the Teams Approvals app via a Flow instead.
    "CREATE_URL": os.environ.get(
        "TEAMS_APPROVAL_CREATE_URL",
        "https://graph.microsoft.com/beta/solutions/approval/approvalItems",
    ),
    # Shared secret the inbound callback must present (header X-Approval-Secret).
    "CALLBACK_SECRET": os.environ.get("TEAMS_APPROVAL_CALLBACK_SECRET", ""),
    # Public base used to build the deep link back into this app.
    "APP_BASE_URL": os.environ.get("APP_BASE_URL", ""),
}


# --- External REST approval integration (in-app + email approval; no Teams needed) ---
EXTERNAL_APPROVAL = {
    # Shared secret the inbound POST /api/v1/external/approvals/ must present
    # (header X-Approval-Secret). Independent of Teams.
    "INBOUND_SECRET": os.environ.get(
        "EXTERNAL_APPROVAL_SECRET",
        # fall back to the Teams secret so existing setups keep working
        os.environ.get("TEAMS_APPROVAL_CALLBACK_SECRET", ""),
    ),
}


# --- Logging: surface approvals + integration logs on the console -------------
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {"format": "{asctime} {levelname} {name}: {message}", "style": "{"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "verbose"},
    },
    "root": {"handlers": ["console"], "level": "WARNING"},
    "loggers": {
        # set APPROVALS_LOG_LEVEL=DEBUG for more detail
        "approvals": {
            "handlers": ["console"],
            "level": os.environ.get("APPROVALS_LOG_LEVEL", "INFO"),
            "propagate": False,
        },
        "django.request": {"handlers": ["console"], "level": "ERROR", "propagate": False},
    },
}


# Public base URL used to build absolute, clickable links in emails (approve links,
# status links). Set this to the URL users actually reach the app on, e.g.
# http://localhost:8000 for local testing or https://approvals.yourco.com in prod.
# When empty, links fall back to the host of the incoming request (which may be an
# internal/localhost host and unreachable from an email client).
APP_BASE_URL = os.environ.get("APP_BASE_URL", "") or (TEAMS_APPROVAL.get("APP_BASE_URL", ""))
