# Approval-Gated Automation

Attach side-effects to any workflow event. When an `ApprovalRequest` reaches the
event (most commonly **fully approved**), the engine runs every enabled
`AutomationAction` in order and logs an `ActionRun` for each.

```
Approvals complete ──▶ fire_event(ON_APPROVED) ──▶ [action 1] [action 2] ...
                                                       deploy   notify   chain
```

It is **data-driven**: an action is just `action_type` (which handler) + `config`
(a JSON blob). Adding automations is a UI/admin task, not a code change.

## Trigger events

`on_submit` · `on_step_approved` (per step) · `on_approved` · `on_rejected` · `on_cancelled`

## Built-in action types

| type_key | What it does | Key config |
|---|---|---|
| `deploy` | Trigger CI/CD (GitHub Actions, GitLab, Jenkins, generic) | `provider, url, ref, token, inputs` |
| `webhook` | HTTP request to any endpoint | `url, method, headers, body` |
| `trigger_workflow` | Start another approval on the same subject (chaining) | `target_workflow` |
| `celery_task` | Dispatch any named Celery task to your workers | `task_name, args, kwargs` |
| `notify` | In-app / email notification | `user_ids, verb` |
| `log` | Record a message (safe; for testing/dry-runs) | `message` |

Add your own: subclass `ActionHandler`, set `type_key`/`label`/`config_schema`,
implement `execute(config, context)`, decorate with `@register_action`. It then
appears automatically in `GET /api/v1/action-types/` for the no-code UI.

## Context & templating

Config strings are templated with `{placeholder}` (or `{{placeholder}}`) against:
`subject`, `subject_id`, `subject_type`, `data.<field>` (form values),
`request_id`, `workflow`, `state`, `initiated_by`, `now`.

```json
{ "url": "https://api.github.com/repos/acme/app/actions/workflows/deploy.yml/dispatches",
  "inputs": { "release_id": "{subject_id}", "env": "{data.environment}" } }
```

## Wire it up (data migration example — deploy on approval)

```python
def seed(apps, schema_editor):
    WD = apps.get_model("workflow_engine", "WorkflowDefinition")
    AA = apps.get_model("automation", "AutomationAction")
    wf = WD.objects.get(slug="release_approval")
    AA.objects.create(
        workflow=wf, name="Deploy to prod", event="on_approved",
        action_type="deploy", order=1, run_async=True, max_retries=3,
        config={
            "provider": "github_actions",
            "url": "https://api.github.com/repos/acme/app/actions/workflows/deploy.yml/dispatches",
            "ref": "main",
            "token": "{{ env GITHUB_TOKEN }}",          # store the real secret securely
            "inputs": {"release_id": "{subject_id}"},
        },
    )
    AA.objects.create(
        workflow=wf, name="Kick off smoke tests", event="on_approved",
        action_type="trigger_workflow", order=2,
        config={"target_workflow": "post_deploy_validation"},
    )
```

## REST API (no-code UX)

```
GET    /api/v1/action-types/                      # all handlers + form schema
POST   /api/v1/automation-actions/                # create (config validated server-side)
POST   /api/v1/automation-actions/{id}/test/      # dry-run, no ActionRun persisted
GET    /api/v1/action-runs/?request={id}&status=failed   # observability
POST   /api/v1/action-runs/{id}/retry/            # re-run a failed action
```

## Execution semantics

- `run_async=True` → enqueued on Celery **after the DB commit** (never runs against
  a row the transaction later rolls back); retried up to `max_retries`.
- `run_async=False` → runs inline (handy for chaining and tests).
- An action failure is **isolated** — it's recorded on the `ActionRun` and never
  rolls back the approval decision.
