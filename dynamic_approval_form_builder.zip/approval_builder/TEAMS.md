# Microsoft Teams Approvals (optional)

When enabled, each approval task is also sent to **Microsoft Teams** via the Graph
API (or a Power Automate flow). A decision made in **Teams** or in **this app**
syncs to the same task — approve from either side.

```
task assigned ──▶ create approval in Teams (Graph)        in-app Approve/Reject
      │                       │                                    │
      │                  approver acts in Teams                    │
      │                       ▼                                    ▼
      └────────── POST /api/v1/teams/callback/ ──▶ ApprovalService.act (one source of truth)
```

## 1. Turn it on per workflow

```python
Flow.define(
    "invoice_approval",
    steps=[Flow.step("Finance", group="Finance")],
    route_to_teams=True,                 # ← the setting
)
```

Or tick **route_to_teams** on the WorkflowDefinition in the Django admin. Approvers
must have the **email** that matches their Microsoft account.

## 2. Configure credentials (env)

```
TEAMS_APPROVAL_ENABLED=1
AZURE_TENANT_ID=…           AZURE_CLIENT_ID=…           AZURE_CLIENT_SECRET=…
TEAMS_APPROVAL_CALLBACK_SECRET=<long-random-string>
APP_BASE_URL=https://app.company.com
# Where the approval is created. Default = Graph beta approvals endpoint.
# To drive the Teams Approvals app via Power Automate instead, set this to your
# Flow's "When an HTTP request is received" URL:
# TEAMS_APPROVAL_CREATE_URL=https://prod-xx.logic.azure.com/workflows/…
```

Register an Azure AD app (client-credentials), grant the Graph permissions your
chosen path needs, and admin-consent them.

## 3. Wire the callback (Teams → app)

Teams/Power Automate must call back when the user decides:

```
POST https://app.company.com/api/v1/teams/callback/
Header: X-Approval-Secret: <TEAMS_APPROVAL_CALLBACK_SECRET>
Body:   {"taskId": 123, "decision": "approve", "comment": "..."}
        (or {"external_ref": "<teams id>", "decision": "reject"})
```

The endpoint verifies the secret, then runs the decision as the task's assignee.
It's **idempotent** — if the item was already decided in-app, it returns 200.

## How it behaves

- **Outbound** runs on a Celery task after commit, so the request path is never
  blocked. If creation fails it's logged and the in-app approval still works.
- **Either side wins:** in-app and the Teams callback both call
  `ApprovalService.act` on the same `ApprovalTask`; whoever acts first decides it.
- After an **in-app** decision, the app makes a best-effort call to close the Teams
  card (Graph path only; Power Automate flows close themselves).
- The external id is stored on `ApprovalTask.external_ref` for correlation.

## Honest caveats

- This is implemented against the documented Graph/Power-Automate contracts but
  **must be validated in your tenant** — Microsoft's Teams Approvals Graph surface
  is partly beta, and many orgs find the **Power Automate** route (set
  `TEAMS_APPROVAL_CREATE_URL` to a Flow trigger) the most reliable. The connector
  supports both; the callback contract is the same.
- Approvers still must exist as **users** in this app (tasks are assigned to users);
  the Teams card is an additional channel, not a replacement for that.
- Secure the callback: keep `TEAMS_APPROVAL_CALLBACK_SECRET` secret and serve over
  HTTPS. Consider IP-allowlisting your Flow/Graph callers.
