# Production Integration Runbook

Steps to take the approvals engine (`apps.approvals`, plus `apps.dynamic_forms`
if you use the form builder) from a dev checkout to a hardened production
deployment **inside your existing app**. Ordered; do them top to bottom.

> Scope note: integrating into an existing app means the two apps' migrations are
> *additive* — you are not replacing your schema. The "fresh migrations" caveat
> only matters if you had previously deployed an older copy of *this* project.

---

## 0. Prerequisites

- Python 3.11+ and Django 5, already running your app.
- **PostgreSQL** (the engine uses JSON fields, generic FKs, indexes).
- **Redis** (or another Celery broker) reachable from web + workers.
- A **Celery worker** and a **Celery beat** process you can run.
- An **SMTP/SES** account for approver/initiator email.
- HTTPS termination in front of the app.

---

## 1. Add the apps (code)

```python
# settings.py
INSTALLED_APPS = [
    # ... your existing apps + django.contrib.*
    "rest_framework",
    "django_filters",
    "drf_spectacular",
    "apps.approvals",        # required: the engine
    "apps.dynamic_forms",    # optional: only if you use the form builder
]

MIDDLEWARE = [
    # ... keep your existing middleware ...
    "apps.approvals.audit.AuditContextMiddleware",   # records who did what
]
```

Add the dependencies to your requirements: `djangorestframework`,
`django-filter`, `drf-spectacular`, `celery`, `redis`. (Copy from this project's
`requirements.txt`.)

---

## 2. Configuration

### Database (env-driven)

```bash
POSTGRES_DB=approvals
POSTGRES_USER=app
POSTGRES_PASSWORD=•••
POSTGRES_HOST=db
POSTGRES_PORT=5432
```

> If `POSTGRES_DB` is unset the project falls back to SQLite — never do that in
> production.

### Core Django prod settings

```bash
DJANGO_DEBUG=0
DJANGO_SECRET_KEY=•••                     # never the dev default
DJANGO_ALLOWED_HOSTS=app.company.com
```

Add the standard hardening to `settings.py`:

```python
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = 31536000
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")  # if behind a proxy
CSRF_TRUSTED_ORIGINS = ["https://app.company.com"]
```

### Celery / broker (env-driven)

```bash
CELERY_BROKER_URL=redis://redis:6379/0
CELERY_RESULT_BACKEND=redis://redis:6379/1
CELERY_EAGER=0            # MUST be 0 in prod (1 only for local/tests)
```

### Email — **override the console backend**

The shipped default prints email to the log. For real delivery set:

```python
# settings.py
EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"   # or anymail/SES
EMAIL_HOST = os.environ["EMAIL_HOST"]
EMAIL_PORT = int(os.environ.get("EMAIL_PORT", 587))
EMAIL_HOST_USER = os.environ["EMAIL_HOST_USER"]
EMAIL_HOST_PASSWORD = os.environ["EMAIL_HOST_PASSWORD"]
EMAIL_USE_TLS = True
```

```bash
DEFAULT_FROM_EMAIL="Approvals <noreply@company.com>"
NOTIFICATION_CHANNELS=inapp,email      # drop "email" to silence all mail
```

### API auth

The DRF defaults are `SessionAuthentication` + `IsAuthenticated` + throttling. If
your clients are a server-rendered app, that's fine (CSRF applies to unsafe
methods). For a SPA/mobile client, add token or JWT auth:

```python
REST_FRAMEWORK["DEFAULT_AUTHENTICATION_CLASSES"] = [
    "rest_framework.authentication.SessionAuthentication",
    "rest_framework_simplejwt.authentication.JWTAuthentication",  # if you add SimpleJWT
]
```

---

## 3. Migrations

```bash
python manage.py migrate
```

This creates the `approvals_*` (and `dynamic_forms_*`) tables alongside yours.
Do **not** run `makemigrations` against these apps in production — ship the
migrations that come with them.

---

## 4. Celery: worker + beat

Run **both** processes (web alone will not fire tasks):

```bash
# worker — runs on_approved tasks + notification delivery
celery -A config worker -l info

# beat — runs the periodic jobs (SLA escalation every 15m, expire forms hourly)
celery -A config beat -l info
```

The beat schedule is already defined in `config/celery.py`
(`check_sla_escalations`, `expire_public_forms`). Tasks are autodiscovered via
`apps.approvals.tasks`, so no extra wiring.

> **Task naming:** `Flow.run_task("apps.billing.tasks.charge_customer")` dispatches
> **by name**. That task must be importable *in the worker image*, not just the web
> image. Deploy the same code to both.

---

## 5. Identities: approvers must be real users

- Approver tasks are assigned to `User` rows. An approver given by **email** must
  match an existing user (`email__iexact`); otherwise submit returns `400`.
- Provision your reviewers as users (SSO/IdP sync is ideal) and put them in the
  groups your workflows reference.

```bash
python manage.py shell -c "from django.contrib.auth.models import Group; Group.objects.get_or_create(name='Finance')"
```

---

## 6. Define your workflows (idempotent) + register models

**Define** the workflow rows (DB). Do this in a **release-phase step** — a
management command or a data migration — not in `ready()` (which runs before the
DB may be ready):

```python
# yourapp/management/commands/setup_approvals.py
from django.core.management.base import BaseCommand
from apps.approvals.flow import Flow

class Command(BaseCommand):
    def handle(self, *a, **k):
        Flow.define(
            "invoice_approval",
            steps=[
                Flow.step("Manager", approvers=["mgr@company.com"]),
                Flow.step("Finance", group="Finance", policy="all"),
            ],
            on_approved=Flow.run_task("apps.billing.tasks.charge_customer",
                                      args=["{subject_id}"]),
            notify_approvers=True, notify_initiator=True,
        )
```

Run it on every deploy (idempotent): `python manage.py setup_approvals`.
For the form builder, the equivalent ships as `seed_form_approval`.

**Register** approvable models with the engine in `AppConfig.ready()` (in-memory,
safe at startup) so callbacks resolve:

```python
# yourapp/apps.py
def ready(self):
    from apps.approvals.registry import ApprovalEngine
    from .models import Invoice
    ApprovalEngine.register(model=Invoice, workflow="invoice_approval",
                            on_approved="yourapp.hooks.on_invoice_approved")
```

---

## 7. Secrets for automation actions

`webhook` / `deploy` actions store config (URLs, tokens) as JSON. **Do not** put
live secrets in plaintext action config or fixtures. Inject them from env / a
secret manager at action-creation time, or reference a secret alias your handler
resolves. Rotate anything that touched a repo.

---

## 8. The approver UI

Two endpoints are served by the app:

- `/approvals/console/` — the lifecycle console
- `/forms-builder/` — the form builder (if using dynamic_forms)

Out of the box the console renders **sample data** with **unwired** buttons. For
production you must:

1. Replace the `SAMPLE` array with `fetch('/api/v1/approval-requests/{id}/')` and
   `/timeline/` (there's a marked spot in the file).
2. Wire Approve/Reject/Delegate to
   `POST /api/v1/approval-tasks/{id}/approve|reject|delegate/` with auth + CSRF.
3. Gate the page behind your login.

Or skip it and drive everything from your own UI against the API. Run
`python manage.py collectstatic` for the admin, DRF browsable API, and Swagger.

---

## 9. API permissions & the public form

- Default permission is `IsAuthenticated`. Tighten per-viewset so only a task's
  **assignee** (or a delegate) can act on it, and only a form's **creator/staff**
  can read its submission history (already enforced on the submissions endpoint).
- The **public form** (`/forms/<token>/`) is intentionally unauthenticated. In
  production: keep the token secret, serve over HTTPS, add a tighter anon throttle,
  and consider CAPTCHA / per-IP limits. It is reachable only after the form is
  approved & published.

---

## 10. Observability

- **Alert on failed automation:** query `ActionRun` where `status="failed"`
  (it carries `attempts`, `output`, `error`) and surface it — a failed `on_approved`
  task never reverses the approval, so it can go unnoticed otherwise.
- Ship Django + Celery logs to your aggregator; watch the beat process liveness.
- `AuditLog` rows grow over time — plan retention/archival.

---

## 11. CI / tests

Run the suite against a Postgres service in CI before deploy:

```bash
pip install -r requirements.txt
python manage.py check --deploy        # surfaces missing security settings
python -m pytest                       # 57 tests in this project
```

`check --deploy` flags anything you missed in §2 (SECRET_KEY, SSL, DEBUG, etc.).

---

## 12. Deploy sequence (every release)

Run in this order; web stays up, workers restart last:

```bash
1. python manage.py collectstatic --noinput
2. python manage.py migrate --noinput
3. python manage.py setup_approvals          # idempotent workflow definitions
4. restart web (gunicorn/uvicorn)
5. restart celery worker AND celery beat
6. smoke test (below)
```

---

## 13. Production smoke test

```python
from apps.approvals.flow import Flow
inv = Invoice.objects.create(...)
req = Flow.submit(inv, by=some_user)         # approver should receive an email
# approver: POST /api/v1/approval-tasks/<task_id>/approve/
Flow.status(inv)        # -> "approved"
# confirm the ActionRun succeeded and the Celery task ran on the worker
```

Verify: email delivered, status flipped, `ActionRun.status == "success"`, audit
trail present.

---

## 14. Rollback

- Code: redeploy the previous image (migrations here are additive, so the prior
  release runs against the new tables without issue).
- If you must remove the apps, do it in a maintenance window: drain in-flight
  requests first (no half-approved items mid-migration), then reverse-migrate.

---

## Quick checklist

- [ ] Apps + middleware added; deps installed
- [ ] Postgres, Redis, SMTP env vars set; `EMAIL_BACKEND` overridden
- [ ] `DEBUG=0`, real `SECRET_KEY`, `ALLOWED_HOSTS`, SSL settings; `check --deploy` clean
- [ ] `migrate` run; no `makemigrations` on these apps in prod
- [ ] Celery **worker + beat** running; `CELERY_EAGER=0`; tasks in the worker image
- [ ] Reviewers exist as users/groups
- [ ] Workflows defined via a release command; models registered in `ready()`
- [ ] Secrets injected from a vault, not plaintext config
- [ ] Approver UI wired to the API + behind login (or your own UI)
- [ ] Permissions tightened; public form throttled
- [ ] Alerting on failed `ActionRun`; audit retention planned
- [ ] Smoke test passes in prod
