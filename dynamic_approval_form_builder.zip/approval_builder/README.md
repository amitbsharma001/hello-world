# Dynamic Approval Form Builder

A pluggable Django sub-application: build dynamic forms, attach a reusable,
**model-agnostic** approval engine, and share a public no-login URL for customers
to submit data. The approval engine is fully decoupled — any model can register.

## Quickstart (local, sqlite, no infra)

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
# API docs:        http://localhost:8000/api/v1/docs/
# Admin:           http://localhost:8000/admin/
# Public form:     http://localhost:8000/forms/<public_token>/
```

Run the end-to-end engine proof (mixed sequential+parallel workflow):

```bash
python e2e_test.py
```

## Full stack (Postgres + Redis + Celery)

```bash
cp .env.example .env
docker compose up --build
```

## Registering any model for approvals

```python
from apps.approvals.registry import ApprovalEngine

ApprovalEngine.register(
    model=Vendor,
    workflow="vendor_onboarding",
    on_approved="myapp.hooks.activate_vendor",
)

req = ApprovalEngine.start(instance=my_vendor, initiated_by=request.user)
```

## Status — implemented vs scaffolded

**Implemented & test-verified**
- Decoupled workflow engine (sequential / parallel / mixed via step policies)
- ApprovalEngine registry + GenericForeignKey subject binding
- State machine: submit, approve, reject, request-changes, delegate, escalate, cancel
- Dynamic forms + EAV submission storage + server-side validation
- Public token/UUID/expiry shareable form (responsive Tailwind template)
- Dual trail: ApprovalActionLog (domain) + AuditLog (generic, IP/UA captured)
- Pluggable notifications (in-app / email / webhook / Slack / Teams) via Celery
- DRF API (CRUD, filtering, search, ordering, pagination) + Swagger/OpenAPI
- Dashboard metrics endpoint, Celery SLA-escalation + form-expiry beats
- Docker + docker-compose

**Scaffolded / designed (see DESIGN.md)** — not in this drop:
- React/ReactFlow visual builder (the `/workflows/{id}/graph/` JSON contract is
  ready and tested; the front-end consumes it)
- Django Channels live updates
- Kubernetes manifests, CI/CD pipeline, multi-tenant row partitioning
- Exhaustive pytest suite (one end-to-end proof is included as `e2e_test.py`)
