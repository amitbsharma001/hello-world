# Flow — plug-and-play approvals for any sub-app

One import, two calls: **define** a workflow, then **submit** any object. Approver
emails and on-approval automation are handled for you.

```python
from apps.workflow_engine.flow import Flow
```

## 1. Define a workflow (idempotent — call it on startup or in a migration)

```python
Flow.define(
    "invoice_approval",
    name="Invoice Approval",
    steps=[
        Flow.step("Manager",  approvers=["mgr@acme.com"]),          # by email
        Flow.step("Finance",  group="Finance", policy="all"),       # whole group must approve
        Flow.step("Director", approvers=["director"]),              # by username
    ],
    on_approved=Flow.run_task("apps.invoices.tasks.post_to_ledger", # ← your Celery task
                              args=["{subject_id}"]),
    notify_approvers=True,    # email each approver when it's their turn (default)
    notify_initiator=True,    # email the submitter on the final decision (default)
    register_model=Invoice,   # optional: enables Invoice().submit_for_approval()
)
```

Approvers accept `User` objects, usernames, or emails. `policy` is `any` / `all` /
`quorum` (with `quorum=N`). A step with more than one approver is automatically
parallel.

## 2. Submit anything — one line

```python
req = Flow.submit(invoice, by=request.user)     # returns the ApprovalRequest
Flow.status(invoice)                            # 'under_review' | 'approved' | 'rejected' | None
Flow.latest(invoice)                            # the ApprovalRequest (audit trail, current step…)
```

## Or make the model itself approvable

```python
from apps.workflow_engine.mixins import ApprovableMixin

class Invoice(ApprovableMixin, models.Model):
    approval_workflow = "invoice_approval"      # the Flow slug
    ...

invoice.submit_for_approval(by=user)
invoice.approval_status     # 'under_review'
invoice.is_approved         # True / False
```

`FormSubmission` in `dynamic_forms` already uses this mixin, so every public form
submission gets `.approval_status` and `.is_approved` for free.

## On-approval automation (the easy part)

`on_approved` (and `on_step`, `on_rejected`) accept one builder or a list:

```python
on_approved=[
    Flow.run_task("apps.deploy.tasks.rollout", args=["{subject_id}"]),
    Flow.trigger("post_deploy_validation"),     # chain another workflow
    Flow.webhook("https://hooks.acme.io/done"),
    Flow.notify([42, 43], verb="invoice_approved"),
]
```

`Flow.run_task` is the headline: it dispatches a named Celery task to your workers
(honors eager mode locally), with retries and a logged `ActionRun`. Config strings
are templated — `{subject_id}`, `{data.<field>}`, `{request_id}`, `{state}`, etc.

## Approvers act through the existing API (no new endpoints per app)

```
POST /api/v1/approval-tasks/{id}/approve/
POST /api/v1/approval-tasks/{id}/reject/
POST /api/v1/approval-tasks/{id}/delegate/   {"to_user": 42}
```

## What you get for free

- Approver + initiator emails, toggleable per workflow.
- Sequential / parallel / quorum routing, delegation, SLA escalation.
- On-approval Celery task / webhook / deploy / workflow-chaining, async with retries.
- Full audit trail + per-run automation logs.
- Zero coupling: your model needs no FK and no base class (the mixin is optional).
