"""
End-to-end proof: build a MIXED workflow (Manager -> [Compliance + Security] ->
Director), register a FormSubmission, run it through the decoupled engine, and
assert it reaches APPROVED with a correct audit trail.

Run with: python e2e_test.py
"""
import os

import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
os.environ["CELERY_EAGER"] = "1"
django.setup()

from django.contrib.auth import get_user_model  # noqa: E402

from apps.approvals.models import ApprovalRequest  # noqa: E402
from apps.approvals.services import ApprovalService  # noqa: E402
from apps.approvals.states import ApprovalState  # noqa: E402
from apps.dynamic_forms.models import (  # noqa: E402
    FieldType, FormDefinition, FormField,
)
from apps.dynamic_forms.services import SubmissionService  # noqa: E402
from apps.approvals.models import (  # noqa: E402
    ApprovalPolicy, ApproverKind, StepApprover, StepType,
    WorkflowDefinition, WorkflowStep,
)

User = get_user_model()


def reset():
    from apps.dynamic_forms.models import FormSubmission
    FormSubmission.objects.all().delete()
    for m in (ApprovalRequest, FormDefinition, WorkflowDefinition):
        m.objects.all().delete()
    User.objects.all().delete()


def main():
    reset()
    mgr = User.objects.create_user("manager")
    comp = User.objects.create_user("compliance")
    sec = User.objects.create_user("security")
    director = User.objects.create_user("director")
    creator = User.objects.create_user("creator")

    # --- MIXED workflow ------------------------------------------------------
    wf = WorkflowDefinition.objects.create(name="Customer Form Approval",
                                           slug="customer_form_approval")
    s1 = WorkflowStep.objects.create(workflow=wf, order=1, name="Manager",
                                     step_type=StepType.SEQUENTIAL, policy=ApprovalPolicy.ANY)
    StepApprover.objects.create(step=s1, kind=ApproverKind.USER, user=mgr)

    s2 = WorkflowStep.objects.create(workflow=wf, order=2, name="Compliance + Security",
                                     step_type=StepType.PARALLEL, policy=ApprovalPolicy.ALL)
    StepApprover.objects.create(step=s2, kind=ApproverKind.USER, user=comp)
    StepApprover.objects.create(step=s2, kind=ApproverKind.USER, user=sec)

    s3 = WorkflowStep.objects.create(workflow=wf, order=3, name="Director",
                                     step_type=StepType.SEQUENTIAL, policy=ApprovalPolicy.ANY)
    StepApprover.objects.create(step=s3, kind=ApproverKind.USER, user=director)
    wf.sync_graph()

    # --- A form bound to that workflow --------------------------------------
    form = FormDefinition.objects.create(name="Vendor Onboarding", workflow=wf,
                                         created_by=creator)
    FormField.objects.create(form=form, label="Customer Name", name="customer_name",
                             field_type=FieldType.TEXT, required=True)
    FormField.objects.create(form=form, label="GST Number", name="gst_number",
                             field_type=FieldType.TEXT, required=True)

    # --- Public submission triggers the engine ------------------------------
    submission = SubmissionService.save(
        form=form,
        data={"customer_name": "Acme Corp", "gst_number": "29ABCDE1234F1Z5"},
        meta={"ip": "1.2.3.4", "user_agent": "pytest", "device": "desktop"},
    )
    req = ApprovalRequest.objects.get(pk=submission.approval_request_id)
    assert req.state == ApprovalState.UNDER_REVIEW, req.state
    assert req.current_step == s1, "should start at Manager"

    def task_for(user):
        return req.tasks.get(step=req.current_step, assignee=user, status="pending")

    # Manager approves -> advances to parallel step
    ApprovalService.act(task_id=task_for(mgr).id, actor=mgr, action="approve")
    req.refresh_from_db()
    assert req.current_step == s2, "should advance to parallel step"

    # Only Compliance approves -> step NOT satisfied (policy=ALL)
    ApprovalService.act(task_id=task_for(comp).id, actor=comp, action="approve")
    req.refresh_from_db()
    assert req.current_step == s2, "parallel ALL must wait for Security"

    # Security approves -> advances to Director
    ApprovalService.act(task_id=task_for(sec).id, actor=sec, action="approve")
    req.refresh_from_db()
    assert req.current_step == s3, "should advance to Director"

    # Director approves -> APPROVED
    ApprovalService.act(task_id=task_for(director).id, actor=director, action="approve")
    req.refresh_from_db()
    submission.refresh_from_db()
    assert req.state == ApprovalState.APPROVED, req.state
    assert submission.status == "approved", "host callback must flip submission status"

    actions = req.actions.count()
    print("PASS: mixed workflow reached APPROVED")
    print(f"  audit actions logged: {actions}")
    print(f"  submission status   : {submission.status}")
    print(f"  graph nodes         : {len(wf.as_graph()['nodes'])}")

    # --- Rejection path ------------------------------------------------------
    sub2 = SubmissionService.save(
        form=form, data={"customer_name": "BadCo", "gst_number": "X"},
        meta={"ip": "9.9.9.9"},
    )
    r2 = ApprovalRequest.objects.get(pk=sub2.approval_request_id)
    mtask = r2.tasks.get(step=r2.current_step, assignee=mgr)
    ApprovalService.act(task_id=mtask.id, actor=mgr, action="reject", comment="No.")
    r2.refresh_from_db()
    sub2.refresh_from_db()
    assert r2.state == ApprovalState.REJECTED
    assert sub2.status == "rejected"
    print("PASS: rejection path -> REJECTED + submission rejected")


if __name__ == "__main__":
    main()
