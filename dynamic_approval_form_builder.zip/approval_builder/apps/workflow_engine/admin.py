from django.contrib import admin

from .models import StepApprover, WorkflowDefinition, WorkflowStep


class StepApproverInline(admin.TabularInline):
    model = StepApprover
    extra = 1


class WorkflowStepInline(admin.TabularInline):
    model = WorkflowStep
    extra = 1


@admin.register(WorkflowDefinition)
class WorkflowDefinitionAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "version", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "slug")
    inlines = [WorkflowStepInline]


@admin.register(WorkflowStep)
class WorkflowStepAdmin(admin.ModelAdmin):
    list_display = ("workflow", "order", "name", "step_type", "policy")
    inlines = [StepApproverInline]
