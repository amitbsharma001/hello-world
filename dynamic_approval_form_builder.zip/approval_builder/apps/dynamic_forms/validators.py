"""Server-side validation derived from each field's type + validation_rules.
Never trust client validation: every submission is re-validated here."""
import re
from datetime import datetime

from .models import FieldType


class FieldValidationError(Exception):
    def __init__(self, errors: dict):
        self.errors = errors
        super().__init__(str(errors))


def validate_submission(form, data: dict) -> dict:
    """Return cleaned {field_name: value}; raise FieldValidationError on failure."""
    errors, cleaned = {}, {}
    for field in form.fields.all():
        raw = data.get(field.name)
        is_empty = raw in (None, "", []) 
        if field.required and is_empty:
            errors[field.name] = "This field is required."
            continue
        if is_empty:
            cleaned[field.name] = field.default_value or ""
            continue
        try:
            cleaned[field.name] = _coerce(field, raw)
        except ValueError as exc:
            errors[field.name] = str(exc)
    if errors:
        raise FieldValidationError(errors)
    return cleaned


def _coerce(field, raw):
    rules = field.validation_rules or {}
    if field.field_type == FieldType.NUMBER:
        try:
            num = float(raw)
        except (TypeError, ValueError):
            raise ValueError("Must be a number.")
        if "min" in rules and num < rules["min"]:
            raise ValueError(f"Must be >= {rules['min']}.")
        if "max" in rules and num > rules["max"]:
            raise ValueError(f"Must be <= {rules['max']}.")
        return str(raw)
    if field.field_type == FieldType.EMAIL:
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", str(raw)):
            raise ValueError("Invalid email address.")
    if field.field_type == FieldType.DATE:
        try:
            datetime.strptime(str(raw), "%Y-%m-%d")
        except ValueError:
            raise ValueError("Use YYYY-MM-DD.")
    if field.field_type in (FieldType.DROPDOWN, FieldType.RADIO):
        allowed = {o.get("value", o) if isinstance(o, dict) else o for o in field.options}
        if allowed and str(raw) not in {str(a) for a in allowed}:
            raise ValueError("Not an allowed option.")
    if field.field_type == FieldType.MULTISELECT:
        values = raw if isinstance(raw, list) else [raw]
        allowed = {o.get("value", o) if isinstance(o, dict) else o for o in field.options}
        if allowed and any(str(v) not in {str(a) for a in allowed} for v in values):
            raise ValueError("Contains a value not in options.")
        return ",".join(str(v) for v in values)
    if "regex" in rules and not re.match(rules["regex"], str(raw)):
        raise ValueError(rules.get("regex_message", "Invalid format."))
    if "max_length" in rules and len(str(raw)) > rules["max_length"]:
        raise ValueError(f"Max length is {rules['max_length']}.")
    return str(raw)
