"""Admin dashboard metrics: counts, SLA, average approval time."""
from datetime import timedelta

from django.db.models import Avg, Count, F
from django.utils import timezone
from rest_framework.permissions import IsAdminUser
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.approvals.models import ApprovalRequest
from apps.approvals.states import ApprovalState
from apps.dynamic_forms.models import FormDefinition, FormSubmission


class DashboardMetricsView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        reqs = ApprovalRequest.objects.all()
        decided = reqs.filter(decided_at__isnull=False, submitted_at__isnull=False)
        avg_seconds = decided.aggregate(
            avg=Avg(F("decided_at") - F("submitted_at"))
        )["avg"]
        recent = FormSubmission.objects.order_by("-created_at")[:10]
        return Response(
            {
                "total_forms": FormDefinition.objects.count(),
                "active_forms": FormDefinition.objects.filter(is_active=True).count(),
                "pending_approvals": reqs.filter(
                    state__in=[ApprovalState.PENDING, ApprovalState.UNDER_REVIEW]
                ).count(),
                "approved": reqs.filter(state=ApprovalState.APPROVED).count(),
                "rejected": reqs.filter(state=ApprovalState.REJECTED).count(),
                "total_submissions": FormSubmission.objects.count(),
                "avg_approval_seconds": avg_seconds.total_seconds()
                if isinstance(avg_seconds, timedelta) else None,
                "recent_submissions": [
                    {
                        "uuid": str(s.submission_uuid),
                        "form": s.form_id,
                        "status": s.status,
                        "at": s.created_at,
                    }
                    for s in recent
                ],
            }
        )
