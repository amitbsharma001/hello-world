"""Host-app callbacks fired by the approval engine on terminal states."""
from django.utils import timezone

from .models import SubmissionStatus


# ---- per-submission approval (optional) ----
def on_submission_approved(submission):
    submission.status = SubmissionStatus.APPROVED
    submission.save(update_fields=["status"])


def on_submission_rejected(submission):
    submission.status = SubmissionStatus.REJECTED
    submission.save(update_fields=["status"])


# ---- form PUBLICATION approval ----
def on_form_published(form):
    """Approved -> the form becomes shareable with customers."""
    form.published = True
    form.published_at = timezone.now()
    form.save(update_fields=["published", "published_at"])


def on_form_rejected(form):
    """Rejected -> keep it unpublished (not shareable)."""
    form.published = False
    form.save(update_fields=["published"])
