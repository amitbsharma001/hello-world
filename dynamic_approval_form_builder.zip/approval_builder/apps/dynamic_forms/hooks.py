"""Host-app callbacks fired by the approval engine on terminal states."""
from .models import SubmissionStatus


def on_submission_approved(submission):
    submission.status = SubmissionStatus.APPROVED
    submission.save(update_fields=["status"])


def on_submission_rejected(submission):
    submission.status = SubmissionStatus.REJECTED
    submission.save(update_fields=["status"])
