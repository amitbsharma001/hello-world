"""Define the workflow a form must pass before it can be shared.

    python manage.py seed_form_approval --group "Form Reviewers"
"""
from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand

from apps.approvals.flow import Flow


class Command(BaseCommand):
    help = "Create/refresh the 'form_publication_approval' workflow."

    def add_arguments(self, parser):
        parser.add_argument("--group", default="Form Reviewers",
                            help="Approver group name (created if missing).")

    def handle(self, *args, **opts):
        group_name = opts["group"]
        Group.objects.get_or_create(name=group_name)
        Flow.define(
            "form_publication_approval",
            name="Form Publication Approval",
            steps=[Flow.step("Review", group=group_name, policy="any")],
            notify_approvers=True,
            notify_initiator=True,
        )
        self.stdout.write(self.style.SUCCESS(
            f"Defined 'form_publication_approval' (reviewers: {group_name})."
        ))
