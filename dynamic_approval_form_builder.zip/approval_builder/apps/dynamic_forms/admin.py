from django.contrib import admin

from .models import FormDefinition, FormField, FormSubmission, SubmissionValue


class FormFieldInline(admin.TabularInline):
    model = FormField
    extra = 1


@admin.register(FormDefinition)
class FormDefinitionAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "version", "is_active", "public_token")
    list_filter = ("is_active", "category")
    search_fields = ("name",)
    inlines = [FormFieldInline]
    readonly_fields = ("public_uuid", "public_token")


class SubmissionValueInline(admin.TabularInline):
    model = SubmissionValue
    extra = 0


@admin.register(FormSubmission)
class FormSubmissionAdmin(admin.ModelAdmin):
    list_display = ("submission_uuid", "form", "status", "customer_ip", "created_at")
    list_filter = ("status", "form")
    inlines = [SubmissionValueInline]
