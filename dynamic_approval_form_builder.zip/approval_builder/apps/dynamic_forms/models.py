"""
Dynamic form definitions + EAV submission storage.

FormDefinition owns ordered FormFields. A FormSubmission snapshots the form
version and stores answers as SubmissionValue rows (Entity-Attribute-Value), so
new fields never require a schema migration. Public sharing is via an
unguessable token + UUID + slug, with optional expiry.
"""
import secrets
import uuid

from django.conf import settings
from django.db import models
from django.utils.text import slugify

from apps.approvals.mixins import ApprovableMixin
from apps.approvals.models import TimeStamped, WorkflowDefinition


class FieldType(models.TextChoices):
    TEXT = "text", "Text"
    TEXTAREA = "textarea", "Textarea"
    NUMBER = "number", "Number"
    EMAIL = "email", "Email"
    DATE = "date", "Date"
    DROPDOWN = "dropdown", "Dropdown"
    MULTISELECT = "multiselect", "Multi Select"
    CHECKBOX = "checkbox", "Checkbox"
    RADIO = "radio", "Radio"
    FILE = "file", "File Upload"


def _gen_token():
    return secrets.token_urlsafe(24)


class FormDefinition(ApprovableMixin, TimeStamped):
    # The form must be APPROVED through this workflow before it can be shared.
    approval_workflow = "form_publication_approval"

    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=120, blank=True)
    version = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)
    # Publication gate — flipped on by the approval engine's on_approved hook.
    published = models.BooleanField(default=False)
    allow_submitter_approver = models.BooleanField(
        default=False,
        help_text="Let the public submitter name an approver; rejection lets them correct & resubmit.",
    )
    approver_domains = models.JSONField(
        default=list, blank=True,
        help_text="If set, submitter-chosen approver emails must use one of these domains (e.g. ['acme.com']).",
    )
    submission_rate_limit = models.PositiveIntegerField(
        default=0,
        help_text="Max public submissions per IP per hour (0 = unlimited).",
    )
    published_at = models.DateTimeField(null=True, blank=True)

    slug = models.SlugField(max_length=220, blank=True)
    public_uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    public_token = models.CharField(max_length=64, default=_gen_token, unique=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    workflow = models.ForeignKey(
        WorkflowDefinition, null=True, blank=True, on_delete=models.SET_NULL,
        help_text="Optional: per-submission approval workflow.",
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL,
        related_name="created_forms",
    )

    class Meta:
        indexes = [
            models.Index(fields=["public_token"]),
            models.Index(fields=["is_active", "category"]),
        ]

    def __str__(self):
        return f"{self.name} v{self.version}"

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    @property
    def public_path(self):
        return f"/forms/{self.public_token}/"

    def is_open(self):
        """Shareable only after publication approval, while active and unexpired."""
        from django.utils import timezone

        if not (self.is_active and self.published):
            return False
        return self.expires_at is None or self.expires_at > timezone.now()


class FormField(TimeStamped):
    form = models.ForeignKey(
        FormDefinition, related_name="fields", on_delete=models.CASCADE
    )
    label = models.CharField(max_length=200, help_text="Business friendly name")
    name = models.CharField(max_length=120, help_text="External parameter name")
    field_type = models.CharField(max_length=20, choices=FieldType.choices)
    required = models.BooleanField(default=False)
    default_value = models.CharField(max_length=500, blank=True)
    validation_rules = models.JSONField(default=dict, blank=True)
    placeholder = models.CharField(max_length=200, blank=True)
    help_text = models.CharField(max_length=300, blank=True)
    options = models.JSONField(default=list, blank=True)  # for select/radio/multiselect
    display_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["display_order"]
        unique_together = ("form", "name")

    def __str__(self):
        return f"{self.form.slug}:{self.name}"


class ApproverKind(models.TextChoices):
    USER = "user", "User"
    GROUP = "group", "Group"
    EMAIL = "email", "Email"


class FormApprover(TimeStamped):
    """An approver authored inline on the form (just like a field).

    Approvers sharing a `step` are parallel (all must approve); steps run in
    order. On submit-for-approval these rows are compiled into a per-form
    publication workflow.
    """
    form = models.ForeignKey(
        FormDefinition, related_name="approvers", on_delete=models.CASCADE
    )
    kind = models.CharField(
        max_length=10, choices=ApproverKind.choices, default=ApproverKind.EMAIL
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.CASCADE, related_name="+",
    )
    group = models.ForeignKey(
        "auth.Group", null=True, blank=True, on_delete=models.CASCADE, related_name="+"
    )
    email = models.EmailField(blank=True)
    label = models.CharField(max_length=200, blank=True)
    step = models.PositiveIntegerField(
        default=1, help_text="Same step = parallel; steps run in order."
    )
    display_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["step", "display_order"]

    def __str__(self):
        who = self.email or (self.user_id and self.user.get_username()) or \
            (self.group_id and self.group.name) or "?"
        return f"{self.form.slug}:step{self.step}:{who}"


class SubmissionStatus(models.TextChoices):
    DRAFT = "draft", "Draft"
    SUBMITTED = "submitted", "Submitted"
    IN_APPROVAL = "in_approval", "In Approval"
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"


class FormSubmission(ApprovableMixin, TimeStamped):
    form = models.ForeignKey(
        FormDefinition, related_name="submissions", on_delete=models.PROTECT
    )
    form_version = models.PositiveIntegerField()
    submission_uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    customer_ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    device = models.CharField(max_length=120, blank=True)
    location = models.CharField(max_length=200, blank=True)
    submitted_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL,
        related_name="form_submissions",
    )

    status = models.CharField(
        max_length=20, choices=SubmissionStatus.choices, default=SubmissionStatus.DRAFT
    )
    approval_request_id = models.BigIntegerField(null=True, blank=True)
    approver_email = models.EmailField(blank=True, default="")
    approver_emails = models.JSONField(default=list, blank=True)
    rejection_reason = models.TextField(blank=True, default="")

    class Meta:
        indexes = [
            models.Index(fields=["form", "status"]),
            models.Index(fields=["submission_uuid"]),
        ]

    def __str__(self):
        return f"Submission {self.submission_uuid} [{self.status}]"

    def as_dict(self):
        return {v.field.name: v.value for v in self.values.select_related("field")}


class SubmissionValue(models.Model):
    """EAV value row — one per answered field."""

    submission = models.ForeignKey(
        FormSubmission, related_name="values", on_delete=models.CASCADE
    )
    field = models.ForeignKey(FormField, on_delete=models.PROTECT)
    value = models.TextField(blank=True)
    file = models.FileField(upload_to="submissions/%Y/%m/", null=True, blank=True)

    class Meta:
        unique_together = ("submission", "field")
        indexes = [models.Index(fields=["field", "value"])]

    def __str__(self):
        return f"{self.field.name}={self.value[:40]}"
