"""
Dynamic form definitions + EAV submission storage.

FormDefinition owns ordered FormFields. A FormSubmission snapshots the form
version and stores answers as SubmissionValue rows (Entity-Attribute-Value), so
new fields never require a schema migration. Public sharing is via an
unguessable token + UUID + slug, with optional expiry.
"""
import secrets
import uuid

from django.conf import settings
from django.db import models
from django.utils.text import slugify

from apps.workflow_engine.mixins import ApprovableMixin
from apps.workflow_engine.models import TimeStamped, WorkflowDefinition


class FieldType(models.TextChoices):
    TEXT = "text", "Text"
    TEXTAREA = "textarea", "Textarea"
    NUMBER = "number", "Number"
    EMAIL = "email", "Email"
    DATE = "date", "Date"
    DROPDOWN = "dropdown", "Dropdown"
    MULTISELECT = "multiselect", "Multi Select"
    CHECKBOX = "checkbox", "Checkbox"
    RADIO = "radio", "Radio"
    FILE = "file", "File Upload"


def _gen_token():
    return secrets.token_urlsafe(24)


class FormDefinition(TimeStamped):
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=120, blank=True)
    version = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)

    slug = models.SlugField(max_length=220, blank=True)
    public_uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    public_token = models.CharField(max_length=64, default=_gen_token, unique=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    workflow = models.ForeignKey(
        WorkflowDefinition, null=True, blank=True, on_delete=models.SET_NULL
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL
    )

    class Meta:
        indexes = [
            models.Index(fields=["public_token"]),
            models.Index(fields=["is_active", "category"]),
        ]

    def __str__(self):
        return f"{self.name} v{self.version}"

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    @property
    def public_path(self):
        return f"/forms/{self.public_token}/"

    def is_open(self):
        from django.utils import timezone

        if not self.is_active:
            return False
        return self.expires_at is None or self.expires_at > timezone.now()


class FormField(TimeStamped):
    form = models.ForeignKey(
        FormDefinition, related_name="fields", on_delete=models.CASCADE
    )
    label = models.CharField(max_length=200, help_text="Business friendly name")
    name = models.CharField(max_length=120, help_text="External parameter name")
    field_type = models.CharField(max_length=20, choices=FieldType.choices)
    required = models.BooleanField(default=False)
    default_value = models.CharField(max_length=500, blank=True)
    validation_rules = models.JSONField(default=dict, blank=True)
    placeholder = models.CharField(max_length=200, blank=True)
    help_text = models.CharField(max_length=300, blank=True)
    options = models.JSONField(default=list, blank=True)  # for select/radio/multiselect
    display_order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["display_order"]
        unique_together = ("form", "name")

    def __str__(self):
        return f"{self.form.slug}:{self.name}"


class SubmissionStatus(models.TextChoices):
    DRAFT = "draft", "Draft"
    SUBMITTED = "submitted", "Submitted"
    IN_APPROVAL = "in_approval", "In Approval"
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"


class FormSubmission(ApprovableMixin, TimeStamped):
    form = models.ForeignKey(
        FormDefinition, related_name="submissions", on_delete=models.PROTECT
    )
    form_version = models.PositiveIntegerField()
    submission_uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

    customer_ip = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    device = models.CharField(max_length=120, blank=True)
    location = models.CharField(max_length=200, blank=True)

    status = models.CharField(
        max_length=20, choices=SubmissionStatus.choices, default=SubmissionStatus.DRAFT
    )
    approval_request_id = models.BigIntegerField(null=True, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["form", "status"]),
            models.Index(fields=["submission_uuid"]),
        ]

    def __str__(self):
        return f"Submission {self.submission_uuid} [{self.status}]"

    def as_dict(self):
        return {v.field.name: v.value for v in self.values.select_related("field")}


class SubmissionValue(models.Model):
    """EAV value row — one per answered field."""

    submission = models.ForeignKey(
        FormSubmission, related_name="values", on_delete=models.CASCADE
    )
    field = models.ForeignKey(FormField, on_delete=models.PROTECT)
    value = models.TextField(blank=True)
    file = models.FileField(upload_to="submissions/%Y/%m/", null=True, blank=True)

    class Meta:
        unique_together = ("submission", "field")
        indexes = [models.Index(fields=["field", "value"])]

    def __str__(self):
        return f"{self.field.name}={self.value[:40]}"
