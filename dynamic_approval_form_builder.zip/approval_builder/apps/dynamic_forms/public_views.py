"""Public, no-login customer form endpoints, secured by an unguessable token and
optional expiry. Server-side validation always runs regardless of client JS."""
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from .models import FormDefinition
from .services import SubmissionService
from .validators import FieldValidationError


def _client_meta(request):
    xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
    ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")
    ua = request.META.get("HTTP_USER_AGENT", "")
    device = "mobile" if "Mobi" in ua else "desktop"
    meta = {"ip": ip, "user_agent": ua, "device": device}
    if getattr(request, "user", None) and request.user.is_authenticated:
        meta["user"] = request.user            # records who submitted, when logged in
    return meta


@method_decorator(ensure_csrf_cookie, name="dispatch")
class PublicFormView(View):
    """GET renders the dynamic form; POST submits or saves a draft."""

    def get(self, request, token):
        form = get_object_or_404(FormDefinition, public_token=token)
        if not form.is_open():
            return render(request, "public/closed.html", {"form": form}, status=410)
        return render(request, "public/form.html", {"form": form})

    def post(self, request, token):
        form = get_object_or_404(FormDefinition, public_token=token)
        if not form.is_open():
            return JsonResponse({"detail": "Form is closed."}, status=410)
        # Per-IP hourly rate limit (0 = unlimited) — guards against approver-email spam.
        if form.submission_rate_limit:
            from django.core.cache import cache
            xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
            ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR", "")
            key = f"subrate:{form.pk}:{ip}"
            count = cache.get(key, 0)
            if count >= form.submission_rate_limit:
                return JsonResponse(
                    {"detail": "Too many submissions from your network. Try again later."},
                    status=429,
                )
            cache.set(key, count + 1, 3600)
        as_draft = request.POST.get("_action") == "draft"
        meta = _client_meta(request)
        # accept multiple <input name="approver_email"> and/or a comma-separated field
        meta["approver_emails"] = (request.POST.getlist("approver_email")
                                   + [request.POST.get("approver_emails", "")])
        meta["base_url"] = request.build_absolute_uri("/").rstrip("/")
        try:
            submission = SubmissionService.save(
                form=form,
                data=request.POST.dict(),
                files=request.FILES,
                meta=meta,
                as_draft=as_draft,
            )
        except FieldValidationError as exc:
            return JsonResponse({"errors": exc.errors}, status=400)
        status_url = request.build_absolute_uri(
            f"/forms/submission/{submission.submission_uuid}/"
        )
        return JsonResponse(
            {
                "status": submission.status,
                "submission_uuid": str(submission.submission_uuid),
                "status_url": status_url,    # submitter can return here to track / correct
            },
            status=201,
        )


def form_builder(request):
    """Serve the form-builder UI (fields + approvers). Wired to the API; rendered
    with @ensure_csrf_cookie so the JS can POST with CSRF."""
    from django.shortcuts import render
    from django.views.decorators.csrf import ensure_csrf_cookie

    return ensure_csrf_cookie(lambda r: render(r, "dynamic_forms/builder.html"))(request)


def form_submissions_view(request):
    """Serve the printable 'all submissions' screen. Reads the API client-side;
    the submissions endpoint enforces creator/admin access (403 otherwise)."""
    from django.shortcuts import render
    from django.views.decorators.csrf import ensure_csrf_cookie

    return ensure_csrf_cookie(lambda r: render(r, "dynamic_forms/submissions.html"))(request)


def public_submission_view(request, sub_uuid):
    """Submitter's status page (by submission UUID). If the approver rejected,
    show the rejection reason and an editable form to correct & restart approval."""
    from django.shortcuts import get_object_or_404, redirect, render

    from .models import FormSubmission, SubmissionStatus
    from .services import resubmit_submission

    sub = get_object_or_404(FormSubmission, submission_uuid=sub_uuid)
    fields = list(sub.form.fields.all())

    if request.method == "POST" and sub.status == SubmissionStatus.REJECTED:
        data = {f.name: request.POST.get(f.name, "") for f in fields}
        approvers = (request.POST.getlist("approver_email")
                     + [request.POST.get("approver_emails", "")]) or sub.approver_emails
        base = request.build_absolute_uri("/").rstrip("/")
        try:
            resubmit_submission(sub, data, approver_emails=approvers, base_url=base)
        except Exception as exc:
            msg = " ".join(str(v) for v in exc.errors.values()) if hasattr(exc, "errors") else str(exc)
            return render(request, "dynamic_forms/submission_status.html", {
                "sub": sub, "fields": fields,
                "values": {f.name: request.POST.get(f.name, "") for f in fields},
                "error": msg,
            })
        return redirect(request.path + "?resubmitted=1")

    values = {v.field.name: v.value for v in sub.values.select_related("field").all()}
    return render(request, "dynamic_forms/submission_status.html", {
        "sub": sub, "fields": fields, "values": values,
        "resubmitted": request.GET.get("resubmitted") == "1",
    })


def public_approval_view(request, token):
    """Tokenised approve/reject page (no login). Works for a public form submission
    (salt 'pub-approval') or an external/iFlow approval (salt 'ext-approval')."""
    from django.core import signing
    from django.shortcuts import render

    from apps.approvals.models import ApprovalRequest
    from apps.approvals.services import ApprovalService
    from apps.approvals.states import TaskStatus

    from .models import FormSubmission

    req = None
    subject_label = ""
    max_age = 60 * 60 * 24 * 30
    try:
        sub_id = signing.loads(token, salt="pub-approval", max_age=max_age)
        sub = FormSubmission.objects.filter(pk=sub_id).first()
        if sub:
            req = ApprovalRequest.objects.filter(pk=sub.approval_request_id).first()
            subject_label = f"{sub.form.name} — submission #{sub.id}"
    except signing.BadSignature:
        pass
    if req is None:
        try:
            ext_id = signing.loads(token, salt="ext-approval", max_age=max_age)
            from apps.approvals.models import ExternalApproval
            ext = ExternalApproval.objects.filter(pk=ext_id).first()
            if ext:
                req = (ApprovalRequest.objects
                       .filter(content_type__model="externalapproval", object_id=ext.pk)
                       .order_by("-created_at").first())
                subject_label = ext.title or ext.name or f"Approval #{ext.pk}"
        except signing.BadSignature:
            pass
    if req is None:
        return render(request, "dynamic_forms/approve.html", {"invalid": True}, status=400)

    description, details = ApprovalService._detail_payload(req)
    task = None
    if req.current_step_id:
        task = req.tasks.filter(step=req.current_step, status=TaskStatus.PENDING).first()

    done = None
    if request.method == "POST" and task:
        action = request.POST.get("action")
        if action in ("approve", "reject"):
            ApprovalService.act(task_id=task.pk, actor=task.assignee, action=action,
                                comment=request.POST.get("comment", ""))
            done = action

    return render(request, "dynamic_forms/approve.html", {
        "subject_label": subject_label, "description": description, "details": details,
        "task": task, "done": done,
    })


def public_task_approval_view(request, token):
    """Per-approver, login-free approve/reject for a SINGLE task. Anyone with the
    emailed link can act on that task (acts as the assigned approver)."""
    from django.core import signing
    from django.shortcuts import render

    from apps.approvals.models import ApprovalTask
    from apps.approvals.services import ApprovalService
    from apps.approvals.states import TaskStatus

    try:
        task_id = signing.loads(token, salt="task-approval", max_age=60 * 60 * 24 * 30)
    except signing.BadSignature:
        return render(request, "dynamic_forms/approve.html", {"invalid": True}, status=400)

    task = ApprovalTask.objects.filter(pk=task_id).select_related(
        "request", "assignee", "step").first()
    if task is None:
        return render(request, "dynamic_forms/approve.html", {"invalid": True}, status=400)

    req = task.request
    subject = req.subject

    # External approvals may require login + bar the creator from approving (SoD).
    from apps.approvals.models import ExternalApproval
    if isinstance(subject, ExternalApproval) and subject.login_required:
        if not request.user.is_authenticated:
            from django.contrib.auth.views import redirect_to_login
            return redirect_to_login(request.get_full_path())
        creator = (subject.creator_email or "").strip().lower()
        user_email = (getattr(request.user, "email", "") or "").strip().lower()
        if creator and user_email == creator:
            return render(request, "dynamic_forms/approve.html",
                          {"forbidden_creator": True,
                           "subject_label": subject.title or subject.name}, status=403)

    description, details = ApprovalService._detail_payload(req)
    subject_label = f"{req.subject} — {task.step.name}" if req.subject is not None else task.step.name
    pending = task.status == TaskStatus.PENDING

    done = None
    if request.method == "POST" and pending:
        action = request.POST.get("action")
        if action in ("approve", "reject"):
            ApprovalService.act(task_id=task.pk, actor=task.assignee, action=action,
                                comment=request.POST.get("comment", ""))
            done = action

    return render(request, "dynamic_forms/approve.html", {
        "subject_label": subject_label, "description": description, "details": details,
        "task": task if pending else None, "done": done,
    })
