"""Public, no-login customer form endpoints, secured by an unguessable token and
optional expiry. Server-side validation always runs regardless of client JS."""
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from .models import FormDefinition
from .services import SubmissionService
from .validators import FieldValidationError


def _client_meta(request):
    xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
    ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")
    ua = request.META.get("HTTP_USER_AGENT", "")
    device = "mobile" if "Mobi" in ua else "desktop"
    return {"ip": ip, "user_agent": ua, "device": device}


@method_decorator(ensure_csrf_cookie, name="dispatch")
class PublicFormView(View):
    """GET renders the dynamic form; POST submits or saves a draft."""

    def get(self, request, token):
        form = get_object_or_404(FormDefinition, public_token=token)
        if not form.is_open():
            return render(request, "public/closed.html", {"form": form}, status=410)
        return render(request, "public/form.html", {"form": form})

    def post(self, request, token):
        form = get_object_or_404(FormDefinition, public_token=token)
        if not form.is_open():
            return JsonResponse({"detail": "Form is closed."}, status=410)
        as_draft = request.POST.get("_action") == "draft"
        try:
            submission = SubmissionService.save(
                form=form,
                data=request.POST.dict(),
                files=request.FILES,
                meta=_client_meta(request),
                as_draft=as_draft,
            )
        except FieldValidationError as exc:
            return JsonResponse({"errors": exc.errors}, status=400)
        return JsonResponse(
            {
                "status": submission.status,
                "submission_uuid": str(submission.submission_uuid),
            },
            status=201,
        )


def form_builder(request):
    """Serve the form-builder UI (fields + approvers). Reads/writes via the API."""
    from pathlib import Path

    from django.http import HttpResponse

    page = Path(__file__).resolve().parent / "templates" / "dynamic_forms" / "builder.html"
    return HttpResponse(page.read_text(encoding="utf-8"), content_type="text/html")
