from rest_framework import mixins, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import FormApprover, FormDefinition, FormField, FormSubmission


class FormFieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormField
        fields = [
            "id", "label", "name", "field_type", "required", "default_value",
            "validation_rules", "placeholder", "help_text", "options", "display_order",
        ]


class FormApproverSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormApprover
        fields = ["id", "kind", "user", "group", "email", "label", "step", "display_order"]


class FormDefinitionSerializer(serializers.ModelSerializer):
    fields = FormFieldSerializer(many=True, required=False)
    approvers = FormApproverSerializer(many=True, required=False)
    public_path = serializers.CharField(read_only=True)
    approval_status = serializers.SerializerMethodField()
    is_shareable = serializers.SerializerMethodField()

    class Meta:
        model = FormDefinition
        fields = [
            "id", "name", "description", "category", "version", "is_active",
            "published", "published_at", "approval_status", "is_shareable",
            "slug", "public_uuid", "public_token", "public_path", "expires_at",
            "workflow", "fields", "approvers", "created_by", "created_at", "updated_at",
        ]
        read_only_fields = [
            "slug", "public_uuid", "public_token", "published", "published_at",
            "created_by",
        ]

    def get_approval_status(self, obj) -> str:
        return obj.approval_status  # None | under_review | approved | rejected ...

    def get_is_shareable(self, obj) -> bool:
        return obj.is_open()

    def create(self, validated_data):
        fields = validated_data.pop("fields", [])
        approvers = validated_data.pop("approvers", [])
        request = self.context.get("request")
        if request and request.user.is_authenticated:
            validated_data["created_by"] = request.user
        form = FormDefinition.objects.create(**validated_data)
        self._write_fields(form, fields)
        self._write_approvers(form, approvers)
        return form

    def update(self, instance, validated_data):
        fields = validated_data.pop("fields", None)
        approvers = validated_data.pop("approvers", None)
        for k, v in validated_data.items():
            setattr(instance, k, v)
        instance.save()
        if fields is not None:
            instance.fields.all().delete()
            self._write_fields(instance, fields)
        if approvers is not None:
            instance.approvers.all().delete()
            self._write_approvers(instance, approvers)
        return instance

    @staticmethod
    def _write_fields(form, fields):
        for i, fd in enumerate(fields):
            fd.setdefault("display_order", i)
            FormField.objects.create(form=form, **fd)

    @staticmethod
    def _write_approvers(form, approvers):
        for i, ad in enumerate(approvers):
            ad.setdefault("display_order", i)
            FormApprover.objects.create(form=form, **ad)


class SubmissionSerializer(serializers.ModelSerializer):
    values = serializers.SerializerMethodField()
    submitted_by = serializers.SerializerMethodField()

    class Meta:
        model = FormSubmission
        fields = [
            "id", "submission_uuid", "form", "form_version", "status",
            "submitted_by", "customer_ip", "device", "location",
            "approval_request_id", "values", "created_at",
        ]

    def get_values(self, obj) -> dict:
        return obj.as_dict()

    def get_submitted_by(self, obj) -> str:
        if obj.submitted_by_id:
            return obj.submitted_by.get_username()
        data = obj.as_dict()
        return data.get("email") or data.get("customer_email") or "anonymous"


class FormDefinitionViewSet(viewsets.ModelViewSet):
    queryset = FormDefinition.objects.prefetch_related("fields")
    serializer_class = FormDefinitionSerializer
    filterset_fields = ["is_active", "category", "workflow"]
    search_fields = ["name", "description", "category"]
    ordering_fields = ["created_at", "name"]

    @action(detail=True, methods=["post"], url_path="submit-for-approval")
    def submit_for_approval(self, request, pk=None):
        """Compile the form's inline approvers into a workflow and start it.
        Once approved, the on_approved hook publishes the form."""
        from .services import build_publication_workflow

        form = self.get_object()
        slug, unresolved = build_publication_workflow(form)
        if unresolved:
            return Response(
                {"detail": "No user account for these approver emails: "
                           + ", ".join(unresolved)},
                status=400,
            )
        if not slug:
            return Response(
                {"detail": "Add at least one approver before submitting."}, status=400
            )
        by = request.user if request.user.is_authenticated else None
        req = form.submit_for_approval(by=by, workflow=slug)
        return Response(
            {"approval_status": form.approval_status,
             "request_id": req.pk, "workflow": slug},
            status=201,
        )

    @action(detail=True, methods=["get"])
    def submissions(self, request, pk=None):
        """History of who submitted what — visible to the form's creator and staff."""
        form = self.get_object()
        user = request.user
        allowed = user.is_authenticated and (
            user.is_staff or (form.created_by_id and form.created_by_id == user.id)
        )
        if not allowed:
            return Response(
                {"detail": "Only the form's creator or an admin can view submissions."},
                status=403,
            )
        subs = form.submissions.prefetch_related("values__field").order_by("-created_at")
        return Response(SubmissionSerializer(subs, many=True).data)

    @action(detail=True, methods=["post"])
    def reorder(self, request, pk=None):
        """Persist drag-and-drop ordering: body = {"order": [field_id, ...]}."""
        form = self.get_object()
        order = request.data.get("order", [])
        for position, field_id in enumerate(order):
            form.fields.filter(pk=field_id).update(display_order=position)
        return Response({"status": "reordered", "count": len(order)})

    @action(detail=True, methods=["post"])
    def clone_field(self, request, pk=None):
        form = self.get_object()
        src = form.fields.filter(pk=request.data.get("field_id")).first()
        if not src:
            return Response({"detail": "field not found"}, status=404)
        src.pk = None
        src.name = f"{src.name}_copy"
        src.label = f"{src.label} (copy)"
        src.display_order = form.fields.count()
        src.save()
        return Response(FormFieldSerializer(src).data, status=201)


class SubmissionViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = FormSubmission.objects.prefetch_related("values__field")
    serializer_class = SubmissionSerializer
    filterset_fields = ["form", "status"]
    ordering_fields = ["created_at"]
