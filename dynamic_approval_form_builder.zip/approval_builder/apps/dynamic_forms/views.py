from rest_framework import mixins, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import FormDefinition, FormField, FormSubmission


class FormFieldSerializer(serializers.ModelSerializer):
    class Meta:
        model = FormField
        fields = [
            "id", "label", "name", "field_type", "required", "default_value",
            "validation_rules", "placeholder", "help_text", "options", "display_order",
        ]


class FormDefinitionSerializer(serializers.ModelSerializer):
    fields = FormFieldSerializer(many=True, required=False)
    public_path = serializers.CharField(read_only=True)

    class Meta:
        model = FormDefinition
        fields = [
            "id", "name", "description", "category", "version", "is_active",
            "slug", "public_uuid", "public_token", "public_path", "expires_at",
            "workflow", "fields", "created_at", "updated_at",
        ]
        read_only_fields = ["slug", "public_uuid", "public_token"]

    def create(self, validated_data):
        fields = validated_data.pop("fields", [])
        request = self.context.get("request")
        if request and request.user.is_authenticated:
            validated_data["created_by"] = request.user
        form = FormDefinition.objects.create(**validated_data)
        self._write_fields(form, fields)
        return form

    def update(self, instance, validated_data):
        fields = validated_data.pop("fields", None)
        for k, v in validated_data.items():
            setattr(instance, k, v)
        instance.save()
        if fields is not None:
            instance.fields.all().delete()
            self._write_fields(instance, fields)
        return instance

    @staticmethod
    def _write_fields(form, fields):
        for i, fd in enumerate(fields):
            fd.setdefault("display_order", i)
            FormField.objects.create(form=form, **fd)


class SubmissionSerializer(serializers.ModelSerializer):
    values = serializers.SerializerMethodField()

    class Meta:
        model = FormSubmission
        fields = [
            "id", "submission_uuid", "form", "form_version", "status",
            "customer_ip", "device", "location", "approval_request_id",
            "values", "created_at",
        ]

    def get_values(self, obj):
        return obj.as_dict()


class FormDefinitionViewSet(viewsets.ModelViewSet):
    queryset = FormDefinition.objects.prefetch_related("fields")
    serializer_class = FormDefinitionSerializer
    filterset_fields = ["is_active", "category", "workflow"]
    search_fields = ["name", "description", "category"]
    ordering_fields = ["created_at", "name"]

    @action(detail=True, methods=["post"])
    def reorder(self, request, pk=None):
        """Persist drag-and-drop ordering: body = {"order": [field_id, ...]}."""
        form = self.get_object()
        order = request.data.get("order", [])
        for position, field_id in enumerate(order):
            form.fields.filter(pk=field_id).update(display_order=position)
        return Response({"status": "reordered", "count": len(order)})

    @action(detail=True, methods=["post"])
    def clone_field(self, request, pk=None):
        form = self.get_object()
        src = form.fields.filter(pk=request.data.get("field_id")).first()
        if not src:
            return Response({"detail": "field not found"}, status=404)
        src.pk = None
        src.name = f"{src.name}_copy"
        src.label = f"{src.label} (copy)"
        src.display_order = form.fields.count()
        src.save()
        return Response(FormFieldSerializer(src).data, status=201)


class SubmissionViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = FormSubmission.objects.prefetch_related("values__field")
    serializer_class = SubmissionSerializer
    filterset_fields = ["form", "status"]
    ordering_fields = ["created_at"]
