"""Service layer for capturing public submissions and wiring them into the
decoupled approval engine."""
from django.db import transaction

from apps.approvals.registry import ApprovalEngine

from .models import FormSubmission, SubmissionStatus, SubmissionValue
from .validators import validate_submission


class SubmissionService:
    @classmethod
    @transaction.atomic
    def save(cls, *, form, data, files=None, meta=None, as_draft=False):
        files = files or {}
        meta = meta or {}
        cleaned = {} if as_draft else validate_submission(form, data)

        submission = FormSubmission.objects.create(
            form=form,
            form_version=form.version,
            customer_ip=meta.get("ip"),
            user_agent=meta.get("user_agent", ""),
            device=meta.get("device", ""),
            location=meta.get("location", ""),
            submitted_by=meta.get("user") if meta.get("user") else None,
            status=SubmissionStatus.DRAFT if as_draft else SubmissionStatus.SUBMITTED,
        )
        values = cleaned if not as_draft else data
        for field in form.fields.all():
            if field.name in values or field.name in files:
                SubmissionValue.objects.create(
                    submission=submission,
                    field=field,
                    value=str(values.get(field.name, "")),
                    file=files.get(field.name),
                )
        approver_emails = meta.get("approver_emails") or meta.get("approver_email") or ""
        if not as_draft and form.allow_submitter_approver and approver_emails:
            # submitter named approver(s) -> per-submission approval they can restart
            start_submission_approval(submission, approver_emails,
                                      base_url=meta.get("base_url", ""))
        elif not as_draft and form.workflow_id:
            request = ApprovalEngine.start(
                instance=submission,
                initiated_by=getattr(form, "created_by", None),
                workflow=form.workflow.slug,
            )
            submission.approval_request_id = request.pk
            submission.status = SubmissionStatus.IN_APPROVAL
            submission.save(update_fields=["approval_request_id", "status"])
        return submission


def build_publication_workflow(form):
    """Compile a form's inline approvers into a per-form publication workflow.

    Returns (slug, unresolved_emails). slug is None if no approvers are set.
    Approvers sharing a `step` become a parallel step (all must approve);
    steps run in order.
    """
    from django.contrib.auth import get_user_model

    from apps.approvals.flow import Flow

    from .models import ApproverKind

    User = get_user_model()
    rows = list(form.approvers.all())          # ordered by step, display_order
    if not rows:
        return None, []

    by_step, unresolved = {}, []
    for ap in rows:
        target = None
        if ap.kind == ApproverKind.USER and ap.user_id:
            target = ap.user
        elif ap.kind == ApproverKind.GROUP and ap.group_id:
            target = ("group", ap.group.name)
        elif ap.email:
            user = User.objects.filter(email__iexact=ap.email).first()
            if user:
                target = user
            else:
                unresolved.append(ap.email)
        if target is not None:
            by_step.setdefault(ap.step, []).append(target)

    if unresolved:
        return None, unresolved

    steps = []
    for step_no in sorted(by_step):
        targets = by_step[step_no]
        users = [t for t in targets if not isinstance(t, tuple)]
        groups = [t[1] for t in targets if isinstance(t, tuple)]
        count = len(users) + len(groups)
        steps.append(Flow.step(
            f"Approval {step_no}", approvers=users, groups=groups,
            policy="all" if count > 1 else "any",
        ))

    slug = f"form_pub_{form.pk}"
    Flow.define(slug, name=f"{form.name} — publication", steps=steps,
                notify_approvers=True, notify_initiator=True)
    return slug, []


def _resolve_approver(email):
    """Find the user with this email, or provision a login-disabled placeholder so
    a task can be assigned and the approver emailed. Gated by the form opting in."""
    from django.contrib.auth import get_user_model
    User = get_user_model()
    user = User.objects.filter(email__iexact=email).first()
    if user:
        return user
    username = email[:150]
    user, created = User.objects.get_or_create(
        username=username, defaults={"email": email, "is_active": False}
    )
    if created:
        user.set_unusable_password()
        user.save(update_fields=["password"])
    return user


def _normalize_emails(value):
    """Accept a list or a comma/semicolon/newline string -> clean, de-duped list."""
    if isinstance(value, (list, tuple)):
        raw = []
        for v in value:
            raw.extend(str(v).replace(";", ",").replace("\n", ",").split(","))
    else:
        raw = str(value or "").replace(";", ",").replace("\n", ",").split(",")
    out, seen = [], set()
    for e in (x.strip() for x in raw):
        key = e.lower()
        if e and key not in seen:
            seen.add(key)
            out.append(e)
    return out


def start_submission_approval(submission, approver_emails, *, policy="all", base_url=""):
    """Build a per-submission workflow routed to one or more submitter-chosen
    approvers and start it. With several approvers, `policy` ('all'|'any'|'quorum')
    decides how the single step clears. Returns the ApprovalRequest."""
    from django.core import signing

    from apps.approvals.flow import Flow
    from apps.approvals.registry import ApprovalEngine

    from .models import SubmissionStatus

    emails = _normalize_emails(approver_emails)
    if not emails:
        raise ValueError("At least one approver email is required.")

    allowed = submission.form.approver_domains or []
    if allowed:
        norm = {d.lower().lstrip("@") for d in allowed}
        bad = [e for e in emails if e.rsplit("@", 1)[-1].lower() not in norm]
        if bad:
            from .validators import FieldValidationError
            raise FieldValidationError({
                "approver_email": "Approver(s) not in an allowed domain: " + ", ".join(bad)
            })

    approvers = [_resolve_approver(e) for e in emails]

    import uuid
    slug = f"submission_{submission.pk}_{uuid.uuid4().hex[:8]}"
    step_policy = policy if len(approvers) > 1 else "any"
    Flow.define(
        slug, name=f"{submission.form.name} — submission #{submission.pk}",
        steps=[Flow.step("Approver", approvers=approvers, policy=step_policy)],
        notify_approvers=True, notify_initiator=False,
    )
    action_url = ""
    if base_url:
        token = signing.dumps(submission.pk, salt="pub-approval")
        action_url = f"{base_url}/forms/approve/{token}/"
    req = ApprovalEngine.start(
        instance=submission, initiated_by=None, workflow=slug,
        context={
            "description": f"New submission to “{submission.form.name}”. Review and approve or reject.",
            "details": submission.as_dict(),
            "action_url": action_url,
        },
    )
    submission.approval_request_id = req.pk
    submission.approver_emails = emails
    submission.approver_email = emails[0]
    submission.rejection_reason = ""
    submission.status = SubmissionStatus.IN_APPROVAL
    submission.save(update_fields=["approval_request_id", "approver_emails",
                                   "approver_email", "rejection_reason", "status"])
    return req


def resubmit_submission(submission, data, *, approver_emails=None, files=None, base_url=""):
    """Submitter corrects a REJECTED submission and restarts approval. The approver
    list can be edited; defaults to the one used before."""
    from .models import SubmissionStatus, SubmissionValue
    from .validators import validate_submission

    if submission.status != SubmissionStatus.REJECTED:
        raise ValueError("Only a rejected submission can be corrected and resubmitted.")
    files = files or {}
    cleaned = validate_submission(submission.form, data)
    submission.values.all().delete()
    for field in submission.form.fields.all():
        if field.name in cleaned or field.name in files:
            SubmissionValue.objects.create(
                submission=submission, field=field,
                value=str(cleaned.get(field.name, "")), file=files.get(field.name),
            )
    emails = approver_emails or submission.approver_emails or submission.approver_email
    return start_submission_approval(submission, emails, base_url=base_url)
