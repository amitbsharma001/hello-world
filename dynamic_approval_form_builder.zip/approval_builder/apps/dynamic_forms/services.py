"""Service layer for capturing public submissions and wiring them into the
decoupled approval engine."""
from django.db import transaction

from apps.workflow_engine.registry import ApprovalEngine

from .models import FormSubmission, SubmissionStatus, SubmissionValue
from .validators import validate_submission


class SubmissionService:
    @classmethod
    @transaction.atomic
    def save(cls, *, form, data, files=None, meta=None, as_draft=False):
        files = files or {}
        meta = meta or {}
        cleaned = {} if as_draft else validate_submission(form, data)

        submission = FormSubmission.objects.create(
            form=form,
            form_version=form.version,
            customer_ip=meta.get("ip"),
            user_agent=meta.get("user_agent", ""),
            device=meta.get("device", ""),
            location=meta.get("location", ""),
            status=SubmissionStatus.DRAFT if as_draft else SubmissionStatus.SUBMITTED,
        )
        values = cleaned if not as_draft else data
        for field in form.fields.all():
            if field.name in values or field.name in files:
                SubmissionValue.objects.create(
                    submission=submission,
                    field=field,
                    value=str(values.get(field.name, "")),
                    file=files.get(field.name),
                )
        if not as_draft and form.workflow_id:
            request = ApprovalEngine.start(
                instance=submission,
                initiated_by=getattr(form, "created_by", None),
                workflow=form.workflow.slug,
            )
            submission.approval_request_id = request.pk
            submission.status = SubmissionStatus.IN_APPROVAL
            submission.save(update_fields=["approval_request_id", "status"])
        return submission
