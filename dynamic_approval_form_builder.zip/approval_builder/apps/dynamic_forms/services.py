"""Service layer for capturing public submissions and wiring them into the
decoupled approval engine."""
from django.db import transaction

from apps.approvals.registry import ApprovalEngine

from .models import FormSubmission, SubmissionStatus, SubmissionValue
from .validators import validate_submission


class SubmissionService:
    @classmethod
    @transaction.atomic
    def save(cls, *, form, data, files=None, meta=None, as_draft=False):
        files = files or {}
        meta = meta or {}
        cleaned = {} if as_draft else validate_submission(form, data)

        submission = FormSubmission.objects.create(
            form=form,
            form_version=form.version,
            customer_ip=meta.get("ip"),
            user_agent=meta.get("user_agent", ""),
            device=meta.get("device", ""),
            location=meta.get("location", ""),
            submitted_by=meta.get("user") if meta.get("user") else None,
            status=SubmissionStatus.DRAFT if as_draft else SubmissionStatus.SUBMITTED,
        )
        values = cleaned if not as_draft else data
        for field in form.fields.all():
            if field.name in values or field.name in files:
                SubmissionValue.objects.create(
                    submission=submission,
                    field=field,
                    value=str(values.get(field.name, "")),
                    file=files.get(field.name),
                )
        if not as_draft and form.workflow_id:
            request = ApprovalEngine.start(
                instance=submission,
                initiated_by=getattr(form, "created_by", None),
                workflow=form.workflow.slug,
            )
            submission.approval_request_id = request.pk
            submission.status = SubmissionStatus.IN_APPROVAL
            submission.save(update_fields=["approval_request_id", "status"])
        return submission


def build_publication_workflow(form):
    """Compile a form's inline approvers into a per-form publication workflow.

    Returns (slug, unresolved_emails). slug is None if no approvers are set.
    Approvers sharing a `step` become a parallel step (all must approve);
    steps run in order.
    """
    from django.contrib.auth import get_user_model

    from apps.approvals.flow import Flow

    from .models import ApproverKind

    User = get_user_model()
    rows = list(form.approvers.all())          # ordered by step, display_order
    if not rows:
        return None, []

    by_step, unresolved = {}, []
    for ap in rows:
        target = None
        if ap.kind == ApproverKind.USER and ap.user_id:
            target = ap.user
        elif ap.kind == ApproverKind.GROUP and ap.group_id:
            target = ("group", ap.group.name)
        elif ap.email:
            user = User.objects.filter(email__iexact=ap.email).first()
            if user:
                target = user
            else:
                unresolved.append(ap.email)
        if target is not None:
            by_step.setdefault(ap.step, []).append(target)

    if unresolved:
        return None, unresolved

    steps = []
    for step_no in sorted(by_step):
        targets = by_step[step_no]
        users = [t for t in targets if not isinstance(t, tuple)]
        groups = [t[1] for t in targets if isinstance(t, tuple)]
        count = len(users) + len(groups)
        steps.append(Flow.step(
            f"Approval {step_no}", approvers=users, groups=groups,
            policy="all" if count > 1 else "any",
        ))

    slug = f"form_pub_{form.pk}"
    Flow.define(slug, name=f"{form.name} — publication", steps=steps,
                notify_approvers=True, notify_initiator=True)
    return slug, []
