from django.apps import AppConfig


class DynamicFormsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.dynamic_forms"
    label = "dynamic_forms"
    verbose_name = "Dynamic Forms"

    def ready(self):
        from apps.approvals.registry import ApprovalEngine

        from .models import FormDefinition, FormSubmission

        # A created form must be approved before it can be shared with customers.
        ApprovalEngine.register(
            model=FormDefinition,
            workflow="form_publication_approval",
            on_approved="apps.dynamic_forms.hooks.on_form_published",
            on_rejected="apps.dynamic_forms.hooks.on_form_rejected",
        )
        # Optional: per-submission approval (kept for apps that want it).
        ApprovalEngine.register(
            model=FormSubmission,
            workflow="customer_form_approval",
            on_approved="apps.dynamic_forms.hooks.on_submission_approved",
            on_rejected="apps.dynamic_forms.hooks.on_submission_rejected",
        )
