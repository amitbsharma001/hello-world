from django.apps import AppConfig


class DynamicFormsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.dynamic_forms"
    label = "dynamic_forms"
    verbose_name = "Dynamic Forms"

    def ready(self):
        # Demonstrates the decoupled registry: any model can opt into approvals.
        from apps.workflow_engine.registry import ApprovalEngine

        from .models import FormSubmission

        ApprovalEngine.register(
            model=FormSubmission,
            workflow="customer_form_approval",
            on_approved="apps.dynamic_forms.hooks.on_submission_approved",
            on_rejected="apps.dynamic_forms.hooks.on_submission_rejected",
        )
