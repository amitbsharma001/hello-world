from django.contrib import admin

from .models import AuditLog


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("created_at", "action", "actor", "from_state", "to_state", "ip_address")
    list_filter = ("action",)
    search_fields = ("comment",)
    readonly_fields = [f.name for f in AuditLog._meta.fields]
