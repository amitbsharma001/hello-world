"""
Pluggable resolvers for DYNAMIC approvers.

Any host app can register a callable that, given the subject instance and the
ApprovalRequest, returns a list of User objects. This is how "dynamic approvers"
(e.g. the line manager of the submitter, the account owner of a vendor) are
supported without hard-coding people into the workflow definition.
"""
from typing import Callable, Dict, List

from django.contrib.auth import get_user_model

User = get_user_model()

RESOLVERS: Dict[str, Callable] = {}


def register_resolver(key: str):
    def _wrap(fn: Callable):
        RESOLVERS[key] = fn
        return fn

    return _wrap


def resolve(key: str, *, subject, request) -> List:
    fn = RESOLVERS.get(key)
    if fn is None:
        return []
    users = fn(subject=subject, request=request) or []
    return [u for u in users if isinstance(u, User)]


# --- Example built-in resolver ------------------------------------------------
@register_resolver("submitter_manager")
def _submitter_manager(*, subject, request):
    """Resolve the manager of whoever initiated the request, if modelled."""
    initiator = getattr(request, "initiated_by", None)
    manager = getattr(getattr(initiator, "profile", None), "manager", None)
    return [manager] if manager else []
