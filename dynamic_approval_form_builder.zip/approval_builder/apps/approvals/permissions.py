from rest_framework.permissions import BasePermission

from .states import TaskStatus


class IsTaskAssignee(BasePermission):
    """Object-level: only the assignee of a PENDING task may act on it."""

    message = "You are not the assignee of this approval task."

    def has_object_permission(self, request, view, obj):
        return obj.assignee_id == request.user.pk and obj.status == TaskStatus.PENDING


class CanInitiateApproval(BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.has_perm(
            "approvals.add_approvalrequest"
        )
