"""Lightweight signals so integrations can react to approval events without the
core service importing them."""
import django.dispatch

# sent after a task decision is processed (approve/reject); kwargs: request, task, action
task_acted = django.dispatch.Signal()
