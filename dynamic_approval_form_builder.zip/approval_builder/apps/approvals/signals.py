"""Signal hooks. Kept thin: the service layer is the single source of truth for
state transitions, so signals here are reserved for cross-cutting concerns
(e.g. cache invalidation, search reindexing) that host apps can extend."""
