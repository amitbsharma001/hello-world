from rest_framework import serializers, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import StepApprover, WorkflowDefinition, WorkflowStep


class StepApproverSerializer(serializers.ModelSerializer):
    class Meta:
        model = StepApprover
        fields = ["id", "kind", "user", "group", "resolver_key"]


class WorkflowStepSerializer(serializers.ModelSerializer):
    approvers = StepApproverSerializer(many=True, required=False)

    class Meta:
        model = WorkflowStep
        fields = [
            "id", "name", "order", "step_type", "policy", "quorum_count",
            "sla_hours", "escalate_to_step_order", "allow_delegation", "approvers",
        ]


class WorkflowDefinitionSerializer(serializers.ModelSerializer):
    steps = WorkflowStepSerializer(many=True, required=False)

    class Meta:
        model = WorkflowDefinition
        fields = [
            "id", "name", "slug", "description", "version", "is_active",
            "graph", "steps", "created_at", "updated_at",
        ]
        read_only_fields = ["slug", "graph"]

    def create(self, validated_data):
        steps = validated_data.pop("steps", [])
        workflow = WorkflowDefinition.objects.create(**validated_data)
        self._write_steps(workflow, steps)
        workflow.sync_graph()
        return workflow

    def update(self, instance, validated_data):
        steps = validated_data.pop("steps", None)
        for k, v in validated_data.items():
            setattr(instance, k, v)
        instance.save()
        if steps is not None:
            instance.steps.all().delete()
            self._write_steps(instance, steps)
        instance.sync_graph()
        return instance

    @staticmethod
    def _write_steps(workflow, steps):
        for step_data in steps:
            approvers = step_data.pop("approvers", [])
            step = WorkflowStep.objects.create(workflow=workflow, **step_data)
            for ap in approvers:
                StepApprover.objects.create(step=step, **ap)


class WorkflowDefinitionViewSet(viewsets.ModelViewSet):
    queryset = WorkflowDefinition.objects.prefetch_related("steps__approvers")
    serializer_class = WorkflowDefinitionSerializer
    filterset_fields = ["is_active", "slug"]
    search_fields = ["name", "slug", "description"]
    ordering_fields = ["created_at", "name", "version"]

    @action(detail=True, methods=["get"])
    def graph(self, request, pk=None):
        """JSON directed graph for the React/Mermaid workflow builder."""
        return Response(self.get_object().as_graph())
