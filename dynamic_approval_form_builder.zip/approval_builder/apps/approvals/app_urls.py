"""All URLs for the approvals + dynamic-forms apps in ONE includable module.

Mount it into your project's root URLconf (e.g. main/urls.py) with a single line:

    from django.urls import include, path
    urlpatterns += [path("", include("apps.approvals.app_urls"))]

Mount at "" (root) so the login-free approve links built into emails
(/approve/t/<token>/) resolve. If you must mount under a prefix, set
APPROVALS_URL_PREFIX in settings to the SAME prefix so the email links match, e.g.

    # settings.py
    APPROVALS_URL_PREFIX = "approvals-app/"
    # main/urls.py
    urlpatterns += [path("approvals-app/", include("apps.approvals.app_urls"))]
"""
from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.approvals.automation.views import (
    ActionRunViewSet, ActionTypeListView, AutomationActionViewSet,
)
from apps.approvals.integrations.views import (
    ExternalApprovalCreate, TeamsApprovalCallback,
)
from apps.approvals.views import (
    ApprovalRequestViewSet, ApprovalTaskViewSet, WorkflowDefinitionViewSet,
    lifecycle_console,
)
from apps.dynamic_forms.public_views import (
    PublicFormView, form_builder, form_submissions_view, public_approval_view,
    public_submission_view, public_task_approval_view,
)
from apps.dynamic_forms.dashboard import DashboardMetricsView
from apps.dynamic_forms.views import FormDefinitionViewSet, SubmissionViewSet

router = DefaultRouter()
router.register("workflows", WorkflowDefinitionViewSet, basename="workflow")
router.register("forms", FormDefinitionViewSet, basename="form")
router.register("submissions", SubmissionViewSet, basename="submission")
router.register("approval-requests", ApprovalRequestViewSet, basename="approval-request")
router.register("approval-tasks", ApprovalTaskViewSet, basename="approval-task")
router.register("automation-actions", AutomationActionViewSet, basename="automation-action")
router.register("action-runs", ActionRunViewSet, basename="action-run")

api_v1 = [
    path("", include(router.urls)),
    path("action-types/", ActionTypeListView.as_view(), name="action-types"),
    path("dashboard/metrics/", DashboardMetricsView.as_view(), name="dashboard-metrics"),
    path("teams/callback/", TeamsApprovalCallback.as_view(), name="teams-callback"),
    path("external/approvals/", ExternalApprovalCreate.as_view(), name="external-approval-create"),
]

urlpatterns = [
    # --- login-free approve links (these MUST match the links built into emails) ---
    path("approve/t/<str:token>/", public_task_approval_view, name="task-approval"),
    path("forms/approve/<str:token>/", public_approval_view, name="public-approval"),

    # --- public, no-login customer form + submission status ---
    path("forms/<str:token>/", PublicFormView.as_view(), name="public-form"),
    path("forms/submission/<uuid:sub_uuid>/", public_submission_view, name="public-submission"),

    # --- internal UIs ---
    path("approvals/console/", lifecycle_console, name="approval-console"),
    path("forms-builder/", form_builder, name="form-builder"),
    path("form-submissions/", form_submissions_view, name="form-submissions"),

    # --- REST API ---
    path("api/v1/", include((api_v1, "approvals_api"), namespace="approvals_v1")),
]
