from django.contrib import admin

from .models import ApprovalActionLog, ApprovalRequest, ApprovalTask


class ApprovalTaskInline(admin.TabularInline):
    model = ApprovalTask
    extra = 0


class ApprovalActionInline(admin.TabularInline):
    model = ApprovalActionLog
    extra = 0
    readonly_fields = ("actor", "action", "from_state", "to_state", "comment", "created_at")


@admin.register(ApprovalRequest)
class ApprovalRequestAdmin(admin.ModelAdmin):
    list_display = ("id", "workflow", "state", "current_step", "initiated_by", "created_at")
    list_filter = ("state", "workflow")
    inlines = [ApprovalTaskInline, ApprovalActionInline]


@admin.register(ApprovalTask)
class ApprovalTaskAdmin(admin.ModelAdmin):
    list_display = ("id", "request", "step", "assignee", "status", "acted_at")
    list_filter = ("status",)
