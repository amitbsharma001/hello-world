from django.contrib import admin

from .models import ApprovalActionLog, ApprovalRequest, ApprovalTask


class ApprovalTaskInline(admin.TabularInline):
    model = ApprovalTask
    extra = 0


class ApprovalActionInline(admin.TabularInline):
    model = ApprovalActionLog
    extra = 0
    readonly_fields = ("actor", "action", "from_state", "to_state", "comment", "created_at")


@admin.register(ApprovalRequest)
class ApprovalRequestAdmin(admin.ModelAdmin):
    list_display = ("id", "workflow", "state", "current_step", "initiated_by", "created_at")
    list_filter = ("state", "workflow")
    inlines = [ApprovalTaskInline, ApprovalActionInline]


@admin.register(ApprovalTask)
class ApprovalTaskAdmin(admin.ModelAdmin):
    list_display = ("id", "request", "step", "assignee", "status", "acted_at")
    list_filter = ("status",)

# ---- merged from automation/notifications/audit ----

from .models import ActionRun, AutomationAction


@admin.register(AutomationAction)
class AutomationActionAdmin(admin.ModelAdmin):
    list_display = ("name", "workflow", "event", "action_type", "is_enabled", "order")
    list_filter = ("event", "action_type", "is_enabled")
    search_fields = ("name",)


@admin.register(ActionRun)
class ActionRunAdmin(admin.ModelAdmin):
    list_display = ("id", "action", "status", "attempts", "started_at", "finished_at")
    list_filter = ("status",)
    readonly_fields = [f.name for f in ActionRun._meta.fields]

from .models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("created_at", "recipient", "verb", "is_read")
    list_filter = ("is_read", "verb")

from .models import AuditLog


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("created_at", "action", "actor", "from_state", "to_state", "ip_address")
    list_filter = ("action",)
    search_fields = ("comment",)
    readonly_fields = [f.name for f in AuditLog._meta.fields]


from .models import StepApprover, WorkflowDefinition, WorkflowStep


class StepApproverInline(admin.TabularInline):
    model = StepApprover
    extra = 1


class WorkflowStepInline(admin.TabularInline):
    model = WorkflowStep
    extra = 1


@admin.register(WorkflowDefinition)
class WorkflowDefinitionAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "version", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "slug")
    inlines = [WorkflowStepInline]


@admin.register(WorkflowStep)
class WorkflowStepAdmin(admin.ModelAdmin):
    list_display = ("workflow", "order", "name", "step_type", "policy")
    inlines = [StepApproverInline]
