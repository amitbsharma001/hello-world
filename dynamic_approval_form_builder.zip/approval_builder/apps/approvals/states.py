from django.db import models


class ApprovalState(models.TextChoices):
    DRAFT = "draft", "Draft"
    PENDING = "pending", "Pending Approval"
    UNDER_REVIEW = "under_review", "Under Review"
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"
    CANCELLED = "cancelled", "Cancelled"
    EXPIRED = "expired", "Expired"
    COMPLETED = "completed", "Completed"


TERMINAL_STATES = {
    ApprovalState.APPROVED,
    ApprovalState.REJECTED,
    ApprovalState.CANCELLED,
    ApprovalState.EXPIRED,
    ApprovalState.COMPLETED,
}


class ApprovalAction(models.TextChoices):
    SUBMIT = "submit", "Submit"
    APPROVE = "approve", "Approve"
    REJECT = "reject", "Reject"
    REQUEST_CHANGES = "request_changes", "Request Changes"
    DELEGATE = "delegate", "Delegate"
    ESCALATE = "escalate", "Escalate"
    CANCEL = "cancel", "Cancel"
    RESUBMIT = "resubmit", "Resubmit"


class TaskStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"
    DELEGATED = "delegated", "Delegated"
    ESCALATED = "escalated", "Escalated"
    SKIPPED = "skipped", "Skipped"
