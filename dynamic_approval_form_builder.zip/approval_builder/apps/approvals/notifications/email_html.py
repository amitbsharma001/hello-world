"""Beautiful, email-client-safe HTML for approval notifications.

Table-based layout with inline styles (works in Gmail/Outlook/Apple Mail),
styled in the Bosch palette. `build_email(verb, payload)` returns
(subject, text_body, html_body); the email backend sends both parts.
"""
import html as _html

# ── Bosch palette ────────────────────────────────────────────────────────────
BLUE = "#007BC0"        # Bosch Blue 50 (primary)
BLUE_DARK = "#00629A"
GREEN = "#00884A"       # Bosch Green 50
RED = "#E2462F"         # Bosch Red 50
TURQUOISE = "#18837E"   # Bosch Turquoise 50
PURPLE = "#9E2896"      # Bosch Purple 40
YELLOW = "#EFBE00"      # Bosch Yellow 85
GRAY_DARK = "#2E3033"   # headings
GRAY = "#5A646E"        # body text
GRAY_50 = "#525F6B"     # Bosch Gray 50
GRAY_BG = "#EEF1F5"
LINE = "#E0E4EA"

# verb -> (accent, badge label, headline, button label)
_STYLE = {
    "task_assigned":    (BLUE,      "Action needed",      "An approval is awaiting you", "Review & approve"),
    "task_escalated":   (TURQUOISE, "Escalated to you",   "An approval was escalated to you", "Review now"),
    "request_approved": (GREEN,     "Approved",           "Your request was approved",  "View request"),
    "request_rejected": (RED,       "Rejected",           "Your request was rejected",  "View details"),
    "changes_requested":(YELLOW,    "Changes requested",  "Changes were requested",     "Update submission"),
}
_DEFAULT = (BLUE, "Update", "You have an update", "Open")

# Bosch "supergraphic" accent strip (segment colors, left → right)
_STRIP = [PURPLE, BLUE, TURQUOISE, GREEN, YELLOW, RED]


def _intro(verb, summary):
    item = f" <strong>{_html.escape(summary)}</strong>" if summary else ""
    return {
        "task_assigned":    f"An item{item} needs your approval. Review it and approve, reject, or delegate.",
        "task_escalated":   f"An approval{item} has been escalated and needs your attention.",
        "request_approved": f"Good news — your request{item} has been approved.",
        "request_rejected": f"Your request{item} was rejected. Open it to see the details.",
        "changes_requested":f"An approver requested changes on your submission{item}.",
    }.get(verb, f"You have an update{item}.")


def _text(verb, summary, action_url, description="", details=None):
    item = f" ({summary})" if summary else ""
    base = {
        "task_assigned":    f"An item{item} needs your approval. Open your approvals queue to approve, reject, or delegate.",
        "task_escalated":   f"An approval{item} has been escalated and needs attention.",
        "request_approved": f"Good news — your request{item} has been approved.",
        "request_rejected": f"Your request{item} was rejected.",
        "changes_requested":f"An approver requested changes on your submission{item}.",
    }.get(verb, f"You have an update{item}.")
    if description:
        base += f"\n\n{description}"
    for row in (details or []):
        base += f"\n{row[0]}: {row[1]}"
    if action_url:
        base += f"\n\n{action_url}"
    return base


def build_email(verb, payload):
    payload = payload or {}
    summary = payload.get("summary") or ""
    action_url = payload.get("action_url") or ""
    description = payload.get("description") or ""
    details = payload.get("details") or []
    accent, badge, headline, btn_label = _STYLE.get(verb, _DEFAULT)

    subject = {
        "task_assigned": "Action needed: approval awaiting you",
        "task_escalated": "Approval escalated to you",
        "request_approved": "Your request was approved",
        "request_rejected": "Your request was rejected",
        "changes_requested": "Changes requested on your submission",
    }.get(verb, f"Notification: {verb.replace('_', ' ')}")

    intro = _intro(verb, summary)
    text_body = _text(verb, summary, action_url, description, details)

    strip = "".join(
        f'<td height="6" style="height:6px;font-size:0;line-height:0;background:{c};">&nbsp;</td>'
        for c in _STRIP
    )

    button = ""
    if action_url:
        url = _html.escape(action_url, quote=True)
        button = f"""
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:8px 0 4px;">
          <tr><td bgcolor="{accent}" style="border-radius:6px;">
            <a href="{url}" target="_blank"
               style="display:inline-block;padding:13px 30px;font-family:Arial,Helvetica,sans-serif;
                      font-size:15px;font-weight:bold;color:#ffffff;text-decoration:none;border-radius:6px;">
              {btn_label} &nbsp;&rarr;
            </a>
          </td></tr>
        </table>"""

    summary_row = ""
    if summary:
        summary_row = f"""
        <tr><td style="padding:2px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                 style="background:{GRAY_BG};border-left:4px solid {accent};border-radius:4px;">
            <tr><td style="padding:12px 16px;font-family:Arial,Helvetica,sans-serif;font-size:14px;color:{GRAY_DARK};">
              {_html.escape(summary)}
            </td></tr>
          </table>
        </td></tr>"""

    desc_row = ""
    if description:
        desc_row = f"""
        <tr><td style="padding:14px 40px 0;font-family:Arial,Helvetica,sans-serif;font-size:15px;
                       color:{GRAY_DARK};line-height:1.6;">{_html.escape(description)}</td></tr>"""

    details_row = ""
    if details:
        cells = ""
        for row in details:
            label = _html.escape(str(row[0]))
            value = _html.escape(str(row[1])) if len(row) > 1 else ""
            cells += f"""
              <tr>
                <td style="padding:9px 14px;border-bottom:1px solid {LINE};font-family:Arial,Helvetica,sans-serif;
                           font-size:13px;color:{GRAY_50};white-space:nowrap;width:38%;vertical-align:top;">{label}</td>
                <td style="padding:9px 14px;border-bottom:1px solid {LINE};font-family:Arial,Helvetica,sans-serif;
                           font-size:13px;color:{GRAY_DARK};font-weight:bold;vertical-align:top;">{value}</td>
              </tr>"""
        details_row = f"""
        <tr><td style="padding:18px 40px 0;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
                 style="border:1px solid {LINE};border-radius:6px;overflow:hidden;">
            <tr><td colspan="2" style="background:{GRAY_BG};padding:8px 14px;font-family:Arial,Helvetica,sans-serif;
                     font-size:11px;font-weight:bold;letter-spacing:.5px;text-transform:uppercase;color:{GRAY_50};">
              Details</td></tr>
            {cells}
          </table>
        </td></tr>"""

    fallback = ""
    if action_url:
        u = _html.escape(action_url, quote=True)
        fallback = (f'<tr><td style="padding:6px 40px 0;font-family:Arial,Helvetica,sans-serif;'
                    f'font-size:12px;color:{GRAY};">Or paste this link: '
                    f'<a href="{u}" style="color:{BLUE};">{u}</a></td></tr>')

    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light only"></head>
<body style="margin:0;padding:0;background:{GRAY_BG};">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{GRAY_BG};">
 <tr><td align="center" style="padding:28px 12px;">
  <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0"
         style="width:600px;max-width:600px;background:#ffffff;border-radius:10px;overflow:hidden;
                box-shadow:0 1px 4px rgba(16,24,40,.08);">
    <tr><td style="padding:0;font-size:0;line-height:0;">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{strip}</tr></table>
    </td></tr>
    <tr><td style="background:{BLUE};padding:18px 40px;">
      <span style="font-family:Arial,Helvetica,sans-serif;font-size:17px;font-weight:bold;color:#ffffff;letter-spacing:.2px;">
        FormFlow Approvals</span>
    </td></tr>
    <tr><td style="padding:30px 40px 6px;">
      <span style="display:inline-block;background:{accent};color:#ffffff;font-family:Arial,Helvetica,sans-serif;
                   font-size:11px;font-weight:bold;letter-spacing:.6px;text-transform:uppercase;
                   padding:5px 12px;border-radius:20px;">{badge}</span>
    </td></tr>
    <tr><td style="padding:14px 40px 0;font-family:Georgia,'Times New Roman',serif;font-size:24px;
                   font-weight:bold;color:{GRAY_DARK};line-height:1.25;">{headline}</td></tr>
    <tr><td style="padding:12px 40px 0;font-family:Arial,Helvetica,sans-serif;font-size:15px;
                   color:{GRAY};line-height:1.6;">{intro}</td></tr>
    {desc_row}
    {summary_row}
    {details_row}
    <tr><td style="padding:22px 40px 4px;">{button}</td></tr>
    {fallback}
    <tr><td style="padding:26px 40px 0;"><hr style="border:none;border-top:1px solid {LINE};margin:0;"></td></tr>
    <tr><td style="padding:16px 40px 30px;font-family:Arial,Helvetica,sans-serif;font-size:12px;color:{GRAY_50};line-height:1.5;">
      You received this because you're part of an approval workflow in FormFlow.<br>
      This is an automated message — please don't reply.
    </td></tr>
  </table>
  <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px;">
    <tr><td align="center" style="padding:14px 0;font-family:Arial,Helvetica,sans-serif;font-size:11px;color:#9AA4AE;">
      FormFlow · Approval workflows</td></tr>
  </table>
 </td></tr>
</table>
</body></html>"""
    return subject, text_body, html
