"""
Pluggable notification channels. Each backend implements send(recipient, verb,
target, payload). The dispatcher fans out to every channel enabled in settings.
Slack and Teams are thin specialisations of the webhook backend.
"""
import json
import logging
from urllib import request as urllib_request

from django.conf import settings
from django.contrib.contenttypes.models import ContentType
from django.core.mail import send_mail

logger = logging.getLogger("notifications")


class BaseBackend:
    def send(self, recipient, verb, target=None, payload=None):  # pragma: no cover
        raise NotImplementedError


class InAppBackend(BaseBackend):
    def send(self, recipient, verb, target=None, payload=None):
        from ..models import Notification

        ct = ContentType.objects.get_for_model(type(target)) if target else None
        Notification.objects.create(
            recipient=recipient, verb=verb, content_type=ct,
            object_id=str(getattr(target, "pk", "")), payload=payload or {},
        )


VERB_TEMPLATES = {
    "task_assigned": ("Action needed: approval awaiting you",
                      "An item needs your approval{summary}.\n"
                      "Open your approvals queue to approve, reject, or delegate."),
    "request_approved": ("Your request was approved",
                         "Good news — your request{summary} has been approved."),
    "request_rejected": ("Your request was rejected",
                         "Your request{summary} was rejected."),
    "changes_requested": ("Changes requested on your submission",
                          "An approver requested changes on your submission{summary}."),
    "task_escalated": ("Approval escalated to you",
                       "An approval{summary} has been escalated and needs attention."),
}


class EmailBackend(BaseBackend):
    def send(self, recipient, verb, target=None, payload=None):
        email = getattr(recipient, "email", None)
        if not email:
            return
        payload = payload or {}
        summary = f" ({payload['summary']})" if payload.get("summary") else ""
        subject, body = VERB_TEMPLATES.get(
            verb, (f"Notification: {verb.replace('_', ' ')}", "You have an update{summary}.")
        )
        body = body.format(summary=summary)
        if payload.get("action_url"):
            body += f"\n\n{payload['action_url']}"
        send_mail(
            subject=subject,
            message=body,
            from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "noreply@example.com"),
            recipient_list=[email],
            fail_silently=True,
        )


class WebhookBackend(BaseBackend):
    url_setting = "APPROVALS_WEBHOOK_URL"

    def send(self, recipient, verb, target=None, payload=None):
        url = getattr(settings, self.url_setting, None)
        if not url:
            return
        body = json.dumps(
            {"recipient": getattr(recipient, "pk", None), "verb": verb,
             "target": str(target), "payload": payload or {}}
        ).encode()
        req = urllib_request.Request(
            url, data=body, headers={"Content-Type": "application/json"}
        )
        try:
            urllib_request.urlopen(req, timeout=5)  # noqa: S310
        except Exception as exc:  # pragma: no cover
            logger.warning("Webhook delivery failed: %s", exc)


class SlackBackend(WebhookBackend):
    url_setting = "APPROVALS_SLACK_WEBHOOK_URL"


class TeamsBackend(WebhookBackend):
    url_setting = "APPROVALS_TEAMS_WEBHOOK_URL"


BACKEND_REGISTRY = {
    "inapp": InAppBackend,
    "email": EmailBackend,
    "webhook": WebhookBackend,
    "slack": SlackBackend,
    "teams": TeamsBackend,
}
