from celery import shared_task


@shared_task(bind=True, max_retries=3, default_retry_delay=30)
def deliver_notification(self, recipient_id, verb, content_type_id, object_id, payload):
    from .dispatcher import deliver

    try:
        deliver(recipient_id, verb, content_type_id, object_id, payload)
    except Exception as exc:  # pragma: no cover
        raise self.retry(exc=exc)


@shared_task
def check_sla_escalations():
    """Periodic beat task: escalate requests whose active step breached its SLA."""
    from datetime import timedelta

    from django.utils import timezone

    from apps.approvals.models import ApprovalRequest
    from apps.approvals.services import ApprovalService
    from apps.approvals.states import TERMINAL_STATES

    now = timezone.now()
    qs = ApprovalRequest.objects.exclude(state__in=TERMINAL_STATES).select_related(
        "current_step"
    )
    escalated = 0
    for req in qs.iterator():
        step = req.current_step
        if not step or not step.sla_hours:
            continue
        active = req.tasks.filter(step=step, status="pending").order_by("created_at").first()
        if active and active.created_at + timedelta(hours=step.sla_hours) < now:
            ApprovalService.escalate(request_id=req.pk, comment="Auto SLA escalation")
            escalated += 1
    return {"escalated": escalated}


@shared_task
def expire_public_forms():
    from django.utils import timezone

    from apps.dynamic_forms.models import FormDefinition

    return FormDefinition.objects.filter(
        expires_at__lt=timezone.now(), is_active=True
    ).update(is_active=False)
