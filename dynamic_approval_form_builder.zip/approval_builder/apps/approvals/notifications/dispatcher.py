"""
notify() is the single entry point used across the codebase. It queues delivery
on Celery when available and falls back to synchronous delivery otherwise (e.g.
during tests or `manage.py shell`), so callers never branch on infrastructure.
"""
from django.conf import settings


def _enabled_channels():
    return getattr(settings, "NOTIFICATION_CHANNELS", ["inapp", "email"])


def deliver(recipient_id, verb, content_type_id=None, object_id="", payload=None):
    from django.contrib.auth import get_user_model

    from .backends import BACKEND_REGISTRY

    User = get_user_model()
    recipient = User.objects.filter(pk=recipient_id).first()
    if not recipient:
        return
    target = None
    if content_type_id:
        from django.contrib.contenttypes.models import ContentType

        ct = ContentType.objects.filter(pk=content_type_id).first()
        if ct:
            target = ct.get_object_for_this_type(pk=object_id) if object_id else None
    for channel in _enabled_channels():
        backend_cls = BACKEND_REGISTRY.get(channel)
        if backend_cls:
            backend_cls().send(recipient, verb, target=target, payload=payload)


def notify(recipient, verb, *, target=None, payload=None):
    if recipient is None:
        return
    ct_id, obj_id = None, ""
    if target is not None:
        from django.contrib.contenttypes.models import ContentType

        ct_id = ContentType.objects.get_for_model(type(target)).pk
        obj_id = str(target.pk)

    # Default to SYNCHRONOUS delivery so email works without a running Celery
    # worker. (With a broker but no worker, .delay() succeeds silently and the
    # notification is never delivered.) Opt into async by setting
    # NOTIFICATIONS_USE_CELERY=1 AND running a worker.
    use_celery = (getattr(settings, "NOTIFICATIONS_USE_CELERY", False)
                  and not getattr(settings, "CELERY_TASK_ALWAYS_EAGER", False))
    if use_celery:
        try:
            from .tasks import deliver_notification
            deliver_notification.delay(recipient.pk, verb, ct_id, obj_id, payload or {})
            return
        except Exception:
            pass  # broker unavailable -> fall through to synchronous
    deliver(recipient.pk, verb, ct_id, obj_id, payload or {})
