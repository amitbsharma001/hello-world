"""
Drop-in mixin: make any model approvable with one base class.

    from apps.approvals.mixins import ApprovableMixin

    class Vendor(ApprovableMixin, models.Model):
        approval_workflow = "vendor_onboarding"   # the Flow slug
        ...

    vendor.submit_for_approval(by=request.user)
    vendor.approval_status      # 'under_review' | 'approved' | 'rejected' | None
    vendor.is_approved          # True/False

No fields are added — binding is via the engine's GenericForeignKey.
"""


class ApprovableMixin:
    approval_workflow = None  # override with the workflow slug

    def submit_for_approval(self, *, by=None, workflow=None):
        from .flow import Flow
        return Flow.submit(self, by=by, workflow=workflow or self.approval_workflow)

    @property
    def latest_approval(self):
        from .flow import Flow
        return Flow.latest(self)

    @property
    def approval_status(self):
        from .flow import Flow
        return Flow.status(self)

    @property
    def is_approved(self) -> bool:
        return self.approval_status == "approved"
