"""
ApprovalEngine: the public, model-agnostic facade.

    ApprovalEngine.register(model=Vendor, workflow="vendor_onboarding")
    ApprovalEngine.register(model=Contract, workflow="contract_approval")
    req = ApprovalEngine.start(instance=my_vendor, initiated_by=request.user)

The engine never imports business models. It binds a workflow *slug* to a
content type and, on start(), hands off to approvals.services.ApprovalService.
"""
from dataclasses import dataclass, field
from typing import Dict, Optional, Type


@dataclass
class Registration:
    workflow_slug: str
    on_approved: Optional[str] = None  # dotted path callable(instance)
    on_rejected: Optional[str] = None
    extra: dict = field(default_factory=dict)


class ApprovalEngine:
    _registry: Dict[str, Registration] = {}

    @staticmethod
    def _key(model: Type) -> str:
        return f"{model._meta.app_label}.{model._meta.model_name}"

    @classmethod
    def register(cls, *, model, workflow: str, on_approved=None, on_rejected=None, **extra):
        cls._registry[cls._key(model)] = Registration(
            workflow_slug=workflow,
            on_approved=on_approved,
            on_rejected=on_rejected,
            extra=extra,
        )

    @classmethod
    def registration_for(cls, instance) -> Optional[Registration]:
        return cls._registry.get(cls._key(type(instance)))

    @classmethod
    def is_registered(cls, instance) -> bool:
        return cls._key(type(instance)) in cls._registry

    @classmethod
    def start(cls, *, instance, initiated_by, workflow: Optional[str] = None):
        """Kick off an approval for any registered instance. Returns ApprovalRequest."""
        from apps.approvals.services import ApprovalService

        reg = cls.registration_for(instance)
        slug = workflow or (reg.workflow_slug if reg else None)
        if not slug:
            raise ValueError(
                f"{type(instance).__name__} is not registered with ApprovalEngine "
                f"and no workflow was supplied."
            )
        return ApprovalService.initiate(
            subject=instance, workflow_slug=slug, initiated_by=initiated_by
        )
