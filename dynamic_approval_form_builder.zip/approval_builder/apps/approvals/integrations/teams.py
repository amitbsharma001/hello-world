"""Microsoft Teams Approvals connector (Graph API).

Outbound: when a task is assigned, `create_approval` obtains an app-only token
(client credentials) and POSTs an approval item to Graph (or to a Power Automate
HTTP trigger, depending on TEAMS_APPROVAL["CREATE_URL"]). The returned id is
stored on the task as `external_ref`.

Inbound: a decision made in Teams calls our callback endpoint, which maps back to
`ApprovalService.act`. Because both the in-app buttons and the Teams callback end
at the same ApprovalTask, an item can be approved from either side.

Everything is guarded: if TEAMS_APPROVAL is not enabled/configured the functions
no-op, so the core flow is never affected. The HTTP calls live in `_token` and
`_post_json` so they can be mocked in tests.
"""
import json
import logging
import urllib.request

from django.conf import settings

logger = logging.getLogger("approvals.teams")


def _conf():
    return getattr(settings, "TEAMS_APPROVAL", {}) or {}


def is_enabled():
    c = _conf()
    return bool(c.get("ENABLED") and c.get("CREATE_URL") and (
        # Graph needs creds; a Power Automate URL may not.
        "graph.microsoft.com" not in c.get("CREATE_URL", "")
        or (c.get("TENANT_ID") and c.get("CLIENT_ID") and c.get("CLIENT_SECRET"))
    ))


def _token():
    """App-only OAuth2 token (client credentials). Mockable in tests."""
    c = _conf()
    url = f"https://login.microsoftonline.com/{c['TENANT_ID']}/oauth2/v2.0/token"
    body = urllib.parse.urlencode({
        "client_id": c["CLIENT_ID"],
        "client_secret": c["CLIENT_SECRET"],
        "scope": "https://graph.microsoft.com/.default",
        "grant_type": "client_credentials",
    }).encode()
    req = urllib.request.Request(url, data=body,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read()).get("access_token", "")


def _post_json(url, payload, token=""):
    """POST JSON and return the parsed response. Mockable in tests."""
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers)
    with urllib.request.urlopen(req, timeout=20) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else {}


def create_approval(*, task, title, description="", details=None, approver_email=""):
    """Create the approval in Teams and return its external id (or "")."""
    if not is_enabled():
        return ""
    c = _conf()
    base = c.get("APP_BASE_URL", "")
    deep_link = f"{base}/approvals/console/" if base else ""
    payload = {
        "displayName": title,
        "description": description or "",
        "approvers": [{"user": {"emailAddress": approver_email}}] if approver_email else [],
        "details": [{"name": str(k), "value": str(v)} for k, v in (details or [])],
        # correlation so the callback can find the task again
        "metadata": {"taskId": task.pk, "requestId": task.request_id, "deepLink": deep_link},
        "responsePrompt": "Approve or reject this request",
        "allowEmailNotification": True,
    }
    try:
        token = _token() if "graph.microsoft.com" in c.get("CREATE_URL", "") else ""
        data = _post_json(c["CREATE_URL"], payload, token=token)
        return str(data.get("id") or data.get("approvalId") or "")
    except Exception as exc:  # never break the approval flow
        logger.warning("Teams approval create failed for task %s: %s", task.pk, exc)
        return ""


def complete_approval(task, decision):
    """Best-effort close of the Teams approval after an in-app decision."""
    if not is_enabled() or not task.external_ref:
        return
    c = _conf()
    if "graph.microsoft.com" not in c.get("CREATE_URL", ""):
        return  # Power Automate flows close themselves
    try:
        url = f"https://graph.microsoft.com/beta/solutions/approval/approvalItems/{task.external_ref}/cancel"
        _post_json(url, {"reason": f"Resolved in app ({decision})"}, token=_token())
    except Exception as exc:
        logger.info("Teams approval close skipped for task %s: %s", task.pk, exc)
