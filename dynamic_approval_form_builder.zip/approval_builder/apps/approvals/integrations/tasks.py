"""Celery tasks for external approval routing (Microsoft Teams)."""
from celery import shared_task


@shared_task(name="apps.approvals.integrations.push_approval_to_teams")
def push_approval_to_teams(task_id):
    from apps.approvals.models import ApprovalTask
    from apps.approvals.services import ApprovalService

    from . import teams

    if not teams.is_enabled():
        return
    try:
        task = ApprovalTask.objects.select_related(
            "request", "request__workflow", "assignee", "step"
        ).get(pk=task_id)
    except ApprovalTask.DoesNotExist:
        return
    description, details = ApprovalService._detail_payload(task.request)
    ext = teams.create_approval(
        task=task,
        title=f"{task.request.workflow.name}: {task.request.subject}",
        description=description,
        details=details,
        approver_email=getattr(task.assignee, "email", "") or "",
    )
    if ext:
        ApprovalTask.objects.filter(pk=task.pk).update(external_ref=ext)
