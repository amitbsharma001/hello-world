"""Adapter for an external REST approval flow (e.g. iFlow transports).

Inbound: `create_from_payload` takes the request body (a list of approvers, each
with a title, plus the metadata fields to display) and creates an approval whose
steps mirror the approver titles — so each "… Approval" is its own stage and the
metadata is viewable on the console and in the approver email.

Outbound: when the approval is fully decided, `on_external_decided` builds the
response document (responders, summary, outcome, dates, priority) and POSTs it to
the caller's `Result_Callback_URL`.
"""
import json
import logging
import urllib.request

logger = logging.getLogger("approvals.external")


def _post_json(url, payload):
    """POST JSON to the result callback. Mockable in tests."""
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=20) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else {}


def create_from_payload(payload, *, base_url=""):
    """Create an approval from the inbound body. Returns (ExternalApproval, ApprovalRequest)."""
    from django.core import signing

    from apps.approvals.flow import Flow
    from apps.approvals.models import ExternalApproval
    from apps.approvals.registry import ApprovalEngine
    from apps.dynamic_forms.services import _resolve_approver  # email -> user (provisioned)

    body = payload.get("body", payload)          # accept {"body": {...}} or the body itself
    approvers = body.get("approvers") or []
    if not approvers:
        raise ValueError("At least one approver is required.")

    ext = ExternalApproval.objects.create(
        payload=body,
        result_callback_url=body.get("Result_Callback_URL", "") or payload.get("Result_Callback_URL", ""),
        name=body.get("name") or body.get("Workflow_Name", ""),
        title=body.get("title") or (approvers[0].get("title", "") if approvers else ""),
        priority=body.get("priority", "Normal"),
    )

    # One step per approver, in order, named by the approver's title (e.g.
    # "Validation Approval", then "Customer Approval").
    steps = []
    for i, ap in enumerate(approvers, start=1):
        user = _resolve_approver(ap["email"])
        steps.append(Flow.step(ap.get("title") or f"Approval {i}", approvers=[user]))

    slug = f"ext_{ext.pk}"
    Flow.define(slug, name=ext.title or ext.name or slug, steps=steps,
                notify_approvers=True, notify_initiator=False)

    action_url = ""
    if base_url:
        token = signing.dumps(ext.pk, salt="ext-approval")
        action_url = f"{base_url}/forms/approve/{token}/"  # reusable token approve page
    req = ApprovalEngine.start(
        instance=ext, initiated_by=None, workflow=slug,
        context={
            "description": body.get("Details", "") or "External approval request.",
            "details": ext.as_dict(),
            "action_url": action_url,
            "base_url": base_url,
        },
    )
    return ext, req


def build_response_document(ext, request):
    """Build the result payload (the shape the caller's API expects)."""
    from apps.approvals.states import TaskStatus

    responses = []
    for task in request.tasks.select_related("assignee", "step").order_by("step__order"):
        decided = task.status in (TaskStatus.APPROVED, TaskStatus.REJECTED)
        user = task.assignee
        responses.append({
            "responder": {
                "id": str(user.pk),
                "displayName": (user.get_full_name() or user.get_username()),
                "email": user.email or "",
                "userPrincipalName": user.email or user.get_username(),
            },
            "stage": task.step.name,
            "requestDate": task.created_at.isoformat() if task.created_at else None,
            "responseDate": (task.updated_at.isoformat() if decided and task.updated_at else None),
            "approverResponse": {"approved": "Approve", "rejected": "Reject"}.get(task.status, "Pending"),
        })

    approved = request.state == "approved"
    rejected = request.state == "rejected"
    responded = sum(1 for r in responses if r["approverResponse"] in ("Approve", "Reject"))
    total = len(responses)
    if approved:
        outcome, summary = "Approved", "All approvers approved the request."
    elif rejected:
        outcome, summary = "Rejected", "The request was rejected."
    else:
        outcome = "Pending"
        summary = f"{responded} of {total} approvers have responded."
    return {
        "responses": responses,
        "responseSummary": summary,
        "completionDate": request.decided_at.isoformat() if request.decided_at else None,
        "outcome": outcome,
        "name": ext.name,
        "title": ext.title,
        "requestDate": request.submitted_at.isoformat() if request.submitted_at else None,
        "expirationDate": request.expires_at.isoformat() if request.expires_at else None,
        "priority": ext.priority,
        # echo the correlation fields the caller sent
        "Workflow_Name": ext.payload.get("Workflow_Name"),
        "iFlow_Id": ext.payload.get("iFlow_Id"),
        "Version": ext.payload.get("Version"),
    }


def on_external_decided(ext):
    """Engine callback (approved or rejected) -> POST the result to the caller."""
    from apps.approvals.models import ApprovalRequest

    req = ApprovalRequest.objects.filter(
        content_type__app_label="approvals", content_type__model="externalapproval",
        object_id=ext.pk,
    ).order_by("-created_at").first()
    if req is None:
        return
    ext.outcome = "Approved" if req.state == "approved" else "Rejected"
    doc = build_response_document(ext, req)
    if ext.result_callback_url:
        try:
            _post_json(ext.result_callback_url, doc)
            ext.result_posted = True
        except Exception as exc:  # never break the decision
            logger.warning("External result callback failed for #%s: %s", ext.pk, exc)
    ext.save(update_fields=["outcome", "result_posted", "updated_at"])
    return doc


from django.dispatch import receiver  # noqa: E402

from apps.approvals.signals import task_acted  # noqa: E402


@receiver(task_acted)
def _external_progress(sender, request, task, action, **kwargs):
    """POST a progress update to the caller on each approver decision. The final
    decision is handled by on_external_decided, so here we only fire for the
    intermediate (non-terminal) ones to avoid double-posting."""
    from django.db import transaction

    from apps.approvals.models import ExternalApproval

    if request.is_terminal:
        return
    subject = request.subject
    if not isinstance(subject, ExternalApproval) or not subject.result_callback_url:
        return
    doc = build_response_document(subject, request)
    url = subject.result_callback_url

    def _send():
        try:
            _post_json(url, doc)
        except Exception as exc:
            logger.warning("External progress callback failed for #%s: %s", subject.pk, exc)

    transaction.on_commit(_send)
