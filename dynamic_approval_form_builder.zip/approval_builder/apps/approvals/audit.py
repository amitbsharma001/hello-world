"""
record_audit() is the single helper the service layer calls. It enriches every
entry with IP / user-agent pulled from a thread-local populated by
AuditContextMiddleware, so callers never have to thread the HttpRequest through
the domain layer.
"""
import threading

from django.contrib.contenttypes.models import ContentType

from .models import AuditLog

_ctx = threading.local()


def set_request_context(*, ip=None, user_agent=None):
    _ctx.ip = ip
    _ctx.user_agent = user_agent


def clear_request_context():
    _ctx.ip = None
    _ctx.user_agent = None


def record_audit(target, *, actor=None, action="", from_state="", to_state="",
                 comment="", task=None, duration_seconds=None, **metadata):
    return AuditLog.objects.create(
        content_type=ContentType.objects.get_for_model(type(target)),
        object_id=str(target.pk),
        actor=actor,
        action=str(action),
        from_state=str(from_state or ""),
        to_state=str(to_state or ""),
        comment=comment,
        ip_address=getattr(_ctx, "ip", None),
        user_agent=getattr(_ctx, "user_agent", "") or "",
        duration_seconds=duration_seconds,
        metadata={"task_id": task.pk if task else None, **metadata},
    )


class AuditContextMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
        ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")
        set_request_context(ip=ip, user_agent=request.META.get("HTTP_USER_AGENT", ""))
        try:
            return self.get_response(request)
        finally:
            clear_request_context()
