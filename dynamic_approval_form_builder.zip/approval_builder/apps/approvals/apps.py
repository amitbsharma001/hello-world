from django.apps import AppConfig


class ApprovalsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.approvals"
    label = "approvals"
    verbose_name = "Approvals"

    def ready(self):
        from . import signals  # noqa: F401
        from .automation.handlers import builtins  # noqa: F401  (registers action types)
        from . import tasks  # noqa: F401  (registers celery shared_tasks)

        # Register the external-approval subject (inbound REST -> approval -> result callback)
        from .registry import ApprovalEngine
        from .models import ExternalApproval
        ApprovalEngine.register(
            model=ExternalApproval,
            workflow="external_approval",   # overridden per-request with a unique slug
            on_approved="apps.approvals.integrations.external.on_external_decided",
            on_rejected="apps.approvals.integrations.external.on_external_decided",
        )
