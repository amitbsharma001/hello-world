from django.apps import AppConfig


class ApprovalsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.approvals"
    label = "approvals"
    verbose_name = "Approvals"

    def ready(self):
        from . import signals  # noqa: F401
