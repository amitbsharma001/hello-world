from django.apps import AppConfig


class ApprovalsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.approvals"
    label = "approvals"
    verbose_name = "Approvals"

    def ready(self):
        from . import signals  # noqa: F401
        from .automation.handlers import builtins  # noqa: F401  (registers action types)
        from . import tasks  # noqa: F401  (registers celery shared_tasks)
