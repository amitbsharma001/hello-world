"""
ApprovalService — the engine's state machine.

Responsibilities:
  * initiate()  : create an ApprovalRequest for any subject + materialise step 1
  * act()       : record an approver's decision and evaluate the active step
  * delegate()  : reassign a task
  * escalate()  : push to a configured fallback step (also driven by SLA beat)

Step evaluation honours the step's ApprovalPolicy:
  ANY    -> one approval advances; one rejection rejects
  ALL    -> every task must approve
  QUORUM -> >= quorum_count approvals

All mutations are wrapped in transactions and emit audit + notification events.
"""
from django.db import transaction
from django.utils import timezone

from apps.approvals.audit import record_audit
from apps.approvals.notifications.dispatcher import notify
from apps.approvals.models import (
    ApprovalPolicy,
    ApproverKind,
    WorkflowDefinition,
)
from apps.approvals import resolvers

from .models import ApprovalRequest, ApprovalTask
from .states import ApprovalAction, ApprovalState, TaskStatus



def task_approval_url(task, base_url):
    """One-click, login-free approve/reject link for a SINGLE task (one approver).
    Uses APP_BASE_URL when configured so links are absolute and reachable in email,
    regardless of which host the request came in on."""
    from django.conf import settings
    base = getattr(settings, "APP_BASE_URL", "") or base_url
    if not base:
        return ""
    from django.core import signing
    token = signing.dumps(task.pk, salt="task-approval")
    return f"{base.rstrip('/')}/approve/t/{token}/"

class ApprovalError(Exception):
    pass


class PermissionDenied(ApprovalError):
    pass


class ApprovalService:
    # ---- automation hook ----------------------------------------------------
    @staticmethod
    def _fire(request, event, step=None):
        """Fire approval-gated automation. Never breaks the approval itself."""
        try:
            from apps.approvals.automation.dispatcher import fire_event
            fire_event(request, event, step=step)
        except Exception:
            pass

    # ---- logging ------------------------------------------------------------
    @staticmethod
    def _log(request, *, actor, action, from_state="", to_state="", comment="", task=None):
        """Write the approval-specific action trail AND the generic audit log."""
        from .models import ApprovalActionLog

        ApprovalActionLog.objects.create(
            request=request, task=task, actor=actor, action=str(action),
            from_state=str(from_state or ""), to_state=str(to_state or ""),
            comment=comment,
        )
        record_audit(
            request, actor=actor, action=action, task=task,
            from_state=from_state, to_state=to_state, comment=comment,
        )

    # ---- lifecycle ----------------------------------------------------------
    @classmethod
    @transaction.atomic
    def initiate(cls, *, subject, workflow_slug, initiated_by, context=None):
        workflow = (
            WorkflowDefinition.objects.filter(slug=workflow_slug, is_active=True)
            .order_by("-version")
            .first()
        )
        if workflow is None:
            raise ApprovalError(f"No active workflow '{workflow_slug}'")

        from django.contrib.contenttypes.models import ContentType

        request = ApprovalRequest.objects.create(
            content_type=ContentType.objects.get_for_model(type(subject)),
            object_id=str(subject.pk),
            workflow=workflow,
            initiated_by=initiated_by,
            state=ApprovalState.PENDING,
            submitted_at=timezone.now(),
            context=context or {},
        )
        cls._log(
            request, actor=initiated_by, action=ApprovalAction.SUBMIT,
            from_state=ApprovalState.DRAFT, to_state=ApprovalState.PENDING,
        )
        first_step = workflow.steps.order_by("order").first()
        cls._fire(request, "on_submit")
        if first_step is None:
            cls._finalise(request, ApprovalState.APPROVED, actor=initiated_by)
        else:
            cls._activate_step(request, first_step)
        return request

    # ---- approver actions ---------------------------------------------------
    @classmethod
    @transaction.atomic
    def act(cls, *, task_id, actor, action, comment=""):
        task = (
            ApprovalTask.objects.select_for_update()
            .select_related("request", "step")
            .get(pk=task_id)
        )
        request = task.request

        if task.assignee_id != getattr(actor, "pk", None):
            raise PermissionDenied("You are not the assignee of this task.")
        if task.status != TaskStatus.PENDING:
            raise ApprovalError("Task already actioned.")
        if request.is_terminal:
            raise ApprovalError("Request is already closed.")

        task.comment = comment
        task.acted_at = timezone.now()

        if action == ApprovalAction.APPROVE:
            task.status = TaskStatus.APPROVED
        elif action == ApprovalAction.REJECT:
            task.status = TaskStatus.REJECTED
        elif action == ApprovalAction.REQUEST_CHANGES:
            task.status = TaskStatus.PENDING  # stays open, sender notified
        else:
            raise ApprovalError(f"Unsupported action '{action}' for act().")
        task.save()

        cls._log(
            request, actor=actor, action=action, task=task,
            from_state=request.state, to_state=request.state, comment=comment,
        )

        if action == ApprovalAction.REQUEST_CHANGES:
            notify(request.initiated_by, "changes_requested", target=request)
            request.state = ApprovalState.UNDER_REVIEW
            request.save(update_fields=["state", "updated_at"])
            return request

        cls._evaluate_step(request)
        from .signals import task_acted
        task_acted.send(sender=cls, request=request, task=task, action=action)
        return request

    @classmethod
    @transaction.atomic
    def delegate(cls, *, task_id, actor, to_user, comment=""):
        task = ApprovalTask.objects.select_for_update().get(pk=task_id)
        if task.assignee_id != getattr(actor, "pk", None):
            raise PermissionDenied("Only the assignee may delegate.")
        if not task.step.allow_delegation:
            raise ApprovalError("Delegation disabled for this step.")
        task.status = TaskStatus.DELEGATED
        task.acted_at = timezone.now()
        task.save()
        new_task = ApprovalTask.objects.create(
            request=task.request, step=task.step, assignee=to_user,
            delegated_from=actor,
        )
        cls._log(
            task.request, actor=actor, action=ApprovalAction.DELEGATE, task=task,
            comment=f"Delegated to user {to_user.pk}. {comment}",
        )
        notify(to_user, "task_assigned", target=task.request)
        return new_task

    @classmethod
    @transaction.atomic
    def escalate(cls, *, request_id, actor=None, comment="SLA breach"):
        request = ApprovalRequest.objects.select_for_update().get(pk=request_id)
        if request.is_terminal or request.current_step is None:
            return request
        target_order = request.current_step.escalate_to_step_order
        cls._log(
            request, actor=actor, action=ApprovalAction.ESCALATE,
            comment=comment,
        )
        if target_order is None:
            # No fallback configured: re-notify current assignees.
            for t in request.tasks.filter(
                step=request.current_step, status=TaskStatus.PENDING
            ):
                notify(t.assignee, "task_escalated", target=request)
            return request
        target = request.workflow.steps.filter(order=target_order).first()
        if target:
            request.tasks.filter(
                step=request.current_step, status=TaskStatus.PENDING
            ).update(status=TaskStatus.ESCALATED)
            cls._activate_step(request, target)
        return request

    @classmethod
    @transaction.atomic
    def cancel(cls, *, request_id, actor, comment=""):
        request = ApprovalRequest.objects.select_for_update().get(pk=request_id)
        if request.is_terminal:
            raise ApprovalError("Already closed.")
        cls._finalise(request, ApprovalState.CANCELLED, actor=actor, comment=comment)
        return request

    # ---- internals ----------------------------------------------------------
    @staticmethod
    def _detail_payload(request):
        """description + ordered [label, value] rows from the request context and
        the subject, shared by the console and the emails."""
        ctx = request.context or {}
        description = ctx.get("description") or ""
        details = ctx.get("details")
        if not isinstance(details, dict):
            details = {k: v for k, v in ctx.items() if k != "description"}
        rows = [[str(k), str(v)] for k, v in details.items()]
        seen = {str(k) for k, _ in details.items()}
        as_dict = getattr(request.subject, "as_dict", None)
        if callable(as_dict):
            try:
                for k, v in as_dict().items():
                    if str(k) not in seen:
                        seen.add(str(k))
                        rows.append([str(k), str(v)])
            except Exception:
                pass
        return description, rows

    @classmethod
    def _activate_step(cls, request, step):
        request.current_step = step
        request.state = ApprovalState.UNDER_REVIEW
        request.save(update_fields=["current_step", "state", "updated_at"])

        assignees = cls._resolve_assignees(step, request)
        if not assignees:
            # Nobody to approve -> auto-advance to keep the chain moving.
            cls._advance_or_finalise(request, step)
            return
        description, details = cls._detail_payload(request)
        route_teams = getattr(request.workflow, "route_to_teams", False)
        base_url = (request.context or {}).get("base_url", "")
        for user in assignees:
            task, _ = ApprovalTask.objects.get_or_create(
                request=request, step=step, assignee=user,
                defaults={"status": TaskStatus.PENDING},
            )
            if request.workflow.notify_approvers:
                # Each approver gets a one-click link to THEIR OWN task (no login).
                action_url = (task_approval_url(task, base_url)
                              or (request.context or {}).get("action_url")
                              or "/api/v1/approval-tasks/")
                notify(user, "task_assigned", target=request, payload={
                    "summary": f"{request.workflow.name}: {request.subject}",
                    "action_url": action_url,
                    "description": description,
                    "details": details,
                })
            if route_teams:
                from django.db import transaction

                from apps.approvals.integrations.tasks import push_approval_to_teams
                transaction.on_commit(
                    lambda tid=task.pk: push_approval_to_teams.delay(tid)
                )

    @classmethod
    def _resolve_assignees(cls, step, request):
        users = []
        for slot in step.approvers.all():
            if slot.kind == ApproverKind.USER and slot.user_id:
                users.append(slot.user)
            elif slot.kind == ApproverKind.GROUP and slot.group_id:
                users.extend(slot.group.user_set.all())
            elif slot.kind == ApproverKind.DYNAMIC:
                users.extend(
                    resolvers.resolve(
                        slot.resolver_key, subject=request.subject, request=request
                    )
                )
        # de-dupe preserving order
        seen, unique = set(), []
        for u in users:
            if u and u.pk not in seen:
                seen.add(u.pk)
                unique.append(u)
        return unique

    @classmethod
    def _evaluate_step(cls, request):
        step = request.current_step
        tasks = list(request.tasks.filter(step=step))
        approved = [t for t in tasks if t.status == TaskStatus.APPROVED]
        rejected = [t for t in tasks if t.status == TaskStatus.REJECTED]
        active = [t for t in tasks if t.status == TaskStatus.PENDING]

        if rejected and step.policy in (ApprovalPolicy.ALL, ApprovalPolicy.ANY):
            cls._finalise(request, ApprovalState.REJECTED, actor=rejected[0].assignee)
            return

        satisfied = False
        if step.policy == ApprovalPolicy.ANY:
            satisfied = len(approved) >= 1
        elif step.policy == ApprovalPolicy.ALL:
            satisfied = len(active) == 0 and not rejected
        elif step.policy == ApprovalPolicy.QUORUM:
            satisfied = len(approved) >= step.quorum_count

        if satisfied:
            cls._advance_or_finalise(request, step)

    @classmethod
    def _advance_or_finalise(cls, request, step):
        cls._fire(request, "on_step_approved", step=step)
        next_step = (
            request.workflow.steps.filter(order__gt=step.order)
            .order_by("order")
            .first()
        )
        if next_step:
            cls._activate_step(request, next_step)
        else:
            cls._finalise(request, ApprovalState.APPROVED, actor=request.initiated_by)

    @classmethod
    def _finalise(cls, request, state, *, actor=None, comment=""):
        from_state = request.state
        request.state = state
        request.decided_at = timezone.now()
        request.current_step = None
        request.save(update_fields=["state", "decided_at", "current_step", "updated_at"])
        cls._log(
            request, actor=actor, action=ApprovalAction.APPROVE
            if state == ApprovalState.APPROVED else ApprovalAction.REJECT,
            from_state=from_state, to_state=state, comment=comment,
        )
        # Fire host-app callbacks + notifications
        cls._run_callbacks(request, state)
        event = {
            ApprovalState.APPROVED: "on_approved",
            ApprovalState.REJECTED: "on_rejected",
            ApprovalState.CANCELLED: "on_cancelled",
        }.get(state)
        if event:
            cls._fire(request, event)
        if request.initiated_by and request.workflow.notify_initiator:
            verb = {
                ApprovalState.APPROVED: "request_approved",
                ApprovalState.REJECTED: "request_rejected",
            }.get(state, f"request_{state}")
            description, details = cls._detail_payload(request)
            notify(request.initiated_by, verb, target=request, payload={
                "summary": f"{request.workflow.name}: {request.subject}",
                "description": description,
                "details": details,
            })

    @classmethod
    def _run_callbacks(cls, request, state):
        from apps.approvals.registry import ApprovalEngine
        from django.utils.module_loading import import_string

        subject = request.subject
        if subject is None:
            return
        reg = ApprovalEngine.registration_for(subject)
        if not reg:
            return
        dotted = reg.on_approved if state == ApprovalState.APPROVED else reg.on_rejected
        if dotted:
            try:
                import_string(dotted)(subject)
            except Exception:  # pragma: no cover - host callback isolation
                pass
