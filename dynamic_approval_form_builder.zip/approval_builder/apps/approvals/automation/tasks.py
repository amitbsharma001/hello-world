from celery import shared_task


@shared_task(bind=True)
def run_action(self, run_id):
    from .dispatcher import execute_run
    from ..models import RunStatus

    run = execute_run(run_id)
    if run.status == RunStatus.FAILED and run.attempts <= run.action.max_retries:
        raise self.retry(
            exc=RuntimeError(run.error or "action failed"),
            countdown=min(60, 10 * run.attempts),
            max_retries=run.action.max_retries,
        )
    return {"run_id": run_id, "status": run.status}
