"""
Build the runtime context for an action and safely template config values.

Config strings may reference context with {placeholders} or {{placeholders}}:
    "https://ci.acme.io/deploy/{subject.pk}?ref={data.git_ref}"
Templating is attribute/item lookup only — no eval, no dunder access.
"""
import re

from django.utils import timezone

_PATTERN = re.compile(r"\{\{?\s*([a-zA-Z0-9_.]+)\s*\}?\}")


def deepget(ctx, dotted):
    cur = ctx
    for part in dotted.split("."):
        if part.startswith("_"):
            return None
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            cur = getattr(cur, part, None)
        if cur is None:
            return None
    return cur


def render(template, ctx):
    if not isinstance(template, str):
        return template

    def repl(m):
        v = deepget(ctx, m.group(1))
        return "" if v is None else str(v)

    return _PATTERN.sub(repl, template)


def render_obj(obj, ctx):
    if isinstance(obj, str):
        return render(obj, ctx)
    if isinstance(obj, dict):
        return {k: render_obj(v, ctx) for k, v in obj.items()}
    if isinstance(obj, list):
        return [render_obj(v, ctx) for v in obj]
    return obj


def build_context(request) -> dict:
    """Assemble everything an action might need from an ApprovalRequest."""
    subject = getattr(request, "subject", None)
    data = {}
    if subject is not None and hasattr(subject, "as_dict"):
        try:
            data = subject.as_dict()
        except Exception:
            data = {}
    return {
        "subject": subject,
        "subject_id": getattr(subject, "pk", None),
        "subject_type": (
            f"{subject._meta.app_label}.{subject._meta.model_name}" if subject else None
        ),
        "data": data,
        "request": request,
        "request_id": getattr(request, "pk", None),
        "workflow": getattr(getattr(request, "workflow", None), "slug", None),
        "state": getattr(request, "state", None),
        "initiated_by": getattr(request, "initiated_by_id", None),
        "now": timezone.now().isoformat(),
    }
