"""
Pluggable action handlers. Each handler declares a `config_schema` (so a UI can
auto-render a form) and an `execute()` that performs the side-effect. New
automations = new handler class + @register_action. Nothing else changes.
"""
from typing import Dict, List, Type

ACTIONS: Dict[str, Type["ActionHandler"]] = {}


def register_action(cls):
    ACTIONS[cls.type_key] = cls
    return cls


def get_handler(key: str):
    cls = ACTIONS.get(key)
    return cls() if cls else None


def list_action_types() -> List[dict]:
    return [
        {
            "type_key": c.type_key,
            "label": c.label,
            "description": c.description,
            "config_schema": c.config_schema,
        }
        for c in sorted(ACTIONS.values(), key=lambda c: c.label)
    ]


def field(name, label, ftype="text", required=False, help="", options=None,
          placeholder="", default=None, secret=False):
    """Describe one config field for the no-code UI."""
    f = {"name": name, "label": label, "type": ftype, "required": required,
         "help": help, "placeholder": placeholder, "secret": secret}
    if options is not None:
        f["options"] = options
    if default is not None:
        f["default"] = default
    return f


class ActionHandler:
    type_key = ""
    label = ""
    description = ""
    config_schema: List[dict] = []

    def validate(self, config: dict):
        missing = [
            f["name"] for f in self.config_schema
            if f.get("required") and not config.get(f["name"]) and f.get("default") is None
        ]
        if missing:
            raise ValueError(f"Missing required config: {', '.join(missing)}")

    def execute(self, *, config: dict, context: dict) -> dict:  # pragma: no cover
        raise NotImplementedError
