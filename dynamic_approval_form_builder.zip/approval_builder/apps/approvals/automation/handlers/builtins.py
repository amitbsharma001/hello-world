"""
Built-in automation handlers.

Add your own by subclassing ActionHandler and decorating with @register_action;
it will instantly appear in the no-code action picker (config_schema drives the
form) with no other wiring.
"""
import json
import logging
from urllib import error as urlerror
from urllib import request as urlrequest

from ..registry import ActionHandler, field, register_action

logger = logging.getLogger("automation")


def _post_json(url, payload, headers=None, method="POST", timeout=10):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urlrequest.Request(url, data=data, method=method,
                             headers={"Content-Type": "application/json", **(headers or {})})
    with urlrequest.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        body = resp.read().decode("utf-8", "replace")[:2000]
        return resp.status, body


@register_action
class LogAction(ActionHandler):
    """No-op that records a message — handy for testing and dry runs."""
    type_key = "log"
    label = "Log a message"
    description = "Write a templated message to the run output. Safe, no side effects."
    config_schema = [field("message", "Message", "textarea", required=True,
                           placeholder="Approved: {subject_type} #{subject_id}")]

    def execute(self, *, config, context):
        msg = config.get("message", "")
        logger.info("automation.log: %s", msg)
        return {"message": msg}


@register_action
class WebhookAction(ActionHandler):
    """POST/PUT/GET an arbitrary endpoint with a templated JSON body."""
    type_key = "webhook"
    label = "Call a webhook"
    description = "Send an HTTP request to any URL when the event fires."
    config_schema = [
        field("url", "URL", "text", required=True, placeholder="https://hooks.acme.io/approved"),
        field("method", "Method", "select", options=["POST", "PUT", "GET"], default="POST"),
        field("headers", "Headers (JSON)", "json", help="e.g. {\"Authorization\": \"Bearer ...\"}"),
        field("body", "Body (JSON)", "json", help="Templated with {placeholders}"),
    ]

    def execute(self, *, config, context):
        method = (config.get("method") or "POST").upper()
        headers = config.get("headers") or {}
        body = config.get("body") if method != "GET" else None
        status, resp = _post_json(config["url"], body, headers=headers, method=method)
        if status >= 400:
            raise RuntimeError(f"Webhook returned HTTP {status}: {resp[:200]}")
        return {"status_code": status, "response": resp[:500]}


@register_action
class DeployAction(ActionHandler):
    """Trigger a CI/CD deployment (GitHub Actions, GitLab, Jenkins, or generic)."""
    type_key = "deploy"
    label = "Deploy code / trigger CI-CD"
    description = "Kick off a pipeline once approvals are complete."
    config_schema = [
        field("provider", "Provider", "select",
              options=["github_actions", "gitlab", "jenkins", "generic"],
              required=True, default="github_actions"),
        field("url", "Endpoint URL", "text", required=True,
              help="GitHub: https://api.github.com/repos/OWNER/REPO/actions/workflows/FILE/dispatches"),
        field("ref", "Git ref / branch", "text", default="main"),
        field("token", "API token", "text", secret=True, required=True),
        field("inputs", "Inputs (JSON)", "json", help="Pipeline parameters, templated"),
    ]

    def execute(self, *, config, context):
        provider = config.get("provider", "generic")
        token = config.get("token", "")
        ref = config.get("ref") or "main"
        inputs = config.get("inputs") or {}
        url = config["url"]
        if provider == "github_actions":
            payload = {"ref": ref, "inputs": {k: str(v) for k, v in inputs.items()}}
            headers = {"Authorization": f"Bearer {token}",
                       "Accept": "application/vnd.github+json"}
        elif provider == "gitlab":
            payload = {"ref": ref, "variables": inputs}
            headers = {"PRIVATE-TOKEN": token}
        elif provider == "jenkins":
            payload = {"parameter": [{"name": k, "value": v} for k, v in inputs.items()]}
            headers = {"Authorization": f"Bearer {token}"}
        else:
            payload = {"ref": ref, "inputs": inputs}
            headers = {"Authorization": f"Bearer {token}"}
        status, resp = _post_json(url, payload, headers=headers, method="POST")
        if status >= 400:
            raise RuntimeError(f"Deploy ({provider}) failed HTTP {status}: {resp[:200]}")
        return {"provider": provider, "status_code": status, "ref": ref}


@register_action
class TriggerWorkflowAction(ActionHandler):
    """Chain into another approval workflow on the same subject (or a related one)."""
    type_key = "trigger_workflow"
    label = "Trigger another workflow"
    description = "Start a new approval (e.g. onboarding -> provisioning) when this one finishes."
    config_schema = [
        field("target_workflow", "Target workflow slug", "text", required=True,
              placeholder="vendor_provisioning"),
        field("subject", "Subject", "select",
              options=["same_subject"], default="same_subject",
              help="Start the new workflow on the same object that was just approved."),
    ]

    def execute(self, *, config, context):
        from apps.approvals.registry import ApprovalEngine

        subject = context.get("subject")
        if subject is None:
            raise RuntimeError("No subject available to start a chained workflow.")
        req = context.get("request")
        new_req = ApprovalEngine.start(
            instance=subject,
            initiated_by=getattr(req, "initiated_by", None),
            workflow=config["target_workflow"],
        )
        return {"chained_request_id": new_req.pk, "workflow": config["target_workflow"]}


@register_action
class CeleryTaskAction(ActionHandler):
    """Dispatch any Celery task by name — the generic 'run my automation' action."""
    type_key = "celery_task"
    label = "Run a background task"
    description = "Send a named Celery task to your workers with templated args."
    config_schema = [
        field("task_name", "Task name", "text", required=True,
              placeholder="apps.deploy.tasks.rollout"),
        field("args", "Args (JSON list)", "json", help="e.g. [\"{subject_id}\"]"),
        field("kwargs", "Kwargs (JSON object)", "json"),
    ]

    def execute(self, *, config, context):
        from celery import current_app
        from django.conf import settings

        name = config["task_name"]
        args = config.get("args") or []
        kwargs = config.get("kwargs") or {}
        # Honor eager mode (local dev / tests): run a registered task inline.
        if getattr(settings, "CELERY_TASK_ALWAYS_EAGER", False) and name in current_app.tasks:
            res = current_app.tasks[name].apply(args=args, kwargs=kwargs)
            return {"task": name, "task_id": res.id, "eager": True}
        res = current_app.send_task(name, args=args, kwargs=kwargs)
        return {"task": name, "task_id": getattr(res, "id", None)}


@register_action
class NotifyAction(ActionHandler):
    """Notify users (in-app / email / configured channels)."""
    type_key = "notify"
    label = "Notify people"
    description = "Send a notification when the event fires."
    config_schema = [
        field("user_ids", "User IDs (comma-separated)", "text", required=True),
        field("verb", "Message / verb", "text", required=True, default="automation_event"),
    ]

    def execute(self, *, config, context):
        from django.contrib.auth import get_user_model

        from apps.approvals.notifications.dispatcher import notify

        User = get_user_model()
        ids = [int(x) for x in str(config["user_ids"]).replace(" ", "").split(",") if x]
        sent = 0
        for u in User.objects.filter(pk__in=ids):
            notify(u, config.get("verb", "automation_event"), target=context.get("request"))
            sent += 1
        return {"notified": sent}
