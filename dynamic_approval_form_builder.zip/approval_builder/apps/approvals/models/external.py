from django.db import models

from .workflow import TimeStamped

# Preferred display order for known iFlow-transport fields. Any OTHER fields the
# caller sends are shown too (after these), so a different external flow with the
# same `approvers` shape but different metadata just works.
VIEWABLE_FIELDS = [
    "Workflow_Name", "Source_Tenant", "Destination_Tenant", "Package_Id",
    "iFlow_Id", "Version", "Validation_Status", "Scheduled_DateTime",
    "Exception_for_DNCT_Validation",
]

# Structural / control keys that are NOT display fields (handled elsewhere).
CONTROL_KEYS = {
    "approvers", "Result_Callback_URL", "Details", "title", "name", "priority",
    "require_callback_ack", "Require_Callback_Ack", "require_callback_success",
    "Requester_Email", "notify_email", "body",
}


class ExternalApproval(TimeStamped):
    """A request received from an external system (e.g. an iFlow transport).
    Holds the raw payload and where to POST the result once decided."""
    payload = models.JSONField(default=dict)
    result_callback_url = models.URLField(blank=True, default="")
    name = models.CharField(max_length=255, blank=True, default="")
    title = models.CharField(max_length=500, blank=True, default="")
    priority = models.CharField(max_length=20, blank=True, default="Normal")
    outcome = models.CharField(max_length=20, blank=True, default="")
    result_posted = models.BooleanField(default=False)
    require_callback_ack = models.BooleanField(
        default=False,
        help_text="If true, the decision is only confirmed when the result callback returns HTTP 2xx.",
    )
    callback_acked = models.BooleanField(default=False)

    class Meta:
        verbose_name = "External approval"

    def __str__(self):
        return self.title or self.name or f"External approval #{self.pk}"

    @property
    def is_confirmed(self):
        """A decision counts as final unless the caller required an ack and it
        hasn't returned 2xx yet."""
        return (not self.require_callback_ack) or self.callback_acked

    def _display_items(self):
        """Every metadata field worth showing, in order: known fields first (when
        present), then any other custom fields the caller sent. Control keys and
        null values are skipped. Returns a list of (original_key, value)."""
        p = self.payload or {}
        items, seen = [], set()
        for k in VIEWABLE_FIELDS:
            if p.get(k) is not None:
                items.append((k, p.get(k)))
                seen.add(k)
        for k, v in p.items():
            if k in CONTROL_KEYS or k in seen or v is None:
                continue
            items.append((k, v))
            seen.add(k)
        return items

    def as_dict(self):
        """Viewable metadata for the console + approver email (space-formatted keys)."""
        return {k.replace("_", " "): v for k, v in self._display_items()}

    def echo_fields(self):
        """Same fields with their ORIGINAL keys, to echo back in the result callback."""
        return {k: v for k, v in self._display_items()}
