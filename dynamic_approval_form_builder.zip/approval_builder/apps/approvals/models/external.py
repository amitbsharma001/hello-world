from django.db import models

from .workflow import TimeStamped

# Fields from the inbound payload that the approver should SEE (order preserved).
VIEWABLE_FIELDS = [
    "Workflow_Name", "Source_Tenant", "Destination_Tenant", "Package_Id",
    "iFlow_Id", "Version", "Validation_Status", "Scheduled_DateTime",
    "Exception_for_DNCT_Validation",
]


class ExternalApproval(TimeStamped):
    """A request received from an external system (e.g. an iFlow transport).
    Holds the raw payload and where to POST the result once decided."""
    payload = models.JSONField(default=dict)
    result_callback_url = models.URLField(blank=True, default="")
    name = models.CharField(max_length=255, blank=True, default="")
    title = models.CharField(max_length=500, blank=True, default="")
    priority = models.CharField(max_length=20, blank=True, default="Normal")
    outcome = models.CharField(max_length=20, blank=True, default="")
    result_posted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "External approval"

    def __str__(self):
        return self.title or self.name or f"External approval #{self.pk}"

    def as_dict(self):
        """The viewable metadata, shown on the console and in the approver email."""
        p = self.payload or {}
        return {k.replace("_", " "): p.get(k) for k in VIEWABLE_FIELDS if p.get(k) is not None}
