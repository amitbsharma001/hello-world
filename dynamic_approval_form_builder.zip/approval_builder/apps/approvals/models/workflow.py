"""
Generic, reusable workflow definitions.

A WorkflowDefinition is a template that is *decoupled* from any business object.
It is composed of ordered WorkflowSteps. Each step can require one or many
approvers (parallel) governed by an approval policy, which is how we express
SEQUENTIAL, PARALLEL and MIXED workflows with a single model:

    SEQUENTIAL : N steps, each with one approver / policy=ANY
    PARALLEL   : 1 step, M approvers, policy=ALL
    MIXED      : N steps, some of which have M approvers with policy=ALL/QUORUM

The relational rows are the source of truth; `as_graph()` serialises them to the
JSON shape consumed by the React/Mermaid workflow builder.
"""
from django.db import models
from django.utils.text import slugify


class StepType(models.TextChoices):
    SEQUENTIAL = "sequential", "Sequential"
    PARALLEL = "parallel", "Parallel"


class ApprovalPolicy(models.TextChoices):
    ANY = "any", "Any one approver"
    ALL = "all", "All approvers"
    QUORUM = "quorum", "Quorum (N of M)"


class ApproverKind(models.TextChoices):
    USER = "user", "Specific user"
    GROUP = "group", "Group"
    DYNAMIC = "dynamic", "Dynamic resolver"


class TimeStamped(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class WorkflowDefinition(TimeStamped):
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    description = models.TextField(blank=True)
    version = models.PositiveIntegerField(default=1)
    is_active = models.BooleanField(default=True)
    # Free-form graph cache for the visual builder; rebuilt from steps on save.
    graph = models.JSONField(default=dict, blank=True)
    # Managed notifications
    notify_approvers = models.BooleanField(
        default=True, help_text="Email/notify approvers when it becomes their turn."
    )
    notify_initiator = models.BooleanField(
        default=True, help_text="Notify the submitter on the final decision."
    )

    class Meta:
        unique_together = ("slug", "version")
        indexes = [models.Index(fields=["slug", "is_active"])]

    def __str__(self):
        return f"{self.name} v{self.version}"

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def as_graph(self) -> dict:
        """Serialise ordered steps to a directed-graph JSON for the builder."""
        nodes = [{"id": "start", "type": "start", "label": "Start"}]
        edges = []
        prev = "start"
        for step in self.steps.all().order_by("order"):
            node_id = f"step-{step.pk}"
            nodes.append(
                {
                    "id": node_id,
                    "type": step.step_type,
                    "label": step.name,
                    "policy": step.policy,
                    "approvers": [a.describe() for a in step.approvers.all()],
                }
            )
            edges.append({"source": prev, "target": node_id})
            prev = node_id
        nodes.append({"id": "approved", "type": "end", "label": "Approved"})
        edges.append({"source": prev, "target": "approved"})
        return {"nodes": nodes, "edges": edges}

    def sync_graph(self):
        self.graph = self.as_graph()
        super().save(update_fields=["graph", "updated_at"])


class WorkflowStep(TimeStamped):
    workflow = models.ForeignKey(
        WorkflowDefinition, related_name="steps", on_delete=models.CASCADE
    )
    name = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0)
    step_type = models.CharField(
        max_length=20, choices=StepType.choices, default=StepType.SEQUENTIAL
    )
    policy = models.CharField(
        max_length=20, choices=ApprovalPolicy.choices, default=ApprovalPolicy.ANY
    )
    quorum_count = models.PositiveIntegerField(default=1)
    # SLA & escalation
    sla_hours = models.PositiveIntegerField(null=True, blank=True)
    escalate_to_step_order = models.IntegerField(null=True, blank=True)
    allow_delegation = models.BooleanField(default=True)

    class Meta:
        ordering = ["order"]
        unique_together = ("workflow", "order")

    def __str__(self):
        return f"{self.workflow.slug}:{self.order}:{self.name}"


class StepApprover(models.Model):
    """An approver slot on a step. Resolved into concrete users at runtime."""

    step = models.ForeignKey(
        WorkflowStep, related_name="approvers", on_delete=models.CASCADE
    )
    kind = models.CharField(max_length=20, choices=ApproverKind.choices)
    user = models.ForeignKey(
        "auth.User", null=True, blank=True, on_delete=models.CASCADE
    )
    group = models.ForeignKey(
        "auth.Group", null=True, blank=True, on_delete=models.CASCADE
    )
    # For DYNAMIC: key registered in resolvers.RESOLVERS, e.g. "vendor_account_manager"
    resolver_key = models.CharField(max_length=120, blank=True)

    def describe(self) -> dict:
        return {
            "kind": self.kind,
            "user": self.user_id,
            "group": self.group_id,
            "resolver_key": self.resolver_key,
        }

    def __str__(self):
        return f"{self.kind}:{self.user_id or self.group_id or self.resolver_key}"
