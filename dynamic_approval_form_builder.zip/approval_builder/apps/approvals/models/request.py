"""
Runtime approval objects. ApprovalRequest is bound to ANY subject via a
GenericForeignKey, keeping the engine fully decoupled from business models.

Per-step parallelism is handled with ApprovalTask rows (one per resolved
approver). A step is satisfied when its tasks meet the step's ApprovalPolicy.
"""
from django.conf import settings
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.db import models

from apps.approvals.models import TimeStamped, WorkflowDefinition, WorkflowStep

from ..states import ApprovalAction, ApprovalState, TaskStatus


class ApprovalRequest(TimeStamped):
    # Decoupled subject binding
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.CharField(max_length=255)
    subject = GenericForeignKey("content_type", "object_id")

    workflow = models.ForeignKey(
        WorkflowDefinition, on_delete=models.PROTECT, related_name="requests"
    )
    current_step = models.ForeignKey(
        WorkflowStep, null=True, blank=True, on_delete=models.SET_NULL
    )
    state = models.CharField(
        max_length=20, choices=ApprovalState.choices, default=ApprovalState.DRAFT
    )
    initiated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL,
        related_name="initiated_approvals",
    )
    submitted_at = models.DateTimeField(null=True, blank=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    context = models.JSONField(default=dict, blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["content_type", "object_id"]),
            models.Index(fields=["state"]),
            models.Index(fields=["workflow", "state"]),
        ]

    def __str__(self):
        return f"ApprovalRequest#{self.pk} [{self.state}] {self.workflow.slug}"

    @property
    def is_terminal(self) -> bool:
        from ..states import TERMINAL_STATES
        return self.state in TERMINAL_STATES


class ApprovalTask(TimeStamped):
    request = models.ForeignKey(
        ApprovalRequest, related_name="tasks", on_delete=models.CASCADE
    )
    step = models.ForeignKey(WorkflowStep, on_delete=models.PROTECT)
    assignee = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="approval_tasks"
    )
    status = models.CharField(
        max_length=20, choices=TaskStatus.choices, default=TaskStatus.PENDING
    )
    delegated_from = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="delegated_tasks",
    )
    acted_at = models.DateTimeField(null=True, blank=True)
    comment = models.TextField(blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["assignee", "status"]),
            models.Index(fields=["request", "step"]),
        ]

    def __str__(self):
        return f"Task#{self.pk} {self.assignee_id} [{self.status}]"


class ApprovalActionLog(TimeStamped):
    """Immutable record of every action taken on a request."""

    request = models.ForeignKey(
        ApprovalRequest, related_name="actions", on_delete=models.CASCADE
    )
    task = models.ForeignKey(
        ApprovalTask, null=True, blank=True, on_delete=models.SET_NULL
    )
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL
    )
    action = models.CharField(max_length=20, choices=ApprovalAction.choices)
    from_state = models.CharField(max_length=20, blank=True)
    to_state = models.CharField(max_length=20, blank=True)
    comment = models.TextField(blank=True)
    duration_seconds = models.PositiveIntegerField(null=True, blank=True)

    class Meta:
        ordering = ["created_at"]
