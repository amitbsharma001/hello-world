"""
Flow — the simple, plug-and-play facade over the approval engine.

Define a workflow (steps + approvers + on-approved automation + emails) in one
declarative call, then submit ANY model instance for approval in one line. Use
it from dynamic_forms or any other sub-app with a single import.

    from apps.approvals.flow import Flow

    Flow.define(
        "invoice_approval",
        name="Invoice Approval",
        steps=[
            Flow.step("Manager", approvers=["mgr@acme.com"]),
            Flow.step("Finance", group="Finance", policy="all"),
        ],
        on_approved=Flow.run_task("apps.invoices.tasks.post_to_ledger",
                                  args=["{subject_id}"]),
        notify_approvers=True,          # email approvers when it's their turn
        register_model=Invoice,         # optional: enables Invoice().submit_for_approval()
    )

    req = Flow.submit(invoice, by=request.user)
    Flow.status(invoice)                # 'under_review' | 'approved' | ...

`define()` is idempotent — safe to call on every startup or in a migration.
"""
from dataclasses import dataclass, field
from typing import List, Optional, Union

from django.contrib.auth import get_user_model
from django.db import transaction

User = get_user_model()


@dataclass
class StepSpec:
    name: str
    approvers: List = field(default_factory=list)   # User | username | email
    group: Optional[str] = None
    groups: List[str] = field(default_factory=list)
    dynamic: List[str] = field(default_factory=list)  # resolver keys
    policy: str = "any"                               # any | all | quorum
    quorum: int = 1
    sla_hours: Optional[int] = None
    escalate_to: Optional[int] = None
    allow_delegation: bool = True


@dataclass
class ActionSpec:
    action_type: str
    config: dict = field(default_factory=dict)
    event: str = "on_approved"
    name: Optional[str] = None
    run_async: bool = True
    max_retries: int = 3
    step_order: Optional[int] = None  # for on_step_approved scoping


def _resolve_users(items):
    """Accept User instances, usernames, or emails -> list of User."""
    users = []
    for it in items or []:
        if isinstance(it, User):
            users.append(it)
        elif isinstance(it, str) and "@" in it:
            users.extend(User.objects.filter(email__iexact=it))
        elif isinstance(it, str):
            users.extend(User.objects.filter(username=it))
    return users


class Flow:
    # ---- builders -----------------------------------------------------------
    @staticmethod
    def step(name, *, approvers=None, group=None, groups=None, dynamic=None,
             policy="any", quorum=1, sla_hours=None, escalate_to=None,
             allow_delegation=True) -> StepSpec:
        return StepSpec(name=name, approvers=approvers or [], group=group,
                        groups=groups or [], dynamic=dynamic or [], policy=policy,
                        quorum=quorum, sla_hours=sla_hours, escalate_to=escalate_to,
                        allow_delegation=allow_delegation)

    @staticmethod
    def run_task(task_name, *, args=None, kwargs=None, event="on_approved",
                 name=None, run_async=True, max_retries=3) -> ActionSpec:
        """The headline automation: run a Celery task when the event fires."""
        return ActionSpec(
            action_type="celery_task", event=event, run_async=run_async,
            max_retries=max_retries, name=name or f"task:{task_name}",
            config={"task_name": task_name, "args": args or [], "kwargs": kwargs or {}},
        )

    @staticmethod
    def webhook(url, *, method="POST", headers=None, body=None,
                event="on_approved", name=None) -> ActionSpec:
        return ActionSpec(action_type="webhook", event=event, name=name or "webhook",
                          config={"url": url, "method": method,
                                  "headers": headers or {}, "body": body or {}})

    @staticmethod
    def deploy(url, *, provider="github_actions", ref="main", token="",
               inputs=None, event="on_approved", name=None) -> ActionSpec:
        return ActionSpec(action_type="deploy", event=event, name=name or "deploy",
                          config={"provider": provider, "url": url, "ref": ref,
                                  "token": token, "inputs": inputs or {}})

    @staticmethod
    def trigger(target_workflow, *, event="on_approved", name=None) -> ActionSpec:
        return ActionSpec(action_type="trigger_workflow", event=event,
                          name=name or f"chain:{target_workflow}",
                          config={"target_workflow": target_workflow})

    @staticmethod
    def notify(user_ids, *, verb="automation_event", event="on_approved") -> ActionSpec:
        ids = ",".join(str(u) for u in user_ids)
        return ActionSpec(action_type="notify", event=event, name="notify",
                          config={"user_ids": ids, "verb": verb})

    # ---- define (idempotent) -----------------------------------------------
    @classmethod
    @transaction.atomic
    def define(cls, slug, *, steps, name=None, actions=None, on_approved=None,
               on_rejected=None, on_step=None, notify_approvers=True,
               notify_initiator=True, register_model=None,
               on_approved_callback=None, on_rejected_callback=None):
        from apps.approvals.models import (
            ApproverKind, StepApprover, WorkflowDefinition, WorkflowStep,
        )
        from django.contrib.auth.models import Group

        wf, _ = WorkflowDefinition.objects.update_or_create(
            slug=slug,
            defaults={"name": name or slug.replace("_", " ").title(),
                      "is_active": True, "notify_approvers": notify_approvers,
                      "notify_initiator": notify_initiator},
        )
        wf.steps.all().delete()
        for i, sp in enumerate(steps, start=1):
            step = WorkflowStep.objects.create(
                workflow=wf, order=i, name=sp.name, policy=sp.policy,
                step_type="parallel" if (len(sp.approvers) + len(sp.groups) +
                                         len(sp.dynamic)) > 1 else "sequential",
                quorum_count=sp.quorum, sla_hours=sp.sla_hours,
                escalate_to_step_order=sp.escalate_to,
                allow_delegation=sp.allow_delegation,
            )
            for u in _resolve_users(sp.approvers):
                StepApprover.objects.create(step=step, kind=ApproverKind.USER, user=u)
            for gname in ([sp.group] if sp.group else []) + sp.groups:
                grp = Group.objects.filter(name=gname).first()
                if grp:
                    StepApprover.objects.create(step=step, kind=ApproverKind.GROUP, group=grp)
            for key in sp.dynamic:
                StepApprover.objects.create(step=step, kind=ApproverKind.DYNAMIC, resolver_key=key)
        wf.sync_graph()

        # automation actions
        cls._sync_actions(wf, actions, on_approved, on_rejected, on_step)

        if register_model is not None:
            from .registry import ApprovalEngine
            ApprovalEngine.register(
                model=register_model, workflow=slug,
                on_approved=on_approved_callback, on_rejected=on_rejected_callback,
            )
        return wf

    @staticmethod
    def _sync_actions(wf, actions, on_approved, on_rejected, on_step):
        from apps.approvals.models import AutomationAction

        AutomationAction.objects.filter(workflow=wf).delete()

        def as_list(x):
            if x is None:
                return []
            return x if isinstance(x, (list, tuple)) else [x]

        specs = []
        specs += as_list(actions)
        for sp in as_list(on_approved):
            sp.event = "on_approved"; specs.append(sp)
        for sp in as_list(on_rejected):
            sp.event = "on_rejected"; specs.append(sp)
        for sp in as_list(on_step):
            sp.event = "on_step_approved"; specs.append(sp)

        for order, sp in enumerate(specs):
            step = None
            if sp.step_order:
                step = wf.steps.filter(order=sp.step_order).first()
            AutomationAction.objects.create(
                workflow=wf, step=step, name=sp.name or sp.action_type,
                event=sp.event, action_type=sp.action_type, config=sp.config,
                order=order, run_async=sp.run_async, max_retries=sp.max_retries,
            )

    # ---- runtime ------------------------------------------------------------
    @classmethod
    def submit(cls, instance, *, by=None, workflow=None, context=None):
        from .registry import ApprovalEngine
        return ApprovalEngine.start(instance=instance, initiated_by=by,
                                    workflow=workflow, context=context)

    @classmethod
    def latest(cls, instance):
        from django.contrib.contenttypes.models import ContentType
        from apps.approvals.models import ApprovalRequest
        ct = ContentType.objects.get_for_model(type(instance))
        return (ApprovalRequest.objects
                .filter(content_type=ct, object_id=str(instance.pk))
                .order_by("-created_at").first())

    @classmethod
    def status(cls, instance) -> Optional[str]:
        req = cls.latest(instance)
        return req.state if req else None
