from django.views.decorators.csrf import ensure_csrf_cookie
from django.shortcuts import render
from pathlib import Path

from django.http import HttpResponse
from rest_framework import mixins, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied as DRFPermissionDenied
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import ApprovalActionLog, ApprovalRequest, ApprovalTask
from .services import ApprovalError, ApprovalService, PermissionDenied
from .states import TaskStatus


class ApprovalActionLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalActionLog
        fields = [
            "id", "actor", "action", "from_state", "to_state",
            "comment", "duration_seconds", "created_at",
        ]


class ApprovalTaskSerializer(serializers.ModelSerializer):
    step_name = serializers.CharField(source="step.name", read_only=True)
    workflow = serializers.CharField(source="request.workflow.slug", read_only=True)

    class Meta:
        model = ApprovalTask
        fields = [
            "id", "request", "step", "step_name", "workflow",
            "assignee", "status", "comment", "acted_at", "created_at",
        ]


class ApprovalRequestSerializer(serializers.ModelSerializer):
    actions = ApprovalActionLogSerializer(many=True, read_only=True)
    current_step_name = serializers.CharField(
        source="current_step.name", read_only=True, default=None
    )
    progress = serializers.SerializerMethodField()

    class Meta:
        model = ApprovalRequest
        fields = [
            "id", "workflow", "state", "current_step", "current_step_name",
            "initiated_by", "submitted_at", "decided_at", "expires_at",
            "progress", "actions", "created_at",
        ]

    def get_progress(self, obj):
        total = obj.workflow.steps.count() or 1
        if obj.current_step:
            done = obj.workflow.steps.filter(order__lt=obj.current_step.order).count()
        else:
            done = total if obj.state == "approved" else 0
        return {"completed": done, "total": total, "percent": round(done / total * 100)}


class _ActionInput(serializers.Serializer):
    comment = serializers.CharField(required=False, allow_blank=True, default="")
    to_user = serializers.IntegerField(required=False)


def _initials(name):
    parts = [p for p in str(name).replace(".", " ").split() if p]
    if len(parts) >= 2:
        return (parts[0][0] + parts[1][0]).upper()
    return (str(name)[:2] or "?").upper()


def _hhmm(dt):
    return dt.strftime("%H:%M") if dt else ""


def _fmt(dt):
    return dt.strftime("%Y-%m-%d %H:%M") if dt else ""


_ACTION_VERB = {
    "submit": "Submitted", "approve": "Approved", "reject": "Rejected",
    "request_changes": "Requested changes", "delegate": "Delegated",
    "escalate": "Escalated", "cancel": "Cancelled", "resubmit": "Resubmitted",
}
_PILL = {
    "success": ("#047857", "#ecfdf5"), "failed": ("#be123c", "#fef2f2"),
    "running": ("#b45309", "#fffbeb"), "pending": ("#6b7280", "#f3f4f6"),
    "skipped": ("#6b7280", "#f3f4f6"),
}


def build_console_payload(req, user):
    """Shape one ApprovalRequest into exactly what the lifecycle console renders."""
    steps = list(req.workflow.steps.all().order_by("order"))
    state = req.state
    cur_order = req.current_step.order if req.current_step_id else None
    total = len(steps) or 1
    done_steps = (
        total if state == "approved"
        else (sum(1 for s in steps if cur_order is not None and s.order < cur_order))
    )
    pct = 100 if state == "approved" else round(done_steps / total * 100)

    n_total = len(steps) + 2
    x_at = (lambda i: round(6 + 88 * i / (n_total - 1))) if n_total > 1 else (lambda i: 50)
    nodes = [{"id": "start", "label": "Submitted", "sub": _hhmm(req.submitted_at),
              "x": x_at(0), "y": 50, "state": "done" if req.submitted_at else "active"}]
    for idx, st in enumerate(steps):
        if state == "rejected" and cur_order is not None and st.order == cur_order:
            ns = "rejected"
        elif state == "approved" or (cur_order is not None and st.order < cur_order):
            ns = "done"
        elif cur_order is not None and st.order == cur_order and state in ("under_review", "pending"):
            ns = "active"
        else:
            ns = "pending"
        nodes.append({"id": f"s{st.order}", "label": st.name,
                      "sub": ns if ns in ("done", "rejected") else "",
                      "x": x_at(idx + 1), "y": 50, "state": ns})
    end_state = "done" if state == "approved" else ("rejected" if state == "rejected" else "pending")
    nodes.append({"id": "done", "label": "Approved",
                  "sub": _hhmm(req.decided_at) if state == "approved" else "",
                  "x": x_at(n_total - 1), "y": 50, "state": end_state})
    ids = [n["id"] for n in nodes]
    edges = [[ids[i], ids[i + 1]] for i in range(len(ids) - 1)]

    timeline = []
    for log in req.actions.all():
        dotst = "rejected" if log.to_state == "rejected" else ("info" if not log.actor_id else "done")
        timeline.append([_hhmm(log.created_at), (log.actor.get_username() if log.actor_id else "system"),
                         _ACTION_VERB.get(log.action, log.action.title()), log.comment or "", dotst])

    ctx = req.context or {}
    description = ctx.get("description") or ""
    ctx_details = ctx.get("details")
    if not isinstance(ctx_details, dict):
        ctx_details = {k: v for k, v in ctx.items() if k != "description"}
    data = [[str(k), str(v)] for k, v in ctx_details.items()]
    asd = getattr(req.subject, "as_dict", None)
    if callable(asd):
        try:
            for k, v in asd().items():
                data.append([str(k), str(v)])
        except Exception:
            pass

    automation = []
    for run in req.action_runs.all():
        fg, bg = _PILL.get(run.status, ("#6b7280", "#f3f4f6"))
        automation.append([run.action.name or run.action.action_type, run.action.action_type,
                           run.action.event, run.status, fg, bg])

    appr_step = req.current_step if req.current_step_id else (steps[-1] if steps else None)
    approvers = []
    if appr_step:
        for t in req.tasks.filter(step=appr_step).select_related("assignee", "step"):
            uname = t.assignee.get_username()
            tst = "done" if t.status == "approved" else ("rejected" if t.status == "rejected" else "active")
            approvers.append([_initials(uname), uname, f"{t.step.name} · {t.status}", tst])

    mytask = None
    if req.current_step_id:
        mytask = req.tasks.filter(step=req.current_step, assignee=user, status="pending").first()

    if state == "approved":
        stage = {"name": "Complete", "policy": "—", "progress": "all stages cleared"}
        stage_label = "Approved · automation complete" if automation else "Approved"
    elif state == "rejected":
        nm = req.current_step.name if req.current_step_id else "Rejected"
        stage = {"name": nm, "policy": "—", "progress": "rejected"}
        stage_label = f"Rejected at {nm}"
    else:
        cs = req.current_step
        stage = {"name": cs.name if cs else "—", "policy": (cs.policy if cs else "—"),
                 "progress": f"step {done_steps + 1} of {total}"}
        stage_label = f"Awaiting {cs.name}" if cs else "Pending"

    subj = req.subject
    title = (str(subj) if subj is not None else "") or f"Request #{req.pk}"
    return {
        "id": req.pk, "title": title, "workflow": req.workflow.slug, "state": state,
        "pct": pct, "stageLabel": stage_label, "description": description,
        "initiated_by": req.initiated_by.get_username() if req.initiated_by_id else "system",
        "submitted": _fmt(req.submitted_at or req.created_at),
        "sla": (f"SLA · expires {_fmt(req.expires_at)}" if req.expires_at else ""),
        "nodes": nodes, "edges": edges, "timeline": timeline, "data": data,
        "automation": automation, "approvers": approvers, "stage": stage,
        "canAct": bool(mytask), "taskId": mytask.pk if mytask else None,
    }


class ApprovalRequestViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = ApprovalRequest.objects.select_related("workflow", "current_step").order_by("-created_at")
    serializer_class = ApprovalRequestSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["state", "workflow"]
    ordering_fields = ["created_at", "decided_at"]

    def get_queryset(self):
        """Non-staff users only see requests they're an approver on or initiated."""
        qs = super().get_queryset()
        user = self.request.user
        if user.is_staff:
            return qs
        from django.db.models import Q
        return qs.filter(Q(tasks__assignee=user) | Q(initiated_by=user)).distinct()

    @action(detail=True, methods=["get"])
    def timeline(self, request, pk=None):
        obj = self.get_object()
        return Response(
            ApprovalActionLogSerializer(obj.actions.all(), many=True).data
        )

    @action(detail=False, methods=["get"], url_path="console")
    def console_feed(self, request):
        """Paginated feed in the console's render shape. Non-staff see only requests
        they act on or initiated."""
        from django.db.models import Q

        qs = (ApprovalRequest.objects
              .select_related("workflow", "current_step", "initiated_by", "content_type")
              .prefetch_related("tasks__assignee", "tasks__step", "actions__actor",
                                "action_runs__action", "workflow__steps")
              .order_by("-created_at"))
        if not request.user.is_staff:
            qs = qs.filter(Q(tasks__assignee=request.user) | Q(initiated_by=request.user)).distinct()

        try:
            page = max(1, int(request.query_params.get("page", 1)))
            page_size = min(50, max(1, int(request.query_params.get("page_size", 8))))
        except (TypeError, ValueError):
            page, page_size = 1, 8
        count = qs.count()
        pages = max(1, (count + page_size - 1) // page_size)
        page = min(page, pages)
        start = (page - 1) * page_size
        items = qs[start:start + page_size]
        data = [build_console_payload(r, request.user) for r in items]
        return Response({"results": data, "page": page, "pages": pages, "count": count})

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        try:
            ApprovalService.cancel(
                request_id=self.get_object().pk, actor=request.user,
                comment=request.data.get("comment", ""),
            )
        except ApprovalError as exc:
            raise ValidationError(str(exc))
        return Response({"status": "cancelled"})


class ApprovalTaskViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    serializer_class = ApprovalTaskSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["status", "request"]

    def get_queryset(self):
        qs = ApprovalTask.objects.select_related(
            "request", "step", "assignee"
        ).order_by("-created_at")
        # "My tasks" by default; staff can see all via ?all=1
        if self.request.query_params.get("all") and self.request.user.is_staff:
            return qs
        return qs.filter(assignee=self.request.user)

    def _act(self, request, pk, action_name):
        serializer = _ActionInput(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            ApprovalService.act(
                task_id=pk, actor=request.user, action=action_name,
                comment=serializer.validated_data["comment"],
            )
        except PermissionDenied as exc:
            raise DRFPermissionDenied(str(exc))
        except ApprovalError as exc:
            raise ValidationError(str(exc))
        # Best-effort: close the matching Teams approval so it doesn't linger.
        try:
            from django.db import transaction

            from apps.approvals.integrations import teams
            task = self.get_object()
            if getattr(task, "external_ref", "") and teams.is_enabled():
                transaction.on_commit(lambda: teams.complete_approval(task, action_name))
        except Exception:
            pass
        return Response({"status": action_name})

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        return self._act(request, pk, "approve")

    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        return self._act(request, pk, "reject")

    @action(detail=True, methods=["post"])
    def request_changes(self, request, pk=None):
        return self._act(request, pk, "request_changes")

    @action(detail=True, methods=["post"])
    def delegate(self, request, pk=None):
        from django.contrib.auth import get_user_model

        serializer = _ActionInput(data=request.data)
        serializer.is_valid(raise_exception=True)
        to_id = serializer.validated_data.get("to_user")
        if not to_id:
            raise ValidationError("to_user is required.")
        to_user = get_user_model().objects.filter(pk=to_id).first()
        if not to_user:
            raise ValidationError("Target user not found.")
        try:
            ApprovalService.delegate(
                task_id=pk, actor=request.user, to_user=to_user,
                comment=serializer.validated_data["comment"],
            )
        except (ApprovalError, PermissionDenied) as exc:
            raise ValidationError(str(exc))
        return Response({"status": "delegated"})


@ensure_csrf_cookie
def lifecycle_console(request):
    """Serve the Approval Lifecycle console. Rendered through the template engine
    with @ensure_csrf_cookie so the JS can read the csrftoken cookie and POST
    approve/reject/delegate to the API."""
    return render(request, "approvals/lifecycle.html")

# workflow definition API (CRUD + graph)
from .workflow_views import WorkflowDefinitionViewSet  # noqa: E402,F401
