from pathlib import Path

from django.http import HttpResponse
from rest_framework import mixins, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied as DRFPermissionDenied
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from .models import ApprovalActionLog, ApprovalRequest, ApprovalTask
from .services import ApprovalError, ApprovalService, PermissionDenied
from .states import TaskStatus


class ApprovalActionLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApprovalActionLog
        fields = [
            "id", "actor", "action", "from_state", "to_state",
            "comment", "duration_seconds", "created_at",
        ]


class ApprovalTaskSerializer(serializers.ModelSerializer):
    step_name = serializers.CharField(source="step.name", read_only=True)
    workflow = serializers.CharField(source="request.workflow.slug", read_only=True)

    class Meta:
        model = ApprovalTask
        fields = [
            "id", "request", "step", "step_name", "workflow",
            "assignee", "status", "comment", "acted_at", "created_at",
        ]


class ApprovalRequestSerializer(serializers.ModelSerializer):
    actions = ApprovalActionLogSerializer(many=True, read_only=True)
    current_step_name = serializers.CharField(
        source="current_step.name", read_only=True, default=None
    )
    progress = serializers.SerializerMethodField()

    class Meta:
        model = ApprovalRequest
        fields = [
            "id", "workflow", "state", "current_step", "current_step_name",
            "initiated_by", "submitted_at", "decided_at", "expires_at",
            "progress", "actions", "created_at",
        ]

    def get_progress(self, obj):
        total = obj.workflow.steps.count() or 1
        if obj.current_step:
            done = obj.workflow.steps.filter(order__lt=obj.current_step.order).count()
        else:
            done = total if obj.state == "approved" else 0
        return {"completed": done, "total": total, "percent": round(done / total * 100)}


class _ActionInput(serializers.Serializer):
    comment = serializers.CharField(required=False, allow_blank=True, default="")
    to_user = serializers.IntegerField(required=False)


class ApprovalRequestViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = ApprovalRequest.objects.select_related("workflow", "current_step")
    serializer_class = ApprovalRequestSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["state", "workflow"]
    ordering_fields = ["created_at", "decided_at"]

    @action(detail=True, methods=["get"])
    def timeline(self, request, pk=None):
        obj = self.get_object()
        return Response(
            ApprovalActionLogSerializer(obj.actions.all(), many=True).data
        )

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        try:
            ApprovalService.cancel(
                request_id=self.get_object().pk, actor=request.user,
                comment=request.data.get("comment", ""),
            )
        except ApprovalError as exc:
            raise ValidationError(str(exc))
        return Response({"status": "cancelled"})


class ApprovalTaskViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    serializer_class = ApprovalTaskSerializer
    permission_classes = [IsAuthenticated]
    filterset_fields = ["status", "request"]

    def get_queryset(self):
        qs = ApprovalTask.objects.select_related(
            "request", "step", "assignee"
        ).order_by("-created_at")
        # "My tasks" by default; staff can see all via ?all=1
        if self.request.query_params.get("all") and self.request.user.is_staff:
            return qs
        return qs.filter(assignee=self.request.user)

    def _act(self, request, pk, action_name):
        serializer = _ActionInput(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            ApprovalService.act(
                task_id=pk, actor=request.user, action=action_name,
                comment=serializer.validated_data["comment"],
            )
        except PermissionDenied as exc:
            raise DRFPermissionDenied(str(exc))
        except ApprovalError as exc:
            raise ValidationError(str(exc))
        return Response({"status": action_name})

    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        return self._act(request, pk, "approve")

    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        return self._act(request, pk, "reject")

    @action(detail=True, methods=["post"])
    def request_changes(self, request, pk=None):
        return self._act(request, pk, "request_changes")

    @action(detail=True, methods=["post"])
    def delegate(self, request, pk=None):
        from django.contrib.auth import get_user_model

        serializer = _ActionInput(data=request.data)
        serializer.is_valid(raise_exception=True)
        to_id = serializer.validated_data.get("to_user")
        if not to_id:
            raise ValidationError("to_user is required.")
        to_user = get_user_model().objects.filter(pk=to_id).first()
        if not to_user:
            raise ValidationError("Target user not found.")
        try:
            ApprovalService.delegate(
                task_id=pk, actor=request.user, to_user=to_user,
                comment=serializer.validated_data["comment"],
            )
        except (ApprovalError, PermissionDenied) as exc:
            raise ValidationError(str(exc))
        return Response({"status": "delegated"})


def lifecycle_console(request):
    """Serve the Approval Lifecycle console (self-contained; reads the API via JS).
    Served directly (not through the template engine) so its JS braces are safe."""
    page = Path(__file__).resolve().parent / "templates" / "approvals" / "lifecycle.html"
    return HttpResponse(page.read_text(encoding="utf-8"), content_type="text/html")
