"""Diagnose approval email delivery.

    python manage.py test_approval_email you@example.com

Prints the active email + notification config, then sends a sample approver email
through the real EmailBackend so you can see exactly what happens (and any error).
"""
from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Send a test approval email and print the email/notification config."

    def add_arguments(self, parser):
        parser.add_argument("email", help="Recipient email address")

    def handle(self, *args, **opts):
        to = opts["email"]
        w = self.stdout.write

        w("── Email / notification config ─────────────────────────────")
        w(f"EMAIL_BACKEND          = {getattr(settings, 'EMAIL_BACKEND', '(unset)')}")
        w(f"EMAIL_HOST             = {getattr(settings, 'EMAIL_HOST', '(unset)') or '(empty -> console backend)'}")
        w(f"EMAIL_PORT             = {getattr(settings, 'EMAIL_PORT', '(unset)')}")
        w(f"EMAIL_HOST_USER        = {getattr(settings, 'EMAIL_HOST_USER', '(unset)')}")
        w(f"DEFAULT_FROM_EMAIL     = {getattr(settings, 'DEFAULT_FROM_EMAIL', '(unset)')}")
        w(f"NOTIFICATION_CHANNELS  = {getattr(settings, 'NOTIFICATION_CHANNELS', '(unset)')}")
        w(f"NOTIFICATIONS_USE_CELERY = {getattr(settings, 'NOTIFICATIONS_USE_CELERY', False)}")
        w(f"CELERY_TASK_ALWAYS_EAGER = {getattr(settings, 'CELERY_TASK_ALWAYS_EAGER', False)}")
        channels = getattr(settings, "NOTIFICATION_CHANNELS", [])
        if "email" not in channels:
            w(self.style.ERROR("\n'email' is NOT in NOTIFICATION_CHANNELS — no emails will be sent. "
                               "Set NOTIFICATION_CHANNELS=inapp,email"))

        w("\n── Sending sample approver email via the real backend ──────")
        from apps.approvals.notifications.email_html import build_email
        from django.core.mail import EmailMultiAlternatives
        subject, text_body, html_body = build_email("task_assigned", {
            "summary": "TEST: Approval required",
            "action_url": (getattr(settings, "APP_BASE_URL", "") or "https://example.com") + "/approve/t/TEST/",
            "description": "This is a test email from test_approval_email.",
            "details": [["Source", "diagnostic"], ["When", "now"]],
        })
        msg = EmailMultiAlternatives(
            subject=subject, body=text_body,
            from_email=getattr(settings, "DEFAULT_FROM_EMAIL", "noreply@example.com"), to=[to],
        )
        msg.attach_alternative(html_body, "text/html")
        try:
            sent = msg.send(fail_silently=False)
            w(self.style.SUCCESS(f"\nmsg.send() returned {sent}. "
                                 f"{'Check the inbox.' if getattr(settings,'EMAIL_HOST','') else 'Console backend: the email is printed above/in the server log.'}"))
        except Exception as exc:
            w(self.style.ERROR(f"\nSEND FAILED: {type(exc).__name__}: {exc}"))
            w("Fix the SMTP settings (EMAIL_HOST/PORT/USER/PASSWORD/TLS) and retry.")
