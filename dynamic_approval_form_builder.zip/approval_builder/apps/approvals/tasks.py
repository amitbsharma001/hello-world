# Imported by Celery autodiscover (apps.approvals.tasks) so the shared_tasks
# in the automation/ and notifications/ subpackages get registered.
from .automation import tasks as _automation_tasks  # noqa: F401
from .notifications import tasks as _notification_tasks  # noqa: F401
from apps.approvals.integrations import tasks as _teams_tasks  # noqa: F401
