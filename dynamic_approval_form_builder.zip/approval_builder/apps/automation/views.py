from rest_framework import mixins, serializers, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from .dispatcher import dry_run, execute_run
from .models import ActionRun, AutomationAction
from .registry import ACTIONS, get_handler, list_action_types


class AutomationActionSerializer(serializers.ModelSerializer):
    class Meta:
        model = AutomationAction
        fields = [
            "id", "workflow", "step", "name", "event", "action_type", "config",
            "order", "is_enabled", "run_async", "max_retries", "continue_on_error",
            "created_at", "updated_at",
        ]

    def validate(self, attrs):
        action_type = attrs.get("action_type", getattr(self.instance, "action_type", None))
        config = attrs.get("config", getattr(self.instance, "config", {}))
        if action_type not in ACTIONS:
            raise serializers.ValidationError(
                {"action_type": f"Unknown action type. Choose from: {', '.join(ACTIONS)}"}
            )
        try:
            get_handler(action_type).validate(config or {})
        except ValueError as exc:
            raise serializers.ValidationError({"config": str(exc)})
        return attrs


class ActionRunSerializer(serializers.ModelSerializer):
    action_name = serializers.CharField(source="action.name", read_only=True)
    action_type = serializers.CharField(source="action.action_type", read_only=True)

    class Meta:
        model = ActionRun
        fields = [
            "id", "action", "action_name", "action_type", "request", "status",
            "attempts", "started_at", "finished_at", "output", "error", "created_at",
        ]


class ActionTypeListView(APIView):
    """Powers a no-code UI: every action type + its config form schema."""
    def get(self, request):
        return Response(list_action_types())


class AutomationActionViewSet(viewsets.ModelViewSet):
    queryset = AutomationAction.objects.select_related("workflow", "step")
    serializer_class = AutomationActionSerializer
    filterset_fields = ["workflow", "event", "action_type", "is_enabled"]
    ordering_fields = ["order", "created_at"]

    @action(detail=True, methods=["post"])
    def test(self, request, pk=None):
        """Dry-run this action (no ActionRun persisted). Optional ?request_id=."""
        from apps.approvals.models import ApprovalRequest

        obj = self.get_object()
        rid = request.data.get("request_id") or request.query_params.get("request_id")
        appr = ApprovalRequest.objects.filter(pk=rid).first() if rid else None
        return Response(dry_run(obj, request=appr))


class ActionRunViewSet(
    mixins.ListModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet
):
    queryset = ActionRun.objects.select_related("action")
    serializer_class = ActionRunSerializer
    filterset_fields = ["status", "request", "action"]
    ordering_fields = ["created_at"]

    @action(detail=True, methods=["post"])
    def retry(self, request, pk=None):
        run = execute_run(self.get_object().pk)
        return Response(ActionRunSerializer(run).data)
