"""
fire_event() is the single entry the approval engine calls. It materialises an
ActionRun per matching, enabled AutomationAction and either runs it inline
(run_async=False) or enqueues it on commit (so the worker never sees a row that
the transaction later rolls back).
"""
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from .context import build_context, render_obj
from .models import ActionRun, AutomationAction, RunStatus, TriggerEvent
from .registry import get_handler


def fire_event(request, event, step=None):
    qs = AutomationAction.objects.filter(
        workflow_id=request.workflow_id, event=event, is_enabled=True
    )
    if event == TriggerEvent.ON_STEP_APPROVED and step is not None:
        qs = qs.filter(Q(step=step) | Q(step__isnull=True))

    run_ids = []
    for action in qs.order_by("order"):
        run = ActionRun.objects.create(action=action, request=request, status=RunStatus.PENDING)
        run_ids.append(run.id)
        if action.run_async:
            transaction.on_commit(lambda rid=run.id: _enqueue(rid))
        else:
            execute_run(run.id)
    return run_ids


def _enqueue(run_id):
    try:
        from .tasks import run_action
        run_action.delay(run_id)
    except Exception:
        execute_run(run_id)  # broker unavailable -> run inline


def execute_run(run_id):
    run = ActionRun.objects.select_related("action", "request").get(pk=run_id)
    action = run.action
    run.status = RunStatus.RUNNING
    run.attempts += 1
    run.started_at = timezone.now()
    run.save(update_fields=["status", "attempts", "started_at", "updated_at"])

    try:
        handler = get_handler(action.action_type)
        if handler is None:
            raise ValueError(f"Unknown action type '{action.action_type}'")
        handler.validate(action.config)
        ctx = build_context(run.request) if run.request else {}
        rendered = render_obj(action.config, ctx)
        output = handler.execute(config=rendered, context=ctx) or {}
        run.status, run.output, run.error = RunStatus.SUCCESS, output, ""
    except Exception as exc:
        run.status, run.error = RunStatus.FAILED, str(exc)
    run.finished_at = timezone.now()
    run.save(update_fields=["status", "output", "error", "finished_at", "updated_at"])
    return run


def dry_run(action, request=None):
    """Execute a handler once WITHOUT persisting an ActionRun (UI 'Test' button)."""
    handler = get_handler(action.action_type)
    if handler is None:
        return {"ok": False, "error": f"Unknown action type '{action.action_type}'"}
    try:
        handler.validate(action.config)
        ctx = build_context(request) if request else {"subject": None, "data": {}}
        output = handler.execute(config=render_obj(action.config, ctx), context=ctx) or {}
        return {"ok": True, "output": output}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
