from django.contrib import admin

from .models import ActionRun, AutomationAction


@admin.register(AutomationAction)
class AutomationActionAdmin(admin.ModelAdmin):
    list_display = ("name", "workflow", "event", "action_type", "is_enabled", "order")
    list_filter = ("event", "action_type", "is_enabled")
    search_fields = ("name",)


@admin.register(ActionRun)
class ActionRunAdmin(admin.ModelAdmin):
    list_display = ("id", "action", "status", "attempts", "started_at", "finished_at")
    list_filter = ("status",)
    readonly_fields = [f.name for f in ActionRun._meta.fields]
