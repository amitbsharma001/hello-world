"""
Approval-gated automation.

An AutomationAction binds a configurable side-effect (deploy, webhook, trigger
another workflow, run a task, notify) to a workflow event. When an
ApprovalRequest hits that event (e.g. fully approved), the dispatcher runs every
enabled action in order and records an ActionRun for full observability.

The action is described entirely by data: `action_type` selects a handler from
the registry and `config` is a JSON blob validated against that handler's schema
— so new automations are added in the UI/admin, not in code.
"""
from django.db import models

from apps.workflow_engine.models import TimeStamped, WorkflowDefinition, WorkflowStep


class TriggerEvent(models.TextChoices):
    ON_SUBMIT = "on_submit", "On submit"
    ON_STEP_APPROVED = "on_step_approved", "On step approved"
    ON_APPROVED = "on_approved", "On fully approved"
    ON_REJECTED = "on_rejected", "On rejected"
    ON_CANCELLED = "on_cancelled", "On cancelled"


class RunStatus(models.TextChoices):
    PENDING = "pending", "Pending"
    RUNNING = "running", "Running"
    SUCCESS = "success", "Success"
    FAILED = "failed", "Failed"
    SKIPPED = "skipped", "Skipped"


class AutomationAction(TimeStamped):
    workflow = models.ForeignKey(
        WorkflowDefinition, related_name="actions", on_delete=models.CASCADE
    )
    # Optional: scope an ON_STEP_APPROVED action to one step (blank = any step)
    step = models.ForeignKey(
        WorkflowStep, null=True, blank=True, on_delete=models.CASCADE
    )
    name = models.CharField(max_length=200)
    event = models.CharField(
        max_length=30, choices=TriggerEvent.choices, default=TriggerEvent.ON_APPROVED
    )
    action_type = models.CharField(max_length=60)  # registry key, e.g. "deploy"
    config = models.JSONField(default=dict, blank=True)
    order = models.PositiveIntegerField(default=0)
    is_enabled = models.BooleanField(default=True)
    run_async = models.BooleanField(default=True)
    max_retries = models.PositiveIntegerField(default=3)
    continue_on_error = models.BooleanField(default=True)

    class Meta:
        ordering = ["order"]
        indexes = [models.Index(fields=["workflow", "event", "is_enabled"])]

    def __str__(self):
        return f"{self.name} [{self.action_type}@{self.event}]"


class ActionRun(TimeStamped):
    action = models.ForeignKey(
        AutomationAction, related_name="runs", on_delete=models.CASCADE
    )
    request = models.ForeignKey(
        "approvals.ApprovalRequest", null=True, blank=True,
        related_name="action_runs", on_delete=models.SET_NULL,
    )
    status = models.CharField(
        max_length=20, choices=RunStatus.choices, default=RunStatus.PENDING
    )
    attempts = models.PositiveIntegerField(default=0)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    output = models.JSONField(default=dict, blank=True)
    error = models.TextField(blank=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["status"]), models.Index(fields=["request"])]

    def __str__(self):
        return f"Run#{self.pk} {self.action.action_type} [{self.status}]"
