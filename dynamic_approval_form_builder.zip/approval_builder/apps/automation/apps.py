from django.apps import AppConfig


class AutomationConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.automation"
    label = "automation"
    verbose_name = "Automation"

    def ready(self):
        # import built-in handlers so they register
        from .handlers import builtins  # noqa: F401
