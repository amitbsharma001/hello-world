# Mounting the approvals app into your existing Django project

Your 404 (`Using the URLconf defined in main.urls …`) means the app's routes —
including `/approve/t/<token>/` from the email — were never added to your root
URLconf. Add them with **one line**.

## 1. Make sure the apps are installed

In your project `settings.py`:

```python
INSTALLED_APPS += [
    "rest_framework",
    "apps.approvals",
    "apps.dynamic_forms",
]

MIDDLEWARE += ["apps.approvals.audit.AuditContextMiddleware"]

# Absolute base URL used to build clickable email links (REQUIRED for email approve links)
APP_BASE_URL = "https://si0vm05484.de.bosch.com:444"
```

## 2. Mount the URLs — one line

In your **`main/urls.py`**:

```python
from django.urls import include, path

urlpatterns += [
    path("", include("apps.approvals.app_urls")),
]
```

That single include registers everything:
- `approve/t/<token>/`  ← the per-approver email link that was 404ing
- `forms/approve/<token>/`, `forms/<token>/`, `forms/submission/<uuid>/`
- `approvals/console/`, `forms-builder/`, `form-submissions/`
- `api/v1/...` (incl. `api/v1/external/approvals/`)

### Mount at root, or fix the prefix

Mount at `""` (root) so the email links resolve as-is. If you must mount under a
prefix, set the **same** prefix in settings so the generated links match:

```python
# settings.py
APPROVALS_URL_PREFIX = "approvals-app/"
# main/urls.py
urlpatterns += [path("approvals-app/", include("apps.approvals.app_urls"))]
```

## 3. Verify

1. Visit `https://si0vm05484.de.bosch.com:444/approve/t/test/` — you should now get
   the app's **"link not valid"** page (HTTP 400), **not** the Django 404. That
   proves the route is mounted.
2. Trigger a new approval; the email button URL should start with `APP_BASE_URL`
   and open the approve/reject page.

## Gotchas specific to your setup

- **URL ordering:** your `main.urls` has many patterns (`forms/eai`, `workflow/`,
  `forms/` …). If any is a greedy catch-all, put the `include("apps.approvals.app_urls")`
  line **above** it. In particular, if you already have a `forms/` route, the app's
  `forms/<token>/` could collide — mount the app under a prefix (step 2) to avoid it,
  or order it before your `forms/` include.
- **SSO / login middleware:** the token approve page and public form must be reachable
  **without login**. Your project clearly has auth (SSO, `account/`, `oauth2/`). Add
  `approve/`, `forms/` (and `approvals/console/` only if you want it public) to your
  auth middleware's exempt/allow list, or those links will redirect to login instead
  of approving.
- **Port 444 / host:** the link host resolved fine in your screenshot, so DNS/port are
  OK — the only missing piece is the URL registration above.
