import json

import pytest

from apps.approvals.services import ApprovalService
from apps.approvals.states import ApprovalState, TaskStatus
from apps.dynamic_forms.models import FieldType

pytestmark = pytest.mark.django_db


def test_create_form_with_nested_fields(api, admin_user):
    api.force_authenticate(admin_user)
    payload = {
        "name": "KYC", "category": "compliance",
        "fields": [
            {"label": "PAN Number", "name": "pan_number",
             "field_type": FieldType.TEXT, "required": True},
            {"label": "GST", "name": "gst_number", "field_type": FieldType.TEXT},
        ],
    }
    resp = api.post("/api/v1/forms/", payload, format="json")
    assert resp.status_code == 201, resp.content
    body = resp.json()
    assert body["public_token"]  # auto-generated
    assert len(body["fields"]) == 2


def test_reorder_fields_endpoint(api, admin_user, simple_form):
    api.force_authenticate(admin_user)
    ids = list(simple_form.fields.values_list("id", flat=True))
    reversed_ids = list(reversed(ids))
    resp = api.post(f"/api/v1/forms/{simple_form.id}/reorder/",
                    {"order": reversed_ids}, format="json")
    assert resp.status_code == 200
    new_order = list(
        simple_form.fields.order_by("display_order").values_list("id", flat=True)
    )
    assert new_order == reversed_ids


def test_workflow_graph_endpoint(api, admin_user, workflow_factory, users):
    api.force_authenticate(admin_user)
    wf = workflow_factory("api_wf", [{"name": "Manager", "users": [users["manager"]]}])
    resp = api.get(f"/api/v1/workflows/{wf.id}/graph/")
    assert resp.status_code == 200
    assert {"nodes", "edges"} <= set(resp.json())


def test_my_tasks_listing_and_approve(api, workflow_factory, users):
    wf = workflow_factory("api_tasks", [{"name": "Manager", "users": [users["manager"]]}])
    req = ApprovalService.initiate(
        subject=users["creator"], workflow_slug=wf.slug, initiated_by=users["creator"]
    )
    api.force_authenticate(users["manager"])

    # "My tasks" returns only the manager's task
    resp = api.get("/api/v1/approval-tasks/")
    assert resp.status_code == 200
    results = resp.json()["results"]
    assert len(results) == 1
    task_id = results[0]["id"]

    # Approve via the action endpoint
    resp = api.post(f"/api/v1/approval-tasks/{task_id}/approve/", {}, format="json")
    assert resp.status_code == 200
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED


def test_non_assignee_gets_no_task(api, workflow_factory, users):
    wf = workflow_factory("api_perm", [{"name": "Manager", "users": [users["manager"]]}])
    ApprovalService.initiate(
        subject=users["creator"], workflow_slug=wf.slug, initiated_by=users["creator"]
    )
    api.force_authenticate(users["security"])
    resp = api.get("/api/v1/approval-tasks/")
    assert resp.json()["results"] == []


def test_timeline_endpoint(api, workflow_factory, users):
    wf = workflow_factory("api_tl", [{"name": "Manager", "users": [users["manager"]]}])
    req = ApprovalService.initiate(
        subject=users["creator"], workflow_slug=wf.slug, initiated_by=users["creator"]
    )
    api.force_authenticate(users["manager"])
    resp = api.get(f"/api/v1/approval-requests/{req.id}/timeline/")
    assert resp.status_code == 200
    assert any(a["action"] == "submit" for a in resp.json())


def test_dashboard_requires_admin(api, users):
    api.force_authenticate(users["manager"])
    assert api.get("/api/v1/dashboard/metrics/").status_code == 403


def test_dashboard_metrics_for_admin(api, admin_user, simple_form):
    from apps.dynamic_forms.services import SubmissionService

    SubmissionService.save(
        form=simple_form, data={"customer_name": "A", "email": "a@b.com"},
        meta={"ip": "1.1.1.1"},
    )
    api.force_authenticate(admin_user)
    resp = api.get("/api/v1/dashboard/metrics/")
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_submissions"] == 1
    assert data["pending_approvals"] >= 1


def test_public_form_submit_flow(client, simple_form):
    url = simple_form.public_path
    # GET renders the form + sets csrf cookie
    assert client.get(url).status_code == 200
    # Invalid (bad email) -> 400 with field errors
    bad = client.post(url, {"customer_name": "X", "email": "nope", "_action": "submit"})
    assert bad.status_code == 400
    assert "email" in bad.json()["errors"]
    # Valid -> 201 with submission uuid
    ok = client.post(url, {"customer_name": "X", "email": "x@y.com", "_action": "submit"})
    assert ok.status_code == 201
    assert ok.json()["submission_uuid"]


def test_expired_form_is_closed(client, simple_form):
    from django.utils import timezone
    from datetime import timedelta

    simple_form.expires_at = timezone.now() - timedelta(days=1)
    simple_form.save(update_fields=["expires_at"])
    assert client.get(simple_form.public_path).status_code == 410
