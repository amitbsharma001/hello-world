import pytest
from django.contrib.auth.models import Group

from apps.approvals.flow import Flow
from apps.approvals.services import ApprovalService
from apps.approvals.states import TaskStatus
from apps.dynamic_forms.models import FieldType, FormDefinition, FormField
from apps.dynamic_forms.services import SubmissionService

pytestmark = pytest.mark.django_db


@pytest.fixture
def publication_workflow(users):
    """Reviewer group + the form_publication_approval workflow."""
    grp, _ = Group.objects.get_or_create(name="Form Reviewers")
    users["manager"].groups.add(grp)
    Flow.define(
        "form_publication_approval",
        steps=[Flow.step("Review", group="Form Reviewers", policy="any")],
        notify_approvers=False,
    )
    return grp


def _make_form(creator):
    form = FormDefinition.objects.create(name="Invoice Intake", created_by=creator)
    FormField.objects.create(form=form, label="Vendor", name="vendor",
                             field_type=FieldType.TEXT, required=True, display_order=0)
    FormField.objects.create(form=form, label="Email", name="email",
                             field_type=FieldType.EMAIL, required=True, display_order=1)
    return form


def _approve_publication(form, approver):
    req = form.latest_approval
    req.refresh_from_db()
    task = req.tasks.get(step=req.current_step, assignee=approver, status=TaskStatus.PENDING)
    ApprovalService.act(task_id=task.id, actor=approver, action="approve")


def test_form_not_shareable_until_approved(publication_workflow, users):
    form = _make_form(users["creator"])
    # brand-new form: no approval yet -> not shareable
    assert form.is_open() is False
    assert form.approval_status is None

    form.submit_for_approval(by=users["creator"])
    form.refresh_from_db()
    assert form.approval_status == "under_review"
    assert form.is_open() is False          # still not shareable while pending

    _approve_publication(form, users["manager"])
    form.refresh_from_db()
    assert form.is_approved is True
    assert form.published is True
    assert form.is_open() is True           # now shareable with customers


def test_public_view_blocked_until_published(publication_workflow, users, client):
    form = _make_form(users["creator"])
    url = f"/forms/{form.public_token}/"
    assert client.get(url).status_code == 410          # not published yet

    form.submit_for_approval(by=users["creator"])
    _approve_publication(form, users["manager"])
    form.refresh_from_db()
    assert client.get(url).status_code == 200          # live after approval


def test_customer_submits_and_creator_sees_history(publication_workflow, users, api):
    form = _make_form(users["creator"])
    form.submit_for_approval(by=users["creator"])
    _approve_publication(form, users["manager"])
    form.refresh_from_db()

    # two customer submissions
    SubmissionService.save(form=form, data={"vendor": "Acme", "email": "a@acme.com"},
                           meta={"ip": "1.1.1.1"})
    SubmissionService.save(form=form, data={"vendor": "Globex", "email": "g@globex.com"},
                           meta={"ip": "2.2.2.2"})

    # creator can see the history with who-submitted-what
    api.force_authenticate(users["creator"])
    resp = api.get(f"/api/v1/forms/{form.id}/submissions/")
    assert resp.status_code == 200
    rows = resp.json()
    assert len(rows) == 2
    vendors = {r["values"]["vendor"] for r in rows}
    assert vendors == {"Acme", "Globex"}
    assert {r["submitted_by"] for r in rows} == {"a@acme.com", "g@globex.com"}


def test_history_hidden_from_other_users(publication_workflow, users, api):
    form = _make_form(users["creator"])
    api.force_authenticate(users["security"])     # not creator, not staff
    resp = api.get(f"/api/v1/forms/{form.id}/submissions/")
    assert resp.status_code == 403


def test_admin_can_see_any_history(publication_workflow, users, api, admin_user):
    form = _make_form(users["creator"])
    api.force_authenticate(admin_user)
    resp = api.get(f"/api/v1/forms/{form.id}/submissions/")
    assert resp.status_code == 200
