import pytest

from apps.approvals.models import ApprovalRequest, ApprovalTask
from apps.approvals.services import ApprovalError, ApprovalService, PermissionDenied
from apps.approvals.states import ApprovalState, TaskStatus
from apps.workflow_engine.models import ApprovalPolicy, StepType

pytestmark = pytest.mark.django_db


def _start(wf, subject_user):
    return ApprovalService.initiate(
        subject=subject_user, workflow_slug=wf.slug, initiated_by=subject_user
    )


def _task(req, user):
    return req.tasks.get(step=req.current_step, assignee=user, status=TaskStatus.PENDING)


def test_sequential_chain_advances_and_approves(workflow_factory, users):
    wf = workflow_factory(
        "seq",
        [
            {"name": "Manager", "users": [users["manager"]]},
            {"name": "Director", "users": [users["director"]]},
        ],
    )
    req = _start(wf, users["creator"])
    assert req.state == ApprovalState.UNDER_REVIEW
    assert req.current_step.name == "Manager"

    ApprovalService.act(task_id=_task(req, users["manager"]).id,
                        actor=users["manager"], action="approve")
    req.refresh_from_db()
    assert req.current_step.name == "Director"

    ApprovalService.act(task_id=_task(req, users["director"]).id,
                        actor=users["director"], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED
    assert req.current_step is None
    assert req.decided_at is not None


def test_parallel_all_waits_for_every_approver(workflow_factory, users):
    wf = workflow_factory(
        "par",
        [{
            "name": "Comp+Sec", "type": StepType.PARALLEL,
            "policy": ApprovalPolicy.ALL,
            "users": [users["compliance"], users["security"]],
        }],
    )
    req = _start(wf, users["creator"])
    assert req.tasks.filter(step=req.current_step).count() == 2

    ApprovalService.act(task_id=_task(req, users["compliance"]).id,
                        actor=users["compliance"], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.UNDER_REVIEW  # still waiting on security

    ApprovalService.act(task_id=_task(req, users["security"]).id,
                        actor=users["security"], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED


def test_quorum_policy_two_of_three(workflow_factory, users, admin_user):
    wf = workflow_factory(
        "quorum",
        [{
            "name": "Board", "type": StepType.PARALLEL,
            "policy": ApprovalPolicy.QUORUM, "quorum": 2,
            "users": [users["compliance"], users["security"], users["director"]],
        }],
    )
    req = _start(wf, users["creator"])
    ApprovalService.act(task_id=_task(req, users["compliance"]).id,
                        actor=users["compliance"], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.UNDER_REVIEW  # 1 of 2

    ApprovalService.act(task_id=_task(req, users["security"]).id,
                        actor=users["security"], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED  # quorum reached, director not needed


def test_mixed_workflow(workflow_factory, users):
    wf = workflow_factory(
        "mixed",
        [
            {"name": "Manager", "users": [users["manager"]]},
            {"name": "Comp+Sec", "type": StepType.PARALLEL,
             "policy": ApprovalPolicy.ALL,
             "users": [users["compliance"], users["security"]]},
            {"name": "Director", "users": [users["director"]]},
        ],
    )
    req = _start(wf, users["creator"])
    for u in ["manager", "compliance", "security", "director"]:
        req.refresh_from_db()
        ApprovalService.act(task_id=_task(req, users[u]).id,
                            actor=users[u], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED


def test_rejection_terminates_request(workflow_factory, users):
    wf = workflow_factory("rej", [{"name": "Manager", "users": [users["manager"]]}])
    req = _start(wf, users["creator"])
    ApprovalService.act(task_id=_task(req, users["manager"]).id,
                        actor=users["manager"], action="reject", comment="no")
    req.refresh_from_db()
    assert req.state == ApprovalState.REJECTED
    assert req.is_terminal


def test_non_assignee_cannot_act(workflow_factory, users):
    wf = workflow_factory("perm", [{"name": "Manager", "users": [users["manager"]]}])
    req = _start(wf, users["creator"])
    task = _task(req, users["manager"])
    with pytest.raises(PermissionDenied):
        ApprovalService.act(task_id=task.id, actor=users["security"], action="approve")


def test_cannot_act_on_closed_request(workflow_factory, users):
    wf = workflow_factory("closed", [{"name": "Manager", "users": [users["manager"]]}])
    req = _start(wf, users["creator"])
    task = _task(req, users["manager"])
    ApprovalService.act(task_id=task.id, actor=users["manager"], action="approve")
    with pytest.raises(ApprovalError):
        ApprovalService.act(task_id=task.id, actor=users["manager"], action="approve")


def test_dual_audit_trail_written(workflow_factory, users):
    from apps.audit.models import AuditLog

    wf = workflow_factory("audit", [{"name": "Manager", "users": [users["manager"]]}])
    req = _start(wf, users["creator"])
    ApprovalService.act(task_id=_task(req, users["manager"]).id,
                        actor=users["manager"], action="approve")
    # submit + approve(task) + approve(finalise) => domain action log populated
    assert req.actions.count() >= 2
    assert AuditLog.objects.filter(object_id=str(req.pk)).exists()
