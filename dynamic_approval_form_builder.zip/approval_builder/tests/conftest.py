"""Shared fixtures + a small workflow factory so tests stay declarative."""
import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from apps.dynamic_forms.models import FieldType, FormDefinition, FormField
from apps.workflow_engine.models import (
    ApprovalPolicy,
    ApproverKind,
    StepApprover,
    StepType,
    WorkflowDefinition,
    WorkflowStep,
)

User = get_user_model()


@pytest.fixture
def users(db):
    names = ["manager", "compliance", "security", "director", "creator", "delegate"]
    return {n: User.objects.create_user(n, password="pw") for n in names}


@pytest.fixture
def admin_user(db):
    return User.objects.create_superuser("admin", "admin@example.com", "pw")


@pytest.fixture
def api():
    return APIClient()


def make_workflow(slug, steps, *, name=None):
    """
    steps = [
        {"name": "Manager", "type": "sequential", "policy": "any",
         "users": [user], "quorum": 1, "sla_hours": None, "escalate_to": None,
         "allow_delegation": True},
        ...
    ]
    """
    wf = WorkflowDefinition.objects.create(name=name or slug, slug=slug)
    for i, sd in enumerate(steps, start=1):
        step = WorkflowStep.objects.create(
            workflow=wf,
            order=i,
            name=sd["name"],
            step_type=sd.get("type", StepType.SEQUENTIAL),
            policy=sd.get("policy", ApprovalPolicy.ANY),
            quorum_count=sd.get("quorum", 1),
            sla_hours=sd.get("sla_hours"),
            escalate_to_step_order=sd.get("escalate_to"),
            allow_delegation=sd.get("allow_delegation", True),
        )
        for u in sd.get("users", []):
            StepApprover.objects.create(step=step, kind=ApproverKind.USER, user=u)
        for g in sd.get("groups", []):
            StepApprover.objects.create(step=step, kind=ApproverKind.GROUP, group=g)
        for key in sd.get("dynamic", []):
            StepApprover.objects.create(
                step=step, kind=ApproverKind.DYNAMIC, resolver_key=key
            )
    wf.sync_graph()
    return wf


@pytest.fixture
def workflow_factory(db):
    return make_workflow


@pytest.fixture
def simple_form(db, users):
    """A 1-step (Manager, ANY) workflow + a 2-field form bound to it."""
    wf = make_workflow(
        "form_wf", [{"name": "Manager", "users": [users["manager"]]}]
    )
    form = FormDefinition.objects.create(
        name="Onboarding", workflow=wf, created_by=users["creator"]
    )
    FormField.objects.create(
        form=form, label="Customer Name", name="customer_name",
        field_type=FieldType.TEXT, required=True,
    )
    FormField.objects.create(
        form=form, label="Email", name="email",
        field_type=FieldType.EMAIL, required=True,
    )
    return form
