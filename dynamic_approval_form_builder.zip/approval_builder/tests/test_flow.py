import pytest
from celery import shared_task

from apps.approvals.services import ApprovalService
from apps.approvals.states import TaskStatus
from apps.approvals.models import ActionRun, RunStatus
from apps.approvals.flow import Flow
from apps.approvals.models import WorkflowDefinition

pytestmark = pytest.mark.django_db

# A real Celery task to prove the headline "run task on approval" use case.
TASK_LOG = []


@shared_task(name="tests.flow.record")
def record_task(subject_id=None):
    TASK_LOG.append(subject_id)
    return {"recorded": subject_id}


def _approve_all(req, users):
    """Approve every pending task across every step until terminal."""
    safety = 0
    while True:
        req.refresh_from_db()
        if req.current_step is None:
            break
        pending = list(req.tasks.filter(step=req.current_step, status=TaskStatus.PENDING))
        if not pending:
            break
        for t in pending:
            ApprovalService.act(task_id=t.id, actor=t.assignee, action="approve")
        safety += 1
        assert safety < 20


def test_flow_define_creates_everything(users):
    Flow.define(
        "invoice_approval",
        name="Invoice Approval",
        steps=[
            Flow.step("Manager", approvers=[users["manager"]]),
            Flow.step("Finance", approvers=[users["compliance"], users["security"]],
                      policy="all"),
        ],
        on_approved=Flow.run_task("tests.flow.record", args=["{subject_id}"]),
        notify_approvers=True,
    )
    wf = WorkflowDefinition.objects.get(slug="invoice_approval")
    assert wf.steps.count() == 2
    finance = wf.steps.get(order=2)
    assert finance.step_type == "parallel" and finance.policy == "all"
    assert finance.approvers.count() == 2
    assert wf.actions.filter(action_type="celery_task").count() == 1


def test_flow_define_is_idempotent(users):
    for _ in range(3):
        Flow.define("idem", steps=[Flow.step("M", approvers=[users["manager"]])],
                    on_approved=Flow.run_task("tests.flow.record"))
    assert WorkflowDefinition.objects.filter(slug="idem").count() == 1
    wf = WorkflowDefinition.objects.get(slug="idem")
    assert wf.steps.count() == 1
    assert wf.actions.count() == 1  # not duplicated


def test_run_task_fires_on_approval(users, django_capture_on_commit_callbacks):
    TASK_LOG.clear()
    Flow.define(
        "deploy_flow",
        steps=[Flow.step("Manager", approvers=[users["manager"]])],
        on_approved=Flow.run_task("tests.flow.record", args=["{subject_id}"]),
    )
    subject = users["creator"]
    # async actions enqueue on commit — capture & execute them like production would
    with django_capture_on_commit_callbacks(execute=True):
        req = Flow.submit(subject, by=users["creator"], workflow="deploy_flow")
        _approve_all(req, users)
    req.refresh_from_db()
    assert req.state == "approved"
    run = ActionRun.objects.get(action__action_type="celery_task")
    assert run.status == RunStatus.SUCCESS
    assert TASK_LOG == [str(subject.pk)]


def test_approver_emails_respect_workflow_flag(users, settings, mailoutbox):
    settings.NOTIFICATION_CHANNELS = ["email"]
    users["manager"].email = "manager@acme.com"
    users["manager"].save()

    Flow.define("with_email", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=True)
    Flow.submit(users["creator"], by=users["creator"], workflow="with_email")
    assert any("manager@acme.com" in m.to for m in mailoutbox)

    mailoutbox.clear()
    Flow.define("no_email", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=False)
    Flow.submit(users["creator"], by=users["creator"], workflow="no_email")
    assert mailoutbox == []


def test_approver_resolution_by_email_and_username(users):
    users["director"].email = "dir@acme.com"
    users["director"].save()
    Flow.define("byref", steps=[
        Flow.step("ByEmail", approvers=["dir@acme.com"]),
        Flow.step("ByUsername", approvers=["security"]),
    ])
    wf = WorkflowDefinition.objects.get(slug="byref")
    assert wf.steps.get(order=1).approvers.first().user == users["director"]
    assert wf.steps.get(order=2).approvers.first().user == users["security"]


def test_mixin_on_form_submission(simple_form, users):
    from apps.dynamic_forms.services import SubmissionService

    sub = SubmissionService.save(
        form=simple_form, data={"customer_name": "Acme", "email": "a@b.com"},
        meta={"ip": "1.1.1.1"},
    )
    # ApprovableMixin gives status/helpers for free
    assert sub.approval_status in ("under_review", "pending")
    assert sub.is_approved is False
    assert sub.latest_approval is not None
