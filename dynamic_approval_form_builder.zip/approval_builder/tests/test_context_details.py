import pytest

from apps.approvals.flow import Flow
from apps.approvals.notifications.email_html import build_email
from apps.dynamic_forms.models import FormDefinition

pytestmark = pytest.mark.django_db


def test_context_appears_on_console_and_email(users, api):
    Flow.define("ctx_wf", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=True)
    form = FormDefinition.objects.create(name="Deploy", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="ctx_wf", context={
        "description": "Promote build to production",
        "details": {"Source": "staging", "Destination": "prod", "Version": "v2.4.0"},
    })

    api.force_authenticate(users["manager"])
    row = api.get("/api/v1/approval-requests/console/").json()[0]
    assert row["description"] == "Promote build to production"
    flat = {k: v for k, v in row["data"]}
    assert flat["Source"] == "staging"
    assert flat["Destination"] == "prod"
    assert flat["Version"] == "v2.4.0"


def test_email_includes_description_and_details():
    subj, text, html = build_email("task_assigned", {
        "summary": "Release v2.4.0",
        "description": "Promote build to production",
        "details": [["Source", "staging"], ["Destination", "prod"], ["Version", "v2.4.0"]],
        "action_url": "https://app.example.com/approvals/console/",
    })
    for token in ("Promote build to production", "Source", "staging", "Version", "v2.4.0"):
        assert token in html
        assert token in text
