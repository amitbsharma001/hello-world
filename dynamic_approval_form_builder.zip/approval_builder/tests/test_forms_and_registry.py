import pytest

from apps.dynamic_forms.models import (
    FieldType, FormDefinition, FormField, SubmissionStatus,
)
from apps.dynamic_forms.services import SubmissionService
from apps.dynamic_forms.validators import FieldValidationError, validate_submission
from apps.approvals.registry import ApprovalEngine

pytestmark = pytest.mark.django_db


def _form_with(field_kwargs_list):
    form = FormDefinition.objects.create(name="F")
    for i, kw in enumerate(field_kwargs_list):
        FormField.objects.create(form=form, display_order=i, **kw)
    return form


def test_required_field_rejected_when_blank():
    form = _form_with([
        {"label": "Name", "name": "name", "field_type": FieldType.TEXT, "required": True},
    ])
    with pytest.raises(FieldValidationError) as exc:
        validate_submission(form, {"name": ""})
    assert "name" in exc.value.errors


def test_email_and_number_validation():
    form = _form_with([
        {"label": "Email", "name": "email", "field_type": FieldType.EMAIL, "required": True},
        {"label": "Age", "name": "age", "field_type": FieldType.NUMBER,
         "required": True, "validation_rules": {"min": 18, "max": 99}},
    ])
    with pytest.raises(FieldValidationError) as exc:
        validate_submission(form, {"email": "nope", "age": "5"})
    assert set(exc.value.errors) == {"email", "age"}

    cleaned = validate_submission(form, {"email": "a@b.com", "age": "30"})
    assert cleaned["email"] == "a@b.com"


def test_dropdown_option_enforced():
    form = _form_with([
        {"label": "Plan", "name": "plan", "field_type": FieldType.DROPDOWN,
         "required": True, "options": ["basic", "pro"]},
    ])
    with pytest.raises(FieldValidationError):
        validate_submission(form, {"plan": "enterprise"})
    assert validate_submission(form, {"plan": "pro"})["plan"] == "pro"


def test_multiselect_joins_values():
    form = _form_with([
        {"label": "Tags", "name": "tags", "field_type": FieldType.MULTISELECT,
         "options": ["a", "b", "c"]},
    ])
    cleaned = validate_submission(form, {"tags": ["a", "c"]})
    assert cleaned["tags"] == "a,c"


def test_submission_stores_eav_and_starts_approval(simple_form, users):
    submission = SubmissionService.save(
        form=simple_form,
        data={"customer_name": "Acme", "email": "ops@acme.com"},
        meta={"ip": "1.1.1.1", "user_agent": "ua", "device": "desktop"},
    )
    assert submission.status == SubmissionStatus.IN_APPROVAL
    assert submission.approval_request_id is not None
    assert submission.as_dict() == {"customer_name": "Acme", "email": "ops@acme.com"}


def test_draft_submission_does_not_validate_or_approve(simple_form):
    submission = SubmissionService.save(
        form=simple_form, data={"customer_name": "partial"}, as_draft=True
    )
    assert submission.status == SubmissionStatus.DRAFT
    assert submission.approval_request_id is None


def test_registry_decoupling():
    from apps.dynamic_forms.models import FormSubmission

    # FormSubmission was registered in AppConfig.ready()
    inst = FormSubmission(pk=1)
    assert ApprovalEngine.is_registered(inst)
    reg = ApprovalEngine.registration_for(inst)
    assert reg.workflow_slug == "customer_form_approval"

    # An unregistered model raises a clear error on start()
    from django.contrib.auth.models import Group  # not registered with the engine

    with pytest.raises(ValueError):
        ApprovalEngine.start(instance=Group(pk=1), initiated_by=None)


def test_graph_contract_shape(workflow_factory, users):
    wf = workflow_factory(
        "g",
        [
            {"name": "Manager", "users": [users["manager"]]},
            {"name": "Director", "users": [users["director"]]},
        ],
    )
    graph = wf.as_graph()
    node_types = [n["type"] for n in graph["nodes"]]
    assert node_types[0] == "start" and node_types[-1] == "end"
    # start + 2 steps + end = 4 nodes, 3 edges
    assert len(graph["nodes"]) == 4
    assert len(graph["edges"]) == 3
