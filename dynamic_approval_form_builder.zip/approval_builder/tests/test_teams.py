import pytest

from apps.approvals.flow import Flow
from apps.approvals.integrations import teams
from apps.approvals.models import ApprovalTask
from apps.approvals.states import TaskStatus
from apps.dynamic_forms.models import FormDefinition

pytestmark = pytest.mark.django_db


def test_disabled_by_default_is_noop(users, django_capture_on_commit_callbacks):
    Flow.define("t_off", steps=[Flow.step("Mgr", approvers=[users["manager"]])],
                notify_approvers=False, route_to_teams=True)
    form = FormDefinition.objects.create(name="A", created_by=users["creator"])
    with django_capture_on_commit_callbacks(execute=True):
        Flow.submit(form, by=users["creator"], workflow="t_off")
    # Teams not configured -> task created normally, no external ref
    task = ApprovalTask.objects.get()
    assert task.status == TaskStatus.PENDING
    assert task.external_ref == ""


def test_route_to_teams_creates_external_ref(users, monkeypatch, django_capture_on_commit_callbacks):
    monkeypatch.setattr(teams, "is_enabled", lambda: True)
    captured = {}

    def fake_create(**kwargs):
        captured.update(kwargs)
        return "teams-abc-123"

    monkeypatch.setattr(teams, "create_approval", fake_create)

    Flow.define("t_on", steps=[Flow.step("Mgr", approvers=[users["manager"]])],
                notify_approvers=False, route_to_teams=True)
    form = FormDefinition.objects.create(name="B", created_by=users["creator"])
    with django_capture_on_commit_callbacks(execute=True):
        Flow.submit(form, by=users["creator"], workflow="t_on")

    task = ApprovalTask.objects.get()
    assert task.external_ref == "teams-abc-123"
    assert captured and "title" in captured       # connector was invoked with context


def test_teams_callback_approves(users, api, settings):
    settings.TEAMS_APPROVAL = {"ENABLED": True, "CALLBACK_SECRET": "s3cret",
                               "CREATE_URL": "https://flow.example/x"}
    Flow.define("t_cb", steps=[Flow.step("Mgr", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="C", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="t_cb")
    task = ApprovalTask.objects.get()

    resp = api.post("/api/v1/teams/callback/",
                    {"taskId": task.pk, "decision": "approve", "comment": "ok in Teams"},
                    format="json", HTTP_X_APPROVAL_SECRET="s3cret")
    assert resp.status_code == 200
    task.refresh_from_db()
    assert task.status == TaskStatus.APPROVED
    form.refresh_from_db()
    assert form.published is True          # decision synced; on_approved published the form


def test_teams_callback_rejects_bad_secret(users, api, settings):
    settings.TEAMS_APPROVAL = {"ENABLED": True, "CALLBACK_SECRET": "s3cret",
                               "CREATE_URL": "https://flow.example/x"}
    Flow.define("t_cb2", steps=[Flow.step("Mgr", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="D", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="t_cb2")
    task = ApprovalTask.objects.get()

    resp = api.post("/api/v1/teams/callback/",
                    {"taskId": task.pk, "decision": "approve"},
                    format="json", HTTP_X_APPROVAL_SECRET="wrong")
    assert resp.status_code == 403
    task.refresh_from_db()
    assert task.status == TaskStatus.PENDING
