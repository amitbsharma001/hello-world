import pytest

from apps.approvals.flow import Flow
from apps.dynamic_forms.models import FormDefinition

pytestmark = pytest.mark.django_db


def test_console_feed_returns_render_shape_and_taskid(users, api):
    Flow.define("demo_wf", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="Demo", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="demo_wf")

    api.force_authenticate(users["manager"])
    resp = api.get("/api/v1/approval-requests/console/")
    assert resp.status_code == 200
    rows = resp.json()
    assert rows, "approver should see the pending request"
    row = rows[0]
    # shape the UI renders
    for key in ("id", "title", "workflow", "state", "pct", "nodes", "edges",
                "timeline", "automation", "approvers", "stage", "canAct", "taskId"):
        assert key in row
    assert row["workflow"] == "demo_wf"
    assert row["canAct"] is True and row["taskId"]
    assert row["nodes"][0]["id"] == "start" and row["nodes"][-1]["id"] == "done"

    # acting via the returned taskId works
    resp2 = api.post(f"/api/v1/approval-tasks/{row['taskId']}/approve/")
    assert resp2.status_code == 200


def test_console_feed_hides_others_requests(users, api):
    Flow.define("demo_wf2", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="Demo2", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="demo_wf2")

    # a user with no task and not the initiator sees nothing
    api.force_authenticate(users["security"])
    resp = api.get("/api/v1/approval-requests/console/")
    assert resp.status_code == 200
    assert resp.json() == []
