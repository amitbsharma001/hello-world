import pytest

from apps.approvals.flow import Flow
from apps.dynamic_forms.models import FormDefinition

pytestmark = pytest.mark.django_db


def test_console_feed_returns_render_shape_and_taskid(users, api):
    Flow.define("demo_wf", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="Demo", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="demo_wf")

    api.force_authenticate(users["manager"])
    resp = api.get("/api/v1/approval-requests/console/")
    assert resp.status_code == 200
    rows = resp.json()["results"]
    assert rows, "approver should see the pending request"
    row = rows[0]
    # shape the UI renders
    for key in ("id", "title", "workflow", "state", "pct", "nodes", "edges",
                "timeline", "automation", "approvers", "stage", "canAct", "taskId"):
        assert key in row
    assert row["workflow"] == "demo_wf"
    assert row["canAct"] is True and row["taskId"]
    assert row["nodes"][0]["id"] == "start" and row["nodes"][-1]["id"] == "done"

    # acting via the returned taskId works
    resp2 = api.post(f"/api/v1/approval-tasks/{row['taskId']}/approve/")
    assert resp2.status_code == 200


def test_console_feed_hides_others_requests(users, api):
    Flow.define("demo_wf2", steps=[Flow.step("Manager", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="Demo2", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="demo_wf2")

    # a user with no task and not the initiator sees nothing
    api.force_authenticate(users["security"])
    resp = api.get("/api/v1/approval-requests/console/")
    assert resp.status_code == 200
    assert resp.json()["results"] == []


def test_request_list_scoped_to_user(users, api):
    from apps.approvals.flow import Flow
    from apps.dynamic_forms.models import FormDefinition
    Flow.define("scope_wf", steps=[Flow.step("Mgr", approvers=[users["manager"]])],
                notify_approvers=False)
    form = FormDefinition.objects.create(name="Scoped", created_by=users["creator"])
    Flow.submit(form, by=users["creator"], workflow="scope_wf")

    # an unrelated, non-staff user sees none
    api.force_authenticate(users["security"])
    body = api.get("/api/v1/approval-requests/").json()
    rows = body if isinstance(body, list) else body.get("results", [])
    assert rows == []
    # the approver sees it
    api.force_authenticate(users["manager"])
    body = api.get("/api/v1/approval-requests/").json()
    rows = body if isinstance(body, list) else body.get("results", [])
    assert len(rows) >= 1


def test_console_feed_paginated(users, api):
    from apps.approvals.flow import Flow
    from apps.dynamic_forms.models import FormDefinition
    Flow.define("pg_wf", steps=[Flow.step("Mgr", approvers=[users["manager"]])],
                notify_approvers=False)
    for i in range(11):
        f = FormDefinition.objects.create(name=f"F{i}", created_by=users["creator"])
        Flow.submit(f, by=users["creator"], workflow="pg_wf")
    api.force_authenticate(users["manager"])
    body = api.get("/api/v1/approval-requests/console/?page=1&page_size=8").json()
    assert body["count"] == 11 and body["pages"] == 2 and body["page"] == 1
    assert len(body["results"]) == 8
    body2 = api.get("/api/v1/approval-requests/console/?page=2&page_size=8").json()
    assert len(body2["results"]) == 3
