import pytest
from django.contrib.auth import get_user_model
from django.test import Client

from apps.approvals.services import ApprovalService
from apps.approvals.states import TaskStatus
from apps.dynamic_forms.models import (
    FormDefinition, FormField, FormSubmission, SubmissionStatus,
)
from apps.dynamic_forms.services import SubmissionService, resubmit_submission

pytestmark = pytest.mark.django_db


def _published_form(creator):
    form = FormDefinition.objects.create(
        name="Access Request", created_by=creator,
        is_active=True, published=True, allow_submitter_approver=True,
    )
    FormField.objects.create(form=form, label="Reason", name="reason",
                             field_type="text", required=True, display_order=0)
    return form


def _approver_task(sub):
    from apps.approvals.models import ApprovalRequest
    req = ApprovalRequest.objects.get(pk=sub.approval_request_id)
    return req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)


def test_submitter_names_approver_starts_approval(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(
        form=form, data={"reason": "VPN access"},
        meta={"ip": "1.1.1.1", "approver_email": "boss@acme.com"},
    )
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.IN_APPROVAL
    assert sub.approver_email == "boss@acme.com"
    # approver was provisioned and assigned
    task = _approver_task(sub)
    assert task.assignee.email == "boss@acme.com"


def test_reject_then_correct_and_resubmit(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(
        form=form, data={"reason": "typo here"},
        meta={"approver_email": "boss@acme.com"},
    )
    task = _approver_task(sub)
    # approver rejects with a note
    ApprovalService.act(task_id=task.pk, actor=task.assignee, action="reject",
                        comment="Need a business justification.")
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.REJECTED
    assert sub.rejection_reason == "Need a business justification."

    # submitter corrects and restarts
    resubmit_submission(sub, {"reason": "Access for the audit project, approved by Finance."})
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.IN_APPROVAL
    assert sub.rejection_reason == ""
    # new pending task -> approve -> approved
    task2 = _approver_task(sub)
    ApprovalService.act(task_id=task2.pk, actor=task2.assignee, action="approve")
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.APPROVED


def test_cannot_resubmit_unless_rejected(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(form=form, data={"reason": "x"},
                                 meta={"approver_email": "boss@acme.com"})
    with pytest.raises(ValueError):
        resubmit_submission(sub, {"reason": "y"})   # still in_approval


def test_public_token_approval_page(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(
        form=form, data={"reason": "need it"},
        meta={"approver_email": "boss@acme.com", "base_url": "http://testserver"},
    )
    from django.core import signing
    token = signing.dumps(sub.pk, salt="pub-approval")
    c = Client()
    # GET renders the approve page
    resp = c.get(f"/forms/approve/{token}/")
    assert resp.status_code == 200
    assert b"Approve" in resp.content
    # POST approve acts (CSRF disabled client)
    resp = c.post(f"/forms/approve/{token}/", {"action": "approve", "comment": ""})
    assert resp.status_code == 200
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.APPROVED


def test_submission_status_page(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(form=form, data={"reason": "x"},
                                 meta={"approver_email": "boss@acme.com"})
    c = Client()
    resp = c.get(f"/forms/submission/{sub.submission_uuid}/")
    assert resp.status_code == 200
    assert b"Access Request" in resp.content


def test_multiple_approvers_all_must_approve(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(
        form=form, data={"reason": "need access"},
        meta={"approver_emails": ["a@acme.com", "b@acme.com"]},
    )
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.IN_APPROVAL
    assert sub.approver_emails == ["a@acme.com", "b@acme.com"]

    from apps.approvals.models import ApprovalRequest
    req = ApprovalRequest.objects.get(pk=sub.approval_request_id)
    tasks = list(req.tasks.filter(step=req.current_step, status=TaskStatus.PENDING))
    assert len(tasks) == 2                      # one task per approver, same step

    # first approves -> still in approval (policy = all)
    ApprovalService.act(task_id=tasks[0].pk, actor=tasks[0].assignee, action="approve")
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.IN_APPROVAL
    # second approves -> approved
    ApprovalService.act(task_id=tasks[1].pk, actor=tasks[1].assignee, action="approve")
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.APPROVED


def test_multiple_approvers_comma_string(users):
    form = _published_form(users["creator"])
    sub = SubmissionService.save(
        form=form, data={"reason": "x"},
        meta={"approver_email": "one@acme.com, two@acme.com; three@acme.com"},
    )
    sub.refresh_from_db()
    assert sub.approver_emails == ["one@acme.com", "two@acme.com", "three@acme.com"]


def test_approver_domain_allowlist(users):
    from apps.dynamic_forms.validators import FieldValidationError
    form = _published_form(users["creator"])
    form.approver_domains = ["acme.com"]
    form.save(update_fields=["approver_domains"])
    # disallowed domain rejected, no submission left behind
    with pytest.raises(FieldValidationError):
        SubmissionService.save(form=form, data={"reason": "x"},
                               meta={"approver_email": "boss@gmail.com"})
    assert FormSubmission.objects.filter(form=form).count() == 0
    # allowed domain works
    sub = SubmissionService.save(form=form, data={"reason": "x"},
                                 meta={"approver_email": "boss@acme.com"})
    sub.refresh_from_db()
    assert sub.status == SubmissionStatus.IN_APPROVAL


def test_submission_rate_limit(users):
    from django.core.cache import cache
    cache.clear()
    form = _published_form(users["creator"])
    form.submission_rate_limit = 2
    form.save(update_fields=["submission_rate_limit"])
    c = Client()
    url = f"/forms/{form.public_token}/"
    ok1 = c.post(url, {"reason": "a", "approver_email": "boss@acme.com"})
    ok2 = c.post(url, {"reason": "b", "approver_email": "boss@acme.com"})
    blocked = c.post(url, {"reason": "c", "approver_email": "boss@acme.com"})
    assert ok1.status_code == 201 and ok2.status_code == 201
    assert blocked.status_code == 429


def test_public_form_page_renders(users):
    form = _published_form(users["creator"])
    c = Client()
    resp = c.get(f"/forms/{form.public_token}/")
    assert resp.status_code == 200
    assert b"Vendor" not in resp.content          # our form is "Access Request"
    assert b"Access Request" in resp.content
    assert b"Who should approve this?" in resp.content   # approvers section present
    assert b"csrfmiddlewaretoken" in resp.content        # CSRF cookie/token set


def test_public_form_closed_when_unpublished(users):
    form = FormDefinition.objects.create(name="Draft form", created_by=users["creator"],
                                         is_active=True, published=False)
    c = Client()
    resp = c.get(f"/forms/{form.public_token}/")
    assert resp.status_code == 410
    assert b"isn" in resp.content                  # "isn't available"


def test_public_form_post_creates_submission_with_approvers(users):
    form = _published_form(users["creator"])
    c = Client()
    resp = c.post(f"/forms/{form.public_token}/",
                  {"reason": "need vpn", "approver_email": ["a@acme.com", "b@acme.com"]})
    assert resp.status_code == 201
    body = resp.json()
    assert body["status"] == "in_approval"
    assert "/forms/submission/" in body["status_url"]
    sub = FormSubmission.objects.get(form=form)
    assert sub.approver_emails == ["a@acme.com", "b@acme.com"]
