import pytest

pytestmark = pytest.mark.django_db


def test_console_page_sets_csrf_cookie(client):
    resp = client.get("/approvals/console/")
    assert resp.status_code == 200
    assert "csrftoken" in resp.cookies          # JS needs this to POST actions
    assert b"Approval Lifecycle" in resp.content


def test_builder_page_sets_csrf_cookie(client):
    resp = client.get("/forms-builder/")
    assert resp.status_code == 200
    assert "csrftoken" in resp.cookies
    assert b"Create form" in resp.content


def test_submissions_page_renders(client):
    resp = client.get("/form-submissions/?id=1")
    assert resp.status_code == 200
    assert b"Submissions" in resp.content


@pytest.mark.django_db
def test_submissions_endpoint_records_submitter_and_values(users, api):
    from apps.dynamic_forms.models import FormDefinition, FormField
    from apps.dynamic_forms.services import SubmissionService

    form = FormDefinition.objects.create(name="Survey", created_by=users["creator"])
    FormField.objects.create(form=form, label="Name", name="name", field_type="text", display_order=0)
    SubmissionService.save(form=form, data={"name": "Asha"},
                           meta={"ip": "1.2.3.4", "user": users["manager"]})
    SubmissionService.save(form=form, data={"name": "Ravi"}, meta={"ip": "5.6.7.8"})

    api.force_authenticate(users["creator"])
    body = api.get(f"/api/v1/forms/{form.id}/submissions/").json()
    rows = body if isinstance(body, list) else body.get("results", [])
    assert len(rows) == 2
    submitters = {r["submitted_by"] for r in rows}
    assert users["manager"].get_username() in submitters     # logged-in submitter captured
    assert "anonymous" in submitters                          # anonymous still recorded
    assert any(r["values"].get("name") == "Asha" for r in rows)
