import pytest

pytestmark = pytest.mark.django_db


def test_console_page_sets_csrf_cookie(client):
    resp = client.get("/approvals/console/")
    assert resp.status_code == 200
    assert "csrftoken" in resp.cookies          # JS needs this to POST actions
    assert b"Approval Lifecycle" in resp.content


def test_builder_page_sets_csrf_cookie(client):
    resp = client.get("/forms-builder/")
    assert resp.status_code == 200
    assert "csrftoken" in resp.cookies
    assert b"Create form" in resp.content
