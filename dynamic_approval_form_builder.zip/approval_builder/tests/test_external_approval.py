import json

import pytest

from apps.approvals.integrations import external as ext_mod
from apps.approvals.models import ApprovalRequest, ExternalApproval
from apps.approvals.states import TaskStatus

pytestmark = pytest.mark.django_db

PAYLOAD = {
    "body": {
        "approvers": [
            {"email": "validator@acme.com", "title": "Validation Approval for Iflow: BT120P0"},
            {"email": "customer@acme.com", "title": "Customer Approval for Iflow: BT120P0"},
        ],
        "Scheduled_DateTime": "Not Scheduled",
        "Workflow_Name": "CF_BT120Q0_to_CF_BT120P0_20260518_155414",
        "Source_Tenant": "BT120Q0",
        "Destination_Tenant": "BT120P0",
        "Package_Id": "rb.example.Boost.SalesProjectMgmt",
        "iFlow_Id": "rb.example.Boost.SalesProjectMgmt.OneQ_SPJ_Project_Req.SalesForce",
        "Version": "1.0.0",
        "Validation_Status": "true",
        "Exception_for_DNCT_Validation": None,
        "Details": "From: BT120Q0\nTo: BT120P0\nPackage Id: rb.example.Boost.SalesProjectMgmt",
        "Result_Callback_URL": "https://caller.example/iflow/result",
        "title": "Request for iFlow transport BT120P0",
        "priority": "High",
    }
}


def test_inbound_creates_multistep_approval_with_viewable_fields():
    ext, req = ext_mod.create_from_payload(PAYLOAD, base_url="http://testserver")
    assert isinstance(ext, ExternalApproval)
    # two stages, named by approver title, in order
    steps = list(req.workflow.steps.order_by("order"))
    assert len(steps) == 2
    assert steps[0].name.startswith("Validation Approval")
    assert steps[1].name.startswith("Customer Approval")
    # metadata is viewable
    d = ext.as_dict()
    assert d["Source Tenant"] == "BT120Q0" and d["Destination Tenant"] == "BT120P0"
    assert d["iFlow Id"].endswith("SalesForce")


def test_full_loop_posts_result_document(monkeypatch):
    posted = {}

    def fake_post(url, payload):
        posted["url"] = url
        posted["doc"] = payload
        return 200

    monkeypatch.setattr(ext_mod, "_post_json", fake_post)

    ext, req = ext_mod.create_from_payload(PAYLOAD)
    # approve stage 1, then stage 2
    for _ in range(2):
        req.refresh_from_db()
        task = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        from apps.approvals.services import ApprovalService
        ApprovalService.act(task_id=task.pk, actor=task.assignee, action="approve")

    req.refresh_from_db()
    assert req.state == "approved"
    # result callback fired with the expected shape
    assert posted["url"] == "https://caller.example/iflow/result"
    doc = posted["doc"]
    assert doc["outcome"] == "Approved"
    assert doc["responseSummary"].startswith("All approvers approved")
    assert len(doc["responses"]) == 2
    assert {r["approverResponse"] for r in doc["responses"]} == {"Approve"}
    assert doc["title"] == "Request for iFlow transport BT120P0"
    assert doc["iFlow_Id"].endswith("SalesForce")
    ext.refresh_from_db()
    assert ext.outcome == "Approved" and ext.result_posted is True


def test_inbound_endpoint_requires_secret(api, settings):
    settings.TEAMS_APPROVAL = {"CALLBACK_SECRET": "s3cret"}
    resp = api.post("/api/v1/external/approvals/", PAYLOAD, format="json")
    assert resp.status_code == 403
    resp = api.post("/api/v1/external/approvals/", PAYLOAD, format="json",
                    HTTP_X_APPROVAL_SECRET="s3cret")
    assert resp.status_code == 201
    assert resp.json()["status"] in ("under_review", "pending")


def test_rejection_posts_rejected_outcome(monkeypatch):
    posted = {}
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posted.update({"u": u, "doc": p}) or 200)
    ext, req = ext_mod.create_from_payload(PAYLOAD)
    task = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    from apps.approvals.services import ApprovalService
    ApprovalService.act(task_id=task.pk, actor=task.assignee, action="reject",
                        comment="iFlow validation failed")
    assert posted["doc"]["outcome"] == "Rejected"
    assert "rejected" in posted["doc"]["responseSummary"].lower()


def test_inbound_uses_standalone_secret(api, settings):
    settings.TEAMS_APPROVAL = {}                       # no Teams at all
    settings.EXTERNAL_APPROVAL = {"INBOUND_SECRET": "ext-only"}
    bad = api.post("/api/v1/external/approvals/", PAYLOAD, format="json",
                   HTTP_X_APPROVAL_SECRET="wrong")
    assert bad.status_code == 403
    ok = api.post("/api/v1/external/approvals/", PAYLOAD, format="json",
                  HTTP_X_APPROVAL_SECRET="ext-only")
    assert ok.status_code == 201


def test_progress_callback_fires_per_approver(monkeypatch, django_capture_on_commit_callbacks):
    posts = []
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posts.append(p) or 200)
    ext, req = ext_mod.create_from_payload(PAYLOAD)   # 2 sequential approvers
    from apps.approvals.services import ApprovalService

    # approver 1 -> intermediate progress post (Pending)
    with django_capture_on_commit_callbacks(execute=True):
        req.refresh_from_db()
        t1 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=t1.pk, actor=t1.assignee, action="approve")
    assert posts and posts[-1]["outcome"] == "Pending"
    assert "1 of 2" in posts[-1]["responseSummary"]

    # approver 2 -> final post (Approved)
    with django_capture_on_commit_callbacks(execute=True):
        req.refresh_from_db()
        t2 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=t2.pk, actor=t2.assignee, action="approve")
    assert posts[-1]["outcome"] == "Approved"
    assert len(posts) >= 2          # one per approver


def test_completion_sends_emails(monkeypatch):
    from django.core import mail
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: 200)
    payload = dict(PAYLOAD)
    payload["body"] = dict(PAYLOAD["body"])
    payload["body"]["Requester_Email"] = "requester@acme.com"
    ext, req = ext_mod.create_from_payload(payload)
    from apps.approvals.services import ApprovalService
    for _ in range(2):
        req.refresh_from_db()
        task = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=task.pk, actor=task.assignee, action="approve")
    # approvers + requester emailed the result
    recipients = {r for m in mail.outbox for r in m.to}
    assert "requester@acme.com" in recipients
    assert "validator@acme.com" in recipients and "customer@acme.com" in recipients
    assert any("approved" in m.subject.lower() for m in mail.outbox)


def test_console_details_not_duplicated(users, api):
    ext, req = ext_mod.create_from_payload(PAYLOAD)
    # the named approvers must be staff to fetch, or use staff viewer
    staff = users["creator"]; staff.is_staff = True; staff.save(update_fields=["is_staff"])
    api.force_authenticate(staff)
    body = api.get("/api/v1/approval-requests/console/").json()
    row = next(r for r in body["results"] if r["id"] == req.pk)
    keys = [k for k, v in row["data"]]
    assert len(keys) == len(set(keys)), f"duplicate detail keys: {keys}"
    assert "Source Tenant" in keys and keys.count("Source Tenant") == 1


def _approve_all(req):
    from apps.approvals.services import ApprovalService
    for _ in range(req.workflow.steps.count()):
        req.refresh_from_db()
        t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=t.pk, actor=t.assignee, action="approve")


def test_callback_ack_required_and_2xx_confirms(monkeypatch):
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: 200)   # 2xx
    payload = {"body": {**PAYLOAD["body"], "require_callback_ack": True}}
    ext, req = ext_mod.create_from_payload(payload)
    assert ext.require_callback_ack is True
    _approve_all(req)
    ext.refresh_from_db()
    assert ext.callback_acked is True
    assert ext.is_confirmed is True


def test_callback_ack_required_but_non_2xx_not_confirmed(monkeypatch):
    import urllib.error

    def boom(url, payload):
        raise urllib.error.HTTPError(url, 500, "err", {}, None)
    monkeypatch.setattr(ext_mod, "_post_json", boom)
    payload = {"body": {**PAYLOAD["body"], "require_callback_ack": True}}
    ext, req = ext_mod.create_from_payload(payload)
    _approve_all(req)
    ext.refresh_from_db()
    assert ext.outcome == "Approved"           # approvers did approve
    assert ext.callback_acked is False
    assert ext.is_confirmed is False           # but NOT confirmed (no 2xx)


def test_callback_ack_not_required_is_confirmed_even_on_failure(monkeypatch):
    import urllib.error
    monkeypatch.setattr(ext_mod, "_post_json",
                        lambda u, p: (_ for _ in ()).throw(urllib.error.URLError("down")))
    ext, req = ext_mod.create_from_payload(PAYLOAD)   # require_callback_ack defaults False
    _approve_all(req)
    ext.refresh_from_db()
    assert ext.callback_acked is False
    assert ext.is_confirmed is True            # not gated -> still confirmed


def test_same_email_two_stages_callback_each(monkeypatch, settings):
    """Regression: two stages sharing one approver email must call the callback on
    each decision (intermediate posts inline, not on commit)."""
    from django.core import signing
    from django.test import Client
    settings.APP_BASE_URL = "https://approvals.example.com"
    posts = []
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posts.append(p["outcome"]) or 200)
    dup = {"body": {**PAYLOAD["body"], "approvers": [
        {"email": "same@acme.com", "title": "Validation Approval"},
        {"email": "same@acme.com", "title": "Customer Approval"},
    ]}}
    ext, req = ext_mod.create_from_payload(dup)
    c = Client()
    t1 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    c.post(f"/approve/t/{signing.dumps(t1.pk, salt='task-approval')}/", {"action": "approve"})
    assert posts == ["Pending"]
    req.refresh_from_db()
    t2 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    c.post(f"/approve/t/{signing.dumps(t2.pk, salt='task-approval')}/", {"action": "approve"})
    assert posts == ["Pending", "Approved"]
