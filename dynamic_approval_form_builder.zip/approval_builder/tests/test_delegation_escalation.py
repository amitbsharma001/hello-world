import pytest
from datetime import timedelta

from django.utils import timezone

from apps.approvals.models import ApprovalTask
from apps.approvals.services import ApprovalError, ApprovalService
from apps.approvals.states import ApprovalState, TaskStatus
from apps.approvals import resolvers

pytestmark = pytest.mark.django_db


def _start(wf, u):
    return ApprovalService.initiate(subject=u, workflow_slug=wf.slug, initiated_by=u)


def test_delegation_reassigns_and_completes(workflow_factory, users):
    wf = workflow_factory("deleg", [{"name": "Manager", "users": [users["manager"]]}])
    req = _start(wf, users["creator"])
    task = req.tasks.get(assignee=users["manager"])

    new_task = ApprovalService.delegate(
        task_id=task.id, actor=users["manager"], to_user=users["delegate"]
    )
    task.refresh_from_db()
    assert task.status == TaskStatus.DELEGATED
    assert new_task.assignee == users["delegate"]
    assert new_task.delegated_from == users["manager"]

    ApprovalService.act(task_id=new_task.id, actor=users["delegate"], action="approve")
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED


def test_delegation_blocked_when_disabled(workflow_factory, users):
    wf = workflow_factory(
        "nodeleg",
        [{"name": "Manager", "users": [users["manager"]], "allow_delegation": False}],
    )
    req = _start(wf, users["creator"])
    task = req.tasks.get(assignee=users["manager"])
    with pytest.raises(ApprovalError):
        ApprovalService.delegate(
            task_id=task.id, actor=users["manager"], to_user=users["delegate"]
        )


def test_escalation_moves_to_fallback_step(workflow_factory, users):
    # Step 1 (Manager) escalates to step 2 (Director)
    wf = workflow_factory(
        "esc",
        [
            {"name": "Manager", "users": [users["manager"]],
             "sla_hours": 4, "escalate_to": 2},
            {"name": "Director", "users": [users["director"]]},
        ],
    )
    req = _start(wf, users["creator"])
    assert req.current_step.name == "Manager"

    ApprovalService.escalate(request_id=req.id, comment="manual")
    req.refresh_from_db()
    assert req.current_step.name == "Director"
    # original manager task marked escalated
    assert req.tasks.filter(assignee=users["manager"],
                            status=TaskStatus.ESCALATED).exists()


def test_sla_beat_auto_escalates_overdue(workflow_factory, users):
    from apps.approvals.notifications.tasks import check_sla_escalations

    wf = workflow_factory(
        "sla",
        [
            {"name": "Manager", "users": [users["manager"]],
             "sla_hours": 1, "escalate_to": 2},
            {"name": "Director", "users": [users["director"]]},
        ],
    )
    req = _start(wf, users["creator"])
    # Backdate the pending task beyond its SLA (bypass auto_now_add).
    ApprovalTask.objects.filter(request=req, assignee=users["manager"]).update(
        created_at=timezone.now() - timedelta(hours=3)
    )
    result = check_sla_escalations()
    req.refresh_from_db()
    assert result["escalated"] == 1
    assert req.current_step.name == "Director"


def test_dynamic_resolver_supplies_approver(workflow_factory, users):
    @resolvers.register_resolver("pick_security")
    def _pick(*, subject, request):
        return [users["security"]]

    wf = workflow_factory("dyn", [{"name": "Sec", "dynamic": ["pick_security"]}])
    req = _start(wf, users["creator"])
    assert req.tasks.filter(assignee=users["security"]).exists()
    ApprovalService.act(
        task_id=req.tasks.get(assignee=users["security"]).id,
        actor=users["security"], action="approve",
    )
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED


def test_request_changes_pauses_without_closing(workflow_factory, users):
    wf = workflow_factory("rc", [{"name": "Manager", "users": [users["manager"]]}])
    req = _start(wf, users["creator"])
    task = req.tasks.get(assignee=users["manager"])
    ApprovalService.act(task_id=task.id, actor=users["manager"],
                        action="request_changes", comment="fix it")
    req.refresh_from_db()
    assert req.state == ApprovalState.UNDER_REVIEW
    assert not req.is_terminal
