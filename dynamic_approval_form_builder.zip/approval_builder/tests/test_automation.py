import pytest

from apps.approvals.models import ApprovalRequest
from apps.approvals.services import ApprovalService
from apps.approvals.states import ApprovalState, TaskStatus
from apps.automation.models import ActionRun, AutomationAction, RunStatus, TriggerEvent
from apps.automation.registry import ActionHandler, register_action

pytestmark = pytest.mark.django_db


def _start(wf, user):
    return ApprovalService.initiate(subject=user, workflow_slug=wf.slug, initiated_by=user)


def _approve(req, user):
    req.refresh_from_db()
    t = req.tasks.get(step=req.current_step, assignee=user, status=TaskStatus.PENDING)
    ApprovalService.act(task_id=t.id, actor=user, action="approve")


# A test-only handler that records calls and can be made to fail.
CALLS = []


@register_action
class _SpyAction(ActionHandler):
    type_key = "spy"
    label = "Spy"
    config_schema = []

    def execute(self, *, config, context):
        CALLS.append(context.get("subject_id"))
        if config.get("boom"):
            raise RuntimeError("boom")
        return {"ran": True, "subject_id": context.get("subject_id")}


def test_action_fires_on_full_approval(workflow_factory, users):
    CALLS.clear()
    wf = workflow_factory("auto1", [{"name": "Manager", "users": [users["manager"]]}])
    AutomationAction.objects.create(
        workflow=wf, name="post-approve", event=TriggerEvent.ON_APPROVED,
        action_type="spy", run_async=False,
    )
    req = _start(wf, users["creator"])
    assert ActionRun.objects.count() == 0  # nothing yet
    _approve(req, users["manager"])
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED
    run = ActionRun.objects.get(action__action_type="spy")
    assert run.status == RunStatus.SUCCESS
    assert run.output["ran"] is True


def test_action_does_not_fire_before_approval(workflow_factory, users):
    wf = workflow_factory("auto2", [
        {"name": "Manager", "users": [users["manager"]]},
        {"name": "Director", "users": [users["director"]]},
    ])
    AutomationAction.objects.create(workflow=wf, name="a", event=TriggerEvent.ON_APPROVED,
                                    action_type="log", config={"message": "done"}, run_async=False)
    req = _start(wf, users["creator"])
    _approve(req, users["manager"])  # only first step
    assert not ActionRun.objects.filter(status=RunStatus.SUCCESS).exists()
    _approve(req, users["director"])
    assert ActionRun.objects.filter(status=RunStatus.SUCCESS).count() == 1


def test_step_event_fires_per_step(workflow_factory, users):
    wf = workflow_factory("auto3", [
        {"name": "Manager", "users": [users["manager"]]},
        {"name": "Director", "users": [users["director"]]},
    ])
    AutomationAction.objects.create(workflow=wf, name="step", event=TriggerEvent.ON_STEP_APPROVED,
                                    action_type="log", config={"message": "step {state}"}, run_async=False)
    req = _start(wf, users["creator"])
    _approve(req, users["manager"])
    _approve(req, users["director"])
    assert ActionRun.objects.filter(action__event=TriggerEvent.ON_STEP_APPROVED).count() == 2


def test_trigger_workflow_chains(workflow_factory, users):
    target = workflow_factory("provisioning", [{"name": "Ops", "users": [users["security"]]}])
    src = workflow_factory("onboarding", [{"name": "Manager", "users": [users["manager"]]}])
    AutomationAction.objects.create(
        workflow=src, name="chain", event=TriggerEvent.ON_APPROVED,
        action_type="trigger_workflow", run_async=False,
        config={"target_workflow": "provisioning", "subject": "same_subject"},
    )
    req = _start(src, users["creator"])
    _approve(req, users["manager"])
    # a second ApprovalRequest now exists on the same subject for the provisioning wf
    chained = ApprovalRequest.objects.filter(workflow=target)
    assert chained.count() == 1
    assert chained.first().state == ApprovalState.UNDER_REVIEW


def test_failed_action_is_recorded(workflow_factory, users):
    wf = workflow_factory("auto4", [{"name": "Manager", "users": [users["manager"]]}])
    AutomationAction.objects.create(workflow=wf, name="bad", event=TriggerEvent.ON_APPROVED,
                                    action_type="spy", config={"boom": True}, run_async=False)
    req = _start(wf, users["creator"])
    _approve(req, users["manager"])
    run = ActionRun.objects.get(action__name="bad")
    assert run.status == RunStatus.FAILED
    assert "boom" in run.error
    # approval itself still succeeded — automation failure is isolated
    req.refresh_from_db()
    assert req.state == ApprovalState.APPROVED


def test_context_templating_in_config(workflow_factory, users):
    wf = workflow_factory("auto5", [{"name": "Manager", "users": [users["manager"]]}])
    AutomationAction.objects.create(
        workflow=wf, name="tmpl", event=TriggerEvent.ON_APPROVED,
        action_type="log", run_async=False,
        config={"message": "approved {subject_type} #{subject_id} state={state}"},
    )
    req = _start(wf, users["creator"])
    _approve(req, users["manager"])
    run = ActionRun.objects.get(action__name="tmpl")
    assert f"#{users['creator'].pk}" in run.output["message"]
    assert "state=approved" in run.output["message"]


# ---- API surface (no-code UX) -------------------------------------------------
def test_action_types_schema_endpoint(api, admin_user):
    api.force_authenticate(admin_user)
    resp = api.get("/api/v1/action-types/")
    assert resp.status_code == 200
    types = {t["type_key"] for t in resp.json()}
    assert {"deploy", "webhook", "trigger_workflow", "celery_task", "notify"} <= types
    deploy = next(t for t in resp.json() if t["type_key"] == "deploy")
    assert any(f["name"] == "provider" for f in deploy["config_schema"])


def test_create_action_validates_config(api, admin_user, workflow_factory, users):
    api.force_authenticate(admin_user)
    wf = workflow_factory("apivalid", [{"name": "M", "users": [users["manager"]]}])
    # missing required 'url' for deploy -> 400
    bad = api.post("/api/v1/automation-actions/", {
        "workflow": wf.id, "name": "d", "event": "on_approved",
        "action_type": "deploy", "config": {"provider": "github_actions"},
    }, format="json")
    assert bad.status_code == 400
    # log action with message -> 201
    ok = api.post("/api/v1/automation-actions/", {
        "workflow": wf.id, "name": "l", "event": "on_approved",
        "action_type": "log", "config": {"message": "hi"},
    }, format="json")
    assert ok.status_code == 201


def test_dry_run_endpoint(api, admin_user, workflow_factory, users):
    api.force_authenticate(admin_user)
    wf = workflow_factory("apitest", [{"name": "M", "users": [users["manager"]]}])
    a = AutomationAction.objects.create(workflow=wf, name="t", event=TriggerEvent.ON_APPROVED,
                                        action_type="log", config={"message": "dry {state}"})
    resp = api.post(f"/api/v1/automation-actions/{a.id}/test/", {}, format="json")
    assert resp.status_code == 200
    assert resp.json()["ok"] is True
    # dry-run must NOT persist a run
    assert ActionRun.objects.count() == 0
