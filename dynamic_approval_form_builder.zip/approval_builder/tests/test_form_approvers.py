import pytest

from apps.approvals.models import WorkflowDefinition
from apps.approvals.services import ApprovalService
from apps.approvals.states import TaskStatus
from apps.dynamic_forms.models import ApproverKind, FormApprover, FormDefinition

pytestmark = pytest.mark.django_db


def _form_with_approvers(creator, approvers):
    """approvers: list of (user, step)."""
    form = FormDefinition.objects.create(name="Vendor Intake", created_by=creator)
    for i, (user, step) in enumerate(approvers):
        FormApprover.objects.create(
            form=form, kind=ApproverKind.USER, user=user, step=step, display_order=i
        )
    return form


def _approve_current(req, actor):
    req.refresh_from_db()
    task = req.tasks.get(step=req.current_step, assignee=actor, status=TaskStatus.PENDING)
    ApprovalService.act(task_id=task.id, actor=actor, action="approve")


def test_inline_approvers_build_parallel_step(users, api):
    """Two approvers in the same step -> one parallel step, both must approve."""
    form = _form_with_approvers(users["creator"], [(users["manager"], 1), (users["director"], 1)])
    api.force_authenticate(users["creator"])
    resp = api.post(f"/api/v1/forms/{form.id}/submit-for-approval/")
    assert resp.status_code == 201
    wf = WorkflowDefinition.objects.get(slug=f"form_pub_{form.id}")
    assert wf.steps.count() == 1
    step = wf.steps.first()
    assert step.policy == "all" and step.approvers.count() == 2

    req = form.latest_approval
    _approve_current(req, users["manager"])
    form.refresh_from_db()
    assert form.published is False          # still needs the second approver
    _approve_current(req, users["director"])
    form.refresh_from_db()
    assert form.published is True           # both approved -> published


def test_inline_approvers_sequential_steps(users):
    form = _form_with_approvers(users["creator"], [(users["manager"], 1), (users["director"], 2)])
    from apps.dynamic_forms.services import build_publication_workflow

    slug, unresolved = build_publication_workflow(form)
    assert unresolved == []
    wf = WorkflowDefinition.objects.get(slug=slug)
    assert wf.steps.count() == 2            # two sequential steps

    form.submit_for_approval(by=users["creator"], workflow=slug)
    req = form.latest_approval
    _approve_current(req, users["manager"])     # step 1
    form.refresh_from_db()
    assert form.published is False
    _approve_current(req, users["director"])    # step 2
    form.refresh_from_db()
    assert form.published is True


def test_unresolved_email_is_rejected(users, api):
    form = FormDefinition.objects.create(name="X", created_by=users["creator"])
    FormApprover.objects.create(form=form, kind=ApproverKind.EMAIL,
                                email="ghost@nowhere.com", step=1)
    api.force_authenticate(users["creator"])
    resp = api.post(f"/api/v1/forms/{form.id}/submit-for-approval/")
    assert resp.status_code == 400
    assert "ghost@nowhere.com" in resp.json()["detail"]


def test_no_approvers_is_rejected(users, api):
    form = FormDefinition.objects.create(name="Y", created_by=users["creator"])
    api.force_authenticate(users["creator"])
    resp = api.post(f"/api/v1/forms/{form.id}/submit-for-approval/")
    assert resp.status_code == 400


def test_approvers_authored_via_api(users, api):
    """Create a form with fields AND approvers in one nested POST (like the UI)."""
    users["manager"].email = "mgr@acme.com"; users["manager"].save()
    api.force_authenticate(users["creator"])
    payload = {
        "name": "Onboarding",
        "fields": [{"label": "Vendor", "name": "vendor", "field_type": "text", "required": True}],
        "approvers": [{"kind": "email", "email": "mgr@acme.com", "step": 1}],
    }
    resp = api.post("/api/v1/forms/", payload, format="json")
    assert resp.status_code == 201
    form_id = resp.json()["id"]
    assert len(resp.json()["approvers"]) == 1

    resp = api.post(f"/api/v1/forms/{form_id}/submit-for-approval/")
    assert resp.status_code == 201
    form = FormDefinition.objects.get(pk=form_id)
    _approve_current(form.latest_approval, users["manager"])
    form.refresh_from_db()
    assert form.published is True
