# Why approval emails aren't arriving — debug checklist

Run the built-in diagnostic first:

```
python manage.py test_approval_email you@yourcompany.com
```

It prints the active config and sends a sample approver email through the real
backend, showing any error. Then check, in order:

## 1. Are you using the console backend? (most common)
If the diagnostic prints `EMAIL_BACKEND = ...console.EmailBackend` /
`EMAIL_HOST = (empty …)`, emails are **printed to the server log, not sent**.
Set real SMTP and restart:

```
EMAIL_HOST=smtp.yourcompany.com
EMAIL_PORT=587
EMAIL_HOST_USER=...
EMAIL_HOST_PASSWORD=...
EMAIL_USE_TLS=1            # if your server needs TLS
DEFAULT_FROM_EMAIL="Approvals <approvals@yourcompany.com>"
```

## 2. Is 'email' an enabled channel?
`NOTIFICATION_CHANNELS` must include `email`:
```
NOTIFICATION_CHANNELS=inapp,email
```

## 3. Were notifications stuck in Celery? (fixed)
Notifications now send **synchronously by default**, so a missing Celery worker no
longer silently swallows them. Only set `NOTIFICATIONS_USE_CELERY=1` if you are
actually running a worker (`celery -A config worker -l info`). Previously, with a
broker up but no worker, `.delay()` queued the email and nothing delivered it.

## 4. Does the approver have an email address?
Approvers are users; the email goes to `user.email`. Externally provisioned
approvers get the email from the payload. If a user has no email, the log shows
`Email skipped … recipient has no email address`.

## 5. Read the logs
Email attempts now log on the `approvals` logger:
- success: `Email 'task_assigned' sent to … via … (count=1)`
- failure: `Email '…' to … FAILED via …: <real SMTP error>`
Make sure `LOGGING` is active (it is in this project) and `APPROVALS_LOG_LEVEL=INFO`.

## Notes
- The completion email on **reject**/approve goes to the approvers (+ optional
  `Requester_Email` in the payload). The **task-assignment** email goes to each
  approver when their stage activates. If you see one but not the other, say which.
- SMTP errors were previously swallowed (`fail_silently=True`); they are now logged.
