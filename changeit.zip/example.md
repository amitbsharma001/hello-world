curl -X POST http://localhost:8000/api/v1/external/approvals/1/substitute/ \
  -H "Content-Type: application/json" \
  -d '{"from_email": "outgoing@acme.com", "to_email": "incoming@acme.com"}'
# -> 200 {"status": "substituted", "new_task_id": 8, "new_approver": "incoming@acme.com"}

curl -X POST http://localhost:8000/api/v1/external/approvals/1/substitute/ \
  -H "Content-Type: application/json" \
  -d '{"from_email": "outgoing@acme.com", "to_email": "incoming@acme.com", "reason": "On leave"}'ssss