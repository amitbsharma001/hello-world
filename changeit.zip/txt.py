class ExternalApprovalSubstitute(APIView):
    """Swap the pending approver on an external approval, by EMAIL — the incoming
    approver need not already exist as a user. No authentication required."""
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request, external_id):

        from apps.approvals.integrations.external import substitute_approver
        from apps.approvals.models import ExternalApproval
        # ...unchanged below (find ext, from_email/to_email/reason, call substitute_approver)