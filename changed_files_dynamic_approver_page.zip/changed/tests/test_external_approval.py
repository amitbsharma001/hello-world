import json

import pytest

from apps.approvals.integrations import external as ext_mod
from apps.approvals.models import ApprovalRequest, ExternalApproval
from apps.approvals.states import TaskStatus

pytestmark = pytest.mark.django_db

PAYLOAD = {
    "body": {
        "approvers": [
            {"email": "validator@acme.com", "title": "Validation Approval for Iflow: BT120P0"},
            {"email": "customer@acme.com", "title": "Customer Approval for Iflow: BT120P0"},
        ],
        "Scheduled_DateTime": "Not Scheduled",
        "Workflow_Name": "CF_BT120Q0_to_CF_BT120P0_20260518_155414",
        "Source_Tenant": "BT120Q0",
        "Destination_Tenant": "BT120P0",
        "Package_Id": "rb.example.Boost.SalesProjectMgmt",
        "iFlow_Id": "rb.example.Boost.SalesProjectMgmt.OneQ_SPJ_Project_Req.SalesForce",
        "Version": "1.0.0",
        "Validation_Status": "true",
        "Exception_for_DNCT_Validation": None,
        "Details": "From: BT120Q0\nTo: BT120P0\nPackage Id: rb.example.Boost.SalesProjectMgmt",
        "Result_Callback_URL": "https://caller.example/iflow/result",
        "title": "Request for iFlow transport BT120P0",
        "priority": "High",
    }
}


def test_inbound_creates_multistep_approval_with_viewable_fields():
    ext, req = ext_mod.create_from_payload(PAYLOAD, base_url="http://testserver")
    assert isinstance(ext, ExternalApproval)
    # two stages, named by approver title, in order
    steps = list(req.workflow.steps.order_by("order"))
    assert len(steps) == 2
    assert steps[0].name.startswith("Validation Approval")
    assert steps[1].name.startswith("Customer Approval")
    # metadata is viewable
    d = ext.as_dict()
    assert d["Source Tenant"] == "BT120Q0" and d["Destination Tenant"] == "BT120P0"
    assert d["iFlow Id"].endswith("SalesForce")


def test_full_loop_posts_result_document(monkeypatch):
    posted = {}

    def fake_post(url, payload):
        posted["url"] = url
        posted["doc"] = payload
        return 200

    monkeypatch.setattr(ext_mod, "_post_json", fake_post)

    ext, req = ext_mod.create_from_payload(PAYLOAD)
    # approve stage 1, then stage 2
    for _ in range(2):
        req.refresh_from_db()
        task = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        from apps.approvals.services import ApprovalService
        ApprovalService.act(task_id=task.pk, actor=task.assignee, action="approve")

    req.refresh_from_db()
    assert req.state == "approved"
    # result callback fired with the expected shape
    assert posted["url"] == "https://caller.example/iflow/result"
    doc = posted["doc"]
    assert doc["outcome"] == "Approved"
    assert doc["responseSummary"].startswith("All approvers approved")
    assert len(doc["responses"]) == 2
    assert {r["approverResponse"] for r in doc["responses"]} == {"Approve"}
    assert doc["title"] == "Request for iFlow transport BT120P0"
    assert doc["iFlow_Id"].endswith("SalesForce")
    ext.refresh_from_db()
    assert ext.outcome == "Approved" and ext.result_posted is True


def test_inbound_endpoint_requires_secret(api, settings):
    settings.TEAMS_APPROVAL = {"CALLBACK_SECRET": "s3cret"}
    resp = api.post("/api/v1/external/approvals/", PAYLOAD, format="json")
    assert resp.status_code == 403
    resp = api.post("/api/v1/external/approvals/", PAYLOAD, format="json",
                    HTTP_X_APPROVAL_SECRET="s3cret")
    assert resp.status_code == 201
    assert resp.json()["status"] in ("under_review", "pending")


def test_rejection_posts_rejected_outcome(monkeypatch):
    posted = {}
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posted.update({"u": u, "doc": p}) or 200)
    ext, req = ext_mod.create_from_payload(PAYLOAD)
    task = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    from apps.approvals.services import ApprovalService
    ApprovalService.act(task_id=task.pk, actor=task.assignee, action="reject",
                        comment="iFlow validation failed")
    assert posted["doc"]["outcome"] == "Rejected"
    assert "rejected" in posted["doc"]["responseSummary"].lower()


def test_inbound_uses_standalone_secret(api, settings):
    settings.TEAMS_APPROVAL = {}                       # no Teams at all
    settings.EXTERNAL_APPROVAL = {"INBOUND_SECRET": "ext-only"}
    bad = api.post("/api/v1/external/approvals/", PAYLOAD, format="json",
                   HTTP_X_APPROVAL_SECRET="wrong")
    assert bad.status_code == 403
    ok = api.post("/api/v1/external/approvals/", PAYLOAD, format="json",
                  HTTP_X_APPROVAL_SECRET="ext-only")
    assert ok.status_code == 201


def test_progress_callback_fires_per_approver(monkeypatch, django_capture_on_commit_callbacks):
    posts = []
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posts.append(p) or 200)
    ext, req = ext_mod.create_from_payload(PAYLOAD)   # 2 sequential approvers
    from apps.approvals.services import ApprovalService

    # approver 1 -> intermediate progress post (Pending)
    with django_capture_on_commit_callbacks(execute=True):
        req.refresh_from_db()
        t1 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=t1.pk, actor=t1.assignee, action="approve")
    assert posts and posts[-1]["outcome"] == "Pending"
    assert "1 of 2" in posts[-1]["responseSummary"]

    # approver 2 -> final post (Approved)
    with django_capture_on_commit_callbacks(execute=True):
        req.refresh_from_db()
        t2 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=t2.pk, actor=t2.assignee, action="approve")
    assert posts[-1]["outcome"] == "Approved"
    assert len(posts) >= 2          # one per approver


def test_completion_sends_emails(monkeypatch):
    from django.core import mail
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: 200)
    payload = dict(PAYLOAD)
    payload["body"] = dict(PAYLOAD["body"])
    payload["body"]["Requester_Email"] = "requester@acme.com"
    ext, req = ext_mod.create_from_payload(payload)
    from apps.approvals.services import ApprovalService
    for _ in range(2):
        req.refresh_from_db()
        task = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=task.pk, actor=task.assignee, action="approve")
    # approvers + requester emailed the result
    recipients = {r for m in mail.outbox for r in m.to}
    assert "requester@acme.com" in recipients
    assert "validator@acme.com" in recipients and "customer@acme.com" in recipients
    assert any("approved" in m.subject.lower() for m in mail.outbox)


def test_console_details_not_duplicated(users, api):
    ext, req = ext_mod.create_from_payload(PAYLOAD)
    # the named approvers must be staff to fetch, or use staff viewer
    staff = users["creator"]; staff.is_staff = True; staff.save(update_fields=["is_staff"])
    api.force_authenticate(staff)
    body = api.get("/api/v1/approval-requests/console/").json()
    row = next(r for r in body["results"] if r["id"] == req.pk)
    keys = [k for k, v in row["data"]]
    assert len(keys) == len(set(keys)), f"duplicate detail keys: {keys}"
    assert "Source Tenant" in keys and keys.count("Source Tenant") == 1


def _approve_all(req):
    from apps.approvals.services import ApprovalService
    for _ in range(req.workflow.steps.count()):
        req.refresh_from_db()
        t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
        ApprovalService.act(task_id=t.pk, actor=t.assignee, action="approve")


def test_callback_ack_required_and_2xx_confirms(monkeypatch):
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: 200)   # 2xx
    payload = {"body": {**PAYLOAD["body"], "require_callback_ack": True}}
    ext, req = ext_mod.create_from_payload(payload)
    assert ext.require_callback_ack is True
    _approve_all(req)
    ext.refresh_from_db()
    assert ext.callback_acked is True
    assert ext.is_confirmed is True


def test_callback_ack_required_but_non_2xx_not_confirmed(monkeypatch):
    import urllib.error

    def boom(url, payload):
        raise urllib.error.HTTPError(url, 500, "err", {}, None)
    monkeypatch.setattr(ext_mod, "_post_json", boom)
    payload = {"body": {**PAYLOAD["body"], "require_callback_ack": True}}
    ext, req = ext_mod.create_from_payload(payload)
    _approve_all(req)
    ext.refresh_from_db()
    assert ext.outcome == "Approved"           # approvers did approve
    assert ext.callback_acked is False
    assert ext.is_confirmed is False           # but NOT confirmed (no 2xx)


def test_callback_ack_not_required_is_confirmed_even_on_failure(monkeypatch):
    import urllib.error
    monkeypatch.setattr(ext_mod, "_post_json",
                        lambda u, p: (_ for _ in ()).throw(urllib.error.URLError("down")))
    ext, req = ext_mod.create_from_payload(PAYLOAD)   # require_callback_ack defaults False
    _approve_all(req)
    ext.refresh_from_db()
    assert ext.callback_acked is False
    assert ext.is_confirmed is True            # not gated -> still confirmed


def test_same_email_two_stages_callback_each(monkeypatch, settings):
    """Regression: two stages sharing one approver email must call the callback on
    each decision (intermediate posts inline, not on commit)."""
    from django.core import signing
    from django.test import Client
    settings.APP_BASE_URL = "https://approvals.example.com"
    posts = []
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posts.append(p["outcome"]) or 200)
    dup = {"body": {**PAYLOAD["body"], "approvers": [
        {"email": "same@acme.com", "title": "Validation Approval"},
        {"email": "same@acme.com", "title": "Customer Approval"},
    ]}}
    ext, req = ext_mod.create_from_payload(dup)
    c = Client()
    t1 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    c.post(f"/approve/t/{signing.dumps(t1.pk, salt='task-approval')}/", {"action": "approve"})
    assert posts == ["Pending"]
    req.refresh_from_db()
    t2 = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    c.post(f"/approve/t/{signing.dumps(t2.pk, salt='task-approval')}/", {"action": "approve"})
    assert posts == ["Pending", "Approved"]


def test_custom_flow_fields_are_dynamic(monkeypatch, api, settings):
    """A different external flow with the same approvers shape but different
    metadata must show ITS fields in the console + echo them in the callback."""
    posted = {}
    monkeypatch.setattr(ext_mod, "_post_json", lambda u, p: posted.update(p) or 200)
    custom = {"body": {
        "approvers": [{"email": "lead@acme.com", "title": "Lead Approval"}],
        "Project_Name": "Apollo",
        "Cost_Center": "CC-4471",
        "Environment": "Production",
        "Details": "Access request for Apollo",
        "Result_Callback_URL": "https://caller.example/custom",
        "title": "Apollo access",
    }}
    ext, req = ext_mod.create_from_payload(custom)
    # the custom fields are viewable (not the iFlow ones)
    d = ext.as_dict()
    assert d["Project Name"] == "Apollo"
    assert d["Cost Center"] == "CC-4471"
    assert d["Environment"] == "Production"
    assert "Source Tenant" not in d           # iFlow field absent -> not shown

    # approve -> callback echoes the custom fields with original keys
    from apps.approvals.services import ApprovalService
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    ApprovalService.act(task_id=t.pk, actor=t.assignee, action="approve")
    assert posted["outcome"] == "Approved"
    assert posted["Project_Name"] == "Apollo"
    assert posted["Cost_Center"] == "CC-4471"
    assert posted["Environment"] == "Production"


def _mk_login_flow(creator="boss@acme.com"):
    payload = {"body": {**PAYLOAD["body"],
                        "login_required": True,
                        "Requester_Email": creator,
                        "approvers": [{"email": "boss@acme.com", "title": "Approval"}]}}
    return ext_mod.create_from_payload(payload)


def test_login_required_redirects_anonymous():
    from django.test import Client
    from django.core import signing
    from apps.approvals.states import TaskStatus
    ext, req = _mk_login_flow()
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    tok = signing.dumps(t.pk, salt="task-approval")
    resp = Client().get(f"/approve/t/{tok}/")
    assert resp.status_code == 302 and "/login" in resp["Location"].lower() or resp.status_code == 302


def test_login_required_blocks_creator(django_user_model):
    from django.test import Client
    from django.core import signing
    from apps.approvals.states import TaskStatus
    ext, req = _mk_login_flow(creator="boss@acme.com")
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    tok = signing.dumps(t.pk, salt="task-approval")
    # the creator (same email) logs in and tries to approve -> 403, task untouched
    creator = django_user_model.objects.get(email="boss@acme.com")
    creator.set_password("x"); creator.is_active = True; creator.save()
    c = Client(); c.force_login(creator)
    resp = c.post(f"/approve/t/{tok}/", {"action": "approve"})
    assert resp.status_code == 403
    t.refresh_from_db()
    assert t.status == TaskStatus.PENDING            # creator could NOT approve


def test_login_required_allows_non_creator(django_user_model):
    from django.test import Client
    from django.core import signing
    from apps.approvals.states import TaskStatus
    # creator is someone else; approver logs in and approves fine
    payload = {"body": {**PAYLOAD["body"], "login_required": True,
                        "Requester_Email": "someone-else@acme.com",
                        "approvers": [{"email": "approver@acme.com", "title": "Approval"}]}}
    ext, req = ext_mod.create_from_payload(payload)
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    tok = signing.dumps(t.pk, salt="task-approval")
    approver = django_user_model.objects.get(email="approver@acme.com")
    approver.is_active = True; approver.save()
    c = Client(); c.force_login(approver)
    resp = c.post(f"/approve/t/{tok}/", {"action": "approve"})
    assert resp.status_code == 200
    t.refresh_from_db()
    assert t.status == TaskStatus.APPROVED


def test_login_not_required_allows_anonymous():
    from django.test import Client
    from django.core import signing
    from apps.approvals.states import TaskStatus
    ext, req = ext_mod.create_from_payload(PAYLOAD)   # login_required defaults False
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    tok = signing.dumps(t.pk, salt="task-approval")
    resp = Client().post(f"/approve/t/{tok}/", {"action": "approve"})
    assert resp.status_code == 200                    # no login needed


def _login_flow_creator_is_approver():
    payload = {"body": {**PAYLOAD["body"], "login_required": True,
                        "Requester_Email": "boss@acme.com",
                        "approvers": [{"email": "boss@acme.com", "title": "Approval"}]}}
    return ext_mod.create_from_payload(payload)


def test_creator_blocked_at_engine_level_via_api(api, django_user_model):
    """Regression: the creator could approve via the REST API / console. The block
    now lives in ApprovalService.act(), so every surface is covered."""
    ext, req = _login_flow_creator_is_approver()
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    boss = django_user_model.objects.get(email="boss@acme.com")
    boss.is_active = True
    boss.save()
    api.force_authenticate(boss)
    resp = api.post(f"/api/v1/approval-tasks/{t.pk}/approve/", {}, format="json")
    assert resp.status_code == 403
    t.refresh_from_db()
    assert t.status == TaskStatus.PENDING


def test_creator_blocked_on_subject_level_link(django_user_model):
    """The /forms/approve/<ext-token>/ page enforces login + creator block too."""
    from django.core import signing
    from django.test import Client
    ext, req = _login_flow_creator_is_approver()
    tok = signing.dumps(ext.pk, salt="ext-approval")
    c = Client()
    # anonymous -> redirected to login
    assert c.get(f"/forms/approve/{tok}/").status_code == 302
    # creator logged in -> 403, task untouched
    boss = django_user_model.objects.get(email="boss@acme.com")
    boss.is_active = True
    boss.save()
    c.force_login(boss)
    resp = c.post(f"/forms/approve/{tok}/", {"action": "approve"})
    assert resp.status_code == 403
    t = req.tasks.get(step=req.current_step)
    assert t.status == TaskStatus.PENDING


def test_approve_page_bosch_layout():
    """The approve page renders the Bosch-styled layout with grouped cards."""
    from django.core import signing
    from django.test import Client
    ext, req = ext_mod.create_from_payload(PAYLOAD)   # login not required
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    tok = signing.dumps(t.pk, salt="task-approval")
    resp = Client().get(f"/approve/t/{tok}/")
    assert resp.status_code == 200
    html = resp.content.decode()
    assert "Approval Required" in html and "BOSCH" in html
    assert "Reference Information" in html and "Request Information" in html
    assert "BT120Q0 → BT120P0" in html            # Source → Target title
    assert "Approve" in html and "Reject" in html


def _page_for(payload_body):
    from django.core import signing
    from django.test import Client
    ext, req = ext_mod.create_from_payload({"body": payload_body})
    t = req.tasks.get(step=req.current_step, status=TaskStatus.PENDING)
    tok = signing.dumps(t.pk, salt="task-approval")
    resp = Client().get(f"/approve/t/{tok}/")
    assert resp.status_code == 200
    return resp.content.decode()


def test_page_generic_flat_workflow():
    """A completely different workflow (no iFlow keys) renders its own fields."""
    html = _page_for({
        "approvers": [{"email": "ops@acme.com", "title": "Ops Approval"}],
        "Server_Name": "srv-fra-042", "Change_Number": "CHG0031245",
        "Environment": "Production", "Patch_Status": "false",
        "Details": "Emergency kernel patch", "title": "Server patch approval",
        "Result_Callback_URL": "https://caller.example/r",
    })
    assert "Server Name" in html and "CHG0031245" in html and "Environment" in html
    assert "Failed" in html                      # Patch_Status false -> colored Failed
    assert "Post-Deployment Details" not in html  # no iFlow grouping leaked in


def test_page_dict_fields_become_cards():
    """Dict-valued payload fields render as their own titled cards."""
    html = _page_for({
        "approvers": [{"email": "sec@acme.com", "title": "Security Approval"}],
        "Access_Details": {"System": "SAP PRD", "Role": "Z_FIN_VIEW", "Duration": "90 days"},
        "Risk_Assessment": {"Level": "Medium", "SoD_Conflicts": "None"},
        "title": "Access request", "Result_Callback_URL": "https://caller.example/r",
    })
    assert "Access Details" in html and "Risk Assessment" in html
    assert "Z_FIN_VIEW" in html and "SoD Conflicts" in html


def test_page_explicit_display_sections():
    """Callers can define their own sections and ordering."""
    html = _page_for({
        "approvers": [{"email": "fin@acme.com", "title": "Finance Approval"}],
        "Amount": "12,500 EUR", "Vendor": "Acme GmbH", "PO_Number": "PO-88123",
        "Budget_Line": "OPEX-2026-Q3",
        "display_sections": [
            {"title": "Purchase Summary", "fields": ["Amount", "Vendor", "PO_Number"]},
            {"title": "Budget", "fields": ["Budget_Line"]},
        ],
        "title": "Purchase approval", "Result_Callback_URL": "https://caller.example/r",
    })
    assert "Purchase Summary" in html and "Budget" in html
    assert "PO-88123" in html and "OPEX-2026-Q3" in html
    assert "display_sections" not in html        # control key never rendered as data
