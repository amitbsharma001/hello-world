"""Public, no-login customer form endpoints, secured by an unguessable token and
optional expiry. Server-side validation always runs regardless of client JS."""
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import ensure_csrf_cookie

from .models import FormDefinition
from .services import SubmissionService
from .validators import FieldValidationError


def _client_meta(request):
    xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
    ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR")
    ua = request.META.get("HTTP_USER_AGENT", "")
    device = "mobile" if "Mobi" in ua else "desktop"
    meta = {"ip": ip, "user_agent": ua, "device": device}
    if getattr(request, "user", None) and request.user.is_authenticated:
        meta["user"] = request.user            # records who submitted, when logged in
    return meta


@method_decorator(ensure_csrf_cookie, name="dispatch")
class PublicFormView(View):
    """GET renders the dynamic form; POST submits or saves a draft."""

    def get(self, request, token):
        form = get_object_or_404(FormDefinition, public_token=token)
        if not form.is_open():
            return render(request, "public/closed.html", {"form": form}, status=410)
        return render(request, "public/form.html", {"form": form})

    def post(self, request, token):
        form = get_object_or_404(FormDefinition, public_token=token)
        if not form.is_open():
            return JsonResponse({"detail": "Form is closed."}, status=410)
        # Per-IP hourly rate limit (0 = unlimited) — guards against approver-email spam.
        if form.submission_rate_limit:
            from django.core.cache import cache
            xff = request.META.get("HTTP_X_FORWARDED_FOR", "")
            ip = xff.split(",")[0].strip() if xff else request.META.get("REMOTE_ADDR", "")
            key = f"subrate:{form.pk}:{ip}"
            count = cache.get(key, 0)
            if count >= form.submission_rate_limit:
                return JsonResponse(
                    {"detail": "Too many submissions from your network. Try again later."},
                    status=429,
                )
            cache.set(key, count + 1, 3600)
        as_draft = request.POST.get("_action") == "draft"
        meta = _client_meta(request)
        # accept multiple <input name="approver_email"> and/or a comma-separated field
        meta["approver_emails"] = (request.POST.getlist("approver_email")
                                   + [request.POST.get("approver_emails", "")])
        meta["base_url"] = request.build_absolute_uri("/").rstrip("/")
        try:
            submission = SubmissionService.save(
                form=form,
                data=request.POST.dict(),
                files=request.FILES,
                meta=meta,
                as_draft=as_draft,
            )
        except FieldValidationError as exc:
            return JsonResponse({"errors": exc.errors}, status=400)
        status_url = request.build_absolute_uri(
            f"/forms/submission/{submission.submission_uuid}/"
        )
        return JsonResponse(
            {
                "status": submission.status,
                "submission_uuid": str(submission.submission_uuid),
                "status_url": status_url,    # submitter can return here to track / correct
            },
            status=201,
        )


def form_builder(request):
    """Serve the form-builder UI (fields + approvers). Wired to the API; rendered
    with @ensure_csrf_cookie so the JS can POST with CSRF."""
    from django.shortcuts import render
    from django.views.decorators.csrf import ensure_csrf_cookie

    return ensure_csrf_cookie(lambda r: render(r, "dynamic_forms/builder.html"))(request)


def form_submissions_view(request):
    """Serve the printable 'all submissions' screen. Reads the API client-side;
    the submissions endpoint enforces creator/admin access (403 otherwise)."""
    from django.shortcuts import render
    from django.views.decorators.csrf import ensure_csrf_cookie

    return ensure_csrf_cookie(lambda r: render(r, "dynamic_forms/submissions.html"))(request)


def public_submission_view(request, sub_uuid):
    """Submitter's status page (by submission UUID). If the approver rejected,
    show the rejection reason and an editable form to correct & restart approval."""
    from django.shortcuts import get_object_or_404, redirect, render

    from .models import FormSubmission, SubmissionStatus
    from .services import resubmit_submission

    sub = get_object_or_404(FormSubmission, submission_uuid=sub_uuid)
    fields = list(sub.form.fields.all())

    if request.method == "POST" and sub.status == SubmissionStatus.REJECTED:
        data = {f.name: request.POST.get(f.name, "") for f in fields}
        approvers = (request.POST.getlist("approver_email")
                     + [request.POST.get("approver_emails", "")]) or sub.approver_emails
        base = request.build_absolute_uri("/").rstrip("/")
        try:
            resubmit_submission(sub, data, approver_emails=approvers, base_url=base)
        except Exception as exc:
            msg = " ".join(str(v) for v in exc.errors.values()) if hasattr(exc, "errors") else str(exc)
            return render(request, "dynamic_forms/submission_status.html", {
                "sub": sub, "fields": fields,
                "values": {f.name: request.POST.get(f.name, "") for f in fields},
                "error": msg,
            })
        return redirect(request.path + "?resubmitted=1")

    values = {v.field.name: v.value for v in sub.values.select_related("field").all()}
    return render(request, "dynamic_forms/submission_status.html", {
        "sub": sub, "fields": fields, "values": values,
        "resubmitted": request.GET.get("resubmitted") == "1",
    })


def public_approval_view(request, token):
    """Tokenised approve/reject page (no login). Works for a public form submission
    (salt 'pub-approval') or an external/iFlow approval (salt 'ext-approval')."""
    from django.core import signing
    from django.shortcuts import render

    from apps.approvals.models import ApprovalRequest
    from apps.approvals.services import ApprovalService
    from apps.approvals.states import TaskStatus

    from .models import FormSubmission

    req = None
    subject_label = ""
    max_age = 60 * 60 * 24 * 30
    try:
        sub_id = signing.loads(token, salt="pub-approval", max_age=max_age)
        sub = FormSubmission.objects.filter(pk=sub_id).first()
        if sub:
            req = ApprovalRequest.objects.filter(pk=sub.approval_request_id).first()
            subject_label = f"{sub.form.name} — submission #{sub.id}"
    except signing.BadSignature:
        pass
    if req is None:
        try:
            ext_id = signing.loads(token, salt="ext-approval", max_age=max_age)
            from apps.approvals.models import ExternalApproval
            ext = ExternalApproval.objects.filter(pk=ext_id).first()
            if ext:
                req = (ApprovalRequest.objects
                       .filter(content_type__model="externalapproval", object_id=ext.pk)
                       .order_by("-created_at").first())
                subject_label = ext.title or ext.name or f"Approval #{ext.pk}"
        except signing.BadSignature:
            pass
    if req is None:
        return render(request, "dynamic_forms/approve.html", {"invalid": True}, status=400)

    guard = _external_login_guard(request, req)
    if guard is not None:
        return guard

    task = None
    if req.current_step_id:
        task = req.tasks.filter(step=req.current_step, status=TaskStatus.PENDING).first()

    done = None
    if request.method == "POST" and task:
        action = request.POST.get("action")
        if action in ("approve", "reject"):
            from django.core.exceptions import PermissionDenied
            try:
                ApprovalService.act(task_id=task.pk, actor=task.assignee, action=action,
                                    comment=request.POST.get("comment", ""))
                done = action
            except PermissionDenied:
                return render(request, "dynamic_forms/approve.html",
                              {"forbidden_creator": True, "subject_label": subject_label},
                              status=403)

    page = _approval_page(req, task, fallback_label=subject_label)
    return render(request, "dynamic_forms/approve.html", {
        **page, "task": task, "done": done,
    })


def public_task_approval_view(request, token):
    """Per-approver, login-free approve/reject for a SINGLE task. Anyone with the
    emailed link can act on that task (acts as the assigned approver)."""
    from django.core import signing
    from django.shortcuts import render

    from apps.approvals.models import ApprovalTask
    from apps.approvals.services import ApprovalService
    from apps.approvals.states import TaskStatus

    try:
        task_id = signing.loads(token, salt="task-approval", max_age=60 * 60 * 24 * 30)
    except signing.BadSignature:
        return render(request, "dynamic_forms/approve.html", {"invalid": True}, status=400)

    task = ApprovalTask.objects.filter(pk=task_id).select_related(
        "request", "assignee", "step").first()
    if task is None:
        return render(request, "dynamic_forms/approve.html", {"invalid": True}, status=400)

    req = task.request

    # External approvals may require login + bar the creator from acting (SoD).
    guard = _external_login_guard(request, req)
    if guard is not None:
        return guard

    subject_label = f"{req.subject} — {task.step.name}" if req.subject is not None else task.step.name
    pending = task.status == TaskStatus.PENDING

    done = None
    if request.method == "POST" and pending:
        action = request.POST.get("action")
        if action in ("approve", "reject"):
            from django.core.exceptions import PermissionDenied
            try:
                ApprovalService.act(task_id=task.pk, actor=task.assignee, action=action,
                                    comment=request.POST.get("comment", ""))
                done = action
            except PermissionDenied:
                return render(request, "dynamic_forms/approve.html",
                              {"forbidden_creator": True, "subject_label": subject_label},
                              status=403)

    page = _approval_page(req, task if pending else None, fallback_label=subject_label)
    return render(request, "dynamic_forms/approve.html", {
        **page, "task": task if pending else None, "done": done,
    })


# ─── Bosch-styled approval page: context builder + shared guards ──────────────

_CARD_GROUPS = [
    ("Change Summary", "doc", ["Business_Case", "Technical_Change",
                               "Validation_Status", "Exception_for_DNCT_Validation"]),
    ("Reference Information", "info", ["Reference_ID", "Failure_Ticket", "Project",
                                       "Workflow_Name", "Package_Id", "iFlow_Id",
                                       "Version", "Scheduled_DateTime",
                                       "Source_Tenant", "Destination_Tenant"]),
    ("Post-Deployment Details", "chart", ["Charge_Code", "Cost_Center",
                                          "Billing_Type", "Notes"]),
]


def _fmt_dt(dt):
    return dt.strftime("%d %b %Y, %I:%M %p") if dt else ""


def _as_display(v):
    """Human-readable rendering for any JSON value."""
    if isinstance(v, dict):
        import json as _json
        return _json.dumps(v, ensure_ascii=False)
    if isinstance(v, (list, tuple)):
        return ", ".join(_as_display(x) for x in v)
    return str(v)


def _style_value(key, value):
    """(css_class, display). Any status-like key gets colored; bare true/false
    become Passed/Failed for readability."""
    s = str(value).strip().lower()
    if "status" in str(key).lower():
        if s in ("true", "passed", "ok", "success", "approved", "valid", "completed"):
            return "good", ("Passed" if s == "true" else str(value))
        if s in ("false", "failed", "error", "rejected", "invalid"):
            return "bad", ("Failed" if s == "false" else str(value))
    return "", str(value)


def _row(k, v):
    cls, disp = _style_value(k, _as_display(v))
    return {"k": str(k).replace("_", " "), "v": disp, "cls": cls}


def _approval_page(req, task=None, fallback_label=None):
    """Bosch-styled context for the approve page — fully dynamic, works for ANY
    workflow. Cards are built, in priority order, from:
      1. an explicit `display_sections` list in the payload
         [{"title": "...", "fields": ["Key_A", "Key_B"]}, ...]
      2. dict-valued payload fields (each dict becomes its own titled card)
      3. the built-in grouping for known iFlow-transport keys (convenience)
      4. everything left over in a generic Details card
    A Request Information card (requested by / on, current approver) is always
    included. Form submissions get their values in a single card."""
    from apps.approvals.models import ExternalApproval
    from apps.approvals.services import ApprovalService

    description, details = ApprovalService._detail_payload(req)
    subject = req.subject
    ext = subject if isinstance(subject, ExternalApproval) else None
    p = (ext.payload or {}) if ext else {}

    def val(*keys):
        for k in keys:
            v = p.get(k)
            if v not in (None, ""):
                return v
        return ""

    display = list(ext._display_items()) if ext else []
    lookup = dict(display)
    cards, used = [], set()

    sections = p.get("display_sections") or p.get("sections") or p.get("Display_Sections")
    if isinstance(sections, list) and sections:
        # 1) caller-defined sections
        for sec in sections:
            if not isinstance(sec, dict):
                continue
            rows = []
            for k in sec.get("fields", []):
                v = lookup.get(k)
                if v in (None, ""):
                    continue
                if isinstance(v, dict):
                    rows.extend(_row(kk, vv) for kk, vv in v.items() if vv not in (None, ""))
                else:
                    rows.append(_row(k, v))
                used.add(k)
            if rows:
                cards.append({"title": str(sec.get("title") or "Details"),
                              "icon": str(sec.get("icon") or "doc"), "rows": rows})
    else:
        # 2) each dict-valued field becomes its own card
        for k, v in display:
            if isinstance(v, dict) and v:
                rows = [_row(kk, vv) for kk, vv in v.items() if vv not in (None, "")]
                if rows:
                    cards.append({"title": str(k).replace("_", " "), "icon": "doc", "rows": rows})
                used.add(k)
        # 3) built-in grouping for known keys among the remaining flat fields
        for title, icon, keys in _CARD_GROUPS:
            rows = []
            for k in keys:
                v = lookup.get(k)
                if k in used or v in (None, ""):
                    continue
                rows.append(_row(k, v))
                used.add(k)
            if rows:
                cards.append({"title": title, "icon": icon, "rows": rows})

    # 4) leftovers -> generic card
    extra = []
    if ext:
        for k, v in display:
            if k in used or v in (None, ""):
                continue
            extra.append(_row(k, v))
    else:
        extra = [{"k": str(k), "v": str(v), "cls": ""} for k, v in details]
    if extra:
        cards.append({"title": "Request Details" if not cards else "Additional Information",
                      "icon": "list", "rows": extra})

    # Always include Request Information (merge if the caller defined one)
    ri_rows = []
    have_requester = any(r["k"].lower().startswith(("requested", "requester"))
                         for c in cards for r in c["rows"])
    if ext and ext.creator_email and not have_requester:
        ri_rows.append(_row("Requested_by", ext.creator_email))
    when = _fmt_dt(req.submitted_at or req.created_at)
    if when:
        ri_rows.append({"k": "Requested on", "v": when, "cls": ""})
    if task is not None:
        who = task.assignee.email or task.assignee.get_username()
        ri_rows.append({"k": "Approver", "v": f"{who} · {task.step.name}", "cls": ""})
    if ri_rows:
        existing = next((c for c in cards if c["title"].lower() == "request information"), None)
        if existing:
            existing["rows"].extend(ri_rows)
        else:
            cards.append({"title": "Request Information", "icon": "user", "rows": ri_rows})

    # Header: heading override > Source -> Target > title/name
    src = str(val("Source_Tenant", "Source", "From"))
    dst = str(val("Destination_Tenant", "Destination", "Target", "To"))
    if ext:
        heading = str(val("heading", "Heading", "Display_Title"))
        big = heading or (f"{src} → {dst}" if (src and dst) else "") or (
            ext.title or ext.name or f"Approval #{ext.pk}")
        type_ = str(val("Type", "Request_Type", "Category")) or "Approval request"
        wf = str(val("Workflow_Name")) or ext.name or req.workflow.name
    else:
        big = fallback_label or (str(subject) if subject is not None else f"Request #{req.pk}")
        type_, wf = req.workflow.name, req.workflow.name

    subtitle_bits = [type_]
    if task is not None:
        subtitle_bits.append(task.step.name)
    subtitle = " | ".join(dict.fromkeys(b for b in subtitle_bits if b))

    meta = []
    if src and dst:
        meta.append({"label": "Source → Target", "value": f"{src} → {dst}"})
    meta.append({"label": "Workflow", "value": wf})
    meta.append({"label": "Type", "value": type_})

    deadline = _fmt_dt(req.expires_at)
    if not deadline:
        sched = str(val("Scheduled_DateTime", "Deadline", "Due_Date"))
        if sched and sched.strip().lower() != "not scheduled":
            deadline = sched

    footer_ref = f"FormFlow request #{req.pk}" + (f" · External #{ext.pk}" if ext else "")
    return {
        "subject_label": big, "subtitle": subtitle, "description": description,
        "cards": cards, "meta": meta, "deadline": deadline, "footer_ref": footer_ref,
    }


def _external_login_guard(request, req):
    """For login_required external approvals: force login and bar the creator.
    Returns an HttpResponse to short-circuit with, or None to continue."""
    from django.contrib.auth.views import redirect_to_login
    from django.shortcuts import render

    from apps.approvals.models import ExternalApproval

    subject = req.subject if req else None
    if not isinstance(subject, ExternalApproval) or not subject.login_required:
        return None
    if not request.user.is_authenticated:
        return redirect_to_login(request.get_full_path())
    creator = (subject.creator_email or "").strip().lower()
    user_email = (getattr(request.user, "email", "") or "").strip().lower()
    if creator and user_email == creator:
        return render(request, "dynamic_forms/approve.html",
                      {"forbidden_creator": True,
                       "subject_label": subject.title or subject.name}, status=403)
    return None
