# Wiring the new dashboard into Assist

**Two files:** `dashboard.html` (this replaces `aegis/templates/aegis/dashboard.html`) and the view edit below. No migrations, no new deps, no CSS changes to `aegis.css` — the template is self-contained (its own top bar + styles), so it won't collide with the app shell.

**Heads-up on validation:** the runnable tree wasn't in my session, so this is written against the structure from our history (`aegis` namespace, `is_admin(request.user)`, `dashboard` view returning `is_admin_user`, templates extending `aegis/base.html`). It is **statically written, not validated against your live tree** — run `make verify` and load `/dashboard/` once before trusting it.

---

## 1. Template

Drop `dashboard.html` at `aegis/templates/aegis/dashboard.html` (overwrites the current one). It renders the built-in **demo dataset** out of the box, so it works before you wire any data.

## 2. View

Replace the existing `dashboard` view in `aegis/views.py`:

```python
@login_required
def dashboard(request):
    """Operations dashboard.

    Everyone gets the personal ("end user") view. Staff additionally get the
    portfolio ("super admin") view and toggle between the two in the top bar.
    Gating is server-side: non-staff never receive the portfolio markup, so the
    UI toggle cannot expose it.
    """
    can_admin = is_admin(request.user)
    name = (request.user.get_full_name() or request.user.get_username() or "User").strip()
    return render(request, "aegis/dashboard.html", {
        "can_admin": can_admin,
        "user_name": name,
        "user_initial": (name[:1] or "U").upper(),
        "user_role": "Super admin · ops lead" if can_admin else "Operations agent",
        # None => ship the built-in demo dataset. Set to build_dashboard_payload(...)
        # (section 4) when you want live numbers.
        "dashboard_payload": None,
    })
```

## 3. URL

`path("dashboard/", views.dashboard, name="dashboard")` already exists — no change. Your nav shows Dashboard to staff only, which is correct.

**Optional unification:** to give non-staff the same rich personal dashboard instead of the stripped `my_work` page, point that route at the same view — non-staff automatically get only the end-user half:

```python
path("my/", views.dashboard, name="my_work"),
```

---

## 4. Going live: the payload contract

The template reads an optional JSON blob (`{{ dashboard_payload|json_script:"assist-payload" }}`). If it's `None`, the demo dataset renders. Provide a dict with any of these keys to override — each maps 1:1 to a section. **Row arrays are positional; keep the column order.**

```
queue:   [[ticket_id, pcls, priority_label, request, action_type, system,
            status_cls, status_label, active_hrs, idle_hrs, region], ...]
           pcls ∈ {p0,p1,p2}   status_cls ∈ {prog,wait,assigned,done}

teams:   [[name, open, critical, sla_pct, resolved, flow, health_label, health_cls], ...]
           flow ∈ {up,down,flat}   health_cls ∈ {good,watch,risk}

members: [[name, flag, account, load_pct, open, critical, at_risk,
            projects, sla_pct, status_cls, status_label], ...]
           status_cls ∈ {good,watch,risk}   projects>1 is highlighted

flags:   [{name, flag, color, reasons:[[prefix, number, suffix], ...]}, ...]

action_mix / hotspots: [{label, value, color}, ...]
insights: {user:{txt, cta}, admin:{txt, cta}}   (txt may contain <b>/<em>)
```

### Reference builder (adapt field names to your model)

Uses the `Ticket` fields from our build (`source`, `source_id`, `title`, `assignee`, `severity`, `status`, `team`, `opened_at`, `resolved_at`) and your configured `TeamMember`s. **Columns that are screenshot-domain-specific** — `action_type`, `system` (CPI/ON_PREM), `active`/`idle` hours, `region` — have no home in the base `Ticket` model; map them to your own fields/custom fields, or leave those cells to fall back. Everything here is a reference skeleton, not validated against your tree:

```python
def build_dashboard_payload(request, can_admin):
    from django.utils import timezone
    from .models import Ticket, TeamMember

    SEV2P = {"sev1": ("p0", "P0 · Critical"), "sev2": ("p1", "P1 · High"),
             "sev3": ("p2", "P2 · Medium"),  "sev4": ("p2", "P2 · Medium")}
    ST2C  = {"open": ("prog", "In progress"), "waiting": ("wait", "Awaiting info"),
             "assigned": ("assigned", "Assigned"), "resolved": ("done", "Resolved")}

    # --- personal queue (the logged-in user's open tickets) ---
    mine = (Ticket.objects.filter(assignee__iexact=(request.user.email or ""))
            .exclude(status="resolved").order_by("severity", "-opened_at")[:25])
    queue = []
    for t in mine:
        pcls, plabel = SEV2P.get(t.severity, ("p2", "P2 · Medium"))
        scls, slabel = ST2C.get(t.status, ("assigned", t.status.title()))
        age_h = (timezone.now() - t.opened_at).total_seconds() / 3600 if t.opened_at else 0
        queue.append([t.source_id, pcls, plabel, t.title[:36],
                      "SUPPORT",              # TODO map to your action-type field
                      (t.source or "").upper(),
                      scls, slabel,
                      f"{age_h:.1f}h",        # active — swap for your real timer if tracked
                      "0.0h",                 # idle  — swap for your real timer if tracked
                      t.team or "—"])

    payload = {"queue": queue}

    # --- admin-only aggregates ---
    if can_admin:
        teams = []
        for team in Ticket.objects.values_list("team", flat=True).distinct():
            if not team: continue
            qs = Ticket.objects.filter(team=team)
            openc = qs.exclude(status="resolved").count()
            crit  = qs.filter(severity__in=["sev1", "sev2"]).exclude(status="resolved").count()
            # sla_pct / resolved / flow / health: plug in your existing health-scoring
            # service here — it already produces these numbers on the current dashboard.
            teams.append([team, str(openc), str(crit), "95.0", "0", "flat",
                          "Healthy" if crit == 0 else "Watch", "good" if crit == 0 else "watch"])
        payload["teams"] = teams

        members = []
        for m in TeamMember.objects.filter(sync_enabled=True):
            qs = Ticket.objects.filter(assignee__iexact=m.account)
            openc = qs.exclude(status="resolved").count()
            crit  = qs.filter(severity__in=["sev1", "sev2"]).exclude(status="resolved").count()
            spans = qs.values("team").distinct().count()
            members.append([m.name, "🏳️", m.account, "60", str(openc), str(crit), "0",
                            str(spans), "95.0", "good", "Healthy"])
        payload["members"] = members

    return payload
```

> Your current dashboard already computes team/member health, SLA %, throughput, and net flow (`member_rows`, `member_summary`, `project_rows`). The fastest path to live numbers is to reshape **those** into the arrays above rather than recomputing — the builder shows the target shape.

---

## Fastest path to a fully validated fold-in

Re-upload the current `django-aegis.zip`. I'll drop the template in, replace the view, reshape your existing `member_rows`/`project_rows`/queue into the payload, and run the full static sweep (all-py-parse, dep audit, `{% url %}` resolution, template-tag balance) the way we've done every prior change — so you get a validated diff, not a hand-written one.
