"""VPN migration: copy every object of one VPN to another VPN or broker.

Reuses the exact :class:`~solace_exporter.models.CollectionSpec` trees that
drive the export, so *what gets migrated* and *what gets exported* can never
drift apart. Raw SEMP payloads are fetched from the source, identity columns
are rewritten to the target VPN, and objects are created on the target in
dependency order (profiles before usernames before queues before RDPs and
bridges), parents before children.

Safety model - deliberately conservative:

* **Plan first.** The engine always produces a full plan; execution is a
  separate, explicit step (interactive confirmation or ``--yes``), and
  ``--migrate-dry-run`` stops after the plan.
* **Create/update only - never delete.** Nothing is ever removed from the
  target.
* **Exists policy** per object: ``skip`` (default), ``update`` (PATCH the
  source attributes onto the existing object) or ``fail``.
* **Attribute-strip retry.** Brokers differ by SEMP version/platform; when a
  create is rejected with ``INVALID_PARAMETER`` naming an attribute, that
  attribute is removed and the create retried (bounded). Every stripped
  attribute is recorded per object - the report never hides what was dropped.
* **Secrets cannot be read.** SEMP v2 never returns passwords (client
  usernames, bridge remotes, REST consumer auth, OAuth client secrets). The
  report lists every migrated type that carries a secret so they can be set
  manually on the target.
* Objects whose name starts with ``#`` are broker-managed and skipped
  (except ``#DEAD_MSG_QUEUE``, which is an ordinary, admin-created queue).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Sequence
from urllib.parse import quote

from .exceptions import ConfigError, SempNotAvailableError, SempWriteError
from .models import CollectionSpec, SheetData
from .semp_client import SempClientProtocol
from .utils.logging import get_logger
from .utils.text import render_path

log = get_logger("migrate")


def roots_for_scopes(scopes: Sequence[str]) -> list["CollectionSpec"]:
    """Per-VPN root specs for the given scopes, in migration dependency order."""
    from .exporters.registry import resolve_scopes

    per_vpn = [r for r in resolve_scopes(tuple(scopes) or ("all",)) if r.per_vpn]
    rank = {key: i for i, key in enumerate(MIGRATION_ROOT_ORDER)}
    per_vpn.sort(key=lambda r: rank.get(r.key, len(rank)))
    return per_vpn

MAX_ATTRIBUTE_STRIPS = 15
_ATTR_IN_ERROR = re.compile(r"'([A-Za-z0-9_]+)'")

#: Per-VPN root spec keys in dependency order (referenced-before-referencing).
MIGRATION_ROOT_ORDER: tuple[str, ...] = (
    "aclProfiles", "clientProfiles", "queueTemplates", "topicEndpointTemplates",
    "clientUsernames", "authorizationGroups", "queues", "topicEndpoints",
    "jndi.connectionFactories", "jndi.queues", "jndi.topics", "replayLogs",
    "mqttRetainCaches", "mqttSessions", "rdps", "bridges",
    "replication.replicatedTopics", "caches", "dmrBridges", "vpns.oauthProfiles",
    "vpns.sequencedTopics",
)

#: Object types whose configuration references secrets SEMP cannot read.
_SECRET_BEARING: dict[str, str] = {
    "clientUsernames": "Client username passwords",
    "bridges.remoteMsgVpns": "Bridge remote authentication passwords / certificates",
    "rdps.restConsumers": "REST consumer authentication credentials",
    "vpns.oauthProfiles": "OAuth client secrets",
}

ACTIONS = ("planned", "created", "updated", "skipped", "failed")


@dataclass
class MigrationEntry:
    """One object's journey: what we did (or would do) and why."""

    spec_key: str
    sheet: str
    obj: str
    action: str            # planned | created | updated | skipped | failed
    detail: str = ""


@dataclass
class MigrationResult:
    source_host: str
    target_host: str
    source_vpn: str
    target_vpn: str
    exists_policy: str
    dry_run: bool
    entries: list[MigrationEntry] = field(default_factory=list)
    secret_notes: list[str] = field(default_factory=list)
    source_sheets: list[SheetData] = field(default_factory=list)
    source_skipped: list[str] = field(default_factory=list)

    def count(self, action: str) -> int:
        return sum(1 for e in self.entries if e.action == action)

    @property
    def total(self) -> int:
        return len(self.entries)

    @property
    def ok(self) -> bool:
        return self.count("failed") == 0


class VpnMigrator:
    """Copy one VPN's configuration onto a target VPN/broker."""

    def __init__(
        self,
        source: SempClientProtocol,
        target: SempClientProtocol,
        *,
        source_vpn: str,
        target_vpn: str,
        exists_policy: str = "skip",
        roots: Sequence[CollectionSpec] | None = None,
        source_host: str = "source",
        target_host: str = "target",
    ) -> None:
        if exists_policy not in ("skip", "update", "fail"):
            raise ConfigError(f"Unknown exists policy {exists_policy!r} (skip|update|fail)")
        self._source = source
        self._target = target
        self.source_vpn = source_vpn
        self.target_vpn = target_vpn
        self.exists_policy = exists_policy
        self._roots = list(roots) if roots is not None else roots_for_scopes(("all",))
        self.source_host = source_host
        self.target_host = target_host
        #: (spec_key, identity-values) of parents that were not created.
        self._failed_parents: set[tuple[str, tuple[str, ...]]] = set()

    # ------------------------------------------------------------------ #
    # Fetch + plan
    # ------------------------------------------------------------------ #
    def fetch_source(self, pool) -> tuple[dict[str, Any], dict[str, list], list[SheetData]]:
        """Fetch the source VPN object and every per-VPN collection (raw)."""
        from .exporters.base import RunContext, TreeExporter

        vpn_object: dict[str, Any] | None = None
        try:
            vpn_object = self._source.get_object(f"msgVpns/{quote(self.source_vpn, safe='')}")
        except SempNotAvailableError:
            pass
        if not vpn_object:  # fall back to scanning the collection
            try:
                vpn_object = next(
                    (dict(r) for r in self._source.get_collection("msgVpns")
                     if str(r.get("msgVpnName")) == self.source_vpn),
                    None,
                )
            except SempNotAvailableError:
                vpn_object = None
        if not vpn_object:
            raise ConfigError(f"Source VPN {self.source_vpn!r} not found on the source broker")

        raw: dict[str, list] = {}
        sheets: list[SheetData] = []
        self._source_skipped: list[str] = []
        for root in self._roots:
            exporter = TreeExporter(root)
            ctx = RunContext(client=self._source, pool=pool, vpns=(self.source_vpn,))
            output = exporter.export(ctx)
            raw.update(output.raw_rows)
            sheets.extend(output.sheets)
            self._source_skipped.extend(
                f"{skip.sheet}: {skip.reason}" for skip in output.skipped
            )
        return vpn_object, raw, sheets

    def plan(
        self, vpn_object: dict[str, Any], raw: dict[str, list]
    ) -> list[tuple[CollectionSpec, dict[str, Any], dict[str, Any]]]:
        """Ordered (spec, walk_ctx, row) tuples - the exact write sequence."""
        ordered: list[tuple[CollectionSpec, dict[str, Any], dict[str, Any]]] = []
        vpn_spec = CollectionSpec(
            key="msgVpn", sheet="Message VPN", path="msgVpns",
            id_fields=("msgVpnName",),
        )
        ordered.append((vpn_spec, {}, vpn_object))
        for root in self._roots:
            for spec in root.walk():
                for walk_ctx, row in raw.get(spec.key, []):
                    ordered.append((spec, dict(walk_ctx), dict(row)))
        return ordered

    # ------------------------------------------------------------------ #
    # Execute
    # ------------------------------------------------------------------ #
    def prepare(self, pool) -> tuple[list, list[SheetData], list[str]]:
        """Fetch the source and build the ordered write plan (no writes)."""
        vpn_object, raw, sheets = self.fetch_source(pool)
        return self.plan(vpn_object, raw), sheets, list(self._source_skipped)

    def run(self, pool, *, execute: bool, progress=None) -> MigrationResult:
        plan, sheets, source_skipped = self.prepare(pool)
        return self.apply(plan, sheets, source_skipped, execute=execute, progress=progress)

    def apply(
        self,
        plan: list,
        sheets: list[SheetData],
        source_skipped: list[str],
        *,
        execute: bool,
        progress=None,
    ) -> MigrationResult:
        result = MigrationResult(
            source_host=self.source_host,
            target_host=self.target_host,
            source_vpn=self.source_vpn,
            target_vpn=self.target_vpn,
            exists_policy=self.exists_policy,
            dry_run=not execute,
            source_sheets=sheets,
            source_skipped=list(source_skipped),
        )
        migrated_keys: set[str] = set()
        vpn_failed = False
        for spec, walk_ctx, row in plan:
            obj_id = self._identity(spec, row)
            if progress is not None:
                progress(spec.sheet, obj_id)
            if vpn_failed and spec.key != "msgVpn":
                entry = MigrationEntry(spec.key, spec.sheet, obj_id, "skipped",
                                       "target VPN was not created")
            else:
                entry = self._migrate_one(spec, walk_ctx, row, obj_id, execute)
            if spec.key == "msgVpn" and entry.action == "failed":
                vpn_failed = True
            result.entries.append(entry)
            if entry.action in ("created", "updated", "planned"):
                migrated_keys.add(spec.key)
        result.secret_notes = sorted(
            note for key, note in _SECRET_BEARING.items() if key in migrated_keys
        )
        log.info(
            "Migration %s: %d planned, %d created, %d updated, %d skipped, %d failed",
            "dry-run" if result.dry_run else "run",
            result.count("planned"), result.count("created"), result.count("updated"),
            result.count("skipped"), result.count("failed"),
        )
        return result

    # ------------------------------------------------------------------ #
    # Per-object mechanics
    # ------------------------------------------------------------------ #
    def _migrate_one(
        self,
        spec: CollectionSpec,
        walk_ctx: dict[str, Any],
        row: dict[str, Any],
        obj_id: str,
        execute: bool,
    ) -> MigrationEntry:
        first_id = str(row.get(spec.id_fields[0], "")) if spec.id_fields else ""
        if first_id.startswith("#") and first_id != "#DEAD_MSG_QUEUE":
            return MigrationEntry(spec.key, spec.sheet, obj_id, "skipped",
                                  "broker-managed object (name starts with '#')")

        ctx_chain = self._chain(walk_ctx)
        if ctx_chain and ctx_chain in self._failed_parents:
            if spec.children:  # cascade the block one level further down
                self._failed_parents.add(ctx_chain + self._own_ids(spec, row))
            return MigrationEntry(spec.key, spec.sheet, obj_id, "skipped",
                                  "parent object was not created on the target")

        if not execute:
            return MigrationEntry(spec.key, spec.sheet, obj_id, "planned", "")

        target_ctx = {**walk_ctx, "msgVpnName": self.target_vpn}
        collection_path = render_path(spec.path, target_ctx)
        body = self._prepare_body(spec, row)
        stripped: list[str] = []

        for _ in range(MAX_ATTRIBUTE_STRIPS + 1):
            try:
                self._target.post_json(collection_path, body)
                detail = f"stripped: {', '.join(stripped)}" if stripped else ""
                return MigrationEntry(spec.key, spec.sheet, obj_id, "created", detail)
            except SempWriteError as exc:
                if exc.semp_status == "ALREADY_EXISTS":
                    return self._handle_exists(spec, walk_ctx, collection_path, row, obj_id, stripped)
                attribute = self._strippable_attribute(exc, body)
                if attribute is not None:
                    body.pop(attribute)
                    stripped.append(attribute)
                    continue
                self._record_failed_parent(spec, walk_ctx, row)
                return MigrationEntry(spec.key, spec.sheet, obj_id, "failed", str(exc))
        self._record_failed_parent(spec, walk_ctx, row)
        return MigrationEntry(spec.key, spec.sheet, obj_id, "failed",
                              f"gave up after stripping {len(stripped)} attributes")

    def _handle_exists(
        self,
        spec: CollectionSpec,
        walk_ctx: dict[str, Any],
        collection_path: str,
        row: dict[str, Any],
        obj_id: str,
        stripped: list[str],
    ) -> MigrationEntry:
        if self.exists_policy == "fail":
            self._record_failed_parent(spec, walk_ctx, row)
            return MigrationEntry(spec.key, spec.sheet, obj_id, "failed",
                                  "already exists on target (policy: fail)")
        if self.exists_policy == "skip":
            return MigrationEntry(spec.key, spec.sheet, obj_id, "skipped",
                                  "already exists on target (policy: skip)")
        object_path = f"{collection_path}/{self._id_segment(spec, row)}"
        body = self._prepare_body(spec, row, for_update=True)
        for _ in range(MAX_ATTRIBUTE_STRIPS + 1):
            try:
                self._target.patch_json(object_path, body)
                detail = "updated in place" + (f"; stripped: {', '.join(stripped)}" if stripped else "")
                return MigrationEntry(spec.key, spec.sheet, obj_id, "updated", detail)
            except SempWriteError as exc:
                attribute = self._strippable_attribute(exc, body)
                if attribute is not None:
                    body.pop(attribute)
                    stripped.append(attribute)
                    continue
                return MigrationEntry(spec.key, spec.sheet, obj_id, "failed",
                                      f"exists; update rejected: {exc}")
        return MigrationEntry(spec.key, spec.sheet, obj_id, "failed",
                              "exists; update gave up after attribute strips")

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    def _prepare_body(
        self, spec: CollectionSpec, row: dict[str, Any], *, for_update: bool = False
    ) -> dict[str, Any]:
        body = {k: v for k, v in row.items() if v is not None}
        if spec.key == "msgVpn":
            body["msgVpnName"] = self.target_vpn
        else:
            body.pop("msgVpnName", None)
        if for_update:
            for id_field in spec.id_fields:
                body.pop(id_field, None)
            body.pop("msgVpnName", None)
        return body

    @staticmethod
    def _strippable_attribute(exc: SempWriteError, body: dict[str, Any]) -> str | None:
        if exc.semp_status not in ("INVALID_PARAMETER", "NOT_ALLOWED"):
            return None
        for match in _ATTR_IN_ERROR.finditer(exc.description):
            if match.group(1) in body:
                return match.group(1)
        return None

    def _identity(self, spec: CollectionSpec, row: dict[str, Any]) -> str:
        if not spec.id_fields:
            return spec.sheet
        return ",".join(str(row.get(f, "?")) for f in spec.id_fields)

    def _id_segment(self, spec: CollectionSpec, row: dict[str, Any]) -> str:
        if spec.key == "msgVpn":
            return quote(self.target_vpn, safe="")
        return ",".join(quote(str(row.get(f, "")), safe="") for f in spec.id_fields)

    @staticmethod
    def _chain(walk_ctx: dict[str, Any]) -> tuple[str, ...]:
        return tuple(str(v) for k, v in walk_ctx.items() if k != "msgVpnName")

    @staticmethod
    def _own_ids(spec: CollectionSpec, row: dict[str, Any]) -> tuple[str, ...]:
        return tuple(str(row.get(f, "")) for f in spec.id_fields)

    def _record_failed_parent(
        self, spec: CollectionSpec, walk_ctx: dict[str, Any], row: dict[str, Any]
    ) -> None:
        if spec.children:
            self._failed_parents.add(self._chain(walk_ctx) + self._own_ids(spec, row))
