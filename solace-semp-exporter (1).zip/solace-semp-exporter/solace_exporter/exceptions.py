"""Exception hierarchy for the Solace SEMP exporter.

All exceptions raised by this package derive from :class:`SempExporterError`
so callers can catch a single base type. Transport-level failures are mapped
to specific subclasses so the CLI can render actionable messages.
"""

from __future__ import annotations


class SempExporterError(Exception):
    """Base class for every error raised by solace_exporter."""


class ConfigError(SempExporterError):
    """Invalid or incomplete configuration (CLI args, env, config file)."""


class SempApiError(SempExporterError):
    """Base class for SEMP API transport/protocol errors."""

    def __init__(self, message: str, *, url: str | None = None, status: int | None = None) -> None:
        super().__init__(message)
        self.url = url
        self.status = status


class SempConnectionError(SempApiError):
    """TCP/DNS level connection failure to the broker management interface."""


class SempSSLError(SempApiError):
    """TLS handshake / certificate verification failure."""


class SempTimeoutError(SempApiError):
    """The broker did not respond within the configured timeout."""


class SempAuthError(SempApiError):
    """HTTP 401/403 - bad credentials or insufficient access level."""


class SempNotAvailableError(SempApiError):
    """Endpoint/object not available on this broker or SEMP version.

    Raised for HTTP 400/404/501 responses on otherwise well-formed requests.
    The orchestrator treats this as a *skippable* condition (older brokers do
    not expose every collection), records it, and continues the export.

    ``endpoint_missing`` distinguishes "this collection does not exist on this
    broker/SEMP version" (short-circuit all remaining contexts) from "this one
    parent object vanished mid-export" (tolerate and keep going).
    """

    def __init__(
        self,
        message: str,
        *,
        url: str | None = None,
        status: int | None = None,
        semp_status: str = "",
    ) -> None:
        super().__init__(message, url=url, status=status)
        self.semp_status = semp_status

    @property
    def endpoint_missing(self) -> bool:
        if self.semp_status in {"INVALID_PATH", "NOT_ALLOWED"}:
            return True
        if self.semp_status == "NOT_FOUND" or self.status == 404:
            return False  # a single object disappeared; siblings may exist
        return True  # untagged 400/501: assume the collection is unsupported


class SempResponseError(SempApiError):
    """The broker returned an unexpected payload or an unmapped HTTP error."""


class ExcelWriteError(SempExporterError):
    """Failure while producing the output workbook."""


class SempWriteError(SempApiError):
    """A SEMP v2 write (POST/PATCH) was rejected.

    Carries the SEMP status tag (``ALREADY_EXISTS``, ``INVALID_PARAMETER``,
    ``NOT_ALLOWED``, ...) and the broker's description so the migration
    engine can branch: exists-policy handling, attribute-strip retry, or an
    honest per-object failure record.
    """

    def __init__(
        self,
        message: str,
        *,
        url: str | None = None,
        status: int | None = None,
        semp_status: str = "",
        description: str = "",
    ) -> None:
        super().__init__(message, url=url, status=status)
        self.semp_status = semp_status
        self.description = description
