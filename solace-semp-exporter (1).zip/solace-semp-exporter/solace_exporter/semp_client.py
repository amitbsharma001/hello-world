"""SEMP v2 Config API client.

Responsibilities:

* thread-local :class:`requests.Session` with connection pooling and
  automatic retry (429/5xx, exponential backoff)
* transparent cursor pagination via ``meta.paging.nextPageUri``
* percent-encoded path handling, timeout, optional TLS verification
* mapping of transport/HTTP failures onto the package exception hierarchy
* API version / capability discovery (``about/api``)

The client is deliberately dumb about *what* it fetches - exporters own the
endpoint knowledge; the client owns the wire.
"""

from __future__ import annotations

import threading
from typing import Any, Callable, Iterable, Protocol

import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import ConnectionConfig
from .exceptions import (
    SempWriteError,
    SempAuthError,
    SempConnectionError,
    SempNotAvailableError,
    SempResponseError,
    SempSSLError,
    SempTimeoutError,
)
from .utils.logging import get_logger

log = get_logger("client")

_SKIPPABLE_STATUS = {400, 404, 501}


class SempClientProtocol(Protocol):
    """Minimal interface exporters depend on (enables fake clients in tests)."""

    def get_collection(self, path: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]: ...
    def get_object(self, path: str) -> dict[str, Any] | None: ...
    def about(self) -> dict[str, Any]: ...

    @property
    def call_count(self) -> int: ...


class SempClient:
    """Concrete SEMP v2 Config client over HTTP(S)."""

    def __init__(
        self,
        config: ConnectionConfig,
        session_factory: Callable[[], requests.Session] | None = None,
    ) -> None:
        self._config = config
        self._session_factory = session_factory or self._build_session
        self._local = threading.local()
        self._calls = 0
        self._calls_lock = threading.Lock()
        if config.use_ssl and not config.verify_ssl:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            log.warning("TLS certificate verification is DISABLED (--no-verify-ssl)")

    # ------------------------------------------------------------------ #
    # Session / transport
    # ------------------------------------------------------------------ #
    def _build_session(self) -> requests.Session:
        cfg = self._config
        session = requests.Session()
        session.auth = (cfg.username, cfg.password)
        session.headers["Accept"] = "application/json"
        session.verify = cfg.verify_ssl
        retry = Retry(
            total=cfg.retries,
            connect=cfg.retries,
            read=cfg.retries,
            backoff_factor=0.5,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET"}),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=cfg.workers, pool_maxsize=cfg.workers * 2)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    @property
    def _session(self) -> requests.Session:
        session = getattr(self._local, "session", None)
        if session is None:
            session = self._session_factory()
            self._local.session = session
        return session

    @property
    def base_url(self) -> str:
        return self._config.base_url

    @property
    def call_count(self) -> int:
        return self._calls

    def _count(self) -> None:
        with self._calls_lock:
            self._calls += 1

    # ------------------------------------------------------------------ #
    # Low-level GET with error mapping
    # ------------------------------------------------------------------ #
    def _get(self, url: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        self._count()
        log.debug("GET %s params=%s", url, params)
        try:
            response = self._session.get(url, params=params, timeout=self._config.timeout)
        except requests.exceptions.SSLError as exc:
            raise SempSSLError(f"TLS error contacting {url}: {exc}", url=url) from exc
        except requests.exceptions.ConnectTimeout as exc:
            raise SempTimeoutError(f"Connection to {url} timed out", url=url) from exc
        except requests.exceptions.ReadTimeout as exc:
            raise SempTimeoutError(f"Broker did not answer within {self._config.timeout}s: {url}", url=url) from exc
        except requests.exceptions.ConnectionError as exc:
            raise SempConnectionError(f"Cannot reach broker at {url}: {exc}", url=url) from exc

        if response.status_code in (401, 403):
            raise SempAuthError(
                f"Authentication/authorization failed (HTTP {response.status_code}). "
                "Check username, password and management access level.",
                url=url,
                status=response.status_code,
            )

        try:
            body: dict[str, Any] = response.json()
        except ValueError as exc:
            raise SempResponseError(
                f"Non-JSON response (HTTP {response.status_code}) from {url}",
                url=url,
                status=response.status_code,
            ) from exc

        if response.status_code >= 400:
            error = (body.get("meta") or {}).get("error") or {}
            description = error.get("description") or response.reason or "unknown error"
            status_tag = str(error.get("status", ""))
            message = f"HTTP {response.status_code} {status_tag}: {description}".strip()
            if response.status_code in _SKIPPABLE_STATUS:
                raise SempNotAvailableError(
                    message, url=url, status=response.status_code, semp_status=status_tag
                )
            raise SempResponseError(message, url=url, status=response.status_code)
        return body

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def get_collection(self, path: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Fetch every page of a collection, following ``nextPageUri`` cursors."""
        url = f"{self.base_url}/{path}" if path else self.base_url
        query: dict[str, Any] | None = {"count": self._config.page_size, **(params or {})}
        rows: list[dict[str, Any]] = []
        while True:
            body = self._get(url, query)
            data = body.get("data")
            if isinstance(data, list):
                rows.extend(data)
            elif isinstance(data, dict):  # single-object endpoint
                rows.append(data)
            next_uri = ((body.get("meta") or {}).get("paging") or {}).get("nextPageUri")
            if not next_uri:
                return rows
            url, query = next_uri, None  # cursor URI already carries the params

    def get_object(self, path: str) -> dict[str, Any] | None:
        url = f"{self.base_url}/{path}" if path else self.base_url
        data = self._get(url).get("data")
        if data is None or isinstance(data, dict):
            return data
        raise SempResponseError(f"Expected object at {url}, got {type(data).__name__}", url=url)

    def about(self) -> dict[str, Any]:
        """Return ``about/api`` info: ``sempVersion`` and ``platform``."""
        return self.get_object("about/api") or {}

    def verify_connection(self) -> dict[str, Any]:
        """Cheap end-to-end probe used before starting an export."""
        info = self.about()
        log.info(
            "Connected to %s (platform=%s, sempVersion=%s)",
            self.base_url, info.get("platform", "?"), info.get("sempVersion", "?"),
        )
        return info

    # -- write operations (migration engine) ---------------------------- #
    def _request_write(self, method: str, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = self._url(path)
        log.debug("%s %s (%d attrs)", method, url, len(body))
        self._count()
        try:
            response = self._session().request(
                method, url, json=body,
                timeout=(self._cfg.connect_timeout, self._cfg.read_timeout),
            )
        except requests.exceptions.SSLError as exc:
            raise SempConnectionError(
                f"TLS error talking to {url}: {exc}. For self-signed broker "
                "certificates disable certificate verification."
            ) from exc
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            raise SempConnectionError(f"Cannot reach {url}: {exc}") from exc
        if response.status_code == 401:
            raise SempAuthError(f"Authentication failed (HTTP 401) for {url}")
        if response.status_code >= 400:
            raise self._write_error(url, response)
        try:
            return response.json()
        except ValueError:
            return {}

    @staticmethod
    def _write_error(url: str, response: requests.Response) -> SempWriteError:
        try:
            error = (response.json().get("meta") or {}).get("error") or {}
        except ValueError:
            error = {}
        status_tag = str(error.get("status", ""))
        description = str(error.get("description") or response.reason or "unknown error")
        return SempWriteError(
            f"HTTP {response.status_code} {status_tag}: {description}".strip(),
            url=url, status=response.status_code,
            semp_status=status_tag, description=description,
        )

    def post_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        """POST (create) an object; raises :class:`SempWriteError` on rejection."""
        return self._request_write("POST", path, body)

    def patch_json(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        """PATCH (update) an object; raises :class:`SempWriteError` on rejection."""
        return self._request_write("PATCH", path, body)

    def about_user(self) -> dict[str, Any]:
        """``/about/user`` - includes the session's global access level."""
        try:
            return self.get_object("about/user") or {}
        except SempNotAvailableError:
            return {}

    def vpn_names(self) -> list[str]:
        """Names of all message VPNs (lightweight ``select=msgVpnName`` call)."""
        rows = self.get_collection("msgVpns", params={"select": "msgVpnName"})
        return [str(r["msgVpnName"]) for r in rows if "msgVpnName" in r]


def chunked(items: Iterable[Any], size: int) -> Iterable[list[Any]]:
    """Yield lists of at most ``size`` items (used for batched submission)."""
    batch: list[Any] = []
    for item in items:
        batch.append(item)
        if len(batch) >= size:
            yield batch
            batch = []
    if batch:
        yield batch

