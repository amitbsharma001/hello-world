"""Configuration analysis: turn a raw export into an audit-grade report.

Built for sharing with customers: on top of the object-by-object export this
module derives

* an **Inventory** (object counts per type per VPN),
* a **Capacity** view (spool sizing and oversubscription per VPN),
* a **Security Posture** matrix (authentication, plain-text services,
  permissive ACLs per VPN), and
* rule-based **Findings** - concrete, config-verifiable observations with a
  severity, category and recommendation.

Honesty guards, by design:

* Every rule asserts only **facts present in the SEMP v2 configuration**.
  Anything that depends on runtime state (bindings, traffic, redundancy
  health) is out of scope and the report says so.
* Rules that cannot be evaluated because the broker/SEMP version does not
  return the relevant attribute are silently skipped - a missing column never
  becomes a finding.
* Wording avoids verdicts ("unused", "wrong") in favour of verifiable
  statements plus a "verify" style recommendation.

Extending: add a function decorated with ``@rule`` that yields
:class:`Finding` objects; it appears in the workbook automatically.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Iterator, Sequence

import pandas as pd

from .models import SheetData
from .utils.logging import get_logger

log = get_logger("analysis")

SEVERITIES = ("High", "Medium", "Low", "Info")
_SEV_RANK = {s: i for i, s in enumerate(SEVERITIES)}

DISCLAIMER = (
    "Findings are derived solely from configuration returned by the SEMP v2 "
    "Config API. Runtime state (queue bindings, traffic, spool usage, "
    "redundancy health) is not assessed."
)

#: Object types shown in the Inventory, in display order: spec key -> label.
_INVENTORY_TYPES: dict[str, str] = {
    "queues": "Queues",
    "queues.subscriptions": "Queue Subscriptions",
    "topicEndpoints": "Topic Endpoints",
    "bridges": "Bridges",
    "clientUsernames": "Client Usernames",
    "clientProfiles": "Client Profiles",
    "aclProfiles": "ACL Profiles",
    "authorizationGroups": "Authorization Groups",
    "mqttSessions": "MQTT Sessions",
    "rdps": "REST Delivery Points",
    "rdps.restConsumers": "REST Consumers",
    "replayLogs": "Replay Logs",
    "jndi.connectionFactories": "JNDI Connection Factories",
    "caches": "Distributed Caches",
    "queueTemplates": "Queue Templates",
    "topicEndpointTemplates": "Topic Endpoint Templates",
    "dmrBridges": "DMR Bridges",
    "replication.replicatedTopics": "Replicated Topics",
}

_PLAINTEXT_SERVICES: dict[str, str] = {
    "serviceSmfPlainTextEnabled": "SMF",
    "serviceMqttPlainTextEnabled": "MQTT",
    "serviceRestIncomingPlainTextEnabled": "REST",
    "serviceAmqpPlainTextEnabled": "AMQP",
    "serviceWebPlainTextEnabled": "Web Transport",
}


def _val(row: dict[str, Any], column: str, default: Any = None) -> Any:
    value = row.get(column, default)
    if value is None:
        return default
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return default
    return value


@dataclass
class Finding:
    """One config-verifiable observation."""

    rule_id: str
    severity: str          # High | Medium | Low | Info
    category: str          # Security | Resilience | Capacity | Hygiene
    vpn: str
    object_type: str
    obj: str
    finding: str
    recommendation: str


class Frames:
    """Sheet frames indexed by spec key, with defensive accessors."""

    def __init__(self, sheets: Sequence[SheetData]) -> None:
        self._by_key = {s.spec_key: s.frame for s in sheets}

    def frame(self, key: str) -> pd.DataFrame:
        return self._by_key.get(key, pd.DataFrame())

    def rows(self, key: str, *required: str) -> Iterator[dict[str, Any]]:
        """Iterate rows as dicts; empty when any required column is missing."""
        frame = self.frame(key)
        if frame.empty or any(c not in frame.columns for c in required):
            return iter(())
        return iter(frame.to_dict("records"))

    def vpns(self) -> list[str]:
        frame = self.frame("vpns")
        if "VPN" in frame.columns:
            return [str(v) for v in frame["VPN"]]
        return []


RuleFunc = Callable[[Frames], Iterable[Finding]]
RULES: list[RuleFunc] = []


def rule(func: RuleFunc) -> RuleFunc:
    """Register a finding rule; registered rules run in definition order."""
    RULES.append(func)
    return func


# --------------------------------------------------------------------------- #
# Security
# --------------------------------------------------------------------------- #
_AUTH_FLAGS = (
    ("authenticationBasicEnabled", "basic"),
    ("authenticationClientCertEnabled", "client-certificate"),
    ("authenticationOauthEnabled", "OAuth"),
    ("authenticationKerberosEnabled", "Kerberos"),
)


@rule
def sec_001_vpn_authentication(frames: Frames) -> Iterable[Finding]:
    frame = frames.frame("vpns")
    for row in frames.rows("vpns", "VPN"):
        vpn = str(row["VPN"])
        if _val(row, "authenticationBasicEnabled") is True and _val(row, "authenticationBasicType") == "none":
            yield Finding(
                "SEC-001", "High", "Security", vpn, "Message VPN", vpn,
                "Basic authentication type is 'none': clients can connect without credentials.",
                "Set authenticationBasicType to internal/ldap/radius or disable basic auth.",
            )
        present = [c for c, _ in _AUTH_FLAGS if c in frame.columns]
        if len(present) == len(_AUTH_FLAGS) and not any(_val(row, c) is True for c, _ in _AUTH_FLAGS):
            yield Finding(
                "SEC-001", "High", "Security", vpn, "Message VPN", vpn,
                "No authentication scheme (basic, client-certificate, OAuth, Kerberos) is enabled.",
                "Enable at least one authentication scheme for this VPN.",
            )


@rule
def sec_002_default_username_enabled(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("clientUsernames", "VPN", "Client Username"):
        if str(row["Client Username"]) == "default" and _val(row, "enabled") is True:
            yield Finding(
                "SEC-002", "High", "Security", str(row["VPN"]), "Client Username", "default",
                "The built-in 'default' client username is enabled; any client that "
                "presents no/unknown credentials is mapped to it.",
                "Disable the 'default' client username unless anonymous access is intended.",
            )


@rule
def sec_003_plaintext_services(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("vpns", "VPN"):
        enabled = [label for attr, label in _PLAINTEXT_SERVICES.items() if _val(row, attr) is True]
        if enabled:
            yield Finding(
                "SEC-003", "Medium", "Security", str(row["VPN"]), "Message VPN", str(row["VPN"]),
                f"Plain-text (non-TLS) service(s) enabled: {', '.join(enabled)}.",
                "Prefer TLS listeners; disable plain-text services unless required "
                "inside a trusted network segment.",
            )


@rule
def sec_004_permissive_acl_defaults(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("aclProfiles", "VPN", "ACL Profile"):
        publish = _val(row, "publishTopicDefaultAction")
        subscribe = _val(row, "subscribeTopicDefaultAction")
        open_actions = [
            name for name, value in (("publish", publish), ("subscribe", subscribe))
            if value == "allow"
        ]
        if open_actions:
            severity = "Medium" if len(open_actions) == 2 else "Low"
            yield Finding(
                "SEC-004", severity, "Security", str(row["VPN"]), "ACL Profile",
                str(row["ACL Profile"]),
                f"Default action is 'allow' for: {', '.join(open_actions)}. "
                "Clients mapped to this profile are unrestricted for those operations.",
                "Use default 'disallow' with explicit topic exceptions (least privilege).",
            )


@rule
def sec_005_default_profile_mappings(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("clientUsernames", "VPN", "Client Username"):
        mapped = [
            label for column, label in
            (("aclProfileName", "ACL profile 'default'"), ("clientProfileName", "client profile 'default'"))
            if _val(row, column) == "default"
        ]
        if mapped and str(row["Client Username"]) != "default":
            yield Finding(
                "SEC-005", "Low", "Security", str(row["VPN"]), "Client Username",
                str(row["Client Username"]),
                f"Mapped to {' and '.join(mapped)}.",
                "Assign purpose-built profiles so permissions are explicit and auditable.",
            )


@rule
def sec_006_rest_consumer_plaintext(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("rdps.restConsumers", "VPN", "REST Consumer"):
        if _val(row, "tlsEnabled") is False:
            rdp = _val(row, "RDP", "")
            yield Finding(
                "SEC-006", "Medium", "Security", str(row["VPN"]), "REST Consumer",
                f"{rdp}/{row['REST Consumer']}" if rdp else str(row["REST Consumer"]),
                "REST consumer delivers over plain HTTP (tlsEnabled = false).",
                "Enable TLS towards the REST endpoint or confine traffic to a trusted network.",
            )


@rule
def sec_007_bridge_plaintext(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("bridges.remoteMsgVpns", "VPN", "Bridge"):
        if _val(row, "tlsEnabled") is False:
            yield Finding(
                "SEC-007", "Medium", "Security", str(row["VPN"]), "Bridge Remote VPN",
                f"{row['Bridge']} -> {_val(row, 'Remote VPN', '?')}",
                "Bridge connects to the remote VPN without TLS (tlsEnabled = false).",
                "Enable TLS on the bridge remote unless both brokers share a trusted network.",
            )


# --------------------------------------------------------------------------- #
# Resilience
# --------------------------------------------------------------------------- #
@rule
def res_001_dangling_dmq(frames: Frames) -> Iterable[Finding]:
    queues_by_vpn: dict[str, set[str]] = {}
    for row in frames.rows("queues", "VPN", "Queue"):
        queues_by_vpn.setdefault(str(row["VPN"]), set()).add(str(row["Queue"]))
    for row in frames.rows("queues", "VPN", "Queue"):
        dmq = _val(row, "deadMsgQueue")
        vpn = str(row["VPN"])
        if dmq and str(dmq) not in queues_by_vpn.get(vpn, set()):
            yield Finding(
                "RES-001", "Medium", "Resilience", vpn, "Queue", str(row["Queue"]),
                f"Dead message queue '{dmq}' is referenced but no queue of that name "
                "exists in this VPN; discarded messages eligible for the DMQ are lost.",
                f"Create queue '{dmq}' (or point deadMsgQueue at an existing queue).",
            )


@rule
def res_002_unlimited_redelivery(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("queues", "VPN", "Queue"):
        if _val(row, "maxRedeliveryCount") == 0:
            yield Finding(
                "RES-002", "Medium", "Resilience", str(row["VPN"]), "Queue", str(row["Queue"]),
                "maxRedeliveryCount is 0 (unlimited): a poison message can be "
                "redelivered forever and block consumers.",
                "Set a finite redelivery count and route exhausted messages to a DMQ.",
            )


@rule
def res_003_ttl_configured_but_ignored(frames: Frames) -> Iterable[Finding]:
    for key, type_name, id_col in (
        ("queues", "Queue", "Queue"),
        ("topicEndpoints", "Topic Endpoint", "Topic Endpoint"),
    ):
        for row in frames.rows(key, "VPN", id_col):
            max_ttl = _val(row, "maxTtl", 0) or 0
            if _val(row, "respectTtlEnabled") is False and max_ttl > 0:
                yield Finding(
                    "RES-003", "Low", "Resilience", str(row["VPN"]), type_name, str(row[id_col]),
                    f"maxTtl is {max_ttl}s but respectTtlEnabled is false - the TTL is not applied.",
                    "Enable respectTtlEnabled or remove maxTtl to keep the configuration unambiguous.",
                )


@rule
def res_004_no_replay_log(frames: Frames) -> Iterable[Finding]:
    replay_vpns = {str(r["VPN"]) for r in frames.rows("replayLogs", "VPN")}
    for vpn in frames.vpns():
        if vpn not in replay_vpns:
            yield Finding(
                "RES-004", "Info", "Resilience", vpn, "Message VPN", vpn,
                "No replay log is configured; message replay is unavailable in this VPN.",
                "Consider a replay log if consumers may need to re-process past messages.",
            )


@rule
def res_005_traffic_disabled(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("queues", "VPN", "Queue"):
        blocked = [
            direction for column, direction in
            (("ingressEnabled", "ingress"), ("egressEnabled", "egress"))
            if _val(row, column) is False
        ]
        if blocked:
            yield Finding(
                "RES-005", "Medium", "Resilience", str(row["VPN"]), "Queue", str(row["Queue"]),
                f"Queue {' and '.join(blocked)} disabled - messages "
                f"{'cannot enter' if 'ingress' in blocked else 'accumulate and are not delivered'}.",
                "Verify this shutdown state is intentional (e.g. maintenance) and time-boxed.",
            )


# --------------------------------------------------------------------------- #
# Capacity
# --------------------------------------------------------------------------- #
@rule
def cap_001_quota_exceeds_vpn_spool(frames: Frames) -> Iterable[Finding]:
    vpn_spool = {
        str(r["VPN"]): _val(r, "maxMsgSpoolUsage")
        for r in frames.rows("vpns", "VPN")
    }
    for row in frames.rows("queues", "VPN", "Queue"):
        spool = vpn_spool.get(str(row["VPN"]))
        quota = _val(row, "maxMsgSpoolUsage")
        if spool and quota and quota > spool:
            yield Finding(
                "CAP-001", "Medium", "Capacity", str(row["VPN"]), "Queue", str(row["Queue"]),
                f"Queue quota ({quota} MB) exceeds the VPN spool limit ({spool} MB); "
                "the queue can never reach its configured quota.",
                "Align the queue quota with the VPN spool budget.",
            )


@rule
def cap_002_heavy_oversubscription(frames: Frames) -> Iterable[Finding]:
    totals: dict[str, float] = {}
    for row in frames.rows("queues", "VPN", "Queue"):
        quota = _val(row, "maxMsgSpoolUsage")
        if isinstance(quota, (int, float)):
            totals[str(row["VPN"])] = totals.get(str(row["VPN"]), 0.0) + float(quota)
    for row in frames.rows("vpns", "VPN"):
        vpn = str(row["VPN"])
        spool = _val(row, "maxMsgSpoolUsage")
        if spool and totals.get(vpn, 0.0) > 5 * float(spool):
            ratio = totals[vpn] / float(spool)
            yield Finding(
                "CAP-002", "Info", "Capacity", vpn, "Message VPN", vpn,
                f"Sum of queue quotas ({totals[vpn]:.0f} MB) is {ratio:.1f}x the VPN "
                f"spool limit ({spool} MB). Oversubscription is normal practice, but at "
                "this ratio quotas no longer bound worst-case spool demand.",
                "Confirm the oversubscription ratio matches the intended capacity model.",
            )


@rule
def cap_003_guaranteed_messaging_disabled(frames: Frames) -> Iterable[Finding]:
    for row in frames.rows("vpns", "VPN"):
        if _val(row, "maxMsgSpoolUsage") == 0:
            yield Finding(
                "CAP-003", "Medium", "Capacity", str(row["VPN"]), "Message VPN", str(row["VPN"]),
                "VPN maxMsgSpoolUsage is 0: no messages can be spooled - guaranteed "
                "messaging is effectively disabled in this VPN.",
                "Verify intentional; set a spool budget if persistent messaging is required.",
            )


# --------------------------------------------------------------------------- #
# Hygiene
# --------------------------------------------------------------------------- #
@rule
def hyg_001_queue_without_subscriptions(frames: Frames) -> Iterable[Finding]:
    subscribed = {
        (str(r["VPN"]), str(r["Queue"]))
        for r in frames.rows("queues.subscriptions", "VPN", "Queue")
    }
    for row in frames.rows("queues", "VPN", "Queue"):
        key = (str(row["VPN"]), str(row["Queue"]))
        if key not in subscribed:
            yield Finding(
                "HYG-001", "Info", "Hygiene", key[0], "Queue", key[1],
                "No topic subscriptions are configured on this queue.",
                "Fine if producers publish directly to the queue; otherwise add the "
                "intended topic subscriptions.",
            )


@rule
def hyg_002_unreferenced_profiles(frames: Frames) -> Iterable[Finding]:
    used_acl: dict[str, set[str]] = {}
    used_client: dict[str, set[str]] = {}
    for row in frames.rows("clientUsernames", "VPN"):
        vpn = str(row["VPN"])
        if _val(row, "aclProfileName"):
            used_acl.setdefault(vpn, set()).add(str(row["aclProfileName"]))
        if _val(row, "clientProfileName"):
            used_client.setdefault(vpn, set()).add(str(row["clientProfileName"]))

    for key, id_col, used, label in (
        ("aclProfiles", "ACL Profile", used_acl, "ACL profile"),
        ("clientProfiles", "Client Profile", used_client, "client profile"),
    ):
        unreferenced: dict[str, list[str]] = {}
        for row in frames.rows(key, "VPN", id_col):
            vpn, name = str(row["VPN"]), str(row[id_col])
            if name != "default" and name not in used.get(vpn, set()):
                unreferenced.setdefault(vpn, []).append(name)
        for vpn, names in unreferenced.items():
            yield Finding(
                "HYG-002", "Info", "Hygiene", vpn, label.title(), ", ".join(sorted(names)),
                f"{len(names)} {label}(s) not referenced by any client username.",
                "Remove if obsolete, or document why they are kept "
                "(note: authorization groups and MQTT sessions may also reference profiles).",
            )


@rule
def hyg_003_disabled_objects(frames: Frames) -> Iterable[Finding]:
    for key, id_col, label in (
        ("clientUsernames", "Client Username", "client username"),
        ("bridges", "Bridge", "bridge"),
    ):
        disabled: dict[str, list[str]] = {}
        for row in frames.rows(key, "VPN", id_col):
            if _val(row, "enabled") is False:
                disabled.setdefault(str(row["VPN"]), []).append(str(row[id_col]))
        for vpn, names in disabled.items():
            yield Finding(
                "HYG-003", "Info", "Hygiene", vpn, label.title(), ", ".join(sorted(names)),
                f"{len(names)} {label}(s) administratively disabled.",
                "Remove if permanently retired; disabled objects still occupy configuration.",
            )


# --------------------------------------------------------------------------- #
# Report assembly
# --------------------------------------------------------------------------- #
@dataclass
class AnalysisReport:
    """Findings + derived views, ready for the workbook writer."""

    findings: list[Finding]
    findings_frame: pd.DataFrame
    inventory_frame: pd.DataFrame
    capacity_frame: pd.DataFrame
    posture_frame: pd.DataFrame
    vpns: list[str] = field(default_factory=list)
    report_title: str = ""
    prepared_for: str = ""
    prepared_by: str = ""

    @property
    def severity_counts(self) -> dict[str, int]:
        counts = {s: 0 for s in SEVERITIES}
        for finding in self.findings:
            counts[finding.severity] = counts.get(finding.severity, 0) + 1
        return counts

    @property
    def top_findings(self) -> list[Finding]:
        ranked = [f for f in self.findings if f.severity in ("High", "Medium")]
        return ranked[:10]

    @property
    def total_objects(self) -> int:
        if self.inventory_frame.empty or "Total" not in self.inventory_frame.columns:
            return 0
        return int(self.inventory_frame["Total"].sum())


def build_analysis(
    sheets: Sequence[SheetData],
    *,
    report_title: str = "",
    prepared_for: str = "",
    prepared_by: str = "",
) -> AnalysisReport:
    """Run every registered rule and derive the audit views."""
    frames = Frames(sheets)
    vpns = frames.vpns()

    findings: list[Finding] = []
    for rule_func in RULES:
        try:
            findings.extend(rule_func(frames))
        except Exception:  # a broken rule must never sink the export
            log.exception("Rule %s failed; skipped", getattr(rule_func, "__name__", rule_func))
    findings.sort(key=lambda f: (_SEV_RANK.get(f.severity, 99), f.rule_id, f.vpn, f.obj))
    log.info("Analysis: %d findings across %d rules", len(findings), len(RULES))

    findings_frame = pd.DataFrame.from_records(
        [
            {
                "Rule": f.rule_id, "Severity": f.severity, "Category": f.category,
                "VPN": f.vpn, "Object Type": f.object_type, "Object": f.obj,
                "Finding": f.finding, "Recommendation": f.recommendation,
            }
            for f in findings
        ],
        columns=["Rule", "Severity", "Category", "VPN", "Object Type", "Object",
                 "Finding", "Recommendation"],
    )
    return AnalysisReport(
        findings=findings,
        findings_frame=findings_frame,
        inventory_frame=_build_inventory(frames, vpns),
        capacity_frame=_build_capacity(frames, vpns),
        posture_frame=_build_posture(frames, vpns),
        vpns=vpns,
        report_title=report_title,
        prepared_for=prepared_for,
        prepared_by=prepared_by,
    )


def _build_inventory(frames: Frames, vpns: list[str]) -> pd.DataFrame:
    records: list[dict[str, Any]] = []
    for key, label in _INVENTORY_TYPES.items():
        frame = frames.frame(key)
        if frame.empty and key not in frames._by_key:
            continue  # scope not exported
        per_vpn = {vpn: 0 for vpn in vpns}
        if "VPN" in frame.columns:
            for vpn, count in frame["VPN"].value_counts().items():
                if str(vpn) in per_vpn:
                    per_vpn[str(vpn)] = int(count)
        records.append({"Object Type": label, "Total": len(frame), **per_vpn})
    records.sort(key=lambda r: (-int(r["Total"]), str(r["Object Type"])))
    return pd.DataFrame.from_records(records, columns=["Object Type", "Total", *vpns])


def _build_capacity(frames: Frames, vpns: list[str]) -> pd.DataFrame:
    queue_rows = list(frames.rows("queues", "VPN", "Queue"))
    te_frame = frames.frame("topicEndpoints")
    replay_frame = frames.frame("replayLogs")
    records: list[dict[str, Any]] = []
    for row in frames.rows("vpns", "VPN"):
        vpn = str(row["VPN"])
        quotas = [
            (float(q), str(r["Queue"]))
            for r in queue_rows if str(r["VPN"]) == vpn
            for q in [_val(r, "maxMsgSpoolUsage")]
            if isinstance(q, (int, float))
        ]
        spool = _val(row, "maxMsgSpoolUsage")
        total_quota = sum(q for q, _ in quotas)
        largest = max(quotas) if quotas else (0.0, "")
        record: dict[str, Any] = {
            "VPN": vpn,
            "Enabled": _val(row, "enabled", ""),
            "VPN Spool Limit (MB)": spool if spool is not None else "",
            "Queues": sum(1 for r in queue_rows if str(r["VPN"]) == vpn),
            "Sum of Queue Quotas (MB)": int(total_quota),
            "Spool Oversubscription": (
                f"{total_quota / float(spool):.1f}x" if spool else ""
            ),
            "Largest Queue Quota (MB)": int(largest[0]),
            "Largest Queue": largest[1],
            "Topic Endpoints": (
                int((te_frame["VPN"] == vpn).sum()) if "VPN" in te_frame.columns else 0
            ),
            "Replay Logs": (
                int((replay_frame["VPN"] == vpn).sum()) if "VPN" in replay_frame.columns else 0
            ),
            "Max Connections": _val(row, "maxConnectionCount", ""),
        }
        records.append(record)
    return pd.DataFrame.from_records(records)


def _build_posture(frames: Frames, vpns: list[str]) -> pd.DataFrame:
    permissive: dict[str, list[str]] = {}
    for row in frames.rows("aclProfiles", "VPN", "ACL Profile"):
        if _val(row, "publishTopicDefaultAction") == "allow" or \
                _val(row, "subscribeTopicDefaultAction") == "allow":
            permissive.setdefault(str(row["VPN"]), []).append(str(row["ACL Profile"]))
    default_user: dict[str, bool] = {}
    user_counts: dict[str, int] = {}
    for row in frames.rows("clientUsernames", "VPN", "Client Username"):
        vpn = str(row["VPN"])
        user_counts[vpn] = user_counts.get(vpn, 0) + 1
        if str(row["Client Username"]) == "default":
            default_user[vpn] = _val(row, "enabled") is True

    records: list[dict[str, Any]] = []
    for row in frames.rows("vpns", "VPN"):
        vpn = str(row["VPN"])
        basic = _val(row, "authenticationBasicEnabled")
        auth_bits: list[str] = []
        if basic is True:
            auth_bits.append(f"basic ({_val(row, 'authenticationBasicType', '?')})")
        for column, label in _AUTH_FLAGS[1:]:
            if _val(row, column) is True:
                auth_bits.append(label)
        plaintext = [l for a, l in _PLAINTEXT_SERVICES.items() if _val(row, a) is True]
        records.append({
            "VPN": vpn,
            "Enabled": _val(row, "enabled", ""),
            "Authentication": ", ".join(auth_bits) if auth_bits else "(not reported)",
            "Plain-Text Services": ", ".join(plaintext) if plaintext else "none",
            "Permissive ACL Profiles": ", ".join(sorted(permissive.get(vpn, []))) or "none",
            "'default' Username Enabled": default_user.get(vpn, False),
            "Client Usernames": user_counts.get(vpn, 0),
        })
    return pd.DataFrame.from_records(records)
