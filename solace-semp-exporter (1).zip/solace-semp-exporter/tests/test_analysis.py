"""Analysis engine: findings rules, derived views, defensive guards."""

from __future__ import annotations

import pandas as pd

from solace_exporter.analysis import DISCLAIMER, RULES, build_analysis
from solace_exporter.config import ConnectionConfig, ExportConfig
from solace_exporter.exporter import ExportOrchestrator
from solace_exporter.models import SheetData
from solace_exporter.testing import sample_client


def _report():
    connection = ConnectionConfig(host="demo", username="u", password="p")
    result = ExportOrchestrator(sample_client(), connection, ExportConfig(scopes=("all",))).run()
    return build_analysis(result.sheets, prepared_for="ACME", prepared_by="ICC")


def test_expected_rules_fire_on_sample_broker():
    report = _report()
    fired = {(f.rule_id, f.vpn, f.obj) for f in report.findings}
    assert ("SEC-002", "dev", "default") in fired            # default username enabled
    assert ("SEC-003", "prod", "prod") in fired              # plain-text services
    assert ("SEC-004", "dev", "default") in fired            # permissive ACL defaults
    assert ("SEC-007", "prod", "b2b-partner -> partner-vpn") in fired  # bridge w/o TLS
    assert ("RES-001", "prod", "ORDERS.IN") in fired         # dangling DMQ reference
    assert ("RES-002", "prod", "billing/eu") in fired        # unlimited redelivery
    assert ("RES-005", "dev", "SANDBOX.Q1") in fired         # egress disabled
    assert ("CAP-001", "dev", "BULK.LOAD") in fired          # quota > VPN spool
    assert ("RES-004", "dev", "dev") in fired                # no replay log
    assert any(f.rule_id == "RES-003" for f in report.findings)  # TTL ignored (TE)
    # every finding is fully populated
    for finding in report.findings:
        assert finding.severity in ("High", "Medium", "Low", "Info")
        assert finding.finding and finding.recommendation and finding.vpn


def test_findings_sorted_by_severity_and_frame_shape():
    report = _report()
    severities = list(report.findings_frame["Severity"])
    rank = {"High": 0, "Medium": 1, "Low": 2, "Info": 3}
    assert severities == sorted(severities, key=rank.__getitem__)
    assert list(report.findings_frame.columns) == [
        "Rule", "Severity", "Category", "VPN", "Object Type", "Object",
        "Finding", "Recommendation",
    ]
    counts = report.severity_counts
    assert counts["High"] >= 1 and sum(counts.values()) == len(report.findings)
    assert all(f.severity in ("High", "Medium") for f in report.top_findings)


def test_inventory_counts_per_vpn_and_total():
    report = _report()
    inventory = report.inventory_frame
    assert list(inventory.columns) == ["Object Type", "Total", "prod", "dev"]
    queues = inventory[inventory["Object Type"] == "Queues"].iloc[0]
    assert (queues["Total"], queues["prod"], queues["dev"]) == (4, 2, 2)
    assert report.total_objects == int(inventory["Total"].sum())
    # sorted descending by Total
    totals = list(inventory["Total"])
    assert totals == sorted(totals, reverse=True)


def test_capacity_oversubscription_and_largest_queue():
    report = _report()
    dev = report.capacity_frame[report.capacity_frame["VPN"] == "dev"].iloc[0]
    assert dev["VPN Spool Limit (MB)"] == 5000
    assert dev["Sum of Queue Quotas (MB)"] == 8100
    assert dev["Spool Oversubscription"] == "1.6x"
    assert (dev["Largest Queue Quota (MB)"], dev["Largest Queue"]) == (8000, "BULK.LOAD")


def test_security_posture_matrix():
    report = _report()
    posture = {row["VPN"]: row for row in report.posture_frame.to_dict("records")}
    assert posture["prod"]["Authentication"] == "basic (internal)"
    assert "MQTT" in posture["prod"]["Plain-Text Services"]
    assert posture["dev"]["Permissive ACL Profiles"] == "default"
    assert posture["dev"]["'default' Username Enabled"] is True
    assert posture["prod"]["'default' Username Enabled"] is False


def test_rules_never_raise_on_empty_or_partial_export():
    empty = build_analysis([])
    assert empty.findings == [] and empty.inventory_frame.empty

    # a queues sheet missing most attribute columns must not blow up any rule
    frame = pd.DataFrame.from_records([{"VPN": "x", "Queue": "Q"}])
    partial = build_analysis([
        SheetData(name="Queues", frame=frame, spec_key="queues", endpoint="q",
                  id_columns=("VPN", "Queue"), per_vpn=True),
    ])
    assert isinstance(partial.findings, list)
    assert len(RULES) >= 13


def test_disclaimer_scopes_the_report():
    assert "SEMP v2" in DISCLAIMER and "not assessed" in DISCLAIMER
