"""VPN migration: ordering, renaming, exists policy, strip-retry, cascades, CLI."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest
from openpyxl import load_workbook
from typer.testing import CliRunner

from solace_exporter.cli import app
from solace_exporter.config import ConnectionConfig, MigrationConfig
from solace_exporter.exceptions import ConfigError
from solace_exporter.migrate import VpnMigrator, roots_for_scopes
from solace_exporter.testing import FakeSempClient, sample_client


def _migrate(source, target, execute=True, **kwargs):
    migrator = VpnMigrator(
        source, target, source_vpn=kwargs.pop("source_vpn", "prod"),
        target_vpn=kwargs.pop("target_vpn", "prod-copy"),
        source_host="src-host", target_host="tgt-host", **kwargs,
    )
    with ThreadPoolExecutor(max_workers=4) as pool:
        return migrator.run(pool, execute=execute)


# --------------------------------------------------------------------------- #
# Engine
# --------------------------------------------------------------------------- #
def test_dry_run_plans_everything_writes_nothing():
    client = sample_client()
    result = _migrate(client, client, execute=False)
    assert result.dry_run and result.count("planned") == result.total > 30
    assert client.posted == [] and client.patched == []
    assert result.source_sheets  # evidence sheets captured for the report


def test_execute_renames_vpn_and_orders_dependencies():
    client = sample_client()
    result = _migrate(client, client)
    assert result.ok and result.count("created") == result.total

    paths = [p for p, _ in client.posted]
    assert paths[0] == "msgVpns"
    assert client.posted[0][1]["msgVpnName"] == "prod-copy"
    acl = paths.index("msgVpns/prod-copy/aclProfiles")
    users = paths.index("msgVpns/prod-copy/clientUsernames")
    queues = paths.index("msgVpns/prod-copy/queues")
    subs = next(i for i, p in enumerate(paths)
                if p.startswith("msgVpns/prod-copy/queues/") and p.endswith("/subscriptions"))
    rdps = paths.index("msgVpns/prod-copy/restDeliveryPoints")
    assert acl < users < queues < subs < rdps
    # child bodies never carry the VPN name; it lives in the URL
    assert "msgVpnName" not in client.posted[queues][1]
    # secrets warning covers migrated secret-bearing types
    assert any("password" in n.lower() for n in result.secret_notes)


def test_cross_broker_same_vpn_name_reads_source_writes_target_only():
    source = sample_client()
    target = FakeSempClient({"msgVpns": []})
    result = _migrate(source, target, target_vpn="prod")
    assert result.ok
    assert source.posted == []                       # source is never written
    assert target.posted and target.posted[0][1]["msgVpnName"] == "prod"
    assert all(p == "msgVpns" or p.startswith("msgVpns/prod/") or p.startswith("msgVpns/prod ")
               or p.startswith("msgVpns/prod")
               for p, _ in target.posted)


def test_exists_policy_skip_and_update():
    already = (400, "ALREADY_EXISTS", "Queue 'ORDERS.IN' already exists")

    client = sample_client()
    client.post_errors["msgVpns/prod-copy/queues"] = [already]
    result = _migrate(client, client)  # default policy: skip
    skipped = [e for e in result.entries if e.action == "skipped"]
    assert len(skipped) == 1 and "policy: skip" in skipped[0].detail
    assert result.ok

    client = sample_client()
    client.post_errors["msgVpns/prod-copy/queues"] = [already]
    result = _migrate(client, client, exists_policy="update")
    updated = [e for e in result.entries if e.action == "updated"]
    assert len(updated) == 1
    patch_path, patch_body = client.patched[0]
    assert patch_path.startswith("msgVpns/prod-copy/queues/")
    assert "queueName" not in patch_body and "msgVpnName" not in patch_body

    client = sample_client()
    client.post_errors["msgVpns/prod-copy/queues"] = [already]
    result = _migrate(client, client, exists_policy="fail")
    assert not result.ok and result.count("failed") == 1


def test_invalid_parameter_strips_attribute_and_retries():
    client = sample_client()
    client.post_errors["msgVpns/prod-copy/queues"] = [
        (400, "INVALID_PARAMETER", "Unknown attribute 'eventMsgSpoolUsageThreshold'"),
    ]
    result = _migrate(client, client)
    assert result.ok
    entry = next(e for e in result.entries
                 if e.sheet == "Queues" and "stripped" in e.detail)
    assert "eventMsgSpoolUsageThreshold" in entry.detail
    queue_bodies = [b for p, b in client.posted if p == "msgVpns/prod-copy/queues"]
    assert all("eventMsgSpoolUsageThreshold" not in b for b in queue_bodies[:1])


def test_failed_parent_cascades_to_children():
    client = sample_client()
    client.post_errors["msgVpns/prod-copy/queues"] = [
        (400, "NOT_ALLOWED", "queues are not allowed here at all"),  # no attr match
    ]
    result = _migrate(client, client)
    failed = [e for e in result.entries if e.action == "failed"]
    assert len(failed) == 1 and failed[0].sheet == "Queues"
    cascade = [e for e in result.entries
               if e.action == "skipped" and "parent" in e.detail]
    assert cascade and all(e.sheet == "Queue Subscriptions" for e in cascade)
    # the failed queue's subscriptions were never posted
    failed_queue = failed[0].obj
    assert not any(f"/queues/{failed_queue}/" in p for p, _ in client.posted)


def test_vpn_creation_failure_stops_everything():
    client = sample_client()
    client.post_errors["msgVpns"] = [(403, "NOT_AUTHORIZED", "no global write access")]
    result = _migrate(client, client)
    assert result.count("failed") == 1
    assert result.count("skipped") == result.total - 1
    assert all("target VPN was not created" in e.detail
               for e in result.entries if e.action == "skipped")
    assert len(client.posted) == 0


def test_broker_managed_hash_objects_skipped():
    source = FakeSempClient({
        "msgVpns": [{"msgVpnName": "prod", "enabled": True}],
        "msgVpns/prod/queues": [
            {"queueName": "#DEAD_MSG_QUEUE", "egressEnabled": True},
            {"queueName": "#mqtt/internal", "egressEnabled": True},
        ],
        "msgVpns/prod/queues/%23DEAD_MSG_QUEUE/subscriptions": [],
        "msgVpns/prod/queues/%23mqtt%2Finternal/subscriptions": [],
    })
    result = _migrate(source, source, roots=roots_for_scopes(("queues",)))
    by_obj = {e.obj: e for e in result.entries if e.sheet == "Queues"}
    assert by_obj["#DEAD_MSG_QUEUE"].action == "created"      # the one legitimate '#'
    assert by_obj["#mqtt/internal"].action == "skipped"
    assert "broker-managed" in by_obj["#mqtt/internal"].detail


def test_migration_config_validation():
    conn = ConnectionConfig(host="src", username="u", password="p")
    with pytest.raises(ConfigError, match="different target VPN"):
        MigrationConfig(source_vpn="a", target_vpn="a").validate(conn)
    with pytest.raises(ConfigError, match="source VPN"):
        MigrationConfig(target_vpn="b").validate(conn)
    with pytest.raises(ConfigError, match="credentials"):
        MigrationConfig(source_vpn="a", target_vpn="a", target_host="other").validate(conn)
    with pytest.raises(ConfigError, match="skip|update|fail"):
        MigrationConfig(source_vpn="a", target_vpn="b", exists="merge").validate(conn)
    # same name on a *different* broker is fine
    MigrationConfig(source_vpn="a", target_vpn="a", target_host="other",
                    target_password="x").validate(conn)


# --------------------------------------------------------------------------- #
# CLI + report workbook
# --------------------------------------------------------------------------- #
def test_cli_migration_executes_with_yes_and_writes_report(tmp_path: Path, monkeypatch):
    import solace_exporter.cli as cli_mod

    clients: dict[str, FakeSempClient] = {}

    def factory(conn, **_):
        clients.setdefault(conn.host, sample_client() if conn.host == "src" else FakeSempClient({"msgVpns": []}))
        return clients[conn.host]

    monkeypatch.setattr(cli_mod, "SempClient", factory)
    report = tmp_path / "migration.xlsx"
    runner = CliRunner()
    result = runner.invoke(app, [
        "--host", "src", "--username", "u", "--password", "p", "--no-interactive",
        "--migrate", "--migrate-to-host", "tgt", "--migrate-to-password", "tp",
        "--source-vpn", "prod", "--target-vpn", "prod", "--yes",
        "--migrate-report", str(report),
        "--log-file", str(tmp_path / "m.log"), "--cache-dir", str(tmp_path / "c"),
    ])
    assert result.exit_code == 0, result.output
    assert clients["tgt"].posted and clients["src"].posted == []
    workbook = load_workbook(report)
    assert workbook.sheetnames[:2] == ["Summary", "Migration Log"]
    assert "Queues" in workbook.sheetnames          # source evidence sheets included
    log_ws = workbook["Migration Log"]
    actions = {r[2] for r in log_ws.iter_rows(min_row=2, values_only=True)}
    assert actions == {"created"}
    summary_text = " ".join(str(c.value) for row in workbook["Summary"].iter_rows()
                            for c in row if c.value)
    assert "Secrets" in summary_text and "never deletes" in summary_text
    assert "Migration result" in result.output


def test_cli_migration_dry_run_and_missing_yes(tmp_path: Path, monkeypatch):
    import solace_exporter.cli as cli_mod

    fake = sample_client()
    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: fake)
    runner = CliRunner()
    base = [
        "--host", "src", "--username", "u", "--password", "p", "--no-interactive",
        "--migrate", "--source-vpn", "prod", "--target-vpn", "prod-copy",
        "--log-file", str(tmp_path / "m.log"), "--cache-dir", str(tmp_path / "c"),
    ]
    report = tmp_path / "plan.xlsx"
    result = runner.invoke(app, [*base, "--migrate-dry-run", "--migrate-report", str(report)])
    assert result.exit_code == 0, result.output
    assert fake.posted == []
    assert "DRY RUN" in " ".join(
        str(c.value) for row in load_workbook(report)["Summary"].iter_rows()
        for c in row if c.value
    )

    result = runner.invoke(app, base)          # live, non-interactive, no --yes
    assert result.exit_code == 2
    assert "--yes" in result.output
