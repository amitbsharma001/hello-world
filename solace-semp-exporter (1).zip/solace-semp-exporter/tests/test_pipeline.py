"""Registry integrity, config layering, orchestrator + Excel roundtrip, CLI."""

from __future__ import annotations

from pathlib import Path

import pytest
from openpyxl import load_workbook
from typer.testing import CliRunner

from solace_exporter.cli import app
from solace_exporter.config import ConnectionConfig, ExportConfig, build_configs
from solace_exporter.exceptions import ConfigError
from solace_exporter.excel_writer import write_workbook
from solace_exporter.exporter import ExportOrchestrator
from solace_exporter.exporters import all_root_specs, resolve_scopes, scope_table
from solace_exporter.models import ExportMetadata


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #
def test_registry_keys_and_sheets_unique():
    keys: list[str] = []
    sheets: list[str] = []
    for root in all_root_specs():
        for spec in root.walk():
            keys.append(spec.key)
            sheets.append(spec.sheet)
    assert len(keys) == len(set(keys))
    assert len(sheets) == len(set(sheets))
    assert all(len(s) <= 31 for s in sheets)


def test_resolve_scopes_accepts_names_and_menu_numbers():
    by_name = resolve_scopes(("queues",))
    number = next(str(n) for n, name, _ in scope_table() if name == "queues")
    assert resolve_scopes((number,)) == by_name
    with pytest.raises(KeyError):
        resolve_scopes(("nonsense",))


# --------------------------------------------------------------------------- #
# Config layering
# --------------------------------------------------------------------------- #
def test_config_precedence_file_env_cli(tmp_path: Path):
    config = tmp_path / "cfg.toml"
    config.write_text(
        '[connection]\nhost = "file-host"\nport = 8080\nusername = "file-user"\n'
        '[export]\nscopes = ["queues"]\n',
        encoding="utf-8",
    )
    conn, exp = build_configs(
        file_path=config,
        environ={"SOLACE_HOST": "env-host", "SOLACE_PASSWORD": "env-pass"},
        cli={"host": "cli-host", "vpns": ("prod",)},
    )
    assert conn.host == "cli-host"          # CLI beats env beats file
    assert conn.password == "env-pass"      # env beats file default
    assert conn.username == "file-user"     # file beats built-in
    assert exp.scopes == ("queues",)
    assert exp.vpns == ("prod",)


def test_validation_catches_missing_and_unknown():
    with pytest.raises(ConfigError):
        ConnectionConfig(host="h").validate()  # no user/password
    with pytest.raises(ConfigError):
        ExportConfig(scopes=("bogus",)).validate({"all", "queues"})


# --------------------------------------------------------------------------- #
# Orchestrator + Excel writer end-to-end (fake broker)
# --------------------------------------------------------------------------- #
def test_full_export_roundtrip_to_excel(tmp_path: Path, fake_client):
    connection = ConnectionConfig(host="demo", username="u", password="p")
    export = ExportConfig(scopes=("all",))
    result = ExportOrchestrator(fake_client, connection, export).run()

    assert result.vpn_count == 2
    assert result.total_rows > 25
    assert not result.errors
    skipped_sheets = {s.sheet for s in result.skipped}
    assert "Distributed Caches" in skipped_sheets  # graceful capability skip

    target = tmp_path / "out.xlsx"
    metadata = ExportMetadata(host="demo", base_url=connection.base_url,
                              scopes=export.scopes, vpn_count=result.vpn_count)
    write_workbook(target, result.sheets, metadata, result)

    workbook = load_workbook(target)
    assert workbook.sheetnames[0] == "Summary"
    assert workbook["_metadata"].sheet_state == "hidden"

    subs = workbook["Queue Subscriptions"]
    header = [c.value for c in subs[1]]
    assert header[:3] == ["VPN", "Queue", "Subscription Topic"]
    assert subs.freeze_panes == "A2"
    assert subs.tables  # formatted as an Excel table (banding + autofilter)

    bridges = workbook["Bridge Remote VPNs"]
    values = {tuple(r) for r in bridges.iter_rows(min_row=2, max_col=4, values_only=True)}
    assert ("prod", "b2b-partner", "auto", "partner-vpn") in values


def test_vpn_filter_validation(fake_client):
    connection = ConnectionConfig(host="demo", username="u", password="p")
    export = ExportConfig(scopes=("queues",), vpns=("does-not-exist",))
    with pytest.raises(ConfigError, match="not found"):
        ExportOrchestrator(fake_client, connection, export).run()


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def test_cli_list_scopes_and_version():
    runner = CliRunner()
    result = runner.invoke(app, ["--list-scopes"])
    assert result.exit_code == 0
    assert "queues" in result.output and "bridges" in result.output

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "solace-semp-exporter" in result.output


# --------------------------------------------------------------------------- #
# Checkpointed resume through the orchestrator
# --------------------------------------------------------------------------- #
def test_orchestrator_resume_skips_completed_roots(tmp_path: Path):
    from solace_exporter.testing import sample_client
    from solace_exporter.utils.checkpoint import Checkpoint

    connection = ConnectionConfig(host="demo", username="u", password="p")
    export = ExportConfig(scopes=("queues", "acl"))

    def checkpoint(read: bool) -> Checkpoint:
        return Checkpoint(host="demo", port=8080, scopes=export.scopes, vpns=export.vpns,
                          cache_dir=tmp_path, enabled_read=read)

    first_client = sample_client()
    first = ExportOrchestrator(first_client, connection, export, checkpoint=checkpoint(False)).run()
    assert first_client.call_count > 0 and not first.errors

    resumed_client = sample_client()
    resumed = ExportOrchestrator(resumed_client, connection, export, checkpoint=checkpoint(True)).run()
    assert resumed_client.call_count == 0                      # nothing re-fetched
    assert resumed.total_rows == first.total_rows
    assert {s.name for s in resumed.sheets} == {s.name for s in first.sheets}


def test_orchestrator_never_caches_roots_with_skips(tmp_path: Path):
    from solace_exporter.testing import sample_client
    from solace_exporter.utils.checkpoint import Checkpoint

    connection = ConnectionConfig(host="demo", username="u", password="p")
    export = ExportConfig(scopes=("cache",))  # distributedCaches is unmapped -> skipped

    saver = Checkpoint(host="demo", port=8080, scopes=export.scopes, vpns=(),
                       cache_dir=tmp_path, enabled_read=False)
    ExportOrchestrator(sample_client(), connection, export, checkpoint=saver).run()

    reader = Checkpoint(host="demo", port=8080, scopes=export.scopes, vpns=(),
                        cache_dir=tmp_path, enabled_read=True)
    resumed_client = sample_client()
    resumed = ExportOrchestrator(resumed_client, connection, export, checkpoint=reader).run()
    assert resumed_client.call_count > 0                       # re-probed, not loaded
    assert {s.sheet for s in resumed.skipped} >= {"Distributed Caches"}
    assert all(s.name != "Distributed Caches" for s in resumed.sheets)


# --------------------------------------------------------------------------- #
# CLI end-to-end against the fake broker
# --------------------------------------------------------------------------- #
def test_cli_non_interactive_export_produces_workbook(tmp_path: Path, monkeypatch):
    import solace_exporter.cli as cli_mod
    from solace_exporter.testing import sample_client

    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())
    output = tmp_path / "out.xlsx"
    runner = CliRunner()
    result = runner.invoke(app, [
        "--host", "demo", "--username", "u", "--password", "p",
        "--scope", "queues", "--no-interactive",
        "--output", str(output),
        "--log-file", str(tmp_path / "export.log"),
        "--cache-dir", str(tmp_path / "cache"),
    ])
    assert result.exit_code == 0, result.output
    workbook = load_workbook(output)
    assert "Queues" in workbook.sheetnames
    header = [c.value for c in workbook["Queues"][1]]
    assert header[:2] == ["VPN", "Queue"]
    assert "Max Msg Spool Usage" in header      # friendly headers by default


def test_cli_missing_host_non_interactive_is_config_error(tmp_path: Path):
    runner = CliRunner()
    result = runner.invoke(app, [
        "--username", "u", "--password", "p", "--no-interactive",
        "--log-file", str(tmp_path / "export.log"),
    ])
    assert result.exit_code == 2
    assert "host" in result.output.lower()


# --------------------------------------------------------------------------- #
# VPN comparison: config validation + CLI end-to-end
# --------------------------------------------------------------------------- #
def test_compare_config_validation():
    valid = {"all", "queues"}
    with pytest.raises(ConfigError, match="exactly two"):
        ExportConfig(compare=("prod",)).validate(valid)
    with pytest.raises(ConfigError, match="different"):
        ExportConfig(compare=("prod", "prod")).validate(valid)
    with pytest.raises(ConfigError, match="disagree"):
        ExportConfig(compare=("prod", "dr"), vpns=("prod", "other")).validate(valid)
    with pytest.raises(ConfigError, match="requires --compare"):
        ExportConfig(compare_output=Path("x.xlsx")).validate(valid)
    ExportConfig(compare=("prod", "dr")).validate(valid)  # happy path


def test_cli_compare_produces_audit_workbook(tmp_path: Path, monkeypatch):
    import solace_exporter.cli as cli_mod
    from solace_exporter.testing import sample_client

    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())
    output = tmp_path / "full.xlsx"
    compare_out = tmp_path / "compare.xlsx"
    runner = CliRunner()
    result = runner.invoke(app, [
        "--host", "demo", "--username", "u", "--password", "p",
        "--scope", "all", "--no-interactive",
        "--compare", "prod,dev",
        "--compare-output", str(compare_out),
        "--output", str(output),
        "--log-file", str(tmp_path / "export.log"),
        "--cache-dir", str(tmp_path / "cache"),
    ])
    assert result.exit_code == 0, result.output
    assert output.exists() and compare_out.exists()

    workbook = load_workbook(compare_out)
    assert workbook.sheetnames[0] == "Summary"

    # Queue-level: prod's queues are absent in dev and vice versa
    queues = workbook["Queues"]
    rows = {tuple(r[:2]) for r in queues.iter_rows(min_row=2, max_col=2, values_only=True)}
    assert ("Only in prod", "ORDERS.IN") in rows
    assert ("Only in dev", "SANDBOX.Q1") in rows

    # VPN-settings level: attribute diff with side-by-side values
    vpns = workbook["VPNs"]
    header = [c.value for c in vpns[1]]
    assert header[:2] == ["Status", "Attribute"] and {"prod", "dev"} <= set(header)
    attrs = {r[1] for r in vpns.iter_rows(min_row=2, values_only=True)}
    assert "Max Msg Spool Usage" in attrs

    # Broker-level sheets never leak into a VPN comparison
    assert "Virtual Hostnames" not in workbook.sheetnames
    assert "Broker" not in workbook.sheetnames

    # console summary rendered
    assert "VPN comparison prod vs dev" in result.output


def test_cli_compare_rejects_unknown_vpn(tmp_path: Path, monkeypatch):
    import solace_exporter.cli as cli_mod
    from solace_exporter.testing import sample_client

    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())
    runner = CliRunner()
    result = runner.invoke(app, [
        "--host", "demo", "--username", "u", "--password", "p",
        "--no-interactive", "--compare", "prod,ghost",
        "--log-file", str(tmp_path / "export.log"),
        "--cache-dir", str(tmp_path / "cache"),
    ])
    assert result.exit_code == 2
    assert "ghost" in result.output


def test_cli_analysis_default_on_and_opt_out(tmp_path: Path, monkeypatch):
    import solace_exporter.cli as cli_mod
    from solace_exporter.testing import sample_client

    monkeypatch.setattr(cli_mod, "SempClient", lambda conn, **_: sample_client())
    runner = CliRunner()

    with_analysis = tmp_path / "audit.xlsx"
    result = runner.invoke(app, [
        "--host", "demo", "--username", "u", "--password", "p",
        "--scope", "all", "--no-interactive",
        "--prepared-for", "ACME Corp",
        "--output", str(with_analysis),
        "--log-file", str(tmp_path / "a.log"), "--cache-dir", str(tmp_path / "c1"),
    ])
    assert result.exit_code == 0, result.output
    names = load_workbook(with_analysis).sheetnames
    assert names[0] == "Overview" and "Findings" in names
    assert "Configuration review findings" in result.output
    assert "High" in result.output

    plain = tmp_path / "plain.xlsx"
    result = runner.invoke(app, [
        "--host", "demo", "--username", "u", "--password", "p",
        "--scope", "queues", "--no-interactive", "--no-analysis",
        "--output", str(plain),
        "--log-file", str(tmp_path / "b.log"), "--cache-dir", str(tmp_path / "c2"),
    ])
    assert result.exit_code == 0, result.output
    assert "Overview" not in load_workbook(plain).sheetnames
